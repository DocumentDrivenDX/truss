CREATE OR REPLACE FUNCTION truss.apply_group(original_input bytea, original_documents bytea, original_request bytea, expected_release text, expected_digest text)
 RETURNS bytea
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'pg_temp'
 SET row_security TO 'off'
 SET "TimeZone" TO 'UTC'
 SET bytea_output TO 'hex'
AS $function$
DECLARE opened jsonb;attempt_id uuid;operation_index int:=0;operation_count int;result jsonb;
 native_state text;failure_code text;unavailable_reason text;parsed_input jsonb;
BEGIN
 opened:=convert_from(truss.object_group_begin(original_input,original_documents,original_request,expected_release,expected_digest),'UTF8')::jsonb;
 IF opened->>'outcome'<>'execute' THEN RETURN convert_to(opened::text,'UTF8');END IF;
 attempt_id:=(opened->>'attemptId')::uuid;
 parsed_input:=convert_from(original_input,'UTF8')::jsonb;
 operation_count:=jsonb_array_length(parsed_input->'operations');
 FOR step_index IN 0..operation_count-1 LOOP
  operation_index:=step_index;
  PERFORM truss.runtime_owned_group_step_in_input(attempt_id,operation_index,convert_to('[]','UTF8'),original_input,parsed_input);
 END LOOP;
 operation_index:=operation_count-1;
 result:=convert_from(truss.object_group_finish(attempt_id),'UTF8')::jsonb;
 -- Internal import provenance attaches to the same completed attempt. This field
 -- is outside the public semantic result and does not alter receipt bytes.
 RETURN convert_to((result||jsonb_build_object('attemptId',attempt_id::text))::text,'UTF8');
EXCEPTION WHEN SQLSTATE '22023' OR SQLSTATE '23505' OR SQLSTATE 'P1001' OR SQLSTATE 'P1003'
 OR SQLSTATE 'P1004' OR SQLSTATE 'P1005' OR SQLSTATE '42501' OR SQLSTATE '0A000'
 OR SQLSTATE '54000' OR SQLSTATE '55P03' THEN
 GET STACKED DIAGNOSTICS native_state=RETURNED_SQLSTATE;
 -- This exception block has rolled back admission, every step and finalization.
 -- Cancellation, deadlock and serialization errors propagate to host settlement.
 unavailable_reason:=CASE native_state WHEN '0A000' THEN 'profile' WHEN '54000' THEN 'resource' WHEN '55P03' THEN 'observation' END;
 IF unavailable_reason IS NOT NULL THEN
  RETURN convert_to(jsonb_build_object('outcome','unavailable','reason',unavailable_reason)::text,'UTF8');END IF;
 failure_code:=CASE native_state WHEN '22023' THEN 'invalid_input' WHEN '23505' THEN 'key_conflict'
  WHEN 'P1001' THEN 'request_conflict' WHEN 'P1003' THEN 'expected_version' WHEN 'P1004' THEN 'not_found'
  WHEN 'P1005' THEN 'dependencies' WHEN '42501' THEN 'unauthorized_person' END;
 RETURN convert_to(jsonb_build_object('outcome','failed','code',failure_code,'operationIndex',operation_index::text,'nativeState',native_state)::text,'UTF8');
END;
$function$
