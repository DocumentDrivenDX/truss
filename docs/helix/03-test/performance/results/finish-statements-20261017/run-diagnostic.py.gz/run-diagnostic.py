"""Diagnostically modified finish tracking; original workload/deadlines, no release qualification."""
import json
import pathlib
import subprocess
import tempfile
import unittest
import psycopg
from truss import LocalPostgres
from test_group_capacity_native import GroupCapacityTests

root=pathlib.Path('/private/tmp/truss-finish-statements-20261017')
module_root=pathlib.Path('/private/tmp/truss-pg18-stock-profiler-linked-20261017')
binpath=pathlib.Path('/private/tmp/truss-practical-performance-env/lib/python3.11/site-packages/pgserver/pginstall/bin')
original_consumer=GroupCapacityTests.consumer
original_ready=GroupCapacityTests.ready
original_capture=GroupCapacityTests.capture_statistics

@classmethod
def setup_class(cls):
    cls.root=pathlib.Path(tempfile.mkdtemp(prefix='truss-stock-statement-diagnostic-'))
    cls.runtime=LocalPostgres(cls.root/'data')
    cls.addClassCleanup(cls.cleanup)
    subprocess.run([str(binpath/'initdb'),'--pgdata',str(cls.root/'data'),
                    '--auth=trust','--auth-local=trust','--encoding=utf8','-U','postgres'],check=True)
    with (cls.root/'data/postgresql.conf').open('a') as config:
        config.write("\nshared_preload_libraries='"+str(module_root/'pg_stat_statements')+"'\n")
        config.write("extension_control_path='"+str(module_root)+":$system'\n")
        config.write("compute_query_id=on\npg_stat_statements.track=none\n")
        config.write("pg_stat_statements.track_planning=off\npg_stat_statements.save=off\n")
    cls.runtime.__enter__();cls.info=cls.runtime.info
    with psycopg.connect(cls.info.connection_uri,autocommit=True) as admin:
        admin.execute('CREATE EXTENSION pg_stat_statements')
        print('Stock profiler settings',admin.execute("SELECT current_setting('compute_query_id'),current_setting('pg_stat_statements.track'),current_setting('pg_stat_statements.track_planning')").fetchone(),flush=True)

def ready(self,*args,**kwargs):
    handles=original_ready(self,*args,**kwargs)
    self.diagnostic_tracking=handles[0].execute('SHOW pg_stat_statements.track').fetchone()[0]
    assert self.diagnostic_tracking=='none', self.diagnostic_tracking
    owner=self.admin.execute("SELECT r.rolname FROM truss.catalog_runtime_installation i JOIN pg_catalog.pg_roles r ON r.oid=i.owner_oid WHERE i.singleton").fetchone()[0]
    # Fixture-only SET privilege, never granted to the consumer. Owner/grants on
    # the production function are preserved. No source/inventory guard is relaxed.
    self.admin.execute(psycopg.sql.SQL('GRANT SET ON PARAMETER pg_stat_statements.track TO {}').format(psycopg.sql.Identifier(owner)))
    before=self.admin.execute("SELECT pg_get_functiondef('truss.apply_group(bytea,bytea,bytea,text,text)'::regprocedure)").fetchone()[0]
    marker=" result:=convert_from(truss.object_group_finish(attempt_id),'UTF8')::jsonb;"
    assert before.count(marker)==1
    after=before.replace(marker," PERFORM pg_catalog.set_config('pg_stat_statements.track','all',true);\n"+marker+"\n PERFORM pg_catalog.set_config('pg_stat_statements.track','none',true);")
    (root/'original-apply-group.sql').write_text(before)
    (root/'diagnostic-apply-group.sql').write_text(after)
    import difflib
    (root/'instrumentation.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original',tofile='diagnostic')))
    attributes="SELECT proowner,proacl,proconfig,prosecdef,provolatile,proparallel FROM pg_proc WHERE oid='truss.apply_group(bytea,bytea,bytea,text,text)'::regprocedure"
    identity=self.admin.execute(attributes).fetchone()
    self.admin.execute(after)
    assert self.admin.execute(attributes).fetchone()==identity
    self.admin.execute('SELECT pg_stat_statements_reset()')
    return handles

def capture(self,connection,host,phase):
    original_capture(self,connection,host,phase)
    if phase!='create':return
    try:
        cursor=self.admin.execute('SELECT * FROM pg_stat_statements ORDER BY total_exec_time DESC')
        columns=[column.name for column in cursor.description]
        statements=[dict(zip(columns,row)) for row in cursor.fetchall()]
        cursor=self.admin.execute('SELECT * FROM pg_stat_statements_info')
        info=dict(zip([column.name for column in cursor.description],cursor.fetchone()))
        report={'scope':'Diagnostically modified finish phase of original CREATE apply, before assertion; perturbed and nonexclusive; incomplete/cancelled nested statements may be absent, not zero cost',
                'settings':{'compute_query_id':'on','consumerTrack':self.diagnostic_tracking,'finishTrack':'all','fixtureSetGrant':'excluded Truss owner only','track_planning':'off'},
                'phase':phase,'backendPid':connection.info.backend_pid,'info':info,'statements':statements}
        (root/'create-statements.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
        print('Captured normalized statement aggregates',len(statements),flush=True)
    except Exception as error:
        print('Stock statement capture unavailable:',type(error).__name__,str(error),flush=True)

GroupCapacityTests.setUpClass=setup_class
GroupCapacityTests.ready=ready
GroupCapacityTests.capture_statistics=capture
suite=unittest.TestSuite([GroupCapacityTests('test_1024_real_creates_updates_replay_and_ordered_public_readback')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
