"""Original unmodified capacity test, counters off, no source changes."""
import json,os,time,unittest
from pathlib import Path
from test_group_capacity_native import GroupCapacityTests
assert not os.environ.get('TRUSS_CAPACITY_FUNCTION_STATS')
start=time.monotonic()
suite=unittest.TestSuite([GroupCapacityTests('test_1024_real_creates_updates_replay_and_ordered_public_readback')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
Path('/private/tmp/truss-finish-statements-20261017/baseline-result.json').write_text(json.dumps({'scope':'original unmodified public1024 capacity test; stock runtime fixture; no profiler preload/source modification/deadline change','seconds':time.monotonic()-start,'tests':result.testsRun,'success':result.wasSuccessful()})+'\n')
raise SystemExit(0 if result.wasSuccessful() else 1)
