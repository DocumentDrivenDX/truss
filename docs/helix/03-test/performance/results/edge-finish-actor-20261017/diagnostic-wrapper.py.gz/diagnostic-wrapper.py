import sys
from pathlib import Path
p=Path('/private/tmp/truss-main-integration-20261010/scripts/benchmark-public-workflows.py')
__file__=str(p)
exec(compile(Path('/private/tmp/truss-load-scaling-20261017/diagnostic-source.py').read_text(),str(p),'exec'))
