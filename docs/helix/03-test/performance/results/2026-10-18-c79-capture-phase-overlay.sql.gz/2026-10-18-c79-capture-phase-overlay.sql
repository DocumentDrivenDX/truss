CREATE OR REPLACE FUNCTION truss.runtime_owned_capture_application(selected_attempt uuid,application_prepared jsonb) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$
DECLARE input_operations jsonb;
 attempt truss.runtime_object_attempt%ROWTYPE;input jsonb;observed jsonb;locked jsonb;
 inventory jsonb;entry jsonb;expected_operation jsonb;actual_operation jsonb;owner record;selected_type int;relation truss.rel_def%ROWTYPE;endpoint_owner record;retained_bytes bigint:=0;current_actor oid;
 original_projection_problem boolean;compact_updates boolean;application_operations jsonb;
BEGIN
 RAISE NOTICE 'capture_phase entry %',clock_timestamp();
 SELECT * INTO STRICT attempt FROM truss.runtime_object_attempt WHERE id=selected_attempt FOR UPDATE NOWAIT;
 input:=convert_from(attempt.input_bytes,'UTF8')::jsonb;
 input_operations:=input->'operations';
 current_actor:=truss.runtime_person(false);
 IF attempt.writer_xid IS DISTINCT FROM pg_current_xact_id()
  OR attempt.actor_oid IS DISTINCT FROM current_actor OR attempt.complete
  OR attempt.next_index<>0 OR attempt.results<>'[]'::jsonb OR attempt.aliases<>'[]'::jsonb
  OR attempt.context->'mutationProfile' IS DISTINCT FROM input->'mutationProfile'
  OR input->'mutationProfile' IS DISTINCT FROM truss.runtime_owned_profile()
  OR EXISTS(SELECT 1 FROM truss.runtime_owned_operation WHERE attempt_id=selected_attempt) THEN
  RAISE EXCEPTION 'original unused owned attempt required' USING ERRCODE='55000';END IF;
 observed:=truss.runtime_owned_input_scope(input);
 -- All component objects and relationships can participate in reparent/cascade;
 -- outside independent endpoints are read witnesses only.
 FOR owner IN SELECT document_id,module_id FROM (SELECT DISTINCT document_id,module_id FROM (
  SELECT value->>'document_id' document_id,value->>'module' module_id FROM jsonb_each(observed->'types')
  UNION ALL SELECT value->>'document_id',value->>'module' FROM jsonb_each(observed->'relationships')
 ) owners) distinct_owners ORDER BY document_id COLLATE "C",module_id COLLATE "C" LOOP
  PERFORM truss.runtime_module_writer_qualified(owner.document_id,owner.module_id,current_actor);
 END LOOP;
 FOR owner IN SELECT document_id,module_id FROM (SELECT DISTINCT value->'definition'->>'document_id' document_id,
  value->'definition'->>'module' module_id FROM jsonb_each(observed->'boundary')) distinct_owners
  ORDER BY document_id COLLATE "C",module_id COLLATE "C" LOOP
  IF NOT truss.runtime_can_read_qualified(owner.document_id,owner.module_id,current_actor) THEN
   RAISE EXCEPTION 'current outside endpoint reader required' USING ERRCODE='42501';END IF;
 END LOOP;
 -- Implicit descendant values and zero-edge multiplicity checks require the
 -- same original readers as explicit operations, before graph exclusion.
 FOR selected_type IN SELECT type_id FROM (
  SELECT DISTINCT (value->>'type_id')::int type_id FROM jsonb_each(observed->'types')
  -- Stored update/delete targets are already in observed.types; alias targets
  -- come from the CREATE pins below. Original reference admission remains in
  -- input_scope and the ordered planner, so this type-set pass adds no new type.
  -- This is a type set, not operation admission. Resolve each exact CREATE pin
  -- once using its first original operation; all per-operation admission,
  -- execution and settlement checks remain on their original paths.
  UNION SELECT (truss.runtime_owned_operation_type_qualified(value,input_operations,(ordinal-1)::int,current_actor)).type_id
   FROM (SELECT DISTINCT ON ((value->>'typeDefinitionPin') COLLATE "C") value,ordinal
    FROM jsonb_array_elements(input_operations) WITH ORDINALITY o(value,ordinal)
    WHERE value->>'operation'='create_object'
    ORDER BY (value->>'typeDefinitionPin') COLLATE "C",ordinal) creations
 ) affected_types ORDER BY type_id LOOP
  IF truss.runtime_object_values_readable_qualified(selected_type,current_actor) IS NOT TRUE THEN
   RAISE EXCEPTION 'complete affected property and item readers required' USING ERRCODE='42501';END IF;
  FOR relation IN WITH selected_relations AS MATERIALIZED (
   SELECT DISTINCT rel_type_id FROM truss.rel_endpoint WHERE source_type=selected_type OR target_type=selected_type)
   SELECT r.* FROM selected_relations s JOIN truss.rel_def r USING(rel_type_id)
   WHERE r.retired_rev IS NULL ORDER BY r.rel_type_id LOOP
   IF NOT truss.runtime_can_read_qualified(relation.document_id,relation.module,current_actor) THEN
    RAISE EXCEPTION 'counted relationship reader required' USING ERRCODE='42501';END IF;
   FOR endpoint_owner IN SELECT DISTINCT t.document_id,t.module FROM truss.rel_endpoint e
    JOIN truss.type_def t ON t.type_id IN(e.source_type,e.target_type) WHERE e.rel_type_id=relation.rel_type_id LOOP
    IF NOT truss.runtime_can_read_qualified(endpoint_owner.document_id,endpoint_owner.module,current_actor) THEN
     RAISE EXCEPTION 'counted relationship endpoint reader required' USING ERRCODE='42501';END IF;
   END LOOP;
  END LOOP;
 END LOOP;
 -- Every graph writer joins this same exclusion in object/edge order. NOWAIT
 -- gives one refusal; it does not hide a retry loop in the embedded library.
 -- Join the same gate as every native row writer. SHARE ROW EXCLUSIVE table
 -- locks conflict with routine autovacuum and caused spurious observation refusals.
 IF NOT pg_try_advisory_xact_lock(1953658227,1735549296) THEN
  RAISE EXCEPTION 'graph writer in flight' USING ERRCODE='55P03';END IF;
 LOCK TABLE truss.object IN ROW EXCLUSIVE MODE NOWAIT;
 LOCK TABLE truss.edge IN ROW EXCLUSIVE MODE NOWAIT;
 locked:=truss.runtime_owned_input_scope(input);
 IF locked IS DISTINCT FROM observed THEN
  RAISE EXCEPTION 'graph changed before write exclusion' USING ERRCODE='55P03';END IF;
 RAISE NOTICE 'capture_phase pre_prepare %',clock_timestamp();
 inventory:=truss.runtime_owned_prepare_application(input,locked,application_prepared);
 RAISE NOTICE 'capture_phase post_prepare %',clock_timestamp();
 PERFORM truss.runtime_owned_key_preflight(inventory);
 RAISE NOTICE 'capture_phase post_key_preflight %',clock_timestamp();
 -- The shared original scope owns one before snapshot. Trusted independent
 -- updates need only scalar plan custody and their exact mapped patch after
 -- preflight; the producer binds actual rows and emits the full transition.
 compact_updates:=application_prepared IS NOT NULL
  AND locked->'independentEndpointScope'='true'::jsonb
  AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(input_operations) o
   WHERE o.value->>'operation' IS DISTINCT FROM 'update_object'
    OR o.value->'target'->>'state' IS DISTINCT FROM 'stored' OR o.value ? 'ownershipChange')
  AND (SELECT count(DISTINCT value->>'primary') FROM jsonb_array_elements(inventory->'operations'))=jsonb_array_length(input_operations)
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(locked->'nodes') n
   WHERE n.value->'root_id' IS DISTINCT FROM 'null'::jsonb OR n.value->'root_type' IS DISTINCT FROM 'null'::jsonb
    OR n.value->'rev' IS DISTINCT FROM inventory->'catalogRevision');
 application_operations:=application_prepared->'operations';
 -- Retain all immutable plans with one INSERT, preserving exact row images.
 WITH selected_plans AS (
  SELECT CASE WHEN compact_updates THEN v.value||jsonb_build_object(
   'compactProfile','truss-application-value-plan/0.1',
   'applicationPatch',application_operations->(v.value->>'operationIndex')::int,
   'desiredImageSha256',encode(sha256(convert_to(((v.value->'afterNodes'->(v.value->>'primary')->'image')-ARRAY['created_at','updated_at']||
    jsonb_build_object('id',(v.value->'afterNodes'->(v.value->>'primary')->'identity'->>'id')::bigint,
     'root_id',NULL,'root_type',NULL))::text,'UTF8')),'hex'),
   'beforeNodes',(SELECT jsonb_object_agg(n.key,jsonb_set(n.value,'{image}',(n.value->'image')-ARRAY['props','retained'])) FROM jsonb_each(v.value->'beforeNodes') n),
   'afterNodes',(SELECT jsonb_object_agg(n.key,jsonb_set(n.value,'{image}',(n.value->'image')-ARRAY['props','retained'])) FROM jsonb_each(v.value->'afterNodes') n))
   ELSE v.value END value
  FROM jsonb_array_elements(inventory->'operations') v),
 plans AS (
  SELECT value||jsonb_build_object('actorName',session_user::text,'mutationProfile',input->'mutationProfile',
   'catalogRevision',inventory->'catalogRevision')||CASE WHEN value->>'operationIndex'='0'
    THEN jsonb_build_object('initialScope',inventory->'initialScope') ELSE '{}'::jsonb END plan
  FROM selected_plans)
 SELECT sum(octet_length(convert_to(plan::text,'UTF8'))),
  jsonb_agg(jsonb_build_object('attempt_id',attempt.id,'operation_index',(plan->>'operationIndex')::int,
   'writer_xid',attempt.writer_xid::text,'plan',plan,'result',NULL) ORDER BY (plan->>'operationIndex')::int)
 INTO retained_bytes,expected_operation FROM plans;
 RAISE NOTICE 'capture_phase post_plan_serialization %',clock_timestamp();
 IF retained_bytes>33554432 THEN RAISE EXCEPTION 'bounded retained whole group inventory required' USING ERRCODE='54000';END IF;
 WITH expected_rows AS MATERIALIZED (
  SELECT r.* FROM jsonb_populate_recordset(NULL::truss.runtime_owned_operation,expected_operation) r),
 inserted AS (
  INSERT INTO truss.runtime_owned_operation(attempt_id,operation_index,writer_xid,plan)
  SELECT r.attempt_id,r.operation_index,r.writer_xid,r.plan FROM expected_rows r RETURNING *)
 SELECT coalesce(bool_or(i IS DISTINCT FROM e),false) INTO original_projection_problem
 FROM expected_rows e FULL JOIN inserted i ON i.operation_index=e.operation_index;
 RAISE NOTICE 'capture_phase post_insert_proof %',clock_timestamp();
 IF original_projection_problem THEN RAISE EXCEPTION 'exact prepared operation insert required' USING ERRCODE='55000';END IF;
 WITH expected_rows AS MATERIALIZED (
  SELECT r.* FROM jsonb_populate_recordset(NULL::truss.runtime_owned_operation,expected_operation) r),
 actual_rows AS MATERIALIZED (SELECT * FROM truss.runtime_owned_operation WHERE attempt_id=attempt.id)
 SELECT coalesce(bool_or(i IS DISTINCT FROM e),false) INTO original_projection_problem
 FROM expected_rows e FULL JOIN actual_rows i ON i.operation_index=e.operation_index;
 RAISE NOTICE 'capture_phase post_retained_census %',clock_timestamp();
 IF original_projection_problem THEN RAISE EXCEPTION 'exact retained prepared operation inventory required' USING ERRCODE='55000';END IF;
END;
$$;
