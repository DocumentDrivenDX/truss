import json, os, time
from pathlib import Path
import psycopg
from truss import LocalPostgres, Ok, CatalogRuntimeConfiguration, CatalogDocument, adopt_psycopg_host, create_reference_assembly
from truss.contracts import MapValue, TextValue, TypedIdentity
from truss.catalog_view import CatalogViewAvailable
from truss.groups import AuthoredValue, GroupSuccess, RequestNone, StoredObjectReference, UpdateObject
from performance_workloads import workloads, schema as workload_schema

def ok(value):
    if not isinstance(value, Ok):
        raise RuntimeError(f'expected Ok, got {value!r}')
    return value.value

root = Path('/private/tmp/truss-c78-capture-data')
run = {'pgdata':str(root),'diagnosticOnly':True,'authority':'Temporary registrar used only for catalog ref acquisition, revoked before timing','schemaDimensions':{'nodes':10000,'edges':20000,'fieldsPerType':128,'targetOperations':1024},'sourcePackage':'/private/tmp/truss-c77-final-package'}
phases=[]
with LocalPostgres(root) as runtime:
    admin = psycopg.connect(runtime.info.connection_uri, autocommit=True, options='-c statement_timeout=10000')
    counts = admin.execute("""SELECT (SELECT count(*) FROM truss.object), (SELECT count(*) FROM truss.edge),
      (SELECT count(*) FROM truss.journal), (SELECT count(*) FROM truss.runtime_object_transition)""").fetchone()
    run['baseline_counts']=counts
    owned=Path('/private/tmp/truss-c77-final-package/truss/_catalog_runtime/owned.sql').read_text()
    start=owned.index('CREATE FUNCTION truss.runtime_owned_update_batch(')
    end=owned.index('$$;',start)+3
    canonical=owned[start:end].replace('CREATE FUNCTION truss.runtime_owned_update_batch(','CREATE OR REPLACE FUNCTION truss.runtime_owned_update_batch(',1)
    admin.execute(canonical)
    admin.execute(Path('/private/tmp/truss-c78-capture-phases.sql').read_text())
    registrar=admin.execute('SELECT rolname FROM truss.catalog_runtime_installation i JOIN pg_roles r ON r.oid=i.registrar_oid WHERE i.singleton').fetchone()[0]
    admin.execute(psycopg.sql.SQL('GRANT {} TO consumer WITH SET FALSE').format(psycopg.sql.Identifier(registrar)))
    params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri); params['user']='consumer'
    connection=psycopg.connect(**params, autocommit=True, options='-c statement_timeout=10000')
    connection.execute('BEGIN')
    host=adopt_psycopg_host(connection,statement_timeout_ms=10000,operation_timeout_ms=30000)
    tx=ok(host.adopt_transaction())
    assembly=ok(create_reference_assembly(CatalogRuntimeConfiguration(),host))
    raw_view=assembly.catalog_view_in_transaction(tx,assembly.catalog_view_request())
    if not isinstance(raw_view,Ok): raise RuntimeError(f'view_error={raw_view!r} native={host._custody.last_attempt.error!r}')
    view_result=raw_view.value
    if not isinstance(view_result,CatalogViewAvailable):
        raise RuntimeError(f'catalog view unavailable: {view_result!r}')
    view=view_result.view
    document_id='perf-wide'; module_id='m'
    type_refs={d.reference.authored_identity:d.reference for d in view.definitions if d.reference.kind=='type' and d.reference.owner.document_id==document_id}
    by_type={str(ref.type_id):ref for ref in type_refs.values()}
    rows=admin.execute("SELECT id,type_id FROM truss.object ORDER BY id LIMIT 1024").fetchall()
    if len(rows)!=1024: raise RuntimeError(f'expected 1024 targets, got {len(rows)}')
    operations=[]
    for index,(object_id,type_id) in enumerate(rows):
        ref=by_type[str(type_id)]
        identity=TypedIdentity(id=str(object_id),type_id=str(ref.type_id),definition_pin=ref.definition_pin,owner=ref.owner)
        operations.append(UpdateObject(target=StoredObjectReference(identity=identity),
          set=(AuthoredValue(name='p1',value=TextValue(kind='string',text=f'capture-tail-{index}')),),unset=()))
    workload=workloads()['wide']
    document=CatalogDocument(document_id,'performance-v1',json.dumps(workload_schema(workload),separators=(',',':')).encode())
    host.detach();connection.rollback();connection.close()
    admin.execute(psycopg.sql.SQL('REVOKE {} FROM consumer').format(psycopg.sql.Identifier(registrar)))
    connection=psycopg.connect(**params,autocommit=True,options='-c statement_timeout=10000')
    connection.add_notice_handler(lambda notice:phases.append(notice.message_primary))
    connection.execute('BEGIN')
    host=adopt_psycopg_host(connection,statement_timeout_ms=10000,operation_timeout_ms=30000)
    tx=ok(host.adopt_transaction())
    assembly=ok(create_reference_assembly(CatalogRuntimeConfiguration(),host))
    host.detach();connection.rollback();connection.close()
    # Restore exact noncapture C77 bodies; the retained fixture contained NOTICE-only overlays.
    sources=[Path('/private/tmp/truss-c77-final-package/truss/_catalog_runtime/owned.sql').read_text(),Path('/private/tmp/truss-c77-final-package/truss/_catalog_runtime/operations.sql').read_text()]
    for name in ('runtime_owned_prepare_application','object_group_begin_prepared','apply_group_prepared'):
        candidates=[s for s in sources if 'CREATE FUNCTION truss.'+name+'(' in s]
        s=candidates[0];a=s.index('CREATE FUNCTION truss.'+name+'(');b=s.index('$$;',a)+3
        admin.execute(s[a:b].replace('CREATE FUNCTION','CREATE OR REPLACE FUNCTION',1))
    baseline=Path('/private/tmp/truss-c78-capture-phases.sql').read_text()
    run['attempts']=[]
    for label,select_mat,plans_mat in [('baseline-before',False,False),('selected-materialized',True,False),('plans-materialized',False,True),('both-materialized',True,True),('baseline-after',False,False)]:
        overlay=baseline
        if select_mat:overlay=overlay.replace('WITH selected_plans AS (','WITH selected_plans AS MATERIALIZED (',1)
        if plans_mat:overlay=overlay.replace(' plans AS (',' plans AS MATERIALIZED (',1)
        admin.execute(overlay)
        c=psycopg.connect(**params,autocommit=True,options='-c statement_timeout=10000')
        notices=[];c.add_notice_handler(lambda notice:notices.append(notice.message_primary))
        c.execute('BEGIN')
        h=adopt_psycopg_host(c,statement_timeout_ms=10000,operation_timeout_ms=30000)
        t=ok(h.adopt_transaction());a=ok(create_reference_assembly(CatalogRuntimeConfiguration(),h))
        ctx=ok(a.group_context_in_transaction(t))
        started=time.perf_counter()
        result=a.apply_in_transaction(t,ctx.input(tuple(operations),MapValue(entries=())),RequestNone(),documents=(document,),bun_executable='bun')
        item={'name':label,'apiMilliseconds':(time.perf_counter()-started)*1000,'functionSha256':__import__('hashlib').sha256(overlay.encode()).hexdigest(),'phases':notices,'result':repr(result) if not isinstance(result,Ok) else type(result.value).__name__}
        if isinstance(result,Ok) and isinstance(result.value,GroupSuccess):
            semantic=result.value.response.semantic.results
            item.update(resultCount=len(semantic),changedCount=sum(v.outcome=='changed' for v in semantic))
        else:item['lastNativeError']=str(h._custody.last_attempt.error)
        h.detach();c.rollback();c.close();run['attempts'].append(item)
        print(json.dumps(item,default=str),flush=True)
    admin.execute(Path('/private/tmp/truss-c78-capture-baseline.sql').read_text())
    admin.close()
Path('/private/tmp/truss-c78-capture-ab-profile.json').write_text(json.dumps(run,indent=2,default=str)+'\n')
