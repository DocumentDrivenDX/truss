import json,os,subprocess,time
from pathlib import Path
argv=['/private/tmp/truss-bunfree-venv/bin/python','scripts/benchmark-public-workflows.py','--truss-root','/private/tmp/truss-performance-release-20261018','--installed-package','--forbid-external-javascript','--capture-failure-diagnostics','--count-sql-submissions','--bulk-size','1000','--read-samples','1000','--write-samples','200','--output','/private/tmp/truss-c82-real-schemas.json']
root=Path('/private/tmp/truss-c82-real-schemas.log')
env=dict(os.environ,PYTHONPATH='/private/tmp/weft-042-final-package:/private/tmp/truss-c82-final-package:/private/tmp/truss-performance-release-20261018/packages/python/tests',PYTHONDONTWRITEBYTECODE='1')
root.with_suffix('.log.argv').write_text(json.dumps({'argv':argv,'PYTHONPATH':env['PYTHONPATH']},indent=2)+'\n')
started=time.monotonic()
with root.open('w') as log:
 result=subprocess.run(argv,cwd='/private/tmp/truss-performance-release-20261018',env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'argv':argv,'PYTHONPATH':env['PYTHONPATH'],'log':str(root),'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-started,'package':'/private/tmp/truss-c82-final-package','qualification':'Original Pizza, Northwind and catalog; unchanged default sample dimensions; 1000-object load batch; 1000 ID reads and 200 committed writes; exact installed package; external JavaScript process forbidden; SQL submissions counted.'}
Path('/private/tmp/truss-c82-real-schemas-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
