import json,time,statistics,unittest
from pathlib import Path
from psycopg.types.json import Jsonb
import test_group_create_native as base
class Probe(base.PublicCreateGroupTests):
 for name in tuple(n for n in dir(base.PublicCreateGroupTests) if n.startswith('test_')):locals()[name]=None
 def test_conversion(self):
  connection,host,assembly,tx=self.ready(document_ids=('adoc',))
  result=self.apply(assembly,tx,*self.input(assembly,tx));host.detach();connection.commit()
  original=self.admin.execute("SELECT to_jsonb(t)-'transition_id' FROM truss.runtime_object_transition t").fetchone()[0]
  self.admin.execute('CREATE TEMP TABLE conversion_probe (LIKE truss.runtime_object_transition INCLUDING DEFAULTS)')
  columns='attempt_id,operation_index,writer_xid,object_id,type_id,before_object,after_object,after_keys,journal'
  old=f'''INSERT INTO conversion_probe({columns}) SELECT r.attempt_id,r.operation_index,r.writer_xid,r.object_id,r.type_id,r.before_object,r.after_object,r.after_keys,r.journal FROM generate_series(0,1023) g CROSS JOIN LATERAL jsonb_populate_record(NULL::truss.runtime_object_transition,jsonb_set(%s::jsonb,'{{operation_index}}',to_jsonb(g))) r'''
  new=f'''INSERT INTO conversion_probe({columns}) SELECT %s::uuid,g,%s::xid8,%s::bigint,%s::int,NULL,%s::jsonb,%s::jsonb,%s::jsonb FROM generate_series(0,1023) g'''
  args=(original['attempt_id'],original['writer_xid'],original['object_id'],original['type_id'],Jsonb(original['after_object']),Jsonb(original['after_keys']),Jsonb(original['journal']))
  records=[]
  for iteration in range(6):
   for mode in (('old','new') if iteration%2==0 else ('new','old')):
    self.admin.execute('TRUNCATE conversion_probe');start=time.perf_counter_ns()
    self.admin.execute(old if mode=='old' else new,(Jsonb(original),) if mode=='old' else args)
    elapsed=(time.perf_counter_ns()-start)/1e6
    rows=self.admin.execute("SELECT to_jsonb(t)-'transition_id' FROM conversion_probe t ORDER BY operation_index").fetchall()
    self.assertEqual(len(rows),1024)
    self.assertTrue(all(row[0]==dict(original,operation_index=i) for i,row in enumerate(rows)))
    records.append(dict(iteration=iteration,mode=mode,milliseconds=elapsed,rows=1024,exactFields=True))
  self.admin.execute('DROP TABLE conversion_probe')
  output={'scope':'Isolated temp-table insert conversion, real public CREATE transition; no triggers/authority/group performance qualification','records':records,'medianMs':{mode:statistics.median(r['milliseconds'] for r in records if r['mode']==mode and r['iteration']>0) for mode in ('old','new')}}
  Path('/private/tmp/truss-transition-conversion-probe-20261017.json').write_text(json.dumps(output,indent=2)+'\n')
unittest.main()
