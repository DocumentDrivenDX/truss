import json, os, sys, time, unittest
from pathlib import Path
from test_key_footprint_capacity_native import KeyFootprintCapacityTests
from test_catalog_rebind_native import CatalogRebindTests, CatalogRebind08Tests
from test_bulk_update_transition_guard_native import BulkUpdateTransitionGuardTests
from test_operation_result_slots_native import OperationResultSlotTests
from test_prepared_plan_capture_native import PreparedPlanCaptureTests

specs = [
    (KeyFootprintCapacityTests, 'test_eight_keys'),
    (CatalogRebindTests, 'test_create_and_register_in_one_host_transaction'),
    (CatalogRebind08Tests, 'test_create_and_register_in_one_host_transaction'),
    (BulkUpdateTransitionGuardTests, 'test_before_insert_journal_tamper_refuses_and_keeps_caller_work'),
    (BulkUpdateTransitionGuardTests, 'test_before_insert_after_object_tamper_refuses_at_finish_and_keeps_caller_work'),
    (BulkUpdateTransitionGuardTests, 'test_before_insert_after_keys_tamper_refuses_at_finish_and_keeps_caller_work'),
    (BulkUpdateTransitionGuardTests, 'test_before_insert_coordinated_retained_tamper_refuses_and_keeps_caller_work'),
    (BulkUpdateTransitionGuardTests, 'test_rewritten_result_slots_refuse_for_create_and_update_before_progress'),
    (OperationResultSlotTests, 'test_rewritten_slot_refuses_and_preserves_prior_caller_work'),
    (PreparedPlanCaptureTests, 'test_before_insert_suppression_refuses_before_object_effect'),
]
for cls, name in specs:
    if not hasattr(cls, name):
        raise RuntimeError(f'missing test selector: {cls.__name__}.{name}')

started = time.monotonic()
suite = unittest.TestSuite(cls(name) for cls, name in specs)
result = unittest.TextTestRunner(verbosity=2).run(suite)
receipt = {
    'package': '/private/tmp/truss-c80-final-package',
    'interpreter': sys.executable,
    'argv': sys.argv,
    'pythonpath': os.environ.get('PYTHONPATH'),
    'rawOutputLog': '/private/tmp/truss-c80-focused-controls.log',
    'weft': '/private/tmp/weft-042-final-package',
    'selectors': [f'{cls.__name__}.{name}' for cls, name in specs],
    'testCount': len(specs),
    'elapsedSeconds': time.monotonic() - started,
    'passed': result.wasSuccessful(),
    'failures': [str(err) for _, err in result.failures],
    'errors': [str(err) for _, err in result.errors],
}
Path('/private/tmp/truss-c80-focused-controls.json').write_text(json.dumps(receipt, indent=2))
raise SystemExit(not result.wasSuccessful())
