import json,runpy,sys
from pathlib import Path
root=Path('/Users/erik/Projects/truss')
sys.path.insert(0,str(root/'scripts'))
import performance_workloads
original=performance_workloads.workloads()
case={**original['dense-edges'],'id':'query-source-boundary-control','types':1,'fieldsPerType':4,'shape':'scalar','nodes':102,'edges':10001,'indexedPropertiesPerType':1,'distribution':'uniform','tier':'boundary-control'}
performance_workloads.workloads=lambda:{**original,case['id']:case}
Path('/private/tmp/truss-query-source-boundary-control-config.json').write_text(json.dumps({'qualification':'Private query source boundary control only; not a declared stress matrix result. No declared workload file modified.','workload':case,'package':'/private/tmp/truss-c79-final-package'},indent=2)+'\n')
sys.argv=[str(root/'scripts/benchmark-public-workflows.py'),'--truss-root',str(root),'--installed-package','--forbid-external-javascript','--capture-failure-diagnostics','--count-sql-submissions','--matrix-case',case['id'],'--bulk-size','1000','--read-samples','1','--write-samples','1','--output','/private/tmp/truss-query-source-boundary-control-report.json']
runpy.run_path(sys.argv[0],run_name='__main__')
