from pathlib import Path
import sys,os,importlib.abc,unittest,json,hashlib
sys.dont_write_bytecode=True
r=Path(__file__).resolve().parent;root=Path('/private/tmp/truss-disclosure-main-integration-20261016');os.environ.pop('TRUSS_MODEL_CORRESPONDENCE_QUALIFICATION',None)
sys.path[:0]=[str(root/'packages/python/src'),str(root/'packages/python/tests')];attempts=[];native=[]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='weft' or fullname.startswith('weft.'):
   attempts.append(fullname);raise ModuleNotFoundError('review control: optional Weft intentionally absent')
sys.meta_path.insert(0,Block())
import test_native_model_correspondence_qualification as t
def forbidden(cls):native.append('setup');raise AssertionError('unexpected native setup')
t.NativeModelCorrespondenceTests.setUpClass=classmethod(forbidden)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(t))
outcome={'imported':True,'tests':result.testsRun,'skipped':len(result.skipped),'successful':result.wasSuccessful(),'weftImportAttempts':attempts,'nativeSetupCalls':native,'testSha256':hashlib.sha256(Path(t.__file__).read_bytes()).hexdigest(),'testPath':t.__file__}
assert result.wasSuccessful() and result.testsRun==1 and len(result.skipped)==1 and not attempts and not native
(r/'blocked-weft-import.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
