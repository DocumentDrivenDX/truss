from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;root=Path('/private/tmp/truss-disclosure-main-integration-20261016');ep='docs/helix/04-build/evidence/native-model-correspondence-20261016';e=root/ep;H=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((e/'retention.json').read_text());receipt=json.loads((e/'receipt.json').read_text());results={}
# Freeze exact submitted evidence and integration source/doc delta locally.
shutil.copytree(e,r/'inputs/evidence');test='packages/python/tests/test_native_model_correspondence_qualification.py';(r/'inputs/test_native_model_correspondence_qualification.py').write_bytes((root/test).read_bytes());(r/'inputs/implementation-plan.md').write_bytes((root/'docs/helix/04-build/implementation-plan.md').read_bytes())
for n,pin in m.items():
 b=(e/n).read_bytes();assert H(b)==pin['sha256'] and len(b)==pin['bytes'],n
assert set(p.name for p in e.iterdir())==set(m)|{'retention.json'}
results['retainedIntegrationFiles']=len(m)
reviews=[]
for epoch in [1,2,3]:
 archive=e/f'astra-r{epoch}.zip';pin=receipt['reviews'][str(epoch)];assert H(archive.read_bytes())==pin['archive']['sha256']
 with zipfile.ZipFile(archive) as z:
  mb=z.read('manifest.json');assert H(mb)==pin['manifest']['sha256'] and len(mb)==pin['manifest']['bytes'];rm=json.loads(mb);assert len(rm)==pin['artifacts'];assert set(z.namelist())==set(rm)|{'manifest.json'}
  for n,check in rm.items():
   b=z.read(n);assert H(b)==check['sha256'] and len(b)==check['bytes'],(epoch,n)
  original=Path(f'/private/tmp/truss-weft-native-correspondence-astra-r{epoch}-20261016');assert mb==(original/'manifest.json').read_bytes()
  for n,check in rm.items():assert (original/n).read_bytes()==z.read(n),(epoch,n)
  reviews.append({'epoch':epoch,'artifacts':len(rm),'manifestSha256':H(mb),'reviewSha256':H(z.read('review.json')),'allOriginalReviewerBytesEqual':True})
results['reviews']=reviews
source=json.loads((e/'source-before.json').read_text());assert len(source)==1360
with zipfile.ZipFile(e/'source-inputs.zip') as z:
 assert set(z.namelist())==set(source)
 for n,pin in source.items():
  b=z.read(n);assert H(b)==pin['sha256'] and len(b)==pin['bytes'],n
 testb=(root/test).read_bytes();assert H(testb)==receipt['source']['sha256']=='07183c90aeb6abe52e11a1b410313d5d8feb12660e0c77f2ea4771719d24eb09';assert testb==z.read('owner/test_native_model_correspondence.py')
 prior=Path('/private/tmp/truss-weft-native-correspondence-astra-r3-20261016/frozen/owner/test_native_model_correspondence.py');assert testb==prior.read_bytes()
 wb=z.read('toolchain/weft.whl');assert H(wb)==receipt['weftWheelSha256'];assert H(z.read('weft/weft/weft.abi3.so'))==receipt['weftNativeSha256']
 import io
 with zipfile.ZipFile(io.BytesIO(wb)) as wheel:
  for n in wheel.namelist():assert wheel.read(n)==z.read('weft/'+n)
 # Compare every captured baseline file to immutable Git, not mutable checkout.
 batch=subprocess.Popen(['git','-C',str(root),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);base=receipt['nativeBaseline'];count=0
 for n,pin in source.items():
  if not n.startswith('base/'):continue
  rel=n[5:];batch.stdin.write((base+':'+rel+'\n').encode());batch.stdin.flush();header=batch.stdout.readline().decode().split();assert len(header)==3 and header[1]=='blob',(n,header);b=batch.stdout.read(int(header[2]));assert batch.stdout.read(1)==b'\n';assert H(b)==pin['sha256'],n;count+=1
 batch.stdin.close();assert batch.wait()==0
 # Preserve the captured runner for cleanup/custody audit.
 for n in ['owner/run-native-correspondence-r2.py','owner/run-native-correspondence-r1.py']:(r/'inputs'/Path(n).name).write_bytes(z.read(n))
results['nativeSourcePins']=len(source);results['capturedBaselineFilesExact']=count;results['integratedTestMatchesReviewedAndNativeSource']=True
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip();assert head==receipt['nativeBaseline'];tracked=subprocess.check_output(['git','-C',str(root),'diff','--name-only'],text=True).splitlines();assert tracked==['docs/helix/04-build/implementation-plan.md'];untracked=subprocess.check_output(['git','-C',str(root),'ls-files','--others','--exclude-standard'],text=True).splitlines();assert set(untracked)=={test}|{ep+'/'+p.name for p in e.iterdir()}
diff=subprocess.check_output(['git','-C',str(root),'diff','--','docs/helix/04-build/implementation-plan.md']);(r/'implementation-plan.patch').write_bytes(diff);old=subprocess.check_output(['git','-C',str(root),'show','HEAD:docs/helix/04-build/implementation-plan.md']);new=(root/'docs/helix/04-build/implementation-plan.md').read_bytes();assert new.startswith(old)
assert receipt['native']==json.loads((e/'campaign.json').read_bytes());log=(e/'native-r4.log').read_text();assert 'Ran 1 test in 5.915s' in log and '\nOK' in log
for role,name in [('accepted-request','accepted-request.json'),('accepted-assessment','accepted-assessment.json'),('runtime-release','runtime-release.json'),('native-inventory','native-inventory.json')]:
 p=next(s for s in json.loads((e/'observation-report.json').read_bytes())['sources'] if s['role']==role);b=(e/name).read_bytes();assert H(b)==p['sha256'] and len(b)==p['bytes']
results.update(status='passed',currentHead=head,onlyExpectedTestEvidenceAppend=True,runtimeOrSQLChanges=False,nativeCampaign='Supplied R4; no reviewer SQL replay',cleanupAssertions=receipt['native']['cleanup'])
(r/'audit.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
