expected = {'Staff': (['staffId'], ['staffId']), 'Project': (['projectId'], ['projectId']), 'Resource': (['resourceId', 'salary', 'token'], ['resourceId']), 'Ownership': (['ownerId', 'ownerResource', 'ownerProject'], ['ownerId']), 'Assignment': (['assignmentId', 'assignmentStaff', 'assignmentProject', 'active'], ['assignmentId'])}
issued_records = {r['record']['element']: r for r in issued['records']}
self.assertEqual(set(issued_records), set(expected))
types = {t['element']: t for t in inventory['types'] if t['retired_rev'] is None}
self.assertEqual(set(types), set(expected))
native_mapping = {}
for name, (fields, key_fields) in expected.items():
    issued_record = issued_records[name]
    self.assertEqual(issued_record['record'], {'documentId': 'domain', 'revision': pin['revision'], 'module': 'm', 'element': name})
    self.assertEqual([f['field']['element'] for f in issued_record['fields']], fields)
    self.assertEqual([f['element'] for f in issued_record['selectedKey']['fields']], key_fields)
    for field in issued_record['fields']:
        self.assertEqual((field['field']['documentId'], field['field']['revision'], field['field']['module']), ('domain', pin['revision'], 'm'))
    native = types[name]
    self.assertEqual((native['document_id'], native['module'], native['kind'], native['provisional']), ('domain', 'm', 'record', False))
    props = [p for p in inventory['properties'] if p['type_id'] == native['type_id'] and p['retired_rev'] is None]
    self.assertEqual({p['element'] for p in props}, set(fields))
    self.assertEqual(len(props), len(fields))
    for prop in props:
        self.assertEqual((prop['definition_document_id'], prop['declaration_module'], prop['home']), ('domain', 'm', 'json'))
    keys = [k for k in inventory['keys'] if k['type_id'] == native['type_id'] and k['retired_rev'] is None]
    self.assertEqual(len(keys), 1)
    self.assertEqual(keys[0]['key_id'], 'pk')
    by_id = {p['prop_id']: p['element'] for p in props}
    self.assertEqual([by_id[k] for k in keys[0]['prop_ids']], key_fields)
    native_mapping[name] = {'typeId': native['type_id'], 'properties': {p['element']: p['prop_id'] for p in props}, 'keyNum': keys[0]['key_num'], 'orderedKeyFields': [by_id[k] for k in keys[0]['prop_ids']]}
