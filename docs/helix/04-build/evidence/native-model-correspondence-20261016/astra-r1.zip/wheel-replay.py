from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
r=Path(__file__).parent;sys.path.insert(0,str(r/'inputs/weft'))
import weft,weft.weft as native
p=Path(native.__file__).resolve();expected=(r/'inputs/weft/weft/weft.abi3.so').resolve();assert p==expected
H=lambda b:hashlib.sha256(b).hexdigest();before=H(p.read_bytes());assert before=='9f1c7bc60f070734f2e935ba53e82a0bd22002e9e738c34f65623ca8bac978dd'
raw=(r/'frozen/native-r2/weft-original-request.json').read_bytes();parent=weft.prepare_application_lineage(raw.decode());context=parent.prepare_current_presence();actual=context.model_requirements_json().encode();captured=(r/'frozen/native-r2/issued-requirements.json').read_bytes();assert actual==captured
j=json.loads(actual);assert j['sourceRequestJson']==raw.decode();assert j['sourceRequestSha256']==H(raw);assert j['preparationSha256']==H(context.json().encode());assert context.source_preparation() is parent
assert H(p.read_bytes())==before
(r/'independent-issued-requirements.json').write_bytes(actual)
receipt={'status':'passed','python':sys.version,'nativePath':str(p),'nativeSha256':before,'shimSha256':H(Path(weft.__file__).read_bytes()),'requestSha256':H(raw),'requirementsSha256':H(actual),'exactCapturedRequirements':True,'sameActualPythonParent':True,'records':len(j['records']),'fields':sum(len(x['fields']) for x in j['records']),'keys':len(j['records']),'scope':'Independent non-SQL replay of supplied wheel bytes; no source/build qualification or native binding/authority claim.'}
(r/'wheel-replay.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
