from pathlib import Path
import hashlib,json,zipfile,subprocess
r=Path(__file__).parent;f=r/'frozen';m=json.loads((f/'manifest.json').read_bytes());rows=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for n,p in m.items():
 b=(f/n).read_bytes();assert len(b)==p['bytes'] and sha(b)==p['sha256'],n
 rows.append({'path':n,**p})
base='984d6a65569adb084c6868fcfd8f5674c5a23ea3';git=Path('/private/tmp/truss-disclosure-main-integration-20261016')
objects={}
for row in subprocess.check_output(['git','ls-tree','-r','-z',base],cwd=git).split(b'\0'):
 if row:
  meta,path=row.split(b'\t');objects[path.decode()]=meta.split()[2].decode()
sourceRows=[];diffs=[]
for epoch in ['native-r3']:
 pins=json.loads((f/epoch/'source-before.json').read_bytes())
 with zipfile.ZipFile(f/epoch/'source-inputs.zip') as z:
  assert set(z.namelist())==set(pins)
  for n,p in pins.items():
   b=z.read(n);assert len(b)==p['bytes'] and sha(b)==p['sha256'],(epoch,n)
   if epoch=='native-r3':
    q=r/'inputs'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    if n.startswith('base/'):
     path=n[5:];blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
     if objects.get(path)!=blob:diffs.append({'path':path,'capturedBlob':blob,'baseBlob':objects.get(path)})
  sourceRows.append({'epoch':epoch,'pins':len(pins),'zipSha256':sha((f/epoch/'source-inputs.zip').read_bytes()),'allMatch':True})
req=(f/'native-r3/weft-original-request.json').read_bytes();assert req==(r/'inputs/base/packages/python/tests/fixtures/current-disclosure/native-weft-request.json').read_bytes()
request=json.loads(req);accepted=json.loads((f/'native-r3/accepted-request.json').read_bytes());issued=json.loads((f/'native-r3/issued-requirements.json').read_bytes());assessment=json.loads((f/'native-r3/accepted-assessment.json').read_bytes());observation=json.loads((f/'native-r3/observation-report.json').read_bytes())
assert accepted=={'modules':[{'pin':request['modules'][0]['pin'],'documentJson':request['modules'][0]['documentJson']}]}
assert issued['sourceRequestJson']==req.decode() and issued['sourceRequestSha256']==sha(req)
assert issued['modelPins']==assessment['modelPins']==[request['modules'][0]['pin']]
for s in observation['sources']:
 b=(f/'native-r3'/(s['role']+'.json')).read_bytes();assert sha(b)==s['sha256'] and len(b)==s['bytes']
assert (f/'native-r3/issued-requirements.json').read_bytes()==(f/'owner/actual-requirements.json').read_bytes()
wheel=(r/'inputs/toolchain/weft.whl').read_bytes();assert sha(wheel)=='e072db75724608d652f3368ab1375907c3fbf2cd1e321a0d7a04bbdad4d92778'
with zipfile.ZipFile(r/'inputs/toolchain/weft.whl') as z:
 wheelrows=[]
 for name in z.namelist():
  if not name.endswith('/'):
   b=z.read(name);p=r/'inputs/weft'/name;assert p.read_bytes()==b,name;wheelrows.append({'path':name,'sha256':sha(b),'bytes':len(b)})
assert sha((r/'inputs/weft/weft/weft.abi3.so').read_bytes())=='9f1c7bc60f070734f2e935ba53e82a0bd22002e9e738c34f65623ca8bac978dd'
(r/'audit.json').write_text(json.dumps({'status':'passed','packetMembers':rows,'sourceArchives':sourceRows,'trussBaseline':base,'baselineDifferences':diffs,'actualRequestIsCapturedOriginalFixture':True,'acceptedAndIssuedOriginalsMatch':True,'observationRolePinsMatch':True,'wheelInstalledMembers':wheelrows,'scope':'Supplied campaign source/archive audit, no SQL. Candidate wheel bytes verified; bridge source/build provenance not established.'},indent=2)+'\n')
print(json.dumps({'manifest':len(rows),'sourceArchives':sourceRows,'baselineDifferences':diffs,'wheelMembers':len(wheelrows)},indent=2))
