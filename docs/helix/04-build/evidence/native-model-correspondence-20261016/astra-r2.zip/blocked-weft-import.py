from pathlib import Path
import sys,os,importlib.abc,unittest,json,traceback
sys.dont_write_bytecode=True
r=Path(__file__).parent;os.environ.pop('TRUSS_MODEL_CORRESPONDENCE_QUALIFICATION',None)
sys.path[:0]=[str(r/'inputs/base/packages/python/src'),str(r/'inputs/base/packages/python/tests'),str(r/'frozen/owner')]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='weft' or fullname.startswith('weft.'):
   raise ModuleNotFoundError('review control: optional Weft intentionally absent')
sys.meta_path.insert(0,Block())
try:
 import test_native_model_correspondence as t
 t.NativeModelCorrespondenceTests.setUpClass=classmethod(lambda cls:(_ for _ in ()).throw(AssertionError('unexpected native setup')))
 result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromModule(t))
 outcome={'imported':True,'tests':result.testsRun,'skipped':len(result.skipped),'successful':result.wasSuccessful()}
except ModuleNotFoundError as e:
 traceback.print_exc();outcome={'imported':False,'error':str(e),'qualificationUnset':True,'nativeStarted':False}
(r/'blocked-weft-import.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
