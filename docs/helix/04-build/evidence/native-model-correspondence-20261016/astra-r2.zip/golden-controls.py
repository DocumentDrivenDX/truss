from pathlib import Path
import ast,json,copy,unittest
r=Path(__file__).parent;s=(r/'frozen/owner/test_native_model_correspondence.py').read_text();tree=ast.parse(s);fn=next(x for c in tree.body if isinstance(c,ast.ClassDef) for x in c.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_exact'))
start=next(i for i,x in enumerate(fn.body) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='expected' for t in x.targets));stop=next(i for i,x in enumerate(fn.body[start:],start) if isinstance(x,ast.For) and isinstance(x.target,ast.Tuple))
# The golden loop is the first name,(fields,key_fields) loop; include it.
block=ast.Module(body=fn.body[start:stop+1],type_ignores=[]);code=compile(ast.fix_missing_locations(block),'frozen-golden-assertions','exec');(r/'extracted-golden.py').write_text(ast.unparse(block)+'\n')
issued=json.loads((r/'frozen/native-r3/issued-requirements.json').read_bytes());assessment=json.loads((r/'frozen/native-r3/accepted-assessment.json').read_bytes());inventory=assessment['inventory'];pin=assessment['modelPins'][0]
def run(i=issued,n=inventory):
 scope={'issued':i,'inventory':n,'pin':pin,'self':unittest.TestCase()};exec(code,scope);return scope['native_mapping']
assert run()==json.loads((r/'frozen/native-r3/native-field-key-mapping.json').read_bytes())
rows=[]
def mutant(name,edit):
 i,n=copy.deepcopy(issued),copy.deepcopy(inventory);edit(i,n)
 try:run(i,n);caught=False
 except (AssertionError,KeyError,TypeError):caught=True
 rows.append({'id':name,'caught':caught})
def resource(i):return next(x for x in i['records'] if x['record']['element']=='Resource')
for key in ['documentId','revision','module','element']:
 mutant('record-'+key,lambda i,n,k=key:resource(i)['record'].__setitem__(k,'foreign'))
for key in ['documentId','revision','module','element']:
 mutant('field-'+key,lambda i,n,k=key:resource(i)['fields'][0]['field'].__setitem__(k,'foreign'))
for key in ['documentId','revision','module','element']:
 mutant('selected-key-field-'+key,lambda i,n,k=key:resource(i)['selectedKey']['fields'][0].__setitem__(k,'foreign'))
mutant('selected-key-id',lambda i,n:resource(i)['selectedKey'].__setitem__('id','different-key'))
mutant('native-field-home',lambda i,n:n['properties'][0].__setitem__('home','typed'))
mutant('native-key-id',lambda i,n:n['keys'][0].__setitem__('key_id','other'))
mutant('missing-native-property',lambda i,n:n['properties'].pop())
mutant('duplicate-native-type',lambda i,n:n['types'].append(copy.deepcopy(n['types'][0])))
mutant('duplicate-issued-record',lambda i,n:i['records'].append(copy.deepcopy(i['records'][0])))
(r/'golden-controls.json').write_text(json.dumps({'baselineMatches':True,'cases':rows,'caught':sum(x['caught'] for x in rows),'survived':[x['id'] for x in rows if not x['caught']],'scope':'Extracted exact frozen native golden assertions over captured data; no SQL/native mutation.'},indent=2)+'\n');print(json.dumps(rows,indent=2))
