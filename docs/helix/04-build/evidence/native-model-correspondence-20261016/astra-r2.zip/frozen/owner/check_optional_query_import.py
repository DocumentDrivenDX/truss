"""Fresh-process qualification guard test; never starts native fixtures."""
import importlib.abc,sys,json,unittest,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--expected',choices=['refusal','skip'],required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();attempts=[]
class DenyWeft(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='weft' or fullname.startswith('weft.'):
   attempts.append(fullname);raise ModuleNotFoundError('Optional query dependency import denied before opt-in')
sys.meta_path.insert(0,DenyWeft())
try:
 import test_native_model_correspondence as module
except ModuleNotFoundError as error:
 assert a.expected=='refusal' and attempts,str(error)
 result={'status':'expected-refusal','attempts':attempts,'error':str(error),'nativeSetupExecuted':False}
else:
 assert a.expected=='skip' and not attempts
 result_run=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(module.NativeModelCorrespondenceTests))
 assert result_run.wasSuccessful() and result_run.testsRun==1 and len(result_run.skipped)==1
 result={'status':'passed','attempts':attempts,'tests':1,'skipped':1,'nativeSetupExecuted':False}
a.output.write_text(json.dumps(result,indent=2)+'\n')
