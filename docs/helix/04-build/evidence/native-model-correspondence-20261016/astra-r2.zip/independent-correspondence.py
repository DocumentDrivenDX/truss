from pathlib import Path
import json,hashlib
r=Path(__file__).parent;f=r/'frozen/native-r3';H=lambda b:hashlib.sha256(b).hexdigest();i=json.loads((f/'issued-requirements.json').read_bytes());a=json.loads((f/'accepted-assessment.json').read_bytes());n=a['inventory'];p=a['modelPins'][0];checks=[]
def check(name,ok):
 assert ok,name;checks.append({'id':name,'pass':True})
def identity(name):return {'documentId':'domain','revision':p['revision'],'module':'m','element':name}
expected={'Staff':(['staffId'],['staffId']),'Project':(['projectId'],['projectId']),'Resource':(['resourceId','salary','token'],['resourceId']),'Ownership':(['ownerId','ownerResource','ownerProject'],['ownerId']),'Assignment':(['assignmentId','assignmentStaff','assignmentProject','active'],['assignmentId'])}
active=[x for x in n['types'] if x['retired_rev'] is None]
check('issued-record-census',len(i['records'])==5 and len({json.dumps(x['record'],sort_keys=True) for x in i['records']})==5)
check('native-type-census',len(active)==5 and len({x['type_id'] for x in active})==5 and len({(x['document_id'],x['module'],x['element']) for x in active})==5)
check('native-property-census',len([x for x in n['properties'] if x['retired_rev'] is None])==12)
check('native-key-census',len([x for x in n['keys'] if x['retired_rev'] is None])==5)
for name,(fields,keys) in expected.items():
 x=next(x for x in i['records'] if x['record']['element']==name);t=next(x for x in active if x['element']==name)
 check(name+'-record',x['record']==identity(name) and (t['document_id'],t['module'],t['kind'],t['provisional'])==('domain','m','record',False))
 check(name+'-fields',[f['field'] for f in x['fields']]==[identity(k) for k in fields])
 check(name+'-complete-selected-key',x['selectedKey']=={'id':'pk','fields':[identity(k) for k in keys]})
 props=[z for z in n['properties'] if z['retired_rev'] is None and z['type_id']==t['type_id']];ks=[z for z in n['keys'] if z['retired_rev'] is None and z['type_id']==t['type_id']]
 check(name+'-native-members',len(props)==len(fields) and {z['element'] for z in props}==set(fields) and len({z['prop_id'] for z in props})==len(props))
 check(name+'-native-identities',all((z['definition_document_id'],z['declaration_module'],z['home'])==('domain','m','json') for z in props))
 byid={z['prop_id']:z['element'] for z in props};check(name+'-native-selected-key',len(ks)==1 and ks[0]['key_id']=='pk' and [byid[k] for k in ks[0]['prop_ids']]==keys)
check('assessment-release-pin',a['releaseId']=='truss-catalog-runtime/0.71-candidate' and a['releaseSha256']==H((f/'runtime-release.json').read_bytes()))
check('report-data-only',all(i[k] is False for k in ['complete','authority','securityReady']) and i['nativeAdmission']=='required')
c=json.loads((f/'campaign.json').read_bytes());check('supplied-one-pass-cleanup',c['status']=='passed' and c['tests']==1 and c['cleanup']['rootRemoved'] and c['cleanup']['postmasterStopped'] and c['cleanup']['postmasterPid']==99837)
check('recorded-root-absent-now',not Path(c['cleanup']['root']).exists())
(r/'independent-correspondence.json').write_text(json.dumps({'status':'passed','checks':checks,'reviewerRanSQL':False,'scope':'Independent strict correspondence over supplied native values, not native re-observation. Five single-component Keys exercise component order only trivially; composite Key/native codec/graph correspondence is not demonstrated. Current absence of recorded root is observed; no historical PID probe.'},indent=2)+'\n');print(len(checks),'passed')
