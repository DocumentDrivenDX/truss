from pathlib import Path
import hashlib,json,sys,subprocess,tarfile,io,shutil,unittest,importlib.util,copy,ast
r=Path(__file__).resolve().parent;o=Path('/private/tmp/truss-graph-cut-transport-review-20261016');m=json.loads((o/'manifest.json').read_bytes());base=m['base'];repo='/Users/erik/Projects/truss';H=lambda b:hashlib.sha256(b).hexdigest()
for n,h in m['files'].items():b=(o/n).read_bytes();assert H(b)==h,n;t=r/'packet'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
(r/'packet/manifest.json').write_bytes((o/'manifest.json').read_bytes());work=r/'working';work.mkdir(exist_ok=True)
paths=['packages/python/src','packages/python/tests/fixtures/current-disclosure/native-graph-capture.json']
tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base,*paths]))).extractall(work)
for p in (o/'packages/python').rglob('*'):
 if p.is_file():t=work/'packages/python'/p.relative_to(o/'packages/python');t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t)
sys.path[:0]=[str(work/'packages/python/src'),str(work/'packages/python/tests')]
from truss._current_disclosure_wire import disclosure_fact_cut,frame_digest,object_members
from truss._current_disclosure_computation import open_current_disclosure_computation
from truss._current_disclosure_pipe import VERSION
fixture=work/'packages/python/tests/fixtures/current-disclosure/native-graph-capture.json';corpus=json.loads(fixture.read_bytes());assert len(corpus['packets'])==15;assert [p['id'] for p in corpus['packets'][3:6]]==['parallel:Alice','parallel:Bob','parallel:Outsider']
wire=lambda v:json.dumps(v,ensure_ascii=True,separators=(',',':')).encode();initial=wire(corpus['initialize']);receipt=frame_digest(initial);obs=[]
for packet in corpus['packets']:
 cut=copy.deepcopy(packet['cut']);arrays={n:wire(cut.pop(n)) for n in ['facts','coverage','graphs','graphCoverage']};raw=disclosure_fact_cut(cut,facts=arrays['facts'],coverage=arrays['coverage'],graphs=arrays['graphs'],graph_coverage=arrays['graphCoverage']);request=wire({'version':VERSION,'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':receipt})[:-1]+b',"cut":'+raw+b'}'
 with open_current_disclosure_computation(bun_executable='/opt/homebrew/bin/bun',timeout_seconds=20) as child:
  assert json.loads(child.exchange(initial,source_receipt=receipt))['kind']=='initialized';response=json.loads(child.exchange(request,source_receipt=receipt));assert response['kind']=='disclosure-evaluated';result=response['result'];parallel=packet['id'].startswith('parallel:');assert result['status']==('refused' if parallel else 'rendered'),packet['id']
  if not parallel:assert [row['key'][0]['string'] for row in result['resources']]==packet['expectedKeys']
 assert child._cleanup_complete;obs.append({'packet':packet['id'],'requestSha256':H(request),'response':response,'cleanupComplete':True})
(r/'packaged-15.json').write_text(json.dumps({'observations':obs,'rendered':12,'parallelRefused':3,'SQLExecuted':False},indent=2)+'\n')
# One focused pure wire test only; no broad/native suite.
spec=importlib.util.spec_from_file_location('wire_tests',work/'packages/python/tests/test_current_disclosure_wire.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
with (r/'wire-test.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('CurrentDisclosureWireTests.test_all_captured_populations_preserve_exact_tokens_without_defaults',t));assert result.wasSuccessful()
raws={'facts':b' \n[{"n":9007199254740993,"minus":-0.00,"s":"\\u0061"}] \t','coverage':b'[]','graphs':b' [{"x":1.2300e-999999}] ','graphCoverage':b'[{"complete":false}]'}
raw=disclosure_fact_cut({'generation':'g'},facts=raws['facts'],coverage=raws['coverage'],graphs=raws['graphs'],graph_coverage=raws['graphCoverage']);assert raw==b'{"generation":"g",'+b','.join(wire(n)+b':'+v for n,v in raws.items())+b'}';assert json.loads(raw)['graphCoverage'][0]['complete'] is False
probe=json.loads((o/'docs/helix/04-build/evidence/graph-cut-transport-20261016/probe.json').read_bytes());assert len(probe['observations'])==6 and H(fixture.read_bytes())==probe['fixtureSha256'];probechecks=[]
for entry in probe['observations']:
 packet=next(p for p in corpus['packets'] if p['id']==entry['packet']);cut=copy.deepcopy(packet['cut']);arrays={n:wire(cut.pop(n)) for n in ['facts','coverage','graphs','graphCoverage']};omitted=entry['cohort']=='packaged-missing-graphs-control'
 if omitted:arrays.update(graphs=b'[]',graphCoverage=b'[]')
 raw=disclosure_fact_cut(cut,facts=arrays['facts'],coverage=arrays['coverage'],graphs=arrays['graphs'],graph_coverage=arrays['graphCoverage']);request=wire({'version':VERSION,'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':receipt})[:-1]+b',"cut":'+raw+b'}';assert H(request)==entry['requestSha256'];response=entry['response'];assert response['sourceReceipt']==receipt and entry['cleanupComplete'] is True;result=response['result'];assert result['status']==('refused' if omitted else 'rendered') and result['authority'] is False and result['complete'] is False
 if omitted:assert result['resources']==[] and result['batch'] is None
 else:assert [row['key'][0]['string'] for row in result['resources']]==packet['expectedKeys']
 probechecks.append({'packet':entry['packet'],'cohort':entry['cohort'],'requestAndResponseConsistent':True})
umf='/Users/erik/.codex/worktrees/security-main-integration/umf'
for name,key in [('tools/security/current-native-disclosure-child-main.ts','sourceEntrySha256'),('src/extensions/security/catalog-runtime-candidate.ts','sourceRuntimeSha256')]:assert H(subprocess.check_output(['git','-C',umf,'show',probe['sourceRevision']+':'+name]))==probe[key]
assert probe['sourceTrackedStatus']=='';assert probe['packagedConsumerManifest']==json.loads((work/'packages/python/src/truss/_current_disclosure_owner/consumer-manifest.json').read_bytes());assert probe['packagedConsumerManifest']['umfRevision']=='206951ff20d766874b9af7d29fdf8027c3bab499'
# Integration wiring carries each captured byte attribute directly; existing authority metadata and 4MiB limit unchanged.
source=(o/'packages/python/src/truss/_current_disclosure_evaluation.py').read_text();before=subprocess.check_output(['git','-C',repo,'show',base+':packages/python/src/truss/_current_disclosure_evaluation.py']).decode()
for text in ["'trusted':True",'if len(evaluation)>4194304',"'maxFacts':10000,'maxSteps':1000000"]:assert text in source and text in before
for field in ['facts_bytes','coverage_bytes','graphs_bytes','graph_coverage_bytes']:assert ('captured.'+field) in source
report={'passed':True,'base':base,'frozenMembers':len(m['files']),'packagedReplay':{'rendered':12,'parallelRefused':3,'cleanupComplete':15},'focusedWireTest':1,'exactPopulationByteControl':True,'completeFalsePreserved':True,'probeSixRequestsAndResponsesConsistent':probechecks,'sourceProbeTwoPinsExactRecordedGitRevision':True,'packagedAndWeftPinsUnchangedByDiff':True,'SQLExecuted':False};(r/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
