"""Native single-use pending revision registration; every fixture rolls back."""
import hashlib
import json
import unittest
import test_catalog_report_write_candidate_native as report_fixture
from test_catalog_staging import ROOT
from truss._acceptance_json import decode_acceptance_json


class RevisionRegistrationNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        report_fixture.ReportWriteCandidateNativeTests.setUpClass()
        cls.Connection=report_fixture.ReportWriteCandidateNativeTests.Connection
        cls.kwargs=report_fixture.ReportWriteCandidateNativeTests.kwargs
        c=cls.Connection(**cls.kwargs)
        try:c.run((ROOT/'packages/postgresql/native/catalog-report/revision-registration-candidate.sql').read_text())
        finally:c.close()
    @classmethod
    def tearDownClass(cls):report_fixture.ReportWriteCandidateNativeTests.tearDownClass()
    setUp=report_fixture.ReportWriteCandidateNativeTests.setUp
    tearDown=report_fixture.ReportWriteCandidateNativeTests.tearDown
    stage=report_fixture.ReportWriteCandidateNativeTests.stage
    admit=report_fixture.ReportWriteCandidateNativeTests.admit
    invoke=report_fixture.ReportWriteCandidateNativeTests.invoke

    def archive(self):
        report_fixture.ReportWriteCandidateNativeTests.archive(self)
        path='packages/python/src/truss/_profiles/catalog-revision-registration-candidate.json'
        original=(ROOT/path).read_bytes();profile=json.loads(original)
        artifacts=[(path,getattr(self,'recipe_bytes',original))]
        artifacts.extend((ref['path'],(ROOT/ref['path']).read_bytes()) for ref in profile['sources'].values())
        if getattr(self,'omit_recipe',False):artifacts=artifacts[1:]
        if getattr(self,'duplicate_recipe',False):artifacts.append((path,original))
        for identity,raw in artifacts:
            self.connection.run("""INSERT INTO truss.installation_archive(installation_id,artifact_role,
                artifact_identity,artifact_bytes,artifact_identity_sha256) VALUES('guard-fixture','input',
                :identity,:raw,sha256(convert_to(:identity,'UTF8')))""",identity=identity,raw=raw)

    def register(self,generation=None):
        return self.connection.run("""SELECT * FROM truss.runtime_write_catalog_report_and_register_revision_candidate(
            :writer,:ordinal,:generation,:identity,:registration,:lifecycle,:indexes)""",
            writer=self.writer,ordinal=self.ordinal,generation=self.generation if generation is None else generation,
            identity=self.identity,registration=self.registration_bytes,
            lifecycle=(ROOT/'packages/python/src/truss/_profiles/fresh-catalog-lifecycle.json').read_bytes(),
            indexes=(ROOT/'packages/python/src/truss/_profiles/absent-binding-index-declarations.json').read_bytes())[0]

    def assert_rolled_back(self):
        for name in ('catalog_acceptance_report','feed_tx','feed_member','feed_prerequisite','feed_configuration_prerequisite'):
            self.assertEqual(self.connection.run('SELECT count(*) FROM truss.'+name),[[0]])
        self.assertEqual(self.connection.run('SELECT rev FROM truss.schema_head'),[[0]])
        self.assertEqual(self.connection.run('SELECT effect_generation::text FROM truss.row_home_operation'),[[self.generation]])

    def trigger(self,table,timing,event,body):
        self.connection.run("CREATE FUNCTION truss.fixture_registration_drift() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN "+body+" END $$; CREATE TRIGGER fixture_registration_drift "+timing+' '+event+' ON truss.'+table+' FOR EACH ROW EXECUTE FUNCTION truss.fixture_registration_drift()')

    def test_pending_revision_registration_complete_original_rows(self):
        self.stage();row=self.register()
        self.assertEqual(row[:3],[self.writer,self.ordinal,str(int(self.generation)+1)])
        self.assertEqual(row[7:],['administrative_single_original_operation_fresh_catalog_rollback_only',False,False])
        self.assertEqual(self.connection.run("SELECT encode(record_send(t),'hex') FROM truss.feed_tx t"),[[row[5]]])
        self.assertEqual(self.connection.run("SELECT encode(record_send(m),'hex') FROM truss.feed_member m"),[[row[6]]])
        self.assertEqual(self.connection.run('SELECT registration_counter,prerequisite_registration_counter,configuration_registration_counter,membership_generation,finalized_generation,manifest_bytes,manifest_sha256 FROM truss.feed_tx'),[[1,0,0,1,None,None,None]])
        member=self.connection.run('SELECT original_fact_key_bytes,original_payload_bytes,original_payload_sha256,original_payload_profile_bytes,original_owner_context_bytes,delivery_ordinal FROM truss.feed_member')[0]
        self.assertEqual(decode_acceptance_json(member[0]),{'kind':'revision','revision':'1'})
        self.assertEqual(member[1],bytes.fromhex(row[4]));self.assertEqual(member[2],hashlib.sha256(member[1]).digest())
        self.assertEqual(member[3],(ROOT/'packages/python/src/truss/_profiles/catalog-revision-composition-candidate.json').read_bytes())
        owner=decode_acceptance_json(member[4]);self.assertEqual(''.join(owner['originalContextHexChunks']),self.context.hex())
        self.assertEqual(self.connection.run("SELECT encode(record_send(r),'hex') FROM truss.schema_rev r WHERE rev=1"),[[''.join(owner['originalRevisionRecordHexChunks'])]])
        self.assertEqual(self.connection.run("SELECT encode(record_send(d),'hex') FROM truss.schema_doc d WHERE rev=1 ORDER BY ord"),[[''.join(v)] for v in owner['originalDocumentRecordHexChunks']])
        self.assertEqual(self.connection.run("SELECT encode(record_send(o),'hex') FROM truss.row_home_operation o"),[[''.join(owner['originalOperationRecordHexChunks'])]])
        self.assertIsNone(member[5]);self.assertEqual(self.connection.run('SELECT rev FROM truss.schema_head'),[[0]])
        from pg8000.exceptions import DatabaseError
        with self.assertRaises(DatabaseError):self.connection.run('COMMIT')
        self.assertEqual(self.connection.run('SELECT count(*) FROM truss.feed_member'),[[0]])

    def test_native_write_clock_and_single_use_refusal(self):
        from pg8000.exceptions import DatabaseError
        self.connection.run("""CREATE FUNCTION truss.fixture_future_acceptance() RETURNS trigger LANGUAGE plpgsql AS $$
          BEGIN NEW.accepted_at:='2099-01-01 00:00:00+00'::timestamptz; RETURN NEW; END $$;
          CREATE TRIGGER fixture_future_acceptance BEFORE INSERT ON truss.schema_rev
          FOR EACH ROW EXECUTE FUNCTION truss.fixture_future_acceptance()""")
        self.stage();before=self.connection.run('SELECT clock_timestamp()')[0][0];row=self.register()
        after=self.connection.run('SELECT clock_timestamp()')[0][0]
        timestamp,clock_bytes=self.connection.run('SELECT original_write_at,original_fact_clock_bytes FROM truss.feed_member')[0]
        self.assertLessEqual(before,timestamp);self.assertLessEqual(timestamp,after)
        self.assertLess(timestamp,self.connection.run('SELECT accepted_at FROM truss.schema_rev WHERE rev=1')[0][0])
        envelope=decode_acceptance_json(clock_bytes)
        self.assertEqual(envelope['originalWriteAt'],self.connection.run("SELECT to_char(original_write_at AT TIME ZONE 'UTC','YYYY-MM-DD\"T\"HH24:MI:SS.US\"Z\"') FROM truss.feed_member")[0][0])
        self.connection.run('SAVEPOINT repeat')
        with self.assertRaises(DatabaseError):self.register(generation=row[2])
        self.connection.run('ROLLBACK TO repeat');self.connection.run('RELEASE repeat')
        self.assertEqual(self.connection.run("SELECT encode(record_send(m),'hex') FROM truss.feed_member m"),[[row[6]]])

    def test_suppressed_writes_refuse_and_preserve_host_state(self):
        from pg8000.exceptions import DatabaseError
        self.stage();self.connection.run("CREATE TEMP TABLE registration_host_work(value text); INSERT INTO registration_host_work VALUES('keep')")
        for table,event in [('feed_tx','INSERT'),('feed_tx','UPDATE'),('feed_member','INSERT')]:
            self.connection.run('SAVEPOINT suppression');self.trigger(table,'BEFORE',event,'RETURN NULL;')
            with self.subTest(table=table,event=event),self.assertRaises(DatabaseError) as caught:self.register()
            self.assertEqual(caught.exception.args[0]['C'],'P0002')
            self.connection.run('ROLLBACK TO suppression');self.connection.run('RELEASE suppression')
            self.assert_rolled_back();self.assertEqual(self.connection.run('SELECT value FROM registration_host_work'),[['keep']])

    def test_rewritten_writes_refuse(self):
        from pg8000.exceptions import DatabaseError
        self.stage()
        for table,event,body in [('feed_tx','INSERT',"NEW.original_context_bytes:=decode('01','hex'); RETURN NEW;"),
                                 ('feed_tx','UPDATE','NEW.registration_counter:=2; RETURN NEW;'),
                                 ('feed_member','INSERT',"NEW.original_write_at:='2000-01-01+00'::timestamptz; RETURN NEW;")]:
            self.connection.run('SAVEPOINT rewrite');self.trigger(table,'BEFORE',event,body)
            with self.subTest(table=table,event=event),self.assertRaises(DatabaseError) as caught:self.register()
            self.assertEqual(caught.exception.args[0]['C'],'55000')
            self.connection.run('ROLLBACK TO rewrite');self.connection.run('RELEASE rewrite');self.assert_rolled_back()

    def test_extra_member_refuses_final_delta(self):
        from pg8000.exceptions import DatabaseError
        self.stage();self.connection.run('SAVEPOINT extra')
        self.trigger('feed_member','AFTER','INSERT',"IF NEW.registration_address=1 THEN NEW.registration_address:=2; INSERT INTO truss.feed_member SELECT NEW.*; END IF; RETURN NEW;")
        with self.assertRaises(DatabaseError) as caught:self.register()
        self.assertEqual(caught.exception.args[0]['M'],'complete original pending revision registration delta required')
        self.connection.run('ROLLBACK TO extra');self.connection.run('RELEASE extra');self.assert_rolled_back()

    def test_late_catalog_or_report_change_refuses(self):
        from pg8000.exceptions import DatabaseError
        self.stage()
        for body in ('UPDATE truss.type_def SET retired_rev=1; RETURN NEW;','DELETE FROM truss.catalog_acceptance_report; RETURN NEW;'):
            self.connection.run('SAVEPOINT catalog_drift');self.trigger('feed_member','AFTER','INSERT',body)
            with self.subTest(body=body),self.assertRaises(DatabaseError):self.register()
            self.connection.run('ROLLBACK TO catalog_drift');self.connection.run('RELEASE catalog_drift');self.assert_rolled_back()

    def test_registration_profile_missing_changed_and_duplicate_refuse(self):
        from pg8000.exceptions import DatabaseError
        for mode in ('missing','changed','duplicate'):
            self.connection.run('SAVEPOINT recipe_setup')
            self.omit_recipe=mode=='missing';self.duplicate_recipe=mode=='duplicate'
            self.recipe_bytes=b'{}' if mode=='changed' else (ROOT/'packages/python/src/truss/_profiles/catalog-revision-registration-candidate.json').read_bytes()
            self.stage();self.connection.run('SAVEPOINT recipe_call')
            with self.subTest(mode=mode),self.assertRaises(DatabaseError):self.register()
            self.connection.run('ROLLBACK TO recipe_call');self.connection.run('RELEASE recipe_call');self.assert_rolled_back()
            self.connection.run('ROLLBACK TO recipe_setup');self.connection.run('RELEASE recipe_setup')

    def test_late_relation_scope_change_refuses(self):
        from pg8000.exceptions import DatabaseError
        self.stage();self.connection.run('SAVEPOINT new_relation')
        self.trigger('feed_member','AFTER','INSERT','CREATE TABLE truss.fixture_uncovered(value text); RETURN NEW;')
        with self.assertRaises(DatabaseError) as caught:self.register()
        self.assertEqual(caught.exception.args[0]['M'],'complete original pending revision registration delta required')
        self.connection.run('ROLLBACK TO new_relation');self.connection.run('RELEASE new_relation');self.assert_rolled_back()
