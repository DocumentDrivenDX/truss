from pathlib import Path
import ast,hashlib,json,subprocess,sys,tarfile,io,zipfile,unittest
from dataclasses import replace
from unittest.mock import patch
from types import SimpleNamespace
p=Path(__file__).resolve().parent;src=Path('/private/tmp/truss-graph-closing-review-20261016');repo='/Users/erik/Projects/truss';base='dadbce957437d60c86e3d9ad637dfdc738454239';H=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((src/'manifest.json').read_bytes())
for n,h in m.items():
 b=(src/n).read_bytes();assert H(b)==h,n;t=p/'packet'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
(p/'packet/manifest.json').write_bytes((src/'manifest.json').read_bytes());e=p/'packet/docs/helix/04-build/evidence/graph-closing-recapture-20261016'
ret=json.loads((e/'retention.json').read_bytes())
for n,h in ret['sourceFiles'].items():assert H((p/'packet'/n).read_bytes())==h
for n,h in ret['files'].items():assert H((e/n).read_bytes())==h
source='packages/python/src/truss/_current_disclosure_facts.py';old=subprocess.check_output(['git','-C',repo,'show',base+':'+source]);new=(p/'packet'/source).read_bytes();assert new.startswith(old) and len(ast.parse(new).body)==len(ast.parse(old).body)+1;(p/'baseline-facts.py').write_bytes(old)
oldnative=subprocess.check_output(['git','-C',repo,'show',base+':packages/python/tests/test_current_disclosure_graphs_native.py']);newnative=(p/'packet/packages/python/tests/test_current_disclosure_graphs_native.py').read_bytes()
for name in ('Deadline','NativeCursor'):
 get=lambda raw:next(n for n in ast.parse(raw).body if isinstance(n,ast.ClassDef) and n.name==name)
 assert ast.dump(get(oldnative))==ast.dump(get(newnative))
native=json.loads((e/'native-manifest.json').read_bytes());summaries=[]
with zipfile.ZipFile(e/'native-inputs-and-results.zip') as z:
 assert set(z.namelist())==set(native)
 for n,v in native.items():b=z.read(n);assert H(b)==v['sha256'] and len(b)==v['bytes'],n
 for case,edges in [('base',12),('parallel',13)]:
  r=json.loads(z.read('native-graph-capture-'+case+'-result.json'));loc=json.loads(z.read('native-inputs-'+case+'/native-locators.json'));assert r['facts']==len(loc['objects'])==14 and r['graphs']==len(loc['edges'])==edges
  assert len(r['closingCaptureChecks'])==9 and len(set(r['closingCaptureChecks']))==9 and len(r['closingMutationRefusals'])==5 and len(r['heldFactLockChecks'])==7
  assert len(r['observations'])==3 and [x['subject'] for x in r['observations']]==['Alice','Bob','Outsider']
  for subject in ['Alice','Bob','Outsider']:
   cut=json.loads(z.read('native-inputs-'+case+'/'+subject+'-cut.json'));assert len(cut['facts'])==14 and len(cut['graphs'])==edges
  summaries.append({k:r[k] for k in ('case','facts','graphs','closingCaptureChecks','closingMutationRefusals','heldFactLockChecks')})
(p/'native-audit.json').write_text(json.dumps({'members':len(native),'cases':summaries,'scope':'Supplied native evidence inspection; no SQL replay'},indent=2)+'\n')
work=p/'working';work.mkdir();tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base,'packages/python/src','packages/python/tests']))).extractall(work)
for n in ret['sourceFiles']:(work/n).write_bytes((p/'packet'/n).read_bytes())
sys.path[:0]=[str(work/'packages/python/src'),str(work/'packages/python/tests')]
with (p/'pure-tests.log').open('w') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(['test_current_disclosure_capture_closing','test_current_disclosure_graphs']));assert result.wasSuccessful() and result.testsRun==13
from truss._current_disclosure_facts import CurrentDisclosureFactCapture,verify_current_disclosure_capture_with_cursor
from truss._current_query_sources import CurrentQuerySourceCapture
s=CurrentQuerySourceCapture('install','receipt','revision',b'init',b'request',b'assessment','profile','digest',None);c=CurrentDisclosureFactCapture(s,b'[1e+02]',b'[]',(('1','2','3',b'r',b'n',b'k'),),b'[]',b'[]',(('4','5','6','7','8','9','10'),));cursor=SimpleNamespace(_deadline=SimpleNamespace(check=lambda:None));mutants=[]
for n in s.__dataclass_fields__:
 value=getattr(s,n);mutants.append((f'source.{n}',replace(c,sources=replace(s,**{n:(value+b'changed' if isinstance(value,bytes) else str(value)+'changed')}))))
for key in ('rows','graph_rows'):
 row=getattr(c,key)[0]
 for i,v in enumerate(row):
  changed=list(row);changed[i]=v+(b'changed' if isinstance(v,bytes) else 'changed');mutants.append((f'{key}.{i}',replace(c,**{key:(tuple(changed),)})))
for label,current in mutants:
 with patch('truss._current_disclosure_facts.capture_current_disclosure_facts_with_cursor',return_value=current):
  try:verify_current_disclosure_capture_with_cursor(cursor,c)
  except ValueError as ex:assert 'changed before closing' in str(ex)
  else:raise AssertionError(label)
report={'passed':True,'frozenFiles':len(m),'baseline':base,'priorSourceBytesExactPrefix':True,'onlyOneAppendedFunction':True,'diagnostic90sCursorUnchanged':True,'pureTestsPassed':13,'nestedSourceAndPrivateRowMutationsRefused':len(mutants),'nativeArchiveMembersVerified':len(native),'nativeCases':2,'reviewerSQL':False};(p/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
