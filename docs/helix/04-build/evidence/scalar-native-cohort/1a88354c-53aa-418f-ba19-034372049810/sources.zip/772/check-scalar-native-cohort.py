"""Owned native scalar report composition; no backend enforcement admission."""
from pathlib import Path
import os,json,hashlib,uuid,subprocess,time,zipfile
root=Path.cwd();out=root/'docs/helix/04-build/evidence/scalar-native-cohort'/str(uuid.uuid4());out.mkdir(parents=True)
env=os.environ.copy();sha=lambda b:hashlib.sha256(b).hexdigest()
host=root/'docs/helix/04-build/evidence/original-occurrence-inventory/2823413d-34e7-4b87-a79a-347561732e5f/receipt.json'
paths={Path(p['path']) for p in json.loads(host.read_text())['sourcePreimages']}
paths.update([Path(__file__).resolve(),host,root/'scripts/check-catalog-new-cohort.ts',root/'scripts/build-configuration-context-admission.py'])
paths.update(root.joinpath('packages/postgresql/native').rglob('*.sql'))
paths.update(root/'docs/helix/04-build/evidence'/p for p in ['qualified-property-layout-0.15.owner-export.sql','source-epoch-storage.owner-export.sql','operation-configuration-storage.owner-export.sql'])
preimages={str(p):p.read_bytes() for p in sorted(paths)}
container=None;inventory=None;cleanup=None;failure=None;native=None
try:
 suffix=uuid.uuid4().hex;dbname='truss_scalar_cohort_'+suffix
 created=subprocess.run(['docker','run','-d','--name','truss-scalar-cohort-'+suffix,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+dbname,'-p','127.0.0.1::5432','postgres:17.9'],capture_output=True,text=True,timeout=60)
 if created.returncode:raise RuntimeError('Owned fixture creation failed: '+created.stderr)
 container=created.stdout.strip()
 if len(container)!=64 or any(c not in '0123456789abcdef' for c in container):raise RuntimeError('Unexpected container identity')
 inspected=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
 ports=inspected['NetworkSettings']['Ports']['5432/tcp']
 if inspected['Id']!=container or len(ports)!=1 or ports[0]['HostIp']!='127.0.0.1':raise RuntimeError('Exact loopback fixture correspondence required')
 inventory={'containerId':container,'imageId':inspected['Image'],'database':dbname,'port':ports[0]['HostPort'],'scope':'Owned disposable native candidate collector fixture'}
 ready=False
 for _ in range(60):
  probe=subprocess.run(['docker','exec',container,'pg_isready','-U','postgres','-d',dbname],capture_output=True,text=True,timeout=5)
  if probe.returncode==0:ready=True;break
  time.sleep(.25)
 if not ready:raise RuntimeError('Fixture readiness exhausted')
 env['TRUSS_OPERATION_TEST_URL']='postgres://postgres@127.0.0.1:'+ports[0]['HostPort']+'/'+dbname
 env['TRUSS_COHORT_EVIDENCE']=str(out/'native.json')
 native=subprocess.run(['bun','scripts/check-catalog-new-cohort.ts'],env=env,capture_output=True,text=True,timeout=120)
 (out/'native.log').write_text(native.stdout+native.stderr)
 if native.returncode:raise RuntimeError('Native composition failed: '+str(native.returncode))
except Exception as e:failure=str(e)
finally:
 if container:
  removed=subprocess.run(['docker','rm','-f',container],capture_output=True,text=True,timeout=30);cleanup={'containerId':container,'exitCode':removed.returncode,'stdout':removed.stdout.strip(),'stderr':removed.stderr.strip()}
  if removed.returncode and not failure:failure='Owned fixture cleanup failed'
 if failure:(out/'failure.json').write_text(json.dumps({'failure':failure,'nativeFixture':inventory,'cleanup':cleanup},indent=2)+'\n')
if failure:raise RuntimeError(failure)
if any(Path(p).read_bytes()!=b for p,b in preimages.items()):raise RuntimeError('Captured native input changed')
with zipfile.ZipFile(out/'sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for i,(p,b) in enumerate(preimages.items()):z.writestr(str(i)+'/'+Path(p).name,b)
receipt={'status':'passed','command':['bun','scripts/check-catalog-new-cohort.ts'],'exitCode':native.returncode,'sourcePreimages':[{'path':p,'archive':str(i)+'/'+Path(p).name,'sha256':sha(b)} for i,(p,b) in enumerate(preimages.items())],'nativeFixture':inventory,'cleanup':cleanup,'nativeReceiptSha256':sha((out/'native.json').read_bytes()),'nativeLogSha256':sha((out/'native.log').read_bytes()),'scope':'Actual PostgreSQL17.9 private new-cohort/report/observer correspondence with original scalar owner duties; no installed scalar data enforcement, authenticated issuer, complete accepted-report authority/publication/finalizer or public admission','premises':['Local Bun/dependencies and Docker image/runtime, not hermetic','Host2823413d config absence and owner custody premises remain; self-declared producer manifests are not issuer authentication'],'acceptancePromoted':False}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':'passed','sourcePins':len(preimages),'checks':len(json.loads((out/'native.json').read_text())['checks']),'receipt':str(out/'receipt.json'),'cleanup':cleanup['exitCode']}))
