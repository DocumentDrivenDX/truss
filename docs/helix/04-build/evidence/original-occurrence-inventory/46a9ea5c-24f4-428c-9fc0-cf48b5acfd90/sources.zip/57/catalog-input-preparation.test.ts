import {test,expect} from 'bun:test';
import {createCatalogInputPreparation} from '../packages/umf-bun/src/catalog-input';
import {createAcceptanceProfileResolver} from '../packages/umf-bun/src/acceptance-profiles';
import {prepareDefaultCatalogHomes} from '../packages/umf-bun/src/catalog-default-homes';
const directory=process.env.TRUSS_UMF_PRODUCER;if(!directory)throw Error('Original Record producer directory required');
const preparation=await createCatalogInputPreparation(directory,'/Users/erik/Projects/umf/package.json');
const fixture=await Bun.file('docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json').json();
function request(){const input=structuredClone(fixture.input);input.binding={state:'absent'};input.transforms=[];
 input.documents=['first-doc','second-doc'].map(documentId=>{const original=' \n'+JSON.stringify({umf:'0.7.0',id:documentId,vocabularies:{},extensions:{},modules:[{id:'m',namespace:'m',elements:[{id:'Item',kind:'record',members:[{module:'m',element:'label'}],extensions:{}},{id:'label',kind:'field',scalarType:'string',nullability:'required',cardinality:'one',extensions:{}}]}]})+'\n';const bytes=Buffer.from(original);return {documentId,documentRevision:'original-r1',artifact:{identity:documentId,bytesBase64:bytes.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')},umfProfile:preparation.umfProfile,ingress:{kind:'native'}}});return input}
const run=(input:unknown)=>preparation.prepare(new TextEncoder().encode(JSON.stringify(input)));
test('real owner validates original ordered UMF sources with reversible interpretation',()=>{const input=request();const result=run(input);expect(result.documents.map(d=>d.documentId)).toEqual(['first-doc','second-doc']);for(let i=0;i<2;i++){const doc=result.documents[i]!;expect(doc.originalText).toBe(Buffer.from(input.documents[i].artifact.bytesBase64,'base64').toString());expect(doc.umfVersion).toBe('0.7.0');expect(doc.interpretation.target.umf).toBe('0.8.0');expect(doc.validation.sourceValidation.valid).toBe(true);expect(doc.validation.transition).not.toBeNull()}expect(result.scope).toBe('original_umf_preparation_only')});
test('foreign original interpretation profile cannot borrow validation',()=>{const input=request();input.documents[0].umfProfile={...preparation.umfProfile,sha256:'0'.repeat(64)};expect(()=>run(input)).toThrow('Unsupported original UMF profile')});
test('archive document identity must equal original owner source',()=>{const input=request();input.documents[0].documentId='other';expect(()=>run(input)).toThrow('Original document identity mismatch')});
test('shape-only original {} source does not become accepted UMF',()=>{const input=request();const bytes=Buffer.from('{}');input.documents[0].artifact={identity:'invalid',bytesBase64:bytes.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')};expect(()=>run(input)).toThrow()});

test('native archive carrier has exact five original fields without interpretation substitution',()=>{const result=run(request());expect(Object.keys(result.archiveDocuments[0]).sort()).toEqual(['documentId','originalText','revision','umfVersion','validation']);expect(Object.isFrozen(result.archiveDocuments[0].validation)).toBe(true)});

test('source declaration extraction preserves original owner and Field references',()=>{const result=run(request());expect(result.declarations.map(d=>d.records[0].documentId)).toEqual(['first-doc','second-doc']);const record=result.declarations[0].records[0];expect([record.moduleId,record.elementId]).toEqual(['m','Item']);expect(record.fields[0].declaration).toBe(result.documents[0].interpretation.source.modules[0].elements[1]);expect(record.fields[0].reference).toEqual({module:'m',element:'label'});expect(Object.isFrozen(record.fields[0].declaration)).toBe(true)});

test('configured original registry refuses unregistered synthetic root profiles',async()=>{const guarded=await createCatalogInputPreparation(directory!,'/Users/erik/Projects/umf/package.json',createAcceptanceProfileResolver([]));expect(()=>guarded.prepare(new TextEncoder().encode(JSON.stringify(request())))).toThrow('/layoutProfile')});

test('absent binding derives complete default json homes from original members',()=>{const result=run(request());const defaults=prepareDefaultCatalogHomes(result);expect(defaults.homes).toEqual(['first-doc','second-doc'].map(documentId=>({documentId,moduleId:'m',elementId:'Item',fieldModule:'m',fieldId:'label',home:'json'})));expect(defaults.originalInputSha256).toBe(new Bun.CryptoHasher('sha256').update(Buffer.from(result.original.originalUtf8Hex,'hex')).digest('hex'));expect(Object.isFrozen(defaults.homes[0])).toBe(true)});
test('present binding cannot be silently replaced with default homes',()=>{const input=request();input.binding=structuredClone(fixture.input.binding);expect(()=>prepareDefaultCatalogHomes(run(input))).toThrow('Original explicit binding home interpretation required')});

test('embedded duplicate source members refuse before owner interpretation',()=>{
 const input=request();const text=Buffer.from(input.documents[0].artifact.bytesBase64,'base64').toString().replace('"id":"first-doc"','"id":"discarded","id":"first-doc"');const bytes=Buffer.from(text);
 input.documents[0].artifact={identity:'duplicate-source',bytesBase64:bytes.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')};
 expect(()=>run(input)).toThrow('duplicate_member');
});

test('reconstructed preparations cannot enter home, extension, report or native staging helpers',async()=>{
 const {collectCatalogExtensionInventory}=await import('../packages/umf-bun/src/catalog-extension-inventory');
 const {collectCatalogReportDocumentBasis}=await import('../packages/umf-bun/src/catalog-report-document-basis');
 const {stageNewCatalogCohort}=await import('../packages/umf-bun/src/catalog-new-stage');
 const original=run(request()),clone=structuredClone(original);let calls=0;const connection={unsafe:async()=>{calls++;return []}};
 expect(()=>prepareDefaultCatalogHomes(clone)).toThrow('validated catalog preparation');
 expect(()=>collectCatalogExtensionInventory(clone)).toThrow('validated catalog preparation');
 await expect(collectCatalogReportDocumentBasis(connection,clone,'1')).rejects.toThrow('validated catalog preparation');
 await expect(stageNewCatalogCohort(connection,clone,[],{})).rejects.toThrow('validated catalog preparation');
 expect(calls).toBe(0);expect(prepareDefaultCatalogHomes(original).homes.length).toBe(2);
});

test('new-only staging cannot silently ignore declared transforms',async()=>{
 const {stageNewCatalogCohort}=await import('../packages/umf-bun/src/catalog-new-stage');const input=request();input.transforms=structuredClone(fixture.input.transforms);const original=run(input);let calls=0;
 await expect(stageNewCatalogCohort({unsafe:async()=>{calls++;return []}},original,prepareDefaultCatalogHomes(original).homes,{})).rejects.toThrow('Complete transform execution');expect(calls).toBe(0);
});

test('UMF report basis never invents a supported-subset artifact for unregistered preparation',async()=>{
 const {collectCatalogUmfReportBasis}=await import('../packages/umf-bun/src/catalog-umf-report-basis');
 const original=run(request());
 expect(()=>collectCatalogUmfReportBasis(original)).toThrow('registered support artifact');
 expect(()=>collectCatalogUmfReportBasis({...original})).toThrow('validated catalog preparation');
});

test('UMF report basis preserves actual original version and registered bytes without a support claim',async()=>{
 const {collectCatalogUmfReportBasis}=await import('../packages/umf-bun/src/catalog-umf-report-basis');
 const input=request();
 const registrations:import('../packages/umf-bun/src/acceptance-profiles').AcceptanceProfileRegistration[]=[];
 for(const [role,key] of [['layout','layoutProfile'],['acceptance','acceptanceProfile'],['validator','validatorProfile'],['support','supportProfile']] as const){
  const bytes=new TextEncoder().encode('authored byte custody only: '+role),profile={identity:role,version:'test',sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')};
  input[key]=profile;registrations.push({role,profile,artifactIdentity:role,bytes});
 }
 const policyBytes=new TextEncoder().encode('policy byte custody');input.policy.profile={identity:'policy',version:'test',sha256:new Bun.CryptoHasher('sha256').update(policyBytes).digest('hex')};
 registrations.push({role:'policy',profile:input.policy.profile,artifactIdentity:'policy',bytes:policyBytes});
 registrations.push({role:'umf',profile:preparation.umfProfile,artifactIdentity:'original-owner-bundle',bytes:new Uint8Array(await Bun.file(directory+'/producer.js').arrayBuffer())});
 const guarded=await createCatalogInputPreparation(directory!,'/Users/erik/Projects/umf/package.json',createAcceptanceProfileResolver(registrations));
 const basis=collectCatalogUmfReportBasis(guarded.prepare(new TextEncoder().encode(JSON.stringify(input))));
 expect(basis.sourceVersions).toEqual(['0.7.0']);expect(basis.interpretationProfile).toEqual(preparation.umfProfile);
 expect(Buffer.from(basis.supportArtifact.bytesBase64,'base64').toString()).toBe('authored byte custody only: support');
 expect(basis.supportProfile).toEqual(input.supportProfile);expect(Object.isFrozen(basis.sourceVersions)).toBe(true);
 expect(basis.scope).toBe('original_umf_and_support_byte_basis_only');expect('supportedSubset' in basis).toBe(false);
});

test('optional original primary markers project without changing source or ordered keys',async()=>{
 const {stageNewCatalogCohort}=await import('../packages/umf-bun/src/catalog-new-stage');
 for(const marker of [undefined,false,true]){
  const input=request();input.documents=input.documents.slice(0,1);
  const source=JSON.parse(Buffer.from(input.documents[0].artifact.bytesBase64,'base64').toString());
  const record=source.modules[0].elements[0];record.members.push({module:'m',element:'code'});
  source.modules[0].elements.push({id:'code',kind:'field',scalarType:'string',nullability:'required',cardinality:'one',extensions:{}});
  record.keys=[{id:'identity',name:'identity',fields:[{module:'m',element:'code'},{module:'m',element:'label'}],...(marker===undefined?{}:{primary:marker})}];
  const original=JSON.stringify(source),bytes=Buffer.from(original);input.documents[0].artifact={identity:'first-doc',bytesBase64:bytes.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')};
  const prepared=run(input);let candidates:unknown;let archive:unknown;
  const connection={unsafe:async(query:string,parameters?:unknown[])=>{
   if(query.includes('runtime_stage_catalog_documents')){archive=JSON.parse(parameters![0] as string);return [{provisional_revision:'1'}]}
   if(query.includes('runtime_stage_new_types'))return [{document_id:'first-doc',module_id:'m',element_id:'Item',type_id:'10'}];
   if(query.includes('runtime_stage_new_properties'))return ['label','code'].map((field_id,i)=>({owner_type_id:'10',field_module:'m',field_id,property_id:String(20+i)}));
   if(query.includes('runtime_stage_new_keys'))candidates=JSON.parse(parameters![1] as string);
   return [];
  }};
  await stageNewCatalogCohort(connection,prepared,prepareDefaultCatalogHomes(prepared).homes,{});
  expect(candidates).toEqual([{ownerTypeId:'10',keyId:'identity',primary:marker===true,propertyIds:['21','20']}]);
  expect((archive as {originalText:string}[])[0].originalText).toBe(original);
  expect(Object.hasOwn(prepared.declarations[0].records[0].keys[0],'primary')).toBe(marker!==undefined);
 }
});

test('non-Boolean primary markers fail original owner validation',()=>{
 const input=request();const source=JSON.parse(Buffer.from(input.documents[0].artifact.bytesBase64,'base64').toString());
 source.modules[0].elements[0].keys=[{id:'identity',name:'identity',fields:[{module:'m',element:'label'}],primary:'false'}];
 const bytes=Buffer.from(JSON.stringify(source));input.documents[0].artifact={identity:'first-doc',bytesBase64:bytes.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(bytes).digest('hex')};
 expect(()=>run(input)).toThrow();
});
