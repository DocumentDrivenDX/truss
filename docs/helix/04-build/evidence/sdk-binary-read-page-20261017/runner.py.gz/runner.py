from pathlib import Path
from contextlib import contextmanager
from datetime import timedelta
import hashlib,json,os,unittest
import psycopg,weft
from psycopg import sql
import test_catalog_runtime_native as base
from truss import CatalogDocument,ModuleAccessGrant,Ok,adopt_psycopg_host,create_reference_assembly,CatalogRuntimeConfiguration
from truss.contracts import MapValue,TextValue,NullValue
from truss.groups import CreateObject,AuthoredValue,RootlessOwnership,GroupSuccess
from truss.access import TrussTarget
from umf_access.engine_catalog import EngineRead
from umf_access.types import StrictModel,MISSING
from truss_binary.models import A
OUT=Path('/private/tmp/truss-binary-pair-preflight-20261017-native');OUT.mkdir(exist_ok=False)
MODEL=Path('/private/tmp/sdk-truss-binary-public-fixture-prep-r1/logical-model.json').read_bytes()
assert hashlib.sha256(MODEL).hexdigest()=='66a6d1de95c95580190a2005deb0d2a72fa4e9262f64c1fe8fe1d6ddc78fcfe5'
class Parameters(StrictModel):pass
class Pair(base.PublicCatalogRuntimeTests):
 for name in tuple(n for n in dir(base.PublicCatalogRuntimeTests) if n.startswith('test_')):locals()[name]=None
 def test_genuine_binary_read_page(self):
  self.install();c,h,a,t=self.consumer();docs=(CatalogDocument('adoc','r1',MODEL),)
  prepared=a.prepare_catalog(docs,source_version='0.8.0',bun_executable=os.environ['TRUSS_BUN_EXECUTABLE'])
  accepted=a.accept_in_transaction(t,prepared,request_key='binary-exact-model');self.assertIsInstance(accepted,Ok,repr(accepted))
  h.detach();c.commit()
  for role in ('binary_reader','binary_writer'):
   self.admin.execute(sql.SQL('CREATE ROLE {} NOLOGIN').format(sql.Identifier(role)));self.addCleanup(self.admin.execute,sql.SQL('DROP ROLE {}').format(sql.Identifier(role)))
  self.admin.execute('BEGIN');ah=adopt_psycopg_host(self.admin);at=ah.adopt_transaction().value;aa=create_reference_assembly(CatalogRuntimeConfiguration(),ah).value
  configured=aa.configure_module_access_in_transaction(at,(ModuleAccessGrant('adoc','m','binary_reader','binary_writer'),));self.assertIsInstance(configured,Ok);ah.detach();self.admin.commit()
  self.admin.execute('GRANT binary_reader,binary_writer TO consumer WITH SET FALSE');self.admin.execute(sql.SQL('REVOKE {} FROM consumer').format(sql.Identifier(self.installation.registrar_role)))
  c,h,a,t=self.consumer();ref=a.get_type_reference_in_transaction(t,document_id='adoc',module_id='m',record_id='A').value;context=a.group_context_in_transaction(t).value
  ops=[]
  for label,optional in [('absent',None),('empty',TextValue(kind='binary',text='')),('null',NullValue()),('present',TextValue(kind='binary',text='AP8='))]:
   values=[AuthoredValue(name='A-label',value=TextValue(kind='string',text=label)),AuthoredValue(name='A-value',value=TextValue(kind='string',text='value')),AuthoredValue(name='blob',value=TextValue(kind='binary',text='' if label=='empty' else 'AP8='))]
   if optional is not None:values.append(AuthoredValue(name='optional_blob',value=optional))
   ops.append(CreateObject(type_definition_pin=ref.definition_pin,values=tuple(values),ownership=RootlessOwnership()))
  result=a.apply_in_transaction(t,context.input(tuple(ops),MapValue(entries=())),context.request('binary-seed'),documents=docs,bun_executable=os.environ['TRUSS_BUN_EXECUTABLE']);self.assertIsInstance(result,Ok,repr(result));self.assertIsInstance(result.value,GroupSuccess,repr(result))
  h.detach();c.commit()
  query='SELECT a."A-label" AS label,a."A-value" AS value,a.blob AS blob,a.optional_blob AS optional_blob FROM "A" a'
  c.execute('BEGIN READ ONLY');h=adopt_psycopg_host(c);t=h.adopt_transaction(access_mode='read_only').value;a=create_reference_assembly(CatalogRuntimeConfiguration(),h).value
  sources=a.query_catalog_sources_in_transaction(t,sql=query+' ORDER BY a."A-label" ASC LIMIT 10',document_ids=('adoc',));self.assertIsInstance(sources,Ok,repr(sources));request=json.loads(sources.value.request_json)
  ps=a.query_catalog_sources_in_transaction(t,sql=query,document_ids=('adoc',));self.assertIsInstance(ps,Ok);page_request=json.loads(ps.value.request_json)
  h.detach();c.rollback()
  entry=EngineRead.build(weft,request,parameters=Parameters,result=A,method='truss-runtime-binary')
  page_entry=EngineRead.build(weft,page_request,parameters=Parameters,result=A,method='truss-runtime-binary',page_size=2,selected_key={'module':'m','record':'A','key':'a-primary'})
  @contextmanager
  def operation(budget):
   c.execute('BEGIN READ ONLY');host=adopt_psycopg_host(c,statement_timeout_ms=10000,operation_timeout_ms=30000)
   try:
    tx=host.adopt_transaction(access_mode='read_only').value;assembly=create_reference_assembly(CatalogRuntimeConfiguration(),host).value;yield assembly,tx
   except BaseException:host.detach();c.rollback();raise
   else:host.detach();c.commit()
  target=TrussTarget(operation,binding_sha256=request['target']['bindingSha256'],platform=(('postgresql','18.6'),),default_timeout=timedelta(seconds=10),catalog_entries=(entry,page_entry))
  rows=target.read(entry,Parameters());self.assertEqual([r.label for r in rows],['absent','empty','null','present'])
  self.assertIs(rows[0].optional_blob,MISSING);self.assertEqual(rows[1].optional_blob,b'');self.assertIsNone(rows[2].optional_blob);self.assertEqual(rows[3].optional_blob,b'\x00\xff');self.assertEqual(rows[1].blob,b'')
  first=target.page(page_entry,Parameters());self.assertIsNotNone(first.next_after);second=target.page(page_entry,Parameters(),after=first.next_after);self.assertIsNone(second.next_after)
  self.assertEqual([r.label for r in first.items+second.items],['absent','empty','null','present']);target.verify()
  (OUT/'original-model.json').write_bytes(MODEL);(OUT/'read-program.json').write_text(entry.originals());(OUT/'page-program.json').write_text(page_entry.originals());(OUT/'native-request.json').write_text(sources.value.request_json)
  (OUT/'receipt.json').write_text(json.dumps({'status':'passed','scope':'R27/R24 private candidate read/page preflight, not stream/final release','postgresql':self.admin.info.server_version,'psycopg':psycopg.__version__,'weft':weft.__version__,'modelSha256':hashlib.sha256(MODEL).hexdigest(),'checks':['public exact-byte catalog registration','public four-object apply and actual commit','generated A binary bytes/null/MISSING','required binary empty and 00ff','explicit primary-Key two-page continuation','fresh native artifact correspondence','target verify native read/page']},indent=2)+'\n')
if __name__=='__main__':unittest.main(verbosity=2)
