mapping = decode_owner_evidence_json(joined.report)
self.assertEqual(mapping['version'], 'truss.native-model.correspondence/0.1-candidate')
self.assertEqual(mapping['scope'], 'actual-context-native-record-member-key-correspondence')
for flag in ('complete', 'authority', 'securityReady'):
    self.assertIs(mapping[flag], False)
self.assertEqual(mapping['nativeAdmission'], 'required')
self.assertEqual(mapping['preparationSha256'], hashlib.sha256(context.json().encode()).hexdigest())
originals = [('accepted-request', capture.accepted_request), ('accepted-assessment', capture.accepted_assessment), ('runtime-release', capture.runtime_release), ('native-inventory', capture.native_inventory), ('issued-requirements', requirements)]
self.assertEqual(mapping['sources'], [{'role': role, 'sha256': hashlib.sha256(value).hexdigest(), 'bytes': len(value)} for role, value in originals])
object_oid = self.admin.execute("SELECT 'truss.object'::regclass::oid::text").fetchone()[0]
physical = {name: {'attnum': attnum, 'typeOid': oid} for attnum, name, oid in self.admin.execute("SELECT attnum,attname,atttypid::text FROM pg_attribute WHERE attrelid='truss.object'::regclass AND attname IN ('id','type_id','props') AND NOT attisdropped").fetchall()}
self.assertEqual({n: c['typeOid'] for n, c in physical.items()}, {'id': '20', 'type_id': '23', 'props': '3802'})
self.assertEqual(len(mapping['records']), len(expected))
refs = [tuple((row['record'][k] for k in ('documentId', 'revision', 'module', 'element'))) for row in mapping['records']]
self.assertEqual(len(set(refs)), len(expected))
self.assertEqual({row['record']['element'] for row in mapping['records']}, set(expected))
self.assertEqual(len({row['typeId'] for row in mapping['records']}), len(expected))
for row in mapping['records']:
    name = row['record']['element']
    gold = native_mapping[name]
    fields, key_fields = expected[name]
    ref = lambda element: {'documentId': 'domain', 'revision': pin['revision'], 'module': 'm', 'element': element}
    self.assertEqual(row['record'], ref(name))
    self.assertEqual(row['typeId'], gold['typeId'])
    self.assertEqual(row['objectHome'], {'relationOid': object_oid, 'columns': physical})
    self.assertEqual(row['fields'], [{'field': ref(field), 'propertyId': gold['properties'][field], 'jsonKey': str(gold['properties'][field])} for field in fields])
    self.assertEqual(len({f['propertyId'] for f in row['fields']}), len(fields))
    self.assertEqual(row['selectedKey'], {'id': 'pk', 'fields': [ref(field) for field in key_fields], 'keyNum': gold['keyNum'], 'propertyIds': [gold['properties'][field] for field in key_fields]})
    exact = {'record': ref(name), 'typeId': gold['typeId'], 'objectHome': {'relationOid': object_oid, 'columns': physical}, 'fields': [{'field': ref(field), 'propertyId': gold['properties'][field], 'jsonKey': str(gold['properties'][field])} for field in fields], 'selectedKey': {'id': 'pk', 'fields': [ref(field) for field in key_fields], 'keyNum': gold['keyNum'], 'propertyIds': [gold['properties'][field] for field in key_fields]}}
    self.assertTrue(same_owner_evidence(row, exact), 'Complete type-exact joined mapping required')
