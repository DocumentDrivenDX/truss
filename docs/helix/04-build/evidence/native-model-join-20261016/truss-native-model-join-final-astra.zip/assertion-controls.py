from pathlib import Path
import sys,ast,json,copy,unittest,hashlib
from types import SimpleNamespace
r=Path(__file__).resolve().parent;e=r/'native';sys.path[:0]=[str(r/'installed'),str(r/'compiler')];from truss._owner_evidence_json import decode_owner_evidence_json,same_owner_evidence
import weft
parent=weft.prepare_application_lineage((e/'weft-original-request.json').read_text());context=parent.prepare_current_presence();requirements=(e/'issued-requirements.json').read_bytes();assert context.model_requirements_json().encode()==requirements
capture=SimpleNamespace(**{k:(e/v).read_bytes() for k,v in [('accepted_request','accepted-request.json'),('accepted_assessment','accepted-assessment.json'),('runtime_release','runtime-release.json'),('native_inventory','native-inventory.json')]});pin=json.loads(requirements)['modelPins'][0];native_mapping=json.loads((e/'native-field-key-mapping.json').read_bytes());inventory=json.loads(capture.native_inventory);home=next(x for x in inventory['relations'] if x['name']=='object');expected={'Staff':(['staffId'],['staffId']),'Project':(['projectId'],['projectId']),'Resource':(['resourceId','salary','token'],['resourceId']),'Ownership':(['ownerId','ownerResource','ownerProject'],['ownerId']),'Assignment':(['assignmentId','assignmentStaff','assignmentProject','active'],['assignmentId'])}
class Admin:
 def execute(self,sql):
  if sql=="SELECT 'truss.object'::regclass::oid::text":return SimpleNamespace(fetchone=lambda:(home['oid'],))
  if sql=="SELECT attnum,attname,atttypid::text FROM pg_attribute WHERE attrelid='truss.object'::regclass AND attname IN ('id','type_id','props') AND NOT attisdropped":return SimpleNamespace(fetchall=lambda:[(c['attnum'],c['name'],c['typeOid']) for c in home['columns'] if c['name'] in ['id','type_id','props'] and not c['dropped']])
  raise AssertionError('Unexpected SQL mock request')
s=(r/'captured/owner/test_native_model_correspondence_native.py').read_text();tree=ast.parse(s);fn=next(n for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_exact'));start=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mapping' for t in n.targets));stop=next(i for i,n in enumerate(fn.body[start:],start) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='retain');block=ast.fix_missing_locations(ast.Module(body=fn.body[start:stop],type_ignores=[]));(r/'extracted-assertions.py').write_text(ast.unparse(block)+'\n');code=compile(block,'exact-native-test-R2-assertions','exec');original=json.loads((e/'joined-report.json').read_bytes())
def check(m):
 self=unittest.TestCase();self.admin=Admin();exec(code,{'self':self,'decode_owner_evidence_json':decode_owner_evidence_json,'same_owner_evidence':same_owner_evidence,'joined':SimpleNamespace(report=json.dumps(m).encode()),'context':context,'capture':capture,'requirements':requirements,'hashlib':hashlib,'native_mapping':native_mapping,'expected':expected,'pin':pin})
check(original);rows=[]
def mutant(name,edit):
 m=copy.deepcopy(original);edit(m)
 try:check(m);caught=False
 except (AssertionError,KeyError,TypeError,ValueError):caught=True
 rows.append({'id':name,'caught':caught});assert caught,name
mutant('duplicate-Record-five-times',lambda m:m.update(records=[copy.deepcopy(m['records'][0]) for _ in range(5)]))
for key in ['documentId','revision','module','element']:mutant('record-'+key,lambda m,k=key:m['records'][0]['record'].update({k:'foreign'}))
for key in ['documentId','revision','module','element']:mutant('field-'+key,lambda m,k=key:m['records'][0]['fields'][0]['field'].update({k:'foreign'}))
for key in ['documentId','revision','module','element']:mutant('key-field-'+key,lambda m,k=key:m['records'][0]['selectedKey']['fields'][0].update({k:'foreign'}))
for name,edit in [('key-id',lambda m:m['records'][0]['selectedKey'].update(id='other')),('json-key',lambda m:m['records'][0]['fields'][0].update(jsonKey='99999')),('native-key-properties',lambda m:m['records'][0]['selectedKey'].update(propertyIds=[99999])),('object-OID',lambda m:m['records'][0]['objectHome'].update(relationOid='99999')),('type-ID',lambda m:m['records'][0].update(typeId=99999)),('key-number-bool',lambda m:m['records'][0]['selectedKey'].update(keyNum=True)),('type-ID-float',lambda m:m['records'][0].update(typeId=float(m['records'][0]['typeId']))),('property-ID-float',lambda m:m['records'][0]['fields'][0].update(propertyId=float(m['records'][0]['fields'][0]['propertyId']))),('attnum-bool',lambda m:m['records'][0]['objectHome']['columns']['id'].update(attnum=True)),('unknown-row-member',lambda m:m['records'][0].update(extra=True)),('field-order',lambda m:m['records'][0]['fields'].reverse())]:mutant(name,edit)
for key in ['authority','complete','securityReady']:mutant('flag-'+key,lambda m,k=key:m.update({k:0}))
for key,value in [('version','unknown'),('scope','unknown'),('nativeAdmission','admitted'),('preparationSha256','0'*64)]:mutant('profile-'+key,lambda m,k=key,v=value:m.update({k:v}))
mutant('source-hash',lambda m:m['sources'][0].update(sha256='0'*64));mutant('source-order',lambda m:m['sources'].reverse());mutant('source-bytes',lambda m:m['sources'][0].update(bytes=1))
(r/'assertion-controls.json').write_text(json.dumps({'passed':True,'baselinePasses':True,'mutants':rows,'caught':len(rows),'SQLExecuted':False,'scope':'Exact R2 assertion block over captured native R4 data; actual physical SQL statements emulated from captured inventory; actual reviewed compiler reissue. Independent assertion/control replay only; supplied native campaign is audited separately.'},indent=2)+'\n');print(len(rows))
