from pathlib import Path
import sys,os,unittest,json,importlib.abc,hashlib
r=Path(__file__).resolve().parent;sys.path[:0]=[str(r/'installed'),str(r/'test-source/packages/python/tests')];attempts=[]
if '--default' in sys.argv or '--old-flag' in sys.argv:
 for key in ['TRUSS_MODEL_JOIN_WEFT_QUALIFICATION','TRUSS_NATIVE_MODEL_JOIN_QUALIFICATION','TRUSS_MODEL_CORRESPONDENCE_QUALIFICATION']:os.environ.pop(key,None)
 class Deny(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname=='weft' or fullname.startswith('weft.'):attempts.append(fullname);raise ImportError('Weft intentionally absent')
 sys.meta_path.insert(0,Deny());name='default';names=['test_native_model_correspondence','test_native_model_correspondence_native','test_native_model_correspondence_qualification']
 if '--old-flag' in sys.argv:os.environ['TRUSS_MODEL_CORRESPONDENCE_QUALIFICATION']='1';name='old-flag';names=['test_native_model_correspondence_native']
else:
 os.environ['TRUSS_MODEL_JOIN_WEFT_QUALIFICATION']='1';sys.path.insert(0,str(r/'compiler'));name='selected';names=['test_owner_evidence_json','test_native_source_descriptor','test_native_source_observation','test_native_model_correspondence']
import truss
assert Path(truss.__file__).is_relative_to(r/'installed');assert not hasattr(truss,'NativeModelCorrespondence') and not hasattr(truss,'capture_native_model_correspondence_with_cursor')
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
# Any unexpectedly activated native class must fail before database setup.
started=[]
def trap(cls):started.append(cls.__name__);raise AssertionError('native execution prohibited')
for module in ['test_native_model_correspondence_native','test_native_model_correspondence_qualification']:
 if module in sys.modules:sys.modules[module].NativeModelCorrespondenceTests.setUpClass=classmethod(trap)
result=unittest.TextTestRunner(verbosity=2).run(suite);assert result.wasSuccessful() and not started and not attempts
loaded={}
for key,module in list(sys.modules.items()):
 path=getattr(module,'__file__',None)
 if path and key.startswith('truss'):
  p=Path(path);assert p.is_relative_to(r/'installed'),str(p);loaded[key]={'path':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(r/f'installed-{name}.json').write_text(json.dumps({'passed':True,'tests':result.testsRun,'skipped':len(result.skipped),'WeftImportAttempts':attempts,'nativeSetupCalls':started,'loadedTrussModules':loaded,'SQLExecuted':False},indent=2)+'\n')
