from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,io,email,tomllib,collections
r=Path(__file__).resolve().parent;o=Path('/private/tmp/truss-native-model-join-native-r4-20261016');i=Path('/private/tmp/truss-disclosure-main-integration-20261016');p=Path('/private/tmp/truss-native-model-join-package-owner-20261016');prior=Path('/private/tmp/truss-native-model-join-astra-r3-20261016');H=lambda b:hashlib.sha256(b).hexdigest();base='cf8ccbad907de4b5303db70ea1f7da72f621cefa'
shutil.copytree(o,r/'native',dirs_exist_ok=True);shutil.copyfile(str(o)+'.log',r/'native.log');shutil.copyfile('/private/tmp/truss-native-model-join-installed-tests-20261016.log',r/'owner-installed-tests.log')
for n in ['check-wheel.py','source-before.json','wheel-correspondence.json']:
 target=r/'packaging'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/n,target)
w=next((p/'wheel').glob('*.whl'));shutil.copyfile(w,r/'packaging'/w.name);wb=w.read_bytes();assert H(wb)=='65ad3a725bacc5f27204998aa8ae943497da82ff19d1bfeb405490a5ddb1144f'
sp=json.loads((p/'source-before.json').read_bytes());runtime=json.loads((prior/'packet/candidate/runtime-overlay-manifest.json').read_bytes())
for n,v in sp.items():b=(p/'source'/n).read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'],n
with zipfile.ZipFile(io.BytesIO(wb)) as z:
 expected={'src/'+n for n in z.namelist() if n.startswith('truss/') and not n.endswith('/')};assert expected=={n for n in sp if n.startswith('src/truss/')};assert len(expected)==501
 for n in expected:
  b=z.read(n[4:]);assert H(b)==sp[n]['sha256'] and b==(p/'installed'/n[4:]).read_bytes();assert H(b)==runtime[n[4:]]['sha256'];assert b==(i/'packages/python'/n).read_bytes()
 metadata=email.message_from_bytes(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))));assert metadata['Version']=='0.0.38.dev0';requirements=metadata.get_all('Requires-Dist');z.extractall(r/'installed')
pyproject=subprocess.check_output(['git','-C',str(i),'show',base+':packages/python/pyproject.toml']);assert pyproject==(i/'packages/python/pyproject.toml').read_bytes()==(p/'source/pyproject.toml').read_bytes();(r/'packaging/pyproject.toml').write_bytes(pyproject)
project=tomllib.loads(pyproject.decode())['project'];assert metadata['Version']==project['version'];expectedrequirements=project['dependencies']+ [v+'; extra == "'+extra+'"' for extra,values in project['optional-dependencies'].items() for v in values];assert requirements==expectedrequirements,(requirements,expectedrequirements)
pins=json.loads((r/'native/source-before.json').read_bytes());assert len(pins)==1872;classes=collections.Counter();deltas={};currentdifferent=[]
with zipfile.ZipFile(r/'native/source-inputs.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(pins) and set(z.namelist())==set(pins)
 batch=subprocess.Popen(['git','-C',str(i),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 for n,v in pins.items():
  b=z.read(n);assert H(b)==v['sha256'] and len(b)==v['bytes'],n;kind=n.split('/')[0];classes[kind]+=1
  if kind=='base':
   rel=n[5:];batch.stdin.write((base+':'+rel+'\n').encode());batch.stdin.flush();head=batch.stdout.readline().decode().split();old=None
   if head[-1]!='missing':old=batch.stdout.read(int(head[2]));assert batch.stdout.read(1)==b'\n'
   if old!=b:deltas[rel]=v
   if not (i/rel).is_file() or (i/rel).read_bytes()!=b:currentdifferent.append(rel)
   if rel.startswith('packages/python/tests/') or rel.startswith('docs/helix/02-design/contracts/bindings/'):
    f=r/'test-source'/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
  if kind=='runtime-stage':assert H(b)==runtime[n[len('runtime-stage/'):]]['sha256'],n
  if kind=='owner':
   f=r/'captured'/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
 batch.stdin.close();assert batch.wait()==0
 assert z.read('owner/test_native_model_correspondence_native.py')==Path('/private/tmp/truss-native-model-join-native-astra-r2-20261016/test-r4-prefix.py').read_bytes()
 assert H(z.read('toolchain/weft.whl'))=='e072db75724608d652f3368ab1375907c3fbf2cd1e321a0d7a04bbdad4d92778'
 assert (r/'native/runtime-release.json').read_bytes()==z.read('runtime-stage/truss/_catalog_runtime/manifest.json')
 for name in ['_native_model_correspondence.py','_owner_evidence_json.py']:assert z.read('owner/packages/python/src/truss/'+name)==(prior/'packet/candidate/packages/python/src/truss'/name).read_bytes()
 for n in z.namelist():
  if n.startswith('weft/'):
   f=r/'compiler'/n[5:];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read(n))
 with zipfile.ZipFile(io.BytesIO(z.read('toolchain/weft.whl'))) as wheel:
  for n in wheel.namelist():assert wheel.read(n)==z.read('weft/'+n)
expected={str(x.relative_to(prior/'packet/candidate')):(x.read_bytes()) for x in (prior/'packet/candidate/packages/python').rglob('*') if x.is_file()}
expected['packages/python/tests/test_native_model_correspondence_native.py']=Path('/private/tmp/truss-native-model-join-native-astra-r2-20261016/test-r4-prefix.py').read_bytes()
assert set(deltas)==set(expected),(set(deltas)-set(expected),set(expected)-set(deltas))
for n,v in deltas.items():assert H(expected[n])==v['sha256'],n
status=subprocess.check_output(['git','-C',str(i),'status','--porcelain','--untracked-files=all']).decode();(r/'integration-status.txt').write_text(status);changes=[line[3:] for line in status.splitlines()];allowed=set(expected)|{'docs/helix/02-design/technical-designs/native-model-correspondence.md','docs/helix/03-test/native-source-binding-test-plan.md','scripts/check-module-boundaries.py'};assert set(changes)==allowed,(set(changes)-allowed,allowed-set(changes))
for n in changes:
 b=(i/n).read_bytes();f=r/'integration'/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
 if n in expected:assert b==expected[n],n
assert (i/'scripts/check-module-boundaries.py').read_bytes()==Path('/private/tmp/truss-native-model-join-boundary-astra-20261016/candidate-checker.py').read_bytes()
assert (i/'docs/helix/02-design/technical-designs/native-model-correspondence.md').read_bytes()==(prior/'packet/candidate/docs/helix/02-design/technical-designs/native-model-correspondence.md').read_bytes()
(r/'integration-tracked.patch').write_bytes(subprocess.check_output(['git','-C',str(i),'diff','--']))
c=json.loads((r/'native/campaign.json').read_bytes());assert c['status']=='passed' and c['sourcePins']==1872 and c['tests']==1 and c['cleanup']['postmasterPid']==61639 and c['cleanup']['rootRemoved'] and c['cleanup']['postmasterStopped'];assert 'Ran 1 test in 6.272s' in (r/'native.log').read_text()
report={'passed':True,'base':base,'sourceClasses':dict(classes),'nativeSourcePinsVerified':1872,'nativeBaseDeltasExactReviewedIntegration':deltas,'nativeCurrentBaseDifferences':currentdifferent,'runtimeStageExactReviewedR3':501,'integrationFilesExactAllowedScope':len(changes),'wheel':{'sha256':H(wb),'members':501,'sourceInstalledAndReviewedRuntimeExact':True,'versionAndAllDependencyMetadataExactCf8':True,'requirements':requirements},'campaign':c,'sourceArchiveSha256':H((r/'native/source-inputs.zip').read_bytes()),'SQLExecuted':False};(r/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='nativeBaseDeltasExactReviewedIntegration'},indent=2))
