from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((r/'audit.json').read_text())
report={
 'status':'test-repair-passed','resolvedFindings':[{'id':'NMC-JOIN-TEST-01','resolution':'Permanent test now refuses extra unique active native membership and missing non-Key issued membership. Both exact assertion blocks independently detect removal of the complete-membership census comparison.'}],'remainingFindings':[],
 'testSource':{'path':'source/packages/python/tests/test_native_model_correspondence.py','sha256':a['newTestSha256'],'bytes':a['newTestBytes']},
 'unchangedProduct':{'path':'source/packages/python/src/truss/_native_model_correspondence.py','sha256':a['unchangedProductSha256']},
 'validation':[
 {'result':'AST comparison confirms only one test function added. Saved owner R1 source matches immutable frozen R1 test; product bytes unchanged.','receipt':'audit.json'},
 {'command':'python3.11 -B run-tests.py selected','result':'13 pass against actual reviewed opt-in Weft native extension; captured metadata remains substituted unit data.','receipt':'selected-tests.json'},
 {'command':'python3.11 -B run-tests.py default','result':'10 pass/3 intentional skips; zero attempted external Weft imports under active import denial.','receipt':'default-tests.json'},
 {'command':'python3.11 -B mutate.py','result':'Census-erased mutant fails new permanent test. Separately extracted native-extra and issued-missing assertion blocks both pass original and both fail mutant. Source restored and final13-test replay passes.','receipts':['mutation.json','census-original.json','census-mutant.json']}
 ],
 'scope':['Test-only correction; no product behavior change or SQL/native replay.','R1 findings/evidence remain immutable. Capacity qualification/investigation remains separate; this test fix makes no capacity change.','No activation, source/codec/graph/native binding, caller/current-cut, continuity/closing release, or132 Truss/shared158 acceptance promotion.','Reuses exact baseline dependencies from immutable R1 reconstruction and reviewed e072 wheel; no hermetic or held-file/ABA claim.'],
 'priorReview':{'path':'/private/tmp/truss-native-model-join-astra-r1-20261016/review.json','sha256':'d38f4e2a5b4aa5bc9b8c09fe3ca46686d0e162552e6bbd2cd5c4980e203b045e'},
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256,bytes}; excludes itself'}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n');m={}
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if not p.is_file() or '__pycache__' in rel.parts or str(rel)=='manifest.json':continue
 b=p.read_bytes();m[str(rel)]={'sha256':H(b),'bytes':len(b)}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'reviewSha256':H((r/'review.json').read_bytes()),'manifestSha256':H((r/'manifest.json').read_bytes()),'artifacts':len(m),'bytes':sum(x['bytes'] for x in m.values())},indent=2))
