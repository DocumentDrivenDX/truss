from pathlib import Path
import ast,sys,copy,json,hashlib
r=Path(__file__).resolve().parent;base=Path('/private/tmp/truss-native-model-join-astra-r1-20261016/source');sys.path.insert(0,str(base/'packages/python/src'));import truss
truss.__path__.insert(0,str(r/'source/packages/python/src/truss'));sys.path.insert(0,str(r/'source/packages/python/tests'))
import test_native_model_correspondence as tests
source=Path(tests.__file__).read_text();tree=ast.parse(source);c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='NativeModelCorrespondenceTests');fn=next(n for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='test_complete_member_census_rejects_extra_native_and_missing_issued_non_key');split=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='r');rows=[]
for name,body in [('extra-native',fn.body[:split]),('missing-issued',fn.body[split:])]:
 f=copy.deepcopy(fn);f.name='control';f.body=body;module=ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[]));(r/(name+'-extracted.py')).write_text(ast.unparse(module)+'\n');ns={'copy':copy};exec(compile(module,str(r/(name+'-extracted.py')),'exec'),ns);case=tests.NativeModelCorrespondenceTests();case.setUp();error=None
 try:ns['control'](case)
 except AssertionError as e:error=str(e)
 expected=sys.argv[1]=='mutant';valid=(error is not None)==expected;rows.append({'case':name,'assertionFailed':error is not None,'error':error,'passed':valid});assert valid,name
(r/('census-'+sys.argv[1]+'.json')).write_text(json.dumps({'passed':True,'cases':rows,'sourceSha256':hashlib.sha256(source.encode()).hexdigest()},indent=2)+'\n');print(json.dumps(rows))
