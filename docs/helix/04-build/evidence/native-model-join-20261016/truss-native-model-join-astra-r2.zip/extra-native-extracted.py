def control(self):
    a = copy.deepcopy(self.assessment)
    resource = next((t['type_id'] for t in a['inventory']['types'] if t['element'] == 'Resource'))
    extra = copy.deepcopy(next((p for p in a['inventory']['properties'] if p['type_id'] == resource and p['element'] == 'salary')))
    extra['prop_id'] = max((p['prop_id'] for p in a['inventory']['properties'])) + 1
    extra['element'] = 'unexpectedUniqueActiveMember'
    a['inventory']['properties'].append(extra)
    with self.assertRaisesRegex(ValueError, 'Complete original property membership'):
        self.join(assessment=a)
