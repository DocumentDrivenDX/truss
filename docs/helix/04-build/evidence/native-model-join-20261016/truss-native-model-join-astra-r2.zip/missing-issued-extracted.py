def control(self):
    r = copy.deepcopy(self.issued)
    record = next((row for row in r['records'] if row['record']['element'] == 'Resource'))
    record['fields'] = [f for f in record['fields'] if f['field']['element'] != 'salary']
    with self.assertRaisesRegex(ValueError, 'Complete original property membership'):
        self.join(issued=r)
