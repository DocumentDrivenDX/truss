from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parent;p=r/'source/packages/python/src/truss/_native_model_correspondence.py';original=p.read_bytes();py='/private/tmp/truss-practical-performance-env/bin/python';rows=[]
def run(label,args,code):
 result=subprocess.run([py,'-B',*args],capture_output=True,text=True);(r/(label+'.log')).write_text(result.stdout+result.stderr);rows.append({'id':label,'command':[py,'-B',*args],'exitCode':result.returncode});assert result.returncode==code,label;return result
run('census-original',[str(r/'census-controls.py'),'original'],0)
try:
 old=b' or len(fields)!=len(properties)';assert original.count(old)==1;mutant=original.replace(old,b'');p.write_bytes(mutant);(r/'census-erased-mutant.py').write_bytes(mutant)
 result=run('mutant-selected',[str(r/'run-tests.py'),'selected'],1);assert 'FAIL: test_complete_member_census_rejects_extra_native_and_missing_issued_non_key' in result.stderr
 (r/'mutant-selected.json').write_bytes((r/'selected-tests.json').read_bytes())
 run('census-mutant',[str(r/'census-controls.py'),'mutant'],0)
finally:p.write_bytes(original)
run('selected-restored',[str(r/'run-tests.py'),'selected'],0)
(r/'mutation.json').write_text(json.dumps({'passed':True,'executions':rows,'mutantSha256':hashlib.sha256(mutant).hexdigest(),'sourceRestoredSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
