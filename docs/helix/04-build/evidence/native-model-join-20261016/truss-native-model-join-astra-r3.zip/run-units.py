from pathlib import Path
import sys,os,unittest,json,importlib.abc
r=Path(__file__).resolve().parent;sys.path[:0]=[str(r/'source/packages/python/src'),str(r/'source/packages/python/tests')];attempts=[]
if '--default' in sys.argv:
 os.environ.pop('TRUSS_MODEL_JOIN_WEFT_QUALIFICATION',None)
 class Deny(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname=='weft' or fullname.startswith('weft.'):attempts.append(fullname);raise ImportError('external Weft denied')
 sys.meta_path.insert(0,Deny());name='default'
else:
 os.environ['TRUSS_MODEL_JOIN_WEFT_QUALIFICATION']='1';sys.path.insert(0,str(r/'installed/selected037'));name='selected'
names=['test_native_model_correspondence']
if '--shared' in sys.argv:names=['test_owner_evidence_json','test_native_source_descriptor','test_native_source_observation'];name='shared'
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names));assert result.wasSuccessful() and not attempts
(r/f'{name}-units.json').write_text(json.dumps({'passed':True,'tests':result.testsRun,'skipped':len(result.skipped),'weftImportAttempts':attempts,'SQLExecuted':False},indent=2)+'\n')
