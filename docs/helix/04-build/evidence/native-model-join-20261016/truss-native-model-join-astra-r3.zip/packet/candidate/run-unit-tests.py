import sys,pathlib,unittest
root=pathlib.Path(__file__).parent
sys.path.insert(0,'/private/tmp/truss-native-model-join-r3-runtime-20261016');sys.path.insert(0,str(root/'packages/python/tests'))
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_native_model_correspondence')).wasSuccessful())
