from pathlib import Path
import gzip,hashlib,json,sys,importlib.util,decimal,time
r=Path(__file__).resolve().parent;sys.path[:0]=[str(r/'source/packages/python/src'),str(r/'installed/selected039')]
from truss._owner_evidence_json import decode_owner_evidence_json as old,decode_issued_model_requirements_json as new,same_owner_evidence as same
spec=importlib.util.spec_from_file_location('original_decoder',r/'packet/baseline/owner-evidence-json.py');baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
controls=[]
def control(label,decode,raw,accept):
 try:v=decode(raw);passed=True
 except ValueError:v=None;passed=False
 assert passed==accept,(label,len(raw),passed,accept)
 controls.append({'id':label,'accepted':passed});return v
for label,d,limit in [('old',old,8388608),('new',new,16000000)]:
 for n in [0,limit-1,limit,limit+1]:control(f'{label}-bytes-{n}',d,b'0'+b' '*(n-1) if n else b'',0<n<=limit)
 for n in [512,513]:control(f'{label}-integer-{n}',d,b'1'*n,n==512)
 for n in [128,129]:control(f'{label}-depth-{n}',d,b'['*n+b'0'+b']'*n,n==128)
 for n in [4096,4097]:
  control(f'{label}-array-{n}',d,b'['+b','.join([b'0']*n)+b']',n==4096)
  control(f'{label}-object-{n}',d,json.dumps({str(i):0 for i in range(n)},separators=(',',':')).encode(),n==4096)
 for name,raw in [('duplicate',b'{"a":0,"a":1}'),('nested-duplicate',b'{"x":{"a":0,"a":1}}'),('nan',b'NaN'),('inf',b'Infinity'),('float-inf',b'1e9999999999999999999999999'),('surrogate-value',b'"\\ud800"'),('surrogate-key',b'{"\\udfff":0}'),('invalid-utf8',b'"\xff"'),('trailing',b'{}x'),('utf8-bom',b'\xef\xbb\xbf{}'),('bytearray',bytearray(b'0')),('string','0')]:control(label+'-'+name,d,raw,False)
 # Root array +244 inner arrays +999755/999756 scalar nodes = exact 1M / first-over.
 for n in [999755,999756]:
  chunks=[b'['+b','.join([b'0']*min(4096,n-i))+b']' for i in range(0,n,4096)];raw=b'['+b','.join(chunks)+b']';assert len(chunks)==245
  # root1 +245 inner containers => scalar count for 1M is999754; correct below
 for n in [999754,999755]:
  raw=b'['+b','.join(b'['+b','.join([b'0']*min(4096,n-i))+b']' for i in range(0,n,4096))+b']';control(f'{label}-nodes-{n+246}',d,raw,n==999754)
for raw in [b'0',b'-0',b'1.0',b'-0.00',b'1e-10000',b'9007199254740993',b'{"a":[true,null,"\xf0\x9f\x98\x80"]}',b'1'*512]:
 assert same(old(raw),baseline.decode_owner_evidence_json(raw)) and same(old(raw),new(raw));controls.append({'id':'semantic-equivalence-'+hashlib.sha256(raw).hexdigest(),'accepted':True})
import weft,weft.weft as native
raw=gzip.decompress((r/'packet/evidence/issued-capacity/original-request.json.gz').read_bytes());expected=gzip.decompress((r/'packet/evidence/issued-capacity/actual-requirements.json.gz').read_bytes());start=time.monotonic();parent=weft.prepare_application_lineage(raw.decode());current=parent.prepare_current_presence();q=current.model_requirements_json().encode();assert q==expected and current.source_preparation() is parent
control('actual-issued-old-refusal',old,q,False);parsed=control('actual-issued-new-scan',new,q,True);assert parsed['sourceRequestJson'].encode()==raw
report={'passed':True,'controls':len(controls),'observations':controls,'actualCompilerReissued':True,'requestBytes':len(raw),'requirementsBytes':len(q),'requirementsSha256':hashlib.sha256(q).hexdigest(),'nativeModuleSha256':hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),'compilerSeconds':time.monotonic()-start,'SQLExecuted':False,'scope':'Decoder capacity and exact compiler report; no full native join or native admission.'}
(r/'decoder-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='observations'}))
