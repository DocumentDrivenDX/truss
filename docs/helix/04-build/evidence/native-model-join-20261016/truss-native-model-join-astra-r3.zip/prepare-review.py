from pathlib import Path
import ast,copy,hashlib,json,subprocess,tarfile,io,zipfile,shutil,difflib
r=Path(__file__).resolve().parent;p=r/'packet';m=json.loads((p/'manifest.json').read_text())
for n,v in m.items():
 b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'],n
base='cf8ccbad907de4b5303db70ea1f7da72f621cefa';repo='/Users/erik/Projects/truss';s=r/'source';s.mkdir(exist_ok=True)
tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base,'packages/python','scripts/check-module-boundaries.py','docs/helix/02-design/contracts/bindings']))).extractall(s)
for q in (p/'candidate/packages/python').rglob('*'):
 if q.is_file():target=s/'packages/python'/q.relative_to(p/'candidate/packages/python');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(q,target)
a=(p/'baseline/owner-evidence-json.py').read_bytes();b=(p/'candidate/packages/python/src/truss/_owner_evidence_json.py').read_bytes();assert a==subprocess.check_output(['git','-C',repo,'show',base+':packages/python/src/truss/_owner_evidence_json.py'])
x=ast.parse(a);y=ast.parse(b);old=next(v for v in x.body if isinstance(v,ast.FunctionDef) and v.name=='decode_owner_evidence_json');new=next(v for v in y.body if isinstance(v,ast.FunctionDef) and v.name=='_decode_evidence_json');old=copy.deepcopy(old);old.name=new.name;old.args=new.args
class Bound(ast.NodeTransformer):
 def visit_Constant(self,n):return ast.copy_location(ast.Name(id='max_bytes',ctx=ast.Load()),n) if n.value==8388608 else n
old=Bound().visit(old);assert ast.dump(old)==ast.dump(new)
oldcmp=next(v for v in x.body if isinstance(v,ast.FunctionDef) and v.name=='same_owner_evidence');newcmp=next(v for v in y.body if isinstance(v,ast.FunctionDef) and v.name=='same_owner_evidence');assert ast.dump(oldcmp)==ast.dump(newcmp)
previous=Path('/private/tmp/truss-native-model-join-native-astra-r1-20261016/captured/owner/packages/python/src/truss/_native_model_correspondence.py').read_text();current=(p/'candidate/packages/python/src/truss/_native_model_correspondence.py').read_text();(r/'join-delta.patch').write_text(''.join(difflib.unified_diff(previous.splitlines(True),current.splitlines(True))))
overlay=json.loads((p/'candidate/runtime-overlay-manifest.json').read_text());mismatches=[]
for n,v in overlay.items():
 f=s/'packages/python/src'/n
 if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=v['sha256']:mismatches.append(n)
assert not mismatches,mismatches
for whl in ['selected039','selected037']:
 target=r/'installed'/whl;target.mkdir(parents=True,exist_ok=True);zipfile.ZipFile(p/'toolchain'/f'{whl}.whl').extractall(target)
(r/'source-audit.json').write_text(json.dumps({'packetMembersVerified':len(m),'baseline':base,'runtimeOverlayMembersVerified':len(overlay),'decoderBaselineExactGit':True,'scannerASTOnlyChangedByteBoundToParameter':True,'comparatorASTUnchanged':True,'SQLExecuted':False},indent=2)+'\n')
print((r/'source-audit.json').read_text());print((r/'join-delta.patch').read_text())
