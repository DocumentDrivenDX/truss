from pathlib import Path
import sys,os,importlib.abc,unittest,json
r=Path(__file__).resolve().parent;old=Path('/private/tmp/truss-native-model-join-native-astra-r1-20261016');sys.path[:0]=[str(old/'reconstructed/base/packages/python/src'),str(Path('/private/tmp/truss-native-model-join-astra-r1-20261016/source/packages/python/tests')),str(r)];import truss
truss.__path__.insert(0,str(old/'captured/owner/packages/python/src/truss'));os.environ.pop('TRUSS_NATIVE_MODEL_JOIN_QUALIFICATION',None);os.environ['TRUSS_MODEL_CORRESPONDENCE_QUALIFICATION']='1';attempts=[];started=[]
class Deny(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='weft' or fullname.startswith('weft.'):
   attempts.append(fullname);raise ImportError('external Weft denied')
sys.meta_path.insert(0,Deny());import importlib.util
spec=importlib.util.spec_from_file_location('review_native_r2',r/'test-r4-prefix.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
def trap(cls):started.append(True);raise AssertionError('native setup forbidden')
t.NativeModelCorrespondenceTests.setUpClass=classmethod(trap)
p=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(t));assert p.wasSuccessful() and p.testsRun==1 and len(p.skipped)==1 and not attempts and not started
(r/'prefix-default-control.json').write_text(json.dumps({'passed':True,'tests':1,'skipped':1,'weftImportAttempts':attempts,'nativeSetupCalls':started},indent=2)+'\n')
