from pathlib import Path
import sys,json,hashlib,copy
from types import SimpleNamespace
r=Path(__file__).resolve().parent;e=r/'native';sys.path.insert(0,str(r/'working/installed'));import truss
sys.path.insert(0,str(r/'working/weft'));import weft
import truss._native_model_correspondence as helper
H=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def ok(name,condition):rows.append({'id':name,'passed':bool(condition)});assert condition,name
q=(e/'issued-requirements.json').read_bytes();issued=json.loads(q);actual=json.loads((e/'joined-report.json').read_bytes());inventory=json.loads((e/'native-inventory.json').read_bytes());gold=json.loads((e/'native-field-key-mapping.json').read_bytes());identity=lambda n:{'documentId':'domain','revision':'query-value-core-r1','module':'m','element':n}
expected_fields={'Staff':(['staffId'],['staffId']),'Project':(['projectId'],['projectId']),'Resource':(['resourceId','salary','token'],['resourceId']),'Ownership':(['ownerId','ownerResource','ownerProject'],['ownerId']),'Assignment':(['assignmentId','assignmentStaff','assignmentProject','active'],['assignmentId'])}
object_home=next(x for x in inventory['relations'] if x['name']=='object');columns={n:{'attnum':next(c for c in object_home['columns'] if c['name']==n)['attnum'],'typeOid':oid} for n,oid in [('id','20'),('type_id','23'),('props','3802')]};expected=[]
for name in sorted(expected_fields):
 fields,keys=expected_fields[name];g=gold[name]
 expected.append({'record':identity(name),'typeId':g['typeId'],'objectHome':{'relationOid':object_home['oid'],'columns':columns},'fields':[{'field':identity(n),'propertyId':g['properties'][n],'jsonKey':str(g['properties'][n])} for n in fields],'selectedKey':{'id':'pk','fields':[identity(n) for n in keys],'keyNum':g['keyNum'],'propertyIds':[g['properties'][n] for n in keys]}})
ok('complete-ordered-joined-records-exact',actual['records']==expected);ok('five-unique-Records',len(actual['records'])==5 and len({tuple(x['record'].values()) for x in actual['records']})==5);ok('twelve-complete-Fields',sum(len(x['fields']) for x in actual['records'])==12);ok('five-single-component-Keys',all(len(x['selectedKey']['fields'])==1 for x in actual['records']))
for key in ['complete','authority','securityReady']:ok(key+'-false',actual[key] is False)
ok('native-admission-required',actual['nativeAdmission']=='required');ok('exact-scope',actual['scope']=='actual-context-native-record-member-key-correspondence');ok('exact-version',actual['version']=='truss.native-model.correspondence/0.1-candidate');ok('preparation-source-pin',actual['preparationSha256']==issued['preparationSha256'])
roles=[('accepted-request','accepted-request.json'),('accepted-assessment','accepted-assessment.json'),('runtime-release','runtime-release.json'),('native-inventory','native-inventory.json'),('issued-requirements','issued-requirements.json')]
ok('all-five-ordered-source-pins',actual['sources']==[{'role':role,'sha256':H((e/n).read_bytes()),'bytes':len((e/n).read_bytes())} for role,n in roles])
# Actual reviewed compiler reissues the exact requirements; this is a non-SQL replay.
parent=weft.prepare_application_lineage((e/'weft-original-request.json').read_text());current=parent.prepare_current_presence();ok('actual-compiler-Q-byte-identical',current.model_requirements_json().encode()==q);ok('actual-context-preparation-hash',H(current.json().encode())==issued['preparationSha256']);ok('actual-parent-identity',current.source_preparation() is parent)
observation=SimpleNamespace(**{k:(e/n).read_bytes() for k,n in [('accepted_request','accepted-request.json'),('accepted_assessment','accepted-assessment.json'),('runtime_release','runtime-release.json'),('native_inventory','native-inventory.json')]});result=helper._join(observation,q,issued['preparationSha256'],lambda:None);ok('original-product-data-replay-byte-identical',result==(e/'joined-report.json').read_bytes());ok('reviewed-original-product-loaded',H(Path(helper.__file__).read_bytes())=='25245cb52727eb9014a09322ec763dcd838d2729272e5dbe9d0c3f37c95a2618')
(r/'expected-joined-records.json').write_text(json.dumps(expected,indent=2)+'\n');(r/'report-controls.json').write_text(json.dumps({'passed':True,'checks':rows,'count':len(rows),'SQLExecuted':False,'loadedNativeSha256':H(Path(weft.weft.__file__).read_bytes()),'scope':'Independent complete report expectations plus actual compiler and deterministic data join replay; supplied native campaign not independently rerun.'},indent=2)+'\n');print(len(rows))
