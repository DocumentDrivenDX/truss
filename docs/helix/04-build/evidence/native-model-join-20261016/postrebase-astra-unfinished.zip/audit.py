from pathlib import Path
import hashlib,json,zipfile,subprocess,io,collections,email,difflib,shutil
r=Path(__file__).resolve().parent;i=Path('/private/tmp/truss-disclosure-main-integration-20261016');e=i/'docs/helix/04-build/evidence/native-model-join-20261016';n=Path('/private/tmp/truss-native-model-join-postrebase-20261016');p=Path('/private/tmp/truss-native-model-join-postrebase-package-owner-20261016');H=lambda b:hashlib.sha256(b).hexdigest();meta=lambda b:{'sha256':H(b),'bytes':len(b)};head='b077dd3eea44b8ffbf76b8b386112a76903686da';parent='318d3edaddf3900d2e198d95d2590228f0a9a059';git=lambda *args:subprocess.check_output(['git','-C',str(i),*args])
assert git('rev-parse','HEAD').decode().strip()==head and git('rev-parse','HEAD^').decode().strip()==parent
oldreview=Path('/private/tmp/truss-native-model-join-final-astra-20261016');before={str(q.relative_to(e)):meta(q.read_bytes()) for q in e.rglob('*') if q.is_file()}
for file in ['README.md','verify-retention.py','retention.json','reviews.json','postrebase.json']:(r/file).write_bytes((e/file).read_bytes())
for q in n.iterdir():
 if q.is_file() and q.suffix=='.json':t=r/'native'/q.name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(q.read_bytes())
(r/'native.log').write_bytes(Path(str(n)+'.log').read_bytes());pins=json.loads((n/'source-before.json').read_bytes());assert len(pins)==1371;classes=collections.Counter();sourceArchive=n/'source-inputs.zip'
with zipfile.ZipFile(sourceArchive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(pins) and set(z.namelist())==set(pins)
 batch=subprocess.Popen(['git','-C',str(i),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 for name,pin in pins.items():
  b=z.read(name);assert meta(b)==pin,name;kind=name.split('/')[0];classes[kind]+=1
  if kind=='base':
   rel=name[5:];batch.stdin.write((head+':'+rel+'\n').encode());batch.stdin.flush();h=batch.stdout.readline().decode().split();assert len(h)==3 and h[1]=='blob',(name,h);raw=batch.stdout.read(int(h[2]));assert batch.stdout.read(1)==b'\n';assert raw==b==(i/rel).read_bytes(),name
  if kind=='owner':t=r/'captured'/name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
 batch.stdin.close();assert batch.wait()==0
 assert 'runtime-stage' not in classes
 assert z.read('owner/test_native_model_correspondence_native.py')==(oldreview/'captured/owner/test_native_model_correspondence_native.py').read_bytes()
 runner=z.read('owner/run-native-correspondence-r2.py');oldrunner=(oldreview/'captured/owner/run-native-correspondence-r2.py').read_bytes();(r/'runner-delta.patch').write_text(''.join(difflib.unified_diff(oldrunner.decode().splitlines(True),runner.decode().splitlines(True),fromfile='R4-stage',tofile='postrebase-base')))
 assert b'runtime-stage/' not in runner and b"sys.path.insert(0,str(base/'packages/python/src'));import truss" in runner
 assert z.read('base/packages/python/src/truss/_catalog_runtime/manifest.json')==(n/'runtime-release.json').read_bytes()
 assert H(z.read('toolchain/weft.whl'))=='e072db75724608d652f3368ab1375907c3fbf2cd1e321a0d7a04bbdad4d92778'
 with zipfile.ZipFile(io.BytesIO(z.read('toolchain/weft.whl'))) as wz:
  for name in wz.namelist():assert wz.read(name)==z.read('weft/'+name)
 # Working trees only; recoverable from retained archive and omitted from artifact manifest.
 for name in z.namelist():
  if name.startswith('weft/') or name.startswith('base/packages/python/tests/') or name.startswith('base/docs/helix/02-design/contracts/bindings/'):
   t=r/'working'/name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(z.read(name))
assets=['packages/postgresql/owned-groups/execute.sql','packages/postgresql/owned-groups/finalize.sql','packages/python/src/truss/_catalog_runtime/owned.sql','packages/python/src/truss/_catalog_runtime/manifest.json'];assetsreport={}
for file in assets:
 a=git('show',head+':'+file);b=git('show',parent+':'+file);assert a==b==(i/file).read_bytes();assert a!=git('show','cf8ccbad:'+file);assetsreport[file]=meta(a)
for name,pin in json.loads((oldreview/'closing-integration-pins.json').read_bytes()).items():assert meta((i/name).read_bytes())==pin,name
wheel=next((p/'wheel').glob('*.whl'));assert H(wheel.read_bytes())=='06e1cd53b46eda6f651ee60be29660a806413caa4854dd729860128705fcb7af';source=json.loads((p/'source-before.json').read_bytes());wheelpaths={name[4:] for name in source if name.startswith('src/truss/')};assert len(wheelpaths)==501
for name,pin in source.items():assert meta((p/'source'/name).read_bytes())==pin,name
with zipfile.ZipFile(wheel) as z:
 assert {name for name in z.namelist() if name.startswith('truss/') and not name.endswith('/')}==wheelpaths
 for name in wheelpaths:
  b=z.read(name);assert meta(b)==source['src/'+name] and b==(p/'installed'/name).read_bytes()==git('show',head+':packages/python/src/'+name)==(i/'packages/python/src'/name).read_bytes()
 md=email.message_from_bytes(z.read(next(name for name in z.namelist() if name.endswith('.dist-info/METADATA'))));assert md['Version']=='0.0.38.dev0';old=json.loads((oldreview/'audit.json').read_bytes())['wheel'];assert md.get_all('Requires-Dist')==old['requirements'];z.extractall(r/'working/installed')
assert git('show',head+':packages/python/pyproject.toml')==git('show',parent+':packages/python/pyproject.toml')==git('show','cf8ccbad:packages/python/pyproject.toml')==(p/'source/pyproject.toml').read_bytes()
for name in ['check-wheel.py','source-before.json','wheel-correspondence.json','check-installed-default.py','installed-default.json']:
 t=r/'packaging'/name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes((p/name).read_bytes())
for epoch,origin in [('native-postrebase',n),('wheel-postrebase',p)]:
 if epoch=='native-postrebase':
  for file in origin.iterdir():
   if file.is_file():assert file.read_bytes()==(e/epoch/file.name).read_bytes(),file.name
 else:
  assert wheel.read_bytes()==(e/epoch/wheel.name).read_bytes()
  for file in ['source-before.json','wheel-correspondence.json']:assert (origin/file).read_bytes()==(e/epoch/file).read_bytes()
# Every previously audited retained file remains exact, except explicit append/wrapper updates.
oldpins=json.loads(Path('/private/tmp/truss-native-model-join-retention-astra-20261016/retained-input-pins.json').read_bytes());allowed={'README.md','retention.json','reviews.json','verify-retention.py'}
for name,pin in oldpins.items():
 if name not in allowed:assert before[name]==pin,name
oldreadme=Path('/private/tmp/truss-native-model-join-retention-astra-20261016/README.md').read_bytes();assert (e/'README.md').read_bytes().startswith(oldreadme)
oldplan=git('show',head+':docs/helix/04-build/implementation-plan.md');current=(i/'docs/helix/04-build/implementation-plan.md').read_bytes();assert current.startswith(oldplan);(r/'checkpoint-addition.md').write_bytes(current[len(oldplan):])
(r/'verifier-delta.patch').write_text(''.join(difflib.unified_diff(Path('/private/tmp/truss-native-model-join-retention-astra-20261016/verify-retention.py').read_text().splitlines(True),(e/'verify-retention.py').read_text().splitlines(True))))
# New ninth review archive is exact original; the eight original archives were already hash-checked above.
name='truss-native-model-join-retention-astra';origin=Path('/private/tmp')/(name+'-20261016')
with zipfile.ZipFile(e/(name+'.zip')) as z:
 m=json.loads(z.read('manifest.json'));assert len(m)==14 and set(z.namelist())==set(m)|{'manifest.json'};assert z.read('manifest.json')==(origin/'manifest.json').read_bytes()
 for name,pin in m.items():assert meta(z.read(name))==pin and z.read(name)==(origin/name).read_bytes()
pv=subprocess.run(['/private/tmp/weft-toolchain/venv/bin/python','-B',str(e/'verify-retention.py')],capture_output=True,text=True);(r/'verifier.stdout').write_text(pv.stdout);(r/'verifier.stderr').write_text(pv.stderr);assert pv.returncode==0;v=json.loads(pv.stdout);assert v['retainedFiles']==109 and v['completeReviewerArtifacts']==335 and v['nativeSourcePins']==6462 and v['wheelMembers']==501
assert before=={str(q.relative_to(e)):meta(q.read_bytes()) for q in e.rglob('*') if q.is_file()}
c=json.loads((n/'campaign.json').read_bytes());assert c['status']=='passed' and c['tests']==1 and c['sourcePins']==1371 and c['cleanup']['postmasterPid']==72013 and c['cleanup']['rootRemoved'] and c['cleanup']['postmasterStopped'];assert 'Ran 1 test in 4.437s' in (r/'native.log').read_text()
a={'passed':True,'capturedCommit':head,'parent':parent,'nativeSourcePins':1371,'sourceClasses':dict(classes),'nativeBaseBytesExactCommitAndCurrent':1359,'noOldRuntimeStageImport':True,'nativeAssetsExactParent':assetsreport,'reviewedComponentFilesUnchanged':14,'wheel':{'sha256':H(wheel.read_bytes()),'bytes':wheel.stat().st_size,'members':501,'sourceInstalledGitCurrentExact':True,'versionAndDependenciesUnchangedCf8':True},'nativeSourceArchive':meta(sourceArchive.read_bytes()),'campaign':c,'retentionVerifier':v,'oldReceiptsUnchanged':True,'newReviewArchiveArtifactsExact':14,'wrapperReadOnly':True,'SQLExecuted':False};(r/'audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
