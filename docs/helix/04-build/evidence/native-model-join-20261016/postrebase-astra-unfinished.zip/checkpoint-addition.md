

Postrebase qualification preserves parent318d3eda's native SQL and dependency
bytes. The actual base-package join passes1native/4.437s with1371pins and verified
PID72013/root cleanup; fresh wheel06e1cd53 matches501 members,42installed tests
pass, default11pass/3skip and1491imports pass. Historical cf8/stage receipts are
not repinned. This component does not close the broader development-main capacity
CI failure or establish native authority, release qualification or a new case pass.
