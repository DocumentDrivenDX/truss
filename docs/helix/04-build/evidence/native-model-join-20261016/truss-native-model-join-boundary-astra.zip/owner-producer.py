from pathlib import Path
import subprocess,json,shutil,hashlib
out=Path('/private/tmp/truss-native-model-join-boundary-owner-20261016');out.mkdir(exist_ok=True)
base=Path('/private/tmp/truss-disclosure-main-integration-20261016/scripts/check-module-boundaries.py').read_text();targets=['dataclasses','hashlib','json','truss._native_source_observation','truss._owner_evidence_json','weft']
entry="    '_native_model_correspondence': {"+','.join(repr(t) for t in targets)+"},\n"
checker=out/'check-module-boundaries.py';checker.write_text(base.replace('ALLOWED = {\n','ALLOWED = {\n    # Original-context/native correspondence data only; no witness admission.\n'+entry))
source=Path('/private/tmp/truss-native-model-join-r3-runtime-20261016/truss');python='/private/tmp/weft-toolchain/venv/bin/python'
def run(path,src=source):
 p=subprocess.run([python,str(path),'--source',str(src),'--json'],capture_output=True,text=True);r=json.loads(p.stdout);assert p.returncode==(0 if r['passed'] else 1);return r
r=run(checker);assert r['passed'],r['errors'];(out/'baseline.json').write_text(json.dumps(r,indent=2)+'\n');controls=[]
for target in targets:
 p=out/('deny-'+target.replace('.','-')+'.py');changed=entry.replace(repr(target),'',1).replace('{,','{').replace(',,',',');p.write_text(checker.read_text().replace(entry,changed));result=run(p);assert not result['passed'] and any('forbidden import '+target in e for e in result['errors']);controls.append({'removed':target,'errors':result['errors']})
clone=out/'root-export-source';shutil.copytree(source,clone,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'));p=clone/'__init__.py';p.write_text(p.read_text()+'\nfrom ._native_model_correspondence import NativeModelCorrespondence\n');r=run(checker,clone);assert not r['passed'] and any('forbidden import truss._native_model_correspondence' in e for e in r['errors']);controls.append({'case':'root-export-forbidden','errors':r['errors']})
(out/'controls.json').write_text(json.dumps(controls,indent=2)+'\n');print(json.dumps({'baselineImports':len(json.loads((out/'baseline.json').read_text())['edges']),'controls':len(controls),'checkerSha256':hashlib.sha256(checker.read_bytes()).hexdigest()}))
