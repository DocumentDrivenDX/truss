from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,io
r=Path(__file__).resolve().parent;origin=Path('/private/tmp/truss-native-model-join-native-r1-20261016');shutil.copytree(origin,r/'inputs');shutil.copy2(str(origin)+'.log',r/'native.log');e=r/'inputs';H=lambda b:hashlib.sha256(b).hexdigest();pins=json.loads((e/'source-before.json').read_bytes());assert len(pins)==1358;rows=[]
with zipfile.ZipFile(e/'source-inputs.zip') as z:
 assert set(z.namelist())==set(pins)
 for n,pin in pins.items():
  b=z.read(n);assert H(b)==pin['sha256'] and len(b)==pin['bytes'];
  if n.startswith('owner/'):
   p=r/'captured'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  if n.startswith('base/packages/python/src/') or n.startswith('base/packages/python/tests/'):
   p=r/'reconstructed'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 product=z.read('owner/packages/python/src/truss/_native_model_correspondence.py');assert H(product)=='004a05fe46bb532cccb6fb3baf62ad4103a6c49c757ba46f9c852e4690cd4a6e'
 assert product==Path('/private/tmp/truss-native-model-join-astra-r1-20261016/frozen/packages/python/src/truss/_native_model_correspondence.py').read_bytes()
 baseline='2a8bd1fee8ee8d644e6d47fff37145ff161170bb';batch=subprocess.Popen(['git','-C','/Users/erik/Projects/truss','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);count=0
 for n,pin in pins.items():
  if not n.startswith('base/'):continue
  batch.stdin.write((baseline+':'+n[5:]+'\n').encode());batch.stdin.flush();head=batch.stdout.readline().decode().split();assert len(head)==3 and head[1]=='blob',(n,head);b=batch.stdout.read(int(head[2]));assert batch.stdout.read(1)==b'\n';assert H(b)==pin['sha256'],n;count+=1
 batch.stdin.close();assert batch.wait()==0
 assert H(z.read('toolchain/weft.whl'))=='e072db75724608d652f3368ab1375907c3fbf2cd1e321a0d7a04bbdad4d92778'
 assert H(z.read('weft/weft/weft.abi3.so'))=='9f1c7bc60f070734f2e935ba53e82a0bd22002e9e738c34f65623ca8bac978dd'
 with zipfile.ZipFile(io.BytesIO(z.read('toolchain/weft.whl'))) as w:
  for n in w.namelist():assert w.read(n)==z.read('weft/'+n)
 assert (e/'runtime-release.json').read_bytes()==z.read('base/packages/python/src/truss/_catalog_runtime/manifest.json')
 for n in ['owner/test_native_model_correspondence.py','owner/run-native-correspondence-r2.py','owner/packages/python/src/truss/_native_model_correspondence.py']:
  owner=Path('/private/tmp/truss-native-model-join-native-owner-20261016')/n[6:];assert owner.read_bytes()==z.read(n),n
q=(e/'issued-requirements.json').read_bytes();issued=json.loads(q);original=(e/'weft-original-request.json').read_bytes();assert issued['sourceRequestJson'].encode()==original and issued['sourceRequestSha256']==H(original)
for reportfile in ['observation-report.json','joined-report.json']:
 report=json.loads((e/reportfile).read_bytes())
 for p in report['sources']:
  names={'accepted-request':'accepted-request.json','accepted-assessment':'accepted-assessment.json','runtime-release':'runtime-release.json','native-inventory':'native-inventory.json','issued-requirements':'issued-requirements.json'};b=(e/names[p['role']]).read_bytes();assert H(b)==p['sha256'] and len(b)==p['bytes']
campaign=json.loads((e/'campaign.json').read_bytes());assert campaign['status']=='passed' and campaign['tests']==1 and campaign['sourcePins']==1358;assert 'Ran 1 test in 5.505s' in (r/'native.log').read_text();assert campaign['cleanup']['rootRemoved'] and campaign['cleanup']['postmasterStopped'] and campaign['cleanup']['postmasterPid']==41237
result={'passed':True,'sourcePins':1358,'baseline':baseline,'baselineFilesExact':count,'sourceArchiveSha256':H((e/'source-inputs.zip').read_bytes()),'productSha256':H(product),'testSha256':pins['owner/test_native_model_correspondence.py']['sha256'],'allSourceRolesCorrespond':True,'nativeCampaign':campaign,'SQLReplay':False,'decoderEpoch':'Original8MiB owner decoder; later R3 profile not captured/qualified'}
(r/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
