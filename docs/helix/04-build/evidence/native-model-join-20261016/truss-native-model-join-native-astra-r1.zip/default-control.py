from pathlib import Path
import sys,os,importlib.abc,unittest,json
r=Path(__file__).resolve().parent;sys.path[:0]=[str(r/'reconstructed/base/packages/python/src'),str(r/'reconstructed/base/packages/python/tests'),str(r/'captured/owner')];import truss
truss.__path__.insert(0,str(r/'captured/owner/packages/python/src/truss'));os.environ.pop('TRUSS_MODEL_CORRESPONDENCE_QUALIFICATION',None);attempts=[];started=[]
class Deny(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='weft' or fullname.startswith('weft.'):
   attempts.append(fullname);raise ImportError('external Weft denied')
sys.meta_path.insert(0,Deny());import test_native_model_correspondence as t
def trap(cls):started.append(True);raise AssertionError('native setup forbidden')
t.NativeModelCorrespondenceTests.setUpClass=classmethod(trap)
p=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(t));assert p.wasSuccessful() and p.testsRun==1 and len(p.skipped)==1 and not attempts and not started
(r/'default-control.json').write_text(json.dumps({'passed':True,'tests':1,'skipped':1,'weftImportAttempts':attempts,'nativeSetupCalls':started},indent=2)+'\n')
