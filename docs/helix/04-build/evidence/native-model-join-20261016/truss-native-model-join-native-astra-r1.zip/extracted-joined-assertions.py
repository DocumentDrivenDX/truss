mapping = decode_owner_evidence_json(joined.report)
self.assertEqual(len(mapping['records']), 5)
for row in mapping['records']:
    name = row['record']['element']
    gold = native_mapping[name]
    self.assertEqual(row['typeId'], gold['typeId'])
    self.assertEqual({f['field']['element']: f['propertyId'] for f in row['fields']}, gold['properties'])
    self.assertEqual(row['selectedKey']['keyNum'], gold['keyNum'])
    self.assertEqual([f['element'] for f in row['selectedKey']['fields']], gold['orderedKeyFields'])
