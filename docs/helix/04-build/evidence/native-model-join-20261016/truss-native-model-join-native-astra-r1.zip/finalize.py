from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();audit=json.loads((r/'audit.json').read_bytes())
report={
 'status':'supplied-native-evidence-corresponds-native-test-assertion-gap-open',
 'productSha256':audit['productSha256'],'testSha256':audit['testSha256'],'sourceArchiveSha256':audit['sourceArchiveSha256'],
 'findings':[{'id':'NMC-JOIN-NATIVE-01','priority':2,'category':'regression-evidence','file':'captured/owner/test_native_model_correspondence.py','line':66,
 'title':'Assert the complete joined mapping and unique Record census',
 'finding':'The native test validates joined rows through element-only lookups and a total count. Its exact assertion block accepts five duplicate copies of the first Record, foreign complete Record/Field/Key identities, wrong Key id/propertyIds, wrong JSON key and wrong object relation OID. Eight of nine independent report mutations survive; wrong typeId is detected.',
 'requestedChange':'Require unique complete Record identities and exact ordered joined records, full Field identities/propertyIds/jsonKeys, full selected Key id/identities/order/native IDs, source/profile flags and independently captured actual object relation/column slots. Replay the mutants before final native revalidation.',
 'scope':'Current supplied report independently matches complete expected records; no current product mapping defect or native data corruption was observed.'}],
 'validation':[
 {'command':'python3.12 audit.py','result':'All1358 source ZIP pins match;1348 baseline files equal2a8 Git. One additional base-tree file is the reviewed paired qualification test07183c90. Captured join product exactly004a05fe and e072/native9f1 wheel entries match. All source-role digests and original request/runtime release correspond.','receipt':'audit.json'},
 {'result':'Supplied native test passes1case/5.505s under original stock host with actual context and direct observer, no metadata substitution. Recorded column-rename refusal, prior caller-work retention, restoration equality and changed-source refusal match test assertions. Captured runner verifies root removal/PID41237 stop and source endpoints/imported project closure.','receipts':['inputs/campaign.json','inputs/join-controls.json'],'log':'native.log'},
 {'command':'python3.11 -B report-controls.py','result':'17 independent checks pass: complete expected5 Records/12 Fields/5 single-component Keys, exact source/profile/preparation pins and complete physical/identity mapping. Actual reviewed compiler reissues byte-identical Q; original join over supplied captured observation reproduces byte-identical report.','receipt':'report-controls.json'},
 {'command':'python3.11 -B joined-assertion-controls.py','result':'Original captured report passes extracted native assertions;8 malformed report mutants survive and1 refuses, establishing the test gap.','receipt':'joined-assertion-controls.json'},
 {'command':'python3.11 -B default-control.py','result':'Fresh default discovery skips1 test with Weft imports denied and native setup trapped; no import attempts or native setup calls.','receipt':'default-control.json'}
 ],
 'scope':[
 'Supplied native-campaign audit plus independent non-SQL compiler/data/guard checks. No reviewer SQL/native replay.',
 'Native R1 uses original004a05fe product and unchanged8MiB owner decoder, captured2a8 runtime0.71 assets and historical e072 candidate wheel. Later R3 named16M decoder, newer Weft039 wheel and later main assets are not qualified by this campaign.',
 'Native object/home metadata and accepted-source correspondence only;5 single-component Keys do not prove native composite-Key ordering/codec, graph, nullable/nested/other homes, authenticated caller/current-cut/continuous source authority or guarded release.',
 'Constructible data outputs remain complete/authority/securityReady=false, native admission required. No activation/default repin or132 Truss/shared158 case promotion.',
 'Source endpoints/import closure are not held-file/ABA or hermetic toolchain evidence. Native restoration equality is an observed same-transaction repair control, not continuity proof.'
 ],
 'retainedAttempts':'First reviewer baseline comparison found the captured untracked paired qualification test; final audit explicitly recognizes its reviewed07183c90 overlay rather than labeling every file baseline-native source. Initial audit source/log retained.',
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256,bytes}; excludes itself and reconstructed/ (recoverable exact source-inputs.zip)'}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n');m={}
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if not p.is_file() or rel.parts[0]=='reconstructed' or '__pycache__' in rel.parts or str(rel)=='manifest.json':continue
 b=p.read_bytes();m[str(rel)]={'sha256':H(b),'bytes':len(b)}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'reviewSha256':H((r/'review.json').read_bytes()),'manifestSha256':H((r/'manifest.json').read_bytes()),'artifacts':len(m),'bytes':sum(x['bytes'] for x in m.values())},indent=2))
