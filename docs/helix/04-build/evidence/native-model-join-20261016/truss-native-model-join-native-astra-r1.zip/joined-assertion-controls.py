from pathlib import Path
import ast,json,copy,unittest
from types import SimpleNamespace
r=Path(__file__).resolve().parent;s=(r/'captured/owner/test_native_model_correspondence.py').read_text();tree=ast.parse(s);fn=next(n for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_exact'))
start=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mapping' for t in n.targets));stop=next(i for i,n in enumerate(fn.body[start:],start) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='retain')
block=ast.fix_missing_locations(ast.Module(body=fn.body[start:stop],type_ignores=[]));(r/'extracted-joined-assertions.py').write_text(ast.unparse(block)+'\n');code=compile(block,'exact-native-joined-assertions','exec');original=json.loads((r/'inputs/joined-report.json').read_bytes());gold=json.loads((r/'inputs/native-field-key-mapping.json').read_bytes())
def check(mapping):exec(code,{'decode_owner_evidence_json':json.loads,'joined':SimpleNamespace(report=json.dumps(mapping).encode()),'self':unittest.TestCase(),'native_mapping':gold})
check(original);rows=[]
def mutant(name,edit):
 m=copy.deepcopy(original);edit(m)
 try:check(m);caught=False
 except (AssertionError,KeyError,TypeError):caught=True
 rows.append({'id':name,'caught':caught})
mutant('duplicate-first-Record-five-times',lambda m:m.update(records=[copy.deepcopy(m['records'][0]) for _ in range(5)]))
mutant('foreign-Record-document',lambda m:m['records'][0]['record'].update(documentId='foreign'))
mutant('foreign-Field-module',lambda m:m['records'][0]['fields'][0]['field'].update(module='foreign'))
mutant('foreign-selected-Key-field-revision',lambda m:m['records'][0]['selectedKey']['fields'][0].update(revision='foreign'))
mutant('wrong-selected-Key-id',lambda m:m['records'][0]['selectedKey'].update(id='other'))
mutant('wrong-property-JSON-key',lambda m:m['records'][0]['fields'][0].update(jsonKey='99999'))
mutant('wrong-ordered-native-key-property-IDs',lambda m:m['records'][0]['selectedKey'].update(propertyIds=[99999]))
mutant('wrong-object-relation-OID',lambda m:m['records'][0]['objectHome'].update(relationOid='99999'))
mutant('wrong-type-ID',lambda m:m['records'][0].update(typeId=99999))
(r/'joined-assertion-controls.json').write_text(json.dumps({'baselinePasses':True,'mutants':rows,'caught':sum(x['caught'] for x in rows),'survived':[x['id'] for x in rows if not x['caught']],'scope':'Exact native test assertion block replayed over supplied captured report; no SQL.'},indent=2)+'\n');print(json.dumps(rows))
