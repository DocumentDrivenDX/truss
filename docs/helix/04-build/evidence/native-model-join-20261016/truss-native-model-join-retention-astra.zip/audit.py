from pathlib import Path
import hashlib,json,zipfile,subprocess,io,contextlib
from unittest.mock import patch
r=Path(__file__).resolve().parent;i=Path('/private/tmp/truss-disclosure-main-integration-20261016');e=i/'docs/helix/04-build/evidence/native-model-join-20261016';meta=lambda b:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};before={str(p.relative_to(e)):meta(p.read_bytes()) for p in e.rglob('*') if p.is_file()}
for name in ['README.md','retention.json','reviews.json','verify-retention.py']:(r/name).write_bytes((e/name).read_bytes())
(r/'initial-probe-history.json').write_bytes((e/'capacity/initial-probe-history.json').read_bytes());(r/'retained-input-pins.json').write_text(json.dumps(before,indent=2)+'\n')
manifest=json.loads((e/'retention.json').read_text());assert set(before)==set(manifest)|{'retention.json'}
for name,pin in manifest.items():assert before[name]==pin,name
reviews=json.loads((e/'reviews.json').read_text());total=0;reviewpins={}
for name,receipt in reviews.items():
 origin=Path('/private/tmp')/(name+'-20261016');archive=e/(name+'.zip');assert meta(archive.read_bytes())==receipt['archive']
 with zipfile.ZipFile(archive) as z:
  pins=json.loads(z.read('manifest.json'));assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(pins)|{'manifest.json'}
  assert z.read('manifest.json')==(origin/'manifest.json').read_bytes();assert z.read('review.json')==(origin/'review.json').read_bytes()
  assert len(pins)==receipt['artifacts'];assert meta(z.read('manifest.json'))==receipt['manifest'];assert meta(z.read('review.json'))==receipt['review']
  for n,pin in pins.items():assert meta(z.read(n))==pin and z.read(n)==(origin/n).read_bytes(),(name,n)
  total+=len(pins);reviewpins[name]={'artifacts':len(pins),'archive':receipt['archive'],'manifest':receipt['manifest'],'review':receipt['review']}
assert total==321 and len(reviews)==8
native=0
for epoch in ['r1','r3','r4']:
 root=e/('native-'+epoch);origin=Path('/private/tmp')/('truss-native-model-join-native-'+epoch+'-20261016');pins=json.loads((root/'source-before.json').read_text());native+=len(pins)
 for name in ['source-inputs.zip','source-before.json','campaign.json','joined-report.json','join-controls.json']:assert (root/name).read_bytes()==(origin/name).read_bytes(),(epoch,name)
 with zipfile.ZipFile(root/'source-inputs.zip') as z:
  assert set(z.namelist())==set(pins) and len(z.namelist())==len(set(z.namelist()))
  for n,pin in pins.items():assert meta(z.read(n))==pin
assert native==5091
plan=i/'docs/helix/04-build/implementation-plan.md';old=subprocess.check_output(['git','-C',str(i),'show','cf8ccbad:docs/helix/04-build/implementation-plan.md']);new=plan.read_bytes();assert new.startswith(old);append=new[len(old):];(r/'implementation-checkpoint.md').write_bytes(append);(r/'implementation-plan-pin.json').write_text(json.dumps(meta(new),indent=2)+'\n')
for n,pin in json.loads(Path('/private/tmp/truss-native-model-join-final-astra-20261016/closing-integration-pins.json').read_bytes()).items():assert meta((i/n).read_bytes())==pin,n
p=subprocess.run(['/private/tmp/weft-toolchain/venv/bin/python','-B',str(e/'verify-retention.py')],capture_output=True,text=True);(r/'verifier.stdout').write_text(p.stdout);(r/'verifier.stderr').write_text(p.stderr);assert p.returncode==0;reported=json.loads(p.stdout);assert reported['retainedFiles']==81 and reported['completeReviewerArtifacts']==321 and reported['nativeSourcePins']==5091 and reported['wheelMembers']==501
# Corrupt only returned in-memory bytes. No retained source/archive is modified.
original=Path.read_bytes;code=compile((e/'verify-retention.py').read_bytes(),str(e/'verify-retention.py'),'exec');controls=[]
for selected in [e/'README.md',e/'native-r4/campaign.json',e/'reviews.json']:
 def corrupted(path,selected=selected):
  raw=original(path)
  return raw+b' ' if path.resolve()==selected.resolve() else raw
 try:
  with patch.object(Path,'read_bytes',corrupted),contextlib.redirect_stdout(io.StringIO()):exec(code,{'__file__':str(e/'verify-retention.py'),'__name__':'__review_control__'})
 except AssertionError:controls.append({'inMemoryCorruption':str(selected.relative_to(e)),'refused':True})
 else:raise AssertionError('corruption accepted')
after={str(p.relative_to(e)):meta(p.read_bytes()) for p in e.rglob('*') if p.is_file()};assert before==after
result={'passed':True,'retainedFiles':81,'reviewArchives':8,'originalReviewerArtifacts':321,'exactOriginalArchiveMembers':True,'nativeSourcePins':5091,'nativeArchivesExactOriginals':True,'wheelMembers':501,'implementationAppendOnly':True,'reviewedProductionAndTestFilesUnchanged':14,'readOnlyVerifierResult':reported,'inMemoryCorruptionControls':controls,'retentionTreeBytesUnchanged':True,'SQLExecuted':False,'archivePins':reviewpins};(r/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='archivePins'},indent=2))
