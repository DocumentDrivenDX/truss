from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,io,collections
r=Path(__file__).resolve().parent;o=Path('/private/tmp/truss-native-model-join-native-r3-20261016');shutil.copytree(o,r/'inputs',dirs_exist_ok=True);shutil.copyfile(str(o)+'.log',r/'native.log');e=r/'inputs';H=lambda b:hashlib.sha256(b).hexdigest();pins=json.loads((e/'source-before.json').read_bytes());assert len(pins)==1861
review=Path('/private/tmp/truss-native-model-join-astra-r3-20261016');base='cf8ccbad907de4b5303db70ea1f7da72f621cefa';counts=collections.Counter();endpoint={}
with zipfile.ZipFile(e/'source-inputs.zip') as z:
 assert set(z.namelist())==set(pins) and len(z.namelist())==len(pins)
 batch=subprocess.Popen(['git','-C','/Users/erik/Projects/truss','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 for n,pin in pins.items():
  b=z.read(n);assert H(b)==pin['sha256'] and len(b)==pin['bytes'],n;kind=n.split('/')[0];counts[kind]+=1
  if kind=='base':
   batch.stdin.write((base+':'+n[5:]+'\n').encode());batch.stdin.flush();head=batch.stdout.readline().decode().split();assert len(head)==3 and head[1]=='blob',(n,head);gitbytes=batch.stdout.read(int(head[2]));assert batch.stdout.read(1)==b'\n';assert gitbytes==b,n
  if kind=='runtime-stage':
   assert b==(review/'source/packages/python/src'/n[len('runtime-stage/'):]).read_bytes(),n
   p=r/'reconstructed'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  if kind in ['owner','weft']:
   p=r/'captured'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  path=(Path('/private/tmp/truss-disclosure-main-integration-20261016')/n[5:] if kind=='base' else Path('/private/tmp/truss-native-model-join-r3-runtime-20261016')/n[len('runtime-stage/'):] if kind=='runtime-stage' else Path('/private/tmp/truss-native-model-join-native-r3-owner-20261016')/n[6:] if kind=='owner' else None)
  if path is not None:endpoint[n]=path.is_file() and path.read_bytes()==b
 batch.stdin.close();assert batch.wait()==0
 assert z.read('owner/test_native_model_correspondence.py')==Path('/private/tmp/truss-native-model-join-native-astra-r2-20261016/test-r2.py').read_bytes()
 for file in ['_native_model_correspondence.py','_owner_evidence_json.py']:
  assert z.read('owner/packages/python/src/truss/'+file)==z.read('runtime-stage/truss/'+file)==(review/'packet/candidate/packages/python/src/truss'/file).read_bytes()
 assert H(z.read('toolchain/weft.whl'))=='e072db75724608d652f3368ab1375907c3fbf2cd1e321a0d7a04bbdad4d92778'
 with zipfile.ZipFile(io.BytesIO(z.read('toolchain/weft.whl'))) as w:
  assert set('weft/'+n for n in w.namelist())==set(n for n in pins if n.startswith('weft/'))
  for n in w.namelist():assert z.read('weft/'+n)==w.read(n)
 assert (e/'runtime-release.json').read_bytes()==z.read('runtime-stage/truss/_catalog_runtime/manifest.json')
q=(e/'issued-requirements.json').read_bytes();issued=json.loads(q);raw=(e/'weft-original-request.json').read_bytes();assert issued['sourceRequestJson'].encode()==raw and issued['sourceRequestSha256']==H(raw)
for filename in ['observation-report.json','joined-report.json']:
 report=json.loads((e/filename).read_bytes())
 for p in report['sources']:
  names={'accepted-request':'accepted-request.json','accepted-assessment':'accepted-assessment.json','runtime-release':'runtime-release.json','native-inventory':'native-inventory.json','issued-requirements':'issued-requirements.json'};b=(e/names[p['role']]).read_bytes();assert H(b)==p['sha256'] and len(b)==p['bytes']
c=json.loads((e/'campaign.json').read_bytes());assert c['status']=='passed' and c['tests']==1 and c['sourcePins']==1861 and c['cleanup']['rootRemoved'] and c['cleanup']['postmasterStopped'] and c['cleanup']['postmasterPid']==53303;assert 'Ran 1 test in 6.714s' in (r/'native.log').read_text()
(r/'audit.json').write_text(json.dumps({'passed':True,'sourcePins':1861,'sourceClasses':dict(counts),'GitBaseline':base,'allBaseFilesExact':1349,'allRuntimeStageFilesExactReviewedR3':501,'testExactReviewedR2':True,'allArchiveMembersAndWheelMembersExact':True,'currentEndpointsChecked':len(endpoint),'currentEndpointsMatch':all(endpoint.values()),'endpointDifferences':[n for n,v in endpoint.items() if not v],'sourceArchiveSha256':H((e/'source-inputs.zip').read_bytes()),'campaign':c,'SQLExecuted':False},indent=2)+'\n');print((r/'audit.json').read_text())
