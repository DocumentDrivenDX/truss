from pathlib import Path
import hashlib,json,subprocess,tarfile,io,shutil
r=Path(__file__).resolve().parent;f=r/'frozen';m=json.loads((f/'manifest.json').read_text());rows=[]
for n,pin in m.items():
 b=(f/n).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],n;rows.append(n)
base='2a8bd1fee8ee8d644e6d47fff37145ff161170bb';s=r/'source';s.mkdir(exist_ok=True)
# Capture exact baseline project Python, config, and governance; omit unrelated bulk evidence.
paths=['packages/python','AGENTS.md','.helix.yml','docs/helix/README.md','docs/helix/02-design','scripts/check-module-boundaries.py']
p=subprocess.Popen(['git','-C','/Users/erik/Projects/truss','archive',base,*paths],stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as t:
 for x in t:
  if x.isfile():
   b=t.extractfile(x).read();out=s/x.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
assert p.wait()==0
sourcepins={}
for n,pin in m.items():
 if n.startswith(('packages/','docs/')):
  dst=s/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((f/n).read_bytes());sourcepins[n]=pin
(r/'audit.json').write_text(json.dumps({'passed':True,'manifestFiles':len(rows),'baseline':base,'overlay':sourcepins},indent=2)+'\n')
print(len(rows))
