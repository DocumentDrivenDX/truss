from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'frozen/manifest.json').read_text())
report={
 'status':'current-implementation-controls-pass-regression-test-gap-open',
 'packet':{'path':'review.zip','sha256':H((r/'review.zip').read_bytes()),'bytes':(r/'review.zip').stat().st_size},
 'baseline':'2a8bd1fee8ee8d644e6d47fff37145ff161170bb',
 'source':{'path':'frozen/packages/python/src/truss/_native_model_correspondence.py',**m['packages/python/src/truss/_native_model_correspondence.py']},
 'findings':[{'id':'NMC-JOIN-TEST-01','priority':2,'category':'regression-evidence','file':'packages/python/tests/test_native_model_correspondence.py','line':57,
 'title':'Protect complete member census with an extra unique active property',
 'finding':'Deleting only len(fields)!=len(properties) from the join passes all12 frozen tests. Existing missing-property and duplicate-property negatives are independently rejected by exact lookup; they do not exercise refusal of extra unique active native members.',
 'reproducer':'erase-complete-field-census.py and erase-complete-field-census.log retain the surviving mutant. The independent extra-unique-active-native-member control fails against that mutant and passes against the original guard.',
 'requestedChange':'Add permanent negative controls for an extra unique active non-Key native property under a matched Record and an omitted non-Key issued Field. Require the same whole-join refusal and verify these controls detect removal of the census comparison.',
 'scope':'No incorrect result was observed in the current implementation; this is a missing permanent regression control for a required join invariant.'}],
 'validation':[
  {'command':'python3.12 reconstruct.py','result':'All15 packet manifest entries verified; exact baseline Python/governance reconstructed and10 overlays applied.6 JSON unit fixtures match the previously retained native-R3 epoch bytes exactly.','receipts':['audit.json','fixture-custody.json','source-after.json']},
  {'command':'python3.11 -B run-tests.py selected','result':'12 tests pass against the reviewed e072 wheel/native9f1. Metadata capture is explicitly mocked; no SQL.','receipts':['selected-original-tests.json','selected-tests.json'],'log':'selected-restored.log'},
  {'command':'python3.11 -B run-tests.py default','result':'9 pass and3 intentional skips with external Weft imports actively denied; zero attempted imports.','receipt':'default-tests.json'},
  {'command':'python3.11 -B adversarial.py','result':'83 controls pass: complete identities/native IDs/member census, descriptor/home restrictions, strict JSON and effective8MiB decoder boundary, actual native receiver/retained-parent/closing checks and deadline failures. Report bound tested with an explicitly scaled guard, not claimed full4MB population evidence.','receipt':'adversarial.json'},
  {'command':'python3.11 -B mutations.py','result':'Ordered-Key equality and original-document equality removals are caught by frozen tests. Member-census removal survives frozen tests and is caught by independent control. All source bytes restored; final12-test replay passes.','receipt':'mutations.json'}
 ],
 'conclusions':[
  'Factory takes an actual native CurrentPresencePreparation, derives requirements through its existing public native methods, retains the same actual current/parent, and invokes the existing native observer directly. It has no supplied-Q or compiler-callback argument.',
  'Join compares original module pins/document bytes and issued Record/member/ordered-Key identities with native metadata; it does not resolve model, key, policy or domain semantics independently. Unsupported selected realizations refuse.',
  'Reports retain full sources/requirements and false completion/authority/securityReady. The constructible dataclass is data, never an unforgeable witness. No operation-currentness or guarded-release conclusion follows from these checks.'
 ],
 'qualifications':[
  'R1 has only substituted native metadata unit evidence. Actual native join execution with source capture remains future work; no SQL was executed by this reviewer.',
  'The declared16,000,000-byte requirements pre-cap composes with unchanged owner JSON decoder cap8,388,608; the effective accepted byte limit is8MiB, with original depth/node/member/numeric/scalar limits also applying.4,000,000 report bytes and existing observer caps are retained; not peak-memory or pre-materialization guarantees.',
  'Ordered composite Key control is supplied metadata only; the native fixture five Keys are single-component. No native composite/domain/facet/comparator/codec/key-byte/graph proof or other storage-home/nullable/structured realization is established.',
  'Closing-identity adversaries deliberately patch methods within trusted local Python to model damage; this is not hostile-code isolation in one interpreter. Native capture is deliberately substituted in every factory test.',
  'Observer and accepted-source assessor remain unchanged from exact baseline. No public export, registration, consumer activation, default dependency repin, caller/current-cut authority, guarded release or132 Truss/shared158 acceptance promotion.',
  'Runtime/caches are non-hermetic; source endpoint correspondence is not a held-file/ABA proof. Fixture historical native results are not retroactively attributed to this new join.'
 ],
 'retainedHistory':'Exact initial prototype private-Rust-method AttributeError source/receipt remains in frozen packet. The first reviewer mutation harness expected authored detection; its failure is retained as the confirmed surviving-census-mutant evidence.',
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256,bytes}; excludes itself and reproducible source/ tree (exact Git baseline plus retained overlay)'},
 'reviewedWeft':{'wheelSha256':'e072db75724608d652f3368ab1375907c3fbf2cd1e321a0d7a04bbdad4d92778','nativeSha256':'9f1c7bc60f070734f2e935ba53e82a0bd22002e9e738c34f65623ca8bac978dd','review':'/private/tmp/weft-model-requirements-bridge-astra-r1-20261016/review.json','reviewSha256':'c3633cdc2400751f6c4f21060d32fa75dd809468c4992a6654080228ea2c05bc'}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={}
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if not p.is_file() or rel.parts[0]=='source' or '__pycache__' in rel.parts or str(rel)=='manifest.json':continue
 b=p.read_bytes();manifest[str(rel)]={'sha256':H(b),'bytes':len(b)}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'reviewSha256':H((r/'review.json').read_bytes()),'manifestSha256':H((r/'manifest.json').read_bytes()),'artifacts':len(manifest),'bytes':sum(v['bytes'] for v in manifest.values())},indent=2))
