from pathlib import Path
import sys,os,unittest,importlib.abc,json,hashlib
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'source/packages/python/src'));sys.path.insert(0,str(r/'source/packages/python/tests'));mode=sys.argv[1];attempts=[]
if mode=='selected':
 sys.path.insert(0,'/private/tmp/weft-model-requirements-bridge-astra-r1-20261016/installed/combined');os.environ['TRUSS_MODEL_JOIN_WEFT_QUALIFICATION']='1'
else:
 os.environ.pop('TRUSS_MODEL_JOIN_WEFT_QUALIFICATION',None)
 class Deny(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname=='weft' or fullname.startswith('weft.'):
    attempts.append(fullname);raise ImportError('Independent optional dependency absence control')
 sys.meta_path.insert(0,Deny())
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_native_model_correspondence'))
receipt={'mode':mode,'passed':result.wasSuccessful(),'testsRun':result.testsRun,'skips':len(result.skipped),'weftImportAttempts':attempts,'SQLExecuted':False}
if mode=='selected':
 import weft
 receipt['loadedNative']={'path':weft.weft.__file__,'sha256':hashlib.sha256(Path(weft.weft.__file__).read_bytes()).hexdigest()}
else:assert attempts==[]
(r/(mode+'-tests.json')).write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if result.wasSuccessful() else 1)
