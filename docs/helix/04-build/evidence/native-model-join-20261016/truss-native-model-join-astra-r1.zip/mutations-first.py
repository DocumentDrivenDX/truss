from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parent;p=r/'source/packages/python/src/truss/_native_model_correspondence.py';original=p.read_bytes();rows=[]
mutants=[
 ('erase-ordered-key-equality',b" or key_row['prop_ids']!=[by_ref[f] for f in ordered]",b'', 'test_composite_order_is_not_set_order_in_supplied_metadata'),
 ('erase-complete-field-census',b' or len(fields)!=len(properties)',b'', 'test_native_id_and_key_census_are_exact'),
 ('erase-original-document-equality',b" or m['documentJson']!=a['documentJson']",b'', 'test_wrong_original_source_and_preparation_hash_refuse')]
try:
 for name,old,new,expected in mutants:
  assert original.count(old)==1,(name,original.count(old));mutant=original.replace(old,new);(r/(name+'.py')).write_bytes(mutant);p.write_bytes(mutant)
  result=subprocess.run(['/private/tmp/truss-practical-performance-env/bin/python','-B',str(r/'run-tests.py'),'selected'],capture_output=True,text=True)
  log=result.stdout+result.stderr;(r/(name+'.log')).write_text(log)
  # Running the authored cases intentionally writes selected-tests.json; preserve each failed epoch then restore below.
  (r/(name+'-tests.json')).write_bytes((r/'selected-tests.json').read_bytes())
  passed=result.returncode==1 and ('FAIL: '+expected) in log
  rows.append({'mutant':name,'sha256':hashlib.sha256(mutant).hexdigest(),'exitCode':result.returncode,'expectedFailedTest':expected,'effective':passed});assert passed,(name,log)
finally:p.write_bytes(original)
result=subprocess.run(['/private/tmp/truss-practical-performance-env/bin/python','-B',str(r/'run-tests.py'),'selected'],capture_output=True,text=True);(r/'selected-restored.log').write_text(result.stdout+result.stderr);assert result.returncode==0
(r/'mutations.json').write_text(json.dumps({'passed':True,'mutations':rows,'restoredSourceSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print(json.dumps(rows))
