from pathlib import Path
import sys,json,copy,hashlib,gc
from types import SimpleNamespace
from unittest.mock import patch
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'source/packages/python/src'));sys.path.insert(0,'/private/tmp/weft-model-requirements-bridge-astra-r1-20261016/installed/combined')
import weft
import truss._native_model_correspondence as mod
f=r/'frozen/packages/python/tests/fixtures/native-model-correspondence';q=json.loads((f/'issued-requirements.json').read_bytes());a=json.loads((f/'accepted-assessment.json').read_bytes());i=json.loads((f/'native-inventory.json').read_bytes())
wire=lambda x:json.dumps(x,separators=(',',':')).encode();H=lambda b:hashlib.sha256(b).hexdigest()
base=SimpleNamespace(**{k:(f/n).read_bytes() for k,n in [('accepted_request','accepted-request.json'),('accepted_assessment','accepted-assessment.json'),('runtime_release','runtime-release.json'),('native_inventory','native-inventory.json')]})
rows=[]
def run(name,fn,refuse=True,exc=(ValueError,)):
 try:out=fn()
 except exc as e:
  rows.append({'id':name,'expectedRefusal':refuse,'passed':refuse,'errorType':type(e).__name__,'error':str(e)});assert refuse,name;return
 rows.append({'id':name,'expectedRefusal':refuse,'passed':not refuse,'outputSha256':H(out) if type(out)is bytes else None});assert not refuse,name;return out
def join(editq=None,edita=None,editi=None,original=None):
 Q=copy.deepcopy(q);A=copy.deepcopy(a);I=copy.deepcopy(i);obs=copy.copy(base)
 if editq:editq(Q)
 if edita:edita(A)
 if editi:editi(I)
 obs.accepted_assessment=wire(A);obs.native_inventory=wire(I)
 return mod._join(obs,wire(Q) if original is None else original,q['preparationSha256'],lambda:None)
original=run('baseline-exact-join',lambda:mod._join(base,(f/'issued-requirements.json').read_bytes(),q['preparationSha256'],lambda:None),False)
# Exact native IDs and full original identity/member census.
for n in [True,False,0,-1,2**31,1.0]:
 run('type-id-'+repr(n),lambda n=n:join(edita=lambda A:A['inventory']['types'][0].update(type_id=n)))
 run('property-id-'+repr(n),lambda n=n:join(edita=lambda A:A['inventory']['properties'][0].update(prop_id=n)))
for n in [True,0,-1,32768,1.0]:run('key-number-'+repr(n),lambda n=n:join(edita=lambda A:A['inventory']['keys'][0].update(key_num=n)))
for label,edit in [('provisional',lambda t:t.update(provisional=True)),('retired',lambda t:t.update(retired_rev=2)),('non-Record',lambda t:t.update(kind='scalar')),('module',lambda t:t.update(module='other')),('document',lambda t:t.update(document_id='other')),('element',lambda t:t.update(element='other'))]:
 run('native-record-'+label,lambda edit=edit:join(edita=lambda A:edit(A['inventory']['types'][0])))
for field in ['definition_document_id','declaration_module','element']:
 run('property-source-'+field,lambda field=field:join(edita=lambda A:A['inventory']['properties'][0].update({field:'other'})))
run('duplicate-native-Record-ID',lambda:join(edita=lambda A:A['inventory']['types'][1].update(type_id=A['inventory']['types'][0]['type_id'])))
run('duplicate-native-property-ID-within-Record',lambda:join(edita=lambda A:A['inventory']['properties'][1].update(prop_id=A['inventory']['properties'][0]['prop_id'])))
def extra_active(A):
 p=copy.deepcopy(A['inventory']['properties'][0]);p.update(prop_id=2000000000,element='unique-unissued-field',name='unique-unissued-field');A['inventory']['properties'].append(p)
run('extra-unique-active-native-member',lambda:join(edita=extra_active))
run('missing-issued-member',lambda:join(editq=lambda Q:Q['records'][0]['fields'].pop()))
run('duplicate-issued-member',lambda:join(editq=lambda Q:Q['records'][0]['fields'].__setitem__(1,copy.deepcopy(Q['records'][0]['fields'][0]))))
run('duplicate-key-component',lambda:join(editq=lambda Q:Q['records'][0]['selectedKey']['fields'].append(copy.deepcopy(Q['records'][0]['selectedKey']['fields'][0]))))
for label,edit in [('shape',lambda d:d.update(kind='array')),('nullable',lambda d:d['type'].update(nullable=True)),('availability',lambda d:d.update(availability='unspecified')),('family',lambda d:d['type'].update(family='date')),('nested-identity',lambda d:d['identity'].update(element='other'))]:
 run('descriptor-'+label,lambda edit=edit:join(editq=lambda Q:edit(Q['records'][0]['fields'][0]['descriptors'][0])))
for label,value in [('home','column'),('cardinality','array'),('nullability','nullable'),('scalar_type','date')]:
 run('property-profile-'+label,lambda label=label,value=value:join(edita=lambda A:A['inventory']['properties'][0].update({label:value})))
for key,value in [('notNull',False),('notNull',1),('generated','s'),('identity','a'),('collationOid','100'),('typmod',20),('dropped',True),('typeOid','25')]:
 run('object-column-'+key,lambda key=key,value=value:join(editi=lambda I:next(c for R in I['relations'] if R['name']=='object' for c in R['columns'] if c['name']=='props').update({key:value})))
for key,value in [('version','unknown'),('authority',True),('complete',True),('securityReady',True),('nativeAdmission','admitted'),('preparationSha256','0'*64)]:run('issued-profile-'+key,lambda key=key,value=value:join(editq=lambda Q:Q.update({key:value})))
for label,raw in [('duplicate-member',b'{"a":1,"a":2}'),('surrogate',b'{"a":"\\ud800"}'),('invalid-utf8',b'{"a":"\xff"}'),('nonfinite',b'{"a":NaN}'),('depth',b'['*130+b'0'+b']'*130),('empty',b''),('first-declared-oversize',b' '*16000001)]:run('strict-'+label,lambda raw=raw:join(original=raw))
# Record/Field order belongs to issued requirements; physical catalog row order is irrelevant.
rev=run('native-catalog-order-independent',lambda:join(edita=lambda A:[A['inventory'][k].reverse() for k in ['types','properties','keys']]),False)
assert json.loads(rev)['records']==json.loads(original)['records']
# Unknown/facet content is retained in hashes and original observations, not given semantic authority.
facets=run('unresolved-facets-do-not-pretend-admission',lambda:join(edita=lambda A:A['inventory']['properties'][0].update(facets={'futureMeaning':True})),False)
assert json.loads(facets)['authority'] is False and json.loads(facets)['complete'] is False
# Effective decoder capacity is stricter than the method's16,000,000 pre-cap.
base_raw=wire(q);budget=8388608
for length in [budget,budget+1]:
 padded=base_raw+b' '*(length-len(base_raw));run('effective-owner-byte-bound-'+str(length),lambda padded=padded:mod._join(base,padded,q['preparationSha256'],lambda:None),length>budget)
# Exercise exact report-bound branch with a scaled test guard; not a claim of actual4MB coverage.
with patch.object(mod,'MAX_REPORT_BYTES',len(original)):run('report-bound-exact-scaled',lambda:mod._join(base,(f/'issued-requirements.json').read_bytes(),q['preparationSha256'],lambda:None),False)
with patch.object(mod,'MAX_REPORT_BYTES',len(original)-1):run('report-bound-first-failure-scaled',lambda:mod._join(base,(f/'issued-requirements.json').read_bytes(),q['preparationSha256'],lambda:None))
# Factory exercises actual issued native objects. Only capture metadata is substituted.
raw=(f/'weft-original-request.json').read_text();parent=weft.prepare_application_lineage(raw);current=parent.prepare_current_presence();other=weft.prepare_application_lineage(raw);cls=type(current);calls=[];cursor=SimpleNamespace(_deadline=SimpleNamespace(check=lambda:calls.append('deadline')))
with patch.object(mod,'capture_native_source_observation_with_cursor',return_value=base) as capture:
 result=mod.capture_native_model_correspondence_with_cursor(cursor,current=current,accepted_request=base.accepted_request)
 assert result.current is current and result.parent is parent and result.requirements==(f/'issued-requirements.json').read_bytes() and result.report==original and capture.call_count==1
 rows.append({'id':'actual-factory-exact-held-inputs','passed':True,'deadlineChecks':len(calls)})
 pid=id(parent);del parent;gc.collect();assert id(result.current.source_preparation())==pid and result.parent is result.current.source_preparation();rows.append({'id':'factory-retains-actual-parent-after-GC','passed':True})
with patch.object(mod,'capture_native_source_observation_with_cursor',side_effect=AssertionError('must not capture')):
 for name,kwargs in [('requirements',{'requirements':b'{}'}),('callback',{'compile':lambda:b'{}'})]:
  run('factory-no-supplied-'+name,lambda kwargs=kwargs:mod.capture_native_model_correspondence_with_cursor(cursor,current=current,accepted_request=base.accepted_request,**kwargs),exc=(TypeError,))
# Deliberate local class-method patches model damaged closing custody, not an external attack.
for name,attr,values in [('changed-preparation','json',[current.json(),current.json()+' ']),('replaced-parent','source_preparation',[current.source_preparation(),other])]:
 with patch.object(mod,'capture_native_source_observation_with_cursor',return_value=base),patch.object(cls,attr,side_effect=values):
  run('closing-'+name,lambda:mod.capture_native_model_correspondence_with_cursor(cursor,current=current,accepted_request=base.accepted_request))
for index in [1,2,3,4,5,6,7,8]:
 count=[0]
 def tick():
  count[0]+=1
  if count[0]==index:raise TimeoutError('adversarial deadline')
 with patch.object(mod,'capture_native_source_observation_with_cursor',return_value=base):
  run('factory-deadline-'+str(index),lambda:mod.capture_native_model_correspondence_with_cursor(SimpleNamespace(_deadline=SimpleNamespace(check=tick)),current=current,accepted_request=base.accepted_request),exc=(TimeoutError,))
receipt={'passed':all(x['passed'] for x in rows),'controls':len(rows),'rows':rows,'nativeModuleSha256':H(Path(weft.weft.__file__).read_bytes()),'effectiveRequirementsBytes':8388608,'SQLExecuted':False,'scope':'Actual Weft issued objects; supplied/substituted metadata unit tests, not native capture or authority. Scaled report-bound controls and trusted local method mutation explicitly qualified.'}
(r/'adversarial.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'passed':True,'controls':len(rows)}))
