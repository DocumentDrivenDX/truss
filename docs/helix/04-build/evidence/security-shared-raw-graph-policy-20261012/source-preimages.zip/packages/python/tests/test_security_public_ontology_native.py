"""Actual public graph ontology fixture; candidate lowering, not admitted security."""
import json,os,subprocess
from pathlib import Path
import psycopg
from truss import Ok
from truss.contracts import TextValue,BooleanValue
from truss.groups import CreateObject,CreateEdge,AuthoredValue,RootlessOwnership,AliasObjectReference,NullOrderKey,GroupSuccess,RequestNone
import test_group_create_native as groups
RECORDS={'Client':{'code':'string'},'Project':{'code':'string'},'Staff':{'code':'string','login':'string'},'Resource':{'code':'string'},'Assignment':{'code':'string','active':'boolean'}}
LINKS={'staff_assignment':('Staff','Assignment'),'assignment_project':('Assignment','Project'),'resource_project':('Resource','Project'),'project_client':('Project','Client')}
class PublicOntologySecurityTests(groups.PublicCreateGroupTests):
 for name in tuple(n for n in dir(groups.PublicCreateGroupTests) if n.startswith('test_')):locals()[name]=None
 def tearDown(self):
  self.admin.rollback();self.admin.execute('DROP SCHEMA IF EXISTS relational_fixture CASCADE;DROP SCHEMA IF EXISTS ontology_fixture CASCADE')
  super().tearDown()
 def consumer(self):
  # Larger atomic ontology seed; retain an explicit finite native deadline.
  from truss import adopt_psycopg_host,create_reference_assembly,CatalogRuntimeConfiguration
  params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']='consumer'
  connection=psycopg.connect(**params,autocommit=True,options='-c statement_timeout=60000')
  self.addCleanup(connection.close);connection.execute('BEGIN');host=adopt_psycopg_host(connection,statement_timeout_ms=60000,operation_timeout_ms=60000);self.addCleanup(host.detach);self.consumer_connections.append((connection,host))
  assembly=create_reference_assembly(CatalogRuntimeConfiguration(),host).value
  return connection,host,assembly,host.adopt_transaction().value
 def model(self,document):
  if document['id']!='adoc':return # The ontology belongs to adoc; retain zdoc baseline.
  m=document['modules'][0];m['elements']=[];m['relationships']=[]
  for name,fields in RECORDS.items():
   m['elements'].append({'id':name,'kind':'record','members':[{'module':'m','element':name+'-'+f} for f in fields],'keys':[{'id':'pk','name':'primary','primary':True,'fields':[{'module':'m','element':name+'-code'}]}],'extensions':{}})
   for field,scalar in fields.items():m['elements'].append({'id':name+'-'+field,'name':name+'-'+field,'kind':'field','scalarType':scalar,'nullability':'required','cardinality':'one','extensions':{}})
  for name,(source,target) in LINKS.items():m['relationships'].append({'id':name,'name':name,'source':[{'module':'m','element':source}],'target':[{'module':'m','element':target,'key':'pk'}],'sourceMultiplicity':{'min':0,'max':100},'targetMultiplicity':{'min':0,'max':100},'targetLifecycle':'independent','directed':True})
 def test_public_created_membership_graph(self):
  c,h,a,t=self.ready(self.model);ops=[]
  def node(record,code,**extras):
   values={'code':code,**extras};ops.append(CreateObject(type_definition_pin=self.types[('adoc',record)].definition_pin,values=tuple(AuthoredValue(name=record+'-'+f,value=BooleanValue(value=v) if isinstance(v,bool) else TextValue(kind='string',text=v)) for f,v in values.items()),ownership=RootlessOwnership(),alias=code))
  node('Client','C');node('Project','A');node('Project','B')
  for login in ['alice','bob','outsider']:node('Staff','staff-'+login,login=login)
  for code in ['RA','RB','RAB','RO']:node('Resource',code)
  for code,active in [('AA',True),('AB',False),('BB',True)]:node('Assignment',code,active=active)
  connections={'staff_assignment':[('staff-alice','AA'),('staff-alice','AB'),('staff-bob','BB')],'assignment_project':[('AA','A'),('AB','B'),('BB','B')],'resource_project':[('RA','A'),('RB','B'),('RAB','A'),('RAB','B')],'project_client':[('A','C'),('B','C')]}
  for link,pairs in connections.items():
   pin=a.get_relationship_reference_in_transaction(t,document_id='adoc',module_id='m',relationship_id=link).value.definition_pin
   for i,(source,target) in enumerate(pairs):ops.append(CreateEdge(relationship_definition_pin=pin,source=AliasObjectReference(alias=source),target=AliasObjectReference(alias=target),values=(),order_key=NullOrderKey(),alias=link+str(i)))
  inp,_=self.input(a,t,tuple(ops));result=a.apply_in_transaction(t,inp,RequestNone(),documents=self.documents,bun_executable='/opt/homebrew/bin/bun');self.assertIsInstance(result,Ok,str(a._host._custody.last_attempt.error));self.assertIsInstance(result.value,GroupSuccess);h.detach();c.commit()
  packet={'records':{},'links':{}}
  for record,fields in RECORDS.items():
   type_id=self.types[('adoc',record)].type_id;props={name:str(pid) for name,pid in self.admin.execute('SELECT name,prop_id FROM truss.prop_def WHERE type_id=%s',(int(type_id),))}
   packet['records'][record]={'typeId':type_id,'fields':{f:{'id':props[record+'-'+f],'scalar':scalar} for f,scalar in fields.items()}}
  for link,(source,target) in LINKS.items():packet['links'][link]={'id':str(self.admin.execute("SELECT rel_type_id FROM truss.rel_def WHERE document_id='adoc' AND module='m' AND rel_id=%s",(link,)).fetchone()[0]),'source':source,'target':target}
  produced=subprocess.run(['/opt/homebrew/bin/bun',str(Path(__file__).resolve().parents[3]/'tests/fixtures/security-public-ontology.ts')],input=json.dumps(packet),text=True,capture_output=True,timeout=30);self.assertEqual(produced.returncode,0,produced.stderr);sql=json.loads(produced.stdout);observations=[]
  version=self.admin.execute('SHOW server_version_num').fetchone()[0];self.assertEqual(version,'180006');observations.append({'id':'native-version','observed':version})
  self.admin.execute('CREATE SCHEMA ontology_fixture')
  for name,source in sql['objects'].items():
   valid=self.admin.execute(source['validitySql']).fetchone()[0];self.assertEqual(valid,'true');observations.append({'id':'complete-object-source-'+name,'observed':valid});self.admin.execute('CREATE VIEW ontology_fixture.'+name.lower()+' AS '+source['sql'])
  for name,source in sql['edges'].items():
   valid=self.admin.execute(source['validitySql']).fetchone()[0];self.assertEqual(valid,'true');observations.append({'id':'complete-edge-endpoints-'+name,'observed':valid});self.admin.execute('CREATE VIEW ontology_fixture.'+name+' AS '+source['sql'])
  self.admin.execute('CREATE VIEW ontology_fixture.assignments AS SELECT a.code,a.active,s.source_code AS staff_code,p.target_code AS project_code FROM ontology_fixture.assignment a LEFT JOIN ontology_fixture.staff_assignment s ON s.target_code=a.code LEFT JOIN ontology_fixture.assignment_project p ON p.source_code=a.code')
  rows=self.admin.execute('SELECT code,active,staff_code,project_code FROM ontology_fixture.assignments ORDER BY code').fetchall();self.assertEqual(rows,[('AA',True,'staff-alice','A'),('AB',False,'staff-alice','B'),('BB',True,'staff-bob','B')]);observations.append({'id':'actual-assignment-business-key-facts','observed':[list(r) for r in rows]})
  self.admin.execute('CREATE ROLE ontology_facts NOLOGIN NOINHERIT NOSUPERUSER NOBYPASSRLS;GRANT USAGE ON SCHEMA truss,ontology_fixture TO ontology_facts;GRANT SELECT(id,type_id,props) ON truss.object TO ontology_facts;GRANT SELECT(id,rel_type_id,source_id,source_type,target_id,target_type) ON truss.edge TO ontology_facts')
  self.addCleanup(self.admin.execute,'DROP OWNED BY ontology_facts;DROP ROLE ontology_facts')
  for name in [*RECORDS,*LINKS,'assignments']:self.admin.execute('ALTER VIEW ontology_fixture.'+name.lower()+' OWNER TO ontology_facts')
  self.admin.execute('CREATE FUNCTION ontology_fixture.decision_bound(text,text) RETURNS text LANGUAGE SQL SECURITY INVOKER SET search_path=pg_catalog,pg_temp SET row_security=on AS $$ '+sql['fold']['sql']+' $$;REVOKE ALL ON FUNCTION ontology_fixture.decision_bound(text,text) FROM PUBLIC;GRANT CREATE ON SCHEMA ontology_fixture TO ontology_facts;ALTER FUNCTION ontology_fixture.decision_bound(text,text) OWNER TO ontology_facts')
  self.admin.execute("CREATE FUNCTION ontology_fixture.eligible_bound(text,text) RETURNS bool LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog,pg_temp SET row_security=on AS $$ DECLARE decision text;BEGIN decision:=ontology_fixture.decision_bound($1,$2);IF decision IS NULL OR decision NOT IN ('permit','deny') THEN RAISE EXCEPTION 'security facts unavailable' USING ERRCODE='55000';END IF;RETURN decision='permit';END $$;REVOKE ALL ON FUNCTION ontology_fixture.eligible_bound(text,text) FROM PUBLIC;ALTER FUNCTION ontology_fixture.eligible_bound(text,text) OWNER TO ontology_facts")
  self.admin.execute("CREATE FUNCTION ontology_fixture.eligible(text) RETURNS bool LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,pg_temp SET row_security=on AS $$ DECLARE subject_count bigint;subject_key text;BEGIN IF current_setting('transaction_isolation')<>'read committed' THEN RAISE EXCEPTION 'security authority profile unavailable' USING ERRCODE='0A000';END IF;SELECT count(*),min(code) INTO subject_count,subject_key FROM ontology_fixture.staff WHERE login OPERATOR(pg_catalog.=) SESSION_USER::pg_catalog.text;IF subject_count<>1 THEN RAISE EXCEPTION 'security facts unavailable' USING ERRCODE='55000';END IF;RETURN ontology_fixture.eligible_bound($1,subject_key);END $$;REVOKE ALL ON FUNCTION ontology_fixture.eligible(text) FROM PUBLIC;ALTER FUNCTION ontology_fixture.eligible(text) OWNER TO ontology_facts;REVOKE CREATE ON SCHEMA ontology_fixture FROM ontology_facts")
  self.admin.execute('ALTER TABLE truss.object ENABLE ROW LEVEL SECURITY;ALTER TABLE truss.object FORCE ROW LEVEL SECURITY;CREATE POLICY complete_private_facts ON truss.object FOR SELECT TO ontology_facts USING(true)')
  resource=packet['records']['Resource'];key=resource['fields']['code']['id']
  for login in ['alice','bob','outsider']:
   self.admin.execute('CREATE ROLE '+login+' LOGIN NOSUPERUSER NOBYPASSRLS;GRANT USAGE ON SCHEMA truss,ontology_fixture TO '+login+';GRANT SELECT(id,type_id,props) ON truss.object TO '+login+';GRANT EXECUTE ON FUNCTION ontology_fixture.eligible(text) TO '+login)
   self.addCleanup(self.admin.execute,'DROP OWNED BY '+login+';DROP ROLE '+login)
  self.admin.execute("CREATE POLICY resource_membership ON truss.object FOR SELECT TO alice,bob,outsider USING(type_id="+resource['typeId']+" AND ontology_fixture.eligible(props->'"+key+"'->>'text'))")
  expected={'alice':['RA','RAB'],'bob':['RAB','RB'],'outsider':[]}
  for login,wanted in expected.items():
   params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']=login
   with psycopg.connect(**params,autocommit=True) as reader:
    identity=reader.execute('SELECT session_user,current_user').fetchone();self.assertEqual(identity,(login,login));observations.append({'id':'original-native-caller-'+login,'observed':list(identity)})
    actual=[r[0] for r in reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,wanted);observations.append({'id':'membership-resource-oracle-'+login,'expected':wanted,'observed':actual})
    count=reader.execute('SELECT count(*) FROM truss.object').fetchone()[0];self.assertEqual(count,len(wanted));observations.append({'id':'membership-count-'+login,'observed':count})
    flags=reader.execute('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user').fetchone();self.assertEqual(flags,(False,False));observations.append({'id':'ordinary-native-flags-'+login,'observed':list(flags)})
    private_count=reader.execute('SELECT count(*) FROM truss.object WHERE type_id=%s',(int(packet['records']['Assignment']['typeId']),)).fetchone()[0];self.assertEqual(private_count,0);observations.append({'id':'hidden-assignment-object-count-'+login,'observed':private_count})
    with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute('SELECT * FROM truss.edge')
    observations.append({'id':'private-native-edge-table-denied-'+login,'observed':'42501'})
    with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute("SELECT ontology_fixture.eligible_bound('RB','staff-bob')")
    observations.append({'id':'caller-supplied-subject-binding-denied-'+login,'observed':'42501'})
    with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute('SET ROLE ontology_facts')
    observations.append({'id':'private-fact-owner-adoption-denied-'+login,'observed':'42501'})
    storage_substitution=reader.execute('SELECT id FROM truss.object WHERE ontology_fixture.eligible(id::text)').fetchall();self.assertEqual(storage_substitution,[]);observations.append({'id':'storage-id-is-not-business-key-'+login,'observed':storage_substitution})
    with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute('SELECT * FROM ontology_fixture.assignments')
    observations.append({'id':'private-assignment-view-denied-'+login,'observed':'42501'})
  aliases={entry.alias:entry.identity for entry in result.value.response.semantic.aliases};assignment=packet['records']['Assignment'];active_id=assignment['fields']['active']['id']
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':False}),int(aliases['AA'].id),int(assignment['typeId'])))
  for login,wanted in [('alice',[]),('bob',['RAB','RB'])]:
   params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']=login
   with psycopg.connect(**params,autocommit=True) as reader:
    actual=[r[0] for r in reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,wanted);observations.append({'id':'fresh-statement-after-committed-assignment-change-'+login,'expected':wanted,'observed':actual})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':True}),int(aliases['AA'].id),int(assignment['typeId'])))
  params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']='alice'
  with psycopg.connect(**params,autocommit=True) as reader:
   actual=[r[0] for r in reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,['RA','RAB']);observations.append({'id':'restored-assignment-original-visibility','observed':actual})
  # A malformed hidden assignment must not look like a complete empty result.
  self.admin.execute('UPDATE truss.object SET props=props-%s WHERE id=%s AND type_id=%s',(active_id,int(aliases['AB'].id),int(assignment['typeId'])))
  valid=self.admin.execute(sql['objects']['Assignment']['validitySql']).fetchone()[0];self.assertEqual(valid,'false');observations.append({'id':'hidden-assignment-required-field-preflight-invalid','observed':valid})
  decision=self.admin.execute("SELECT ontology_fixture.decision_bound('RB','staff-bob')").fetchone()[0];self.assertEqual(decision,'indeterminate');observations.append({'id':'unrelated-valid-permit-cannot-hide-incomplete-facts','observed':decision})
  for login in ['alice','bob','outsider']:
   params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']=login
   with psycopg.connect(**params,autocommit=True) as reader:
    for operation,query in [('list','SELECT id FROM truss.object'),('count','SELECT count(*) FROM truss.object')]:
     with self.assertRaises(psycopg.errors.ObjectNotInPrerequisiteState) as failure:reader.execute(query).fetchall()
     self.assertEqual(failure.exception.sqlstate,'55000');self.assertEqual(failure.exception.diag.message_primary,'security facts unavailable');observations.append({'id':'incomplete-private-facts-refuse-'+operation+'-'+login,'observed':{'sqlState':'55000','message':'security facts unavailable'}})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':False}),int(aliases['AB'].id),int(assignment['typeId'])))
  valid=self.admin.execute(sql['objects']['Assignment']['validitySql']).fetchone()[0];self.assertEqual(valid,'true');observations.append({'id':'complete-assignment-facts-restored','observed':valid})
  params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']='bob'
  with psycopg.connect(**params,autocommit=True) as reader:
   actual=[r[0] for r in reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,['RAB','RB']);observations.append({'id':'restored-facts-original-bob-visibility','observed':actual})
  # An endpoint object exists, but a required business key cannot be decoded.
  project=packet['records']['Project'];project_key=project['fields']['code']['id']
  self.admin.execute('UPDATE truss.object SET props=props-%s WHERE id=%s AND type_id=%s',(project_key,int(aliases['B'].id),int(project['typeId'])))
  rows=self.admin.execute('SELECT occurrence_id,source_code,target_code FROM ontology_fixture.resource_project ORDER BY occurrence_id').fetchall();self.assertEqual(len(rows),4);self.assertEqual(sum(row[2] is None for row in rows),2);observations.append({'id':'malformed-project-key-preserves-original-edge-population','edgeCount':len(rows),'nullTargetKeys':2})
  decision=self.admin.execute("SELECT ontology_fixture.decision_bound('RA','staff-alice')").fetchone()[0];self.assertEqual(decision,'indeterminate');observations.append({'id':'valid-other-project-does-not-hide-null-endpoint-key','observed':decision})
  for login in ['alice','bob','outsider']:
   params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']=login
   with psycopg.connect(**params,autocommit=True) as reader:
    with self.assertRaises(psycopg.errors.ObjectNotInPrerequisiteState) as failure:reader.execute('SELECT count(*) FROM truss.object').fetchall()
    self.assertEqual(failure.exception.sqlstate,'55000');observations.append({'id':'incomplete-endpoint-key-refuses-count-'+login,'observed':'55000'})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(project_key,json.dumps({'kind':'string','text':'B'}),int(aliases['B'].id),int(project['typeId'])))
  decision=self.admin.execute("SELECT ontology_fixture.decision_bound('RA','staff-alice')").fetchone()[0];self.assertEqual(decision,'permit');observations.append({'id':'restored-project-key-restores-original-decision','observed':decision})
  # Ownerless data must not short-circuit a missing intrinsic subject binding.
  for resource_key,subject_key in [('RO',None),(None,'staff-alice')]:
   decision=self.admin.execute('SELECT ontology_fixture.decision_bound(%s,%s)',(resource_key,subject_key)).fetchone()[0];self.assertEqual(decision,'indeterminate');observations.append({'id':'missing-intrinsic-key-indeterminate-'+('subject' if subject_key is None else 'resource'),'observed':decision})
  staff=packet['records']['Staff'];login_id=staff['fields']['login']['id']
  self.admin.execute('UPDATE truss.object SET props=props-%s WHERE id=%s AND type_id=%s',(login_id,int(aliases['staff-alice'].id),int(staff['typeId'])))
  params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']='alice'
  with psycopg.connect(**params,autocommit=True) as reader:
   with self.assertRaises(psycopg.errors.ObjectNotInPrerequisiteState) as failure:reader.execute("SELECT ontology_fixture.eligible('RO')").fetchall()
   self.assertEqual(failure.exception.sqlstate,'55000');observations.append({'id':'missing-original-caller-binding-refuses-even-ownerless-resource','observed':'55000'})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(login_id,json.dumps({'kind':'string','text':'alice'}),int(aliases['staff-alice'].id),int(staff['typeId'])))
  with psycopg.connect(**params,autocommit=True) as reader:
   result=reader.execute("SELECT ontology_fixture.eligible('RO'),ontology_fixture.eligible('RA')").fetchone();self.assertEqual(result,(False,True));observations.append({'id':'restored-caller-binding-distinguishes-denial-and-permit','observed':list(result)})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(login_id,json.dumps({'kind':'string','text':'alice'}),int(aliases['staff-outsider'].id),int(staff['typeId'])))
  params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']='alice'
  with psycopg.connect(**params,autocommit=True) as reader:
   for operation,query in [('ownerless',"SELECT ontology_fixture.eligible('RO')"),('count','SELECT count(*) FROM truss.object')]:
    with self.assertRaises(psycopg.errors.ObjectNotInPrerequisiteState) as failure:reader.execute(query).fetchall()
    self.assertEqual(failure.exception.sqlstate,'55000');self.assertEqual(failure.exception.diag.message_primary,'security facts unavailable');observations.append({'id':'ambiguous-original-caller-refuses-'+operation,'observed':{'sqlState':'55000','message':'security facts unavailable'}})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(login_id,json.dumps({'kind':'string','text':'outsider'}),int(aliases['staff-outsider'].id),int(staff['typeId'])))
  with psycopg.connect(**params,autocommit=True) as reader:
   actual=[r[0] for r in reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,['RA','RAB']);observations.append({'id':'unique-original-caller-mapping-restores-visibility','observed':actual})
  params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']='alice'
  with psycopg.connect(**params,autocommit=True) as old_snapshot:
   old_snapshot.execute('BEGIN ISOLATION LEVEL REPEATABLE READ')
   old_snapshot.execute('SELECT count(*) FROM pg_class').fetchone() # Establish original snapshot before change.
   isolation=old_snapshot.execute('SHOW transaction_isolation').fetchone()[0];self.assertEqual(isolation,'repeatable read');observations.append({'id':'old-authority-snapshot-established-before-change','observed':isolation})
   self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':False}),int(aliases['AA'].id),int(assignment['typeId'])))
   with self.assertRaises(psycopg.errors.FeatureNotSupported) as failure:old_snapshot.execute('SELECT count(*) FROM truss.object').fetchall()
   self.assertEqual(failure.exception.sqlstate,'0A000');self.assertEqual(failure.exception.diag.message_primary,'security authority profile unavailable');observations.append({'id':'first-protected-read-under-old-snapshot-refuses','observed':{'sqlState':'0A000','message':'security authority profile unavailable'}})
   old_snapshot.rollback()
  with psycopg.connect(**params,autocommit=True) as fresh:
   actual=[r[0] for r in fresh.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,[]);observations.append({'id':'fresh-read-after-committed-authority-change-denies','observed':actual})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':True}),int(aliases['AA'].id),int(assignment['typeId'])))
  with psycopg.connect(**params,autocommit=True) as fresh:
   actual=[r[0] for r in fresh.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,['RA','RAB']);observations.append({'id':'restored-authority-fresh-read-original-vector','observed':actual})
  # Actual graph assignment writer waits through the fixture's buffered release.
  import threading,time
  writer=psycopg.connect(self.info.connection_uri,autocommit=True,options='-c statement_timeout=10000');self.addCleanup(writer.close)
  writer_pid=writer.execute('SELECT pg_backend_pid()').fetchone()[0];errors=[]
  def revoke_assignment():
   try:writer.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':False}),int(aliases['AA'].id),int(assignment['typeId'])))
   except Exception as exc:errors.append(type(exc).__name__)
  self.admin.execute('BEGIN');self.admin.execute('LOCK TABLE truss.object,truss.edge,truss.type_def,truss.prop_def,truss.rel_def,truss.rel_endpoint IN SHARE MODE')
  thread=threading.Thread(target=revoke_assignment);thread.start()
  try:
   deadline=time.monotonic()+5;waiting=None
   while time.monotonic()<deadline:
    waiting=self.admin.execute("SELECT mode,granted FROM pg_locks WHERE pid=%s AND relation='truss.object'::regclass AND mode='RowExclusiveLock'",(writer_pid,)).fetchone()
    if waiting==('RowExclusiveLock',False):break
    time.sleep(.01)
   self.assertEqual(waiting,('RowExclusiveLock',False));observations.append({'id':'graph-assignment-revoker-native-wait','writerPid':writer_pid,'observed':list(waiting)})
   with psycopg.connect(**params,autocommit=True) as guarded_reader:
    buffered=[r[0] for r in guarded_reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(buffered,['RA','RAB'])
   self.assertTrue(thread.is_alive());observations.append({'id':'buffered-graph-read-released-before-revoker-commit','observed':buffered,'boundary':'fixture records final buffered return before releasing native source locks'})
  finally:self.admin.rollback();thread.join(12)
  self.assertFalse(thread.is_alive());self.assertEqual(errors,[]);observations.append({'id':'graph-assignment-revoker-completes-after-release','observed':'committed'})
  with psycopg.connect(**params,autocommit=True) as fresh:
   actual=[r[0] for r in fresh.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,[]);observations.append({'id':'new-read-after-drained-graph-change-denies','observed':actual})
  self.admin.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':True}),int(aliases['AA'].id),int(assignment['typeId'])))
  # Source-table exclusion cannot fence native role authority changes.
  control=psycopg.connect(self.info.connection_uri,autocommit=True,options='-c statement_timeout=5000');self.addCleanup(control.close)
  self.admin.execute('BEGIN');self.admin.execute('LOCK TABLE truss.object,truss.edge,truss.type_def,truss.prop_def,truss.rel_def,truss.rel_endpoint IN SHARE MODE')
  try:
   control.execute('ALTER ROLE alice BYPASSRLS')
   held=self.admin.execute("SELECT count(*) FROM pg_locks WHERE pid=pg_backend_pid() AND mode='ShareLock' AND granted AND relation IN ('truss.object'::regclass,'truss.edge'::regclass,'truss.type_def'::regclass,'truss.prop_def'::regclass,'truss.rel_def'::regclass,'truss.rel_endpoint'::regclass)").fetchone()[0];self.assertEqual(held,6);observations.append({'id':'native-role-change-commits-while-six-source-locks-held','observed':held})
   with psycopg.connect(**params,autocommit=True) as changed_reader:
    flags=changed_reader.execute('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user').fetchone();self.assertEqual(flags,(False,True));observations.append({'id':'changed-original-caller-bypass-attribute','observed':list(flags)})
    count=changed_reader.execute('SELECT count(*) FROM truss.object').fetchone()[0];self.assertEqual(count,13);observations.append({'id':'bypass-authority-defeats-source-lock-only-profile','observed':count,'qualification':'deliberate disposable authority-widening counterexample'})
  finally:
   control.execute('ALTER ROLE alice NOBYPASSRLS');self.admin.rollback()
  with psycopg.connect(**params,autocommit=True) as restored_reader:
   actual=[r[0] for r in restored_reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,['RA','RAB']);observations.append({'id':'restored-native-caller-authority-original-vector','observed':actual})
  # Exercise the existing installation-wide authority guard's original SQL.
  contracts=Path(__file__).resolve().parents[3]/'docs/helix/02-design/contracts'
  self.admin.execute((contracts/'installation-policy-guard-v0.1.proposal.sql').read_text())
  installation_bytes=self.admin.execute('SELECT installation_id::text FROM truss.catalog_runtime_installation').fetchone()[0].encode();profile_bytes=b'ontology-authority-guard-fixture/0.1'
  self.admin.execute('INSERT INTO truss.policy_generation_guard VALUES(1,%s,%s,1)',(installation_bytes,profile_bytes))
  acquire=(contracts/'installation-policy-guard-acquire-v0.1.proposal.sql').read_text()
  advance=(contracts/'installation-policy-generation-advance-v0.1.proposal.sql').read_text()
  for ordinal in [1,2,3]:advance=advance.replace('$'+str(ordinal),'%s')
  authority_writer=psycopg.connect(self.info.connection_uri,autocommit=True,options='-c statement_timeout=10000');self.addCleanup(authority_writer.close)
  authority_pid=authority_writer.execute('SELECT pg_backend_pid()').fetchone()[0];authority_errors=[];advanced=[]
  def controlled_role_change():
   try:
    authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone();authority_writer.execute('ALTER ROLE alice BYPASSRLS');rows=authority_writer.execute(advance,(installation_bytes,profile_bytes,1)).fetchall()
    if rows!=[('1',installation_bytes.hex(),profile_bytes.hex(),'2')]:raise ValueError('Original generation advance refused')
    advanced.extend(rows);authority_writer.execute('COMMIT')
   except Exception as exc:authority_errors.append(type(exc).__name__);authority_writer.rollback()
  self.admin.execute('BEGIN');self.admin.execute('SELECT rev FROM truss.schema_head WHERE id=1 FOR SHARE').fetchone();guard_cursor=self.admin.execute(acquire);captured=guard_cursor.fetchall();self.assertEqual(captured,[('1',installation_bytes.hex(),profile_bytes.hex(),'1')]);observations.append({'id':'original-proposed-guard-acquisition','observed':[list(row) for row in captured]})
  decoder_packet={'columns':[{'name':column.name,'typeOid':str(column.type_code)} for column in guard_cursor.description],'rows':[list(row) for row in captured],'expected':{'installationIdentityHex':installation_bytes.hex(),'policyProfileHex':profile_bytes.hex()}}
  decoder=subprocess.run(['/opt/homebrew/bin/bun',str(Path(__file__).resolve().parents[3]/'tests/fixtures/security-authority-guard-decode.ts')],input=json.dumps(decoder_packet),text=True,capture_output=True,timeout=30);self.assertEqual(decoder.returncode,0,decoder.stderr);decoded=json.loads(decoder.stdout);self.assertEqual(decoded['generation'],'1');observations.append({'id':'actual-native-guard-descriptors-and-row-decoded','input':decoder_packet,'observed':decoded,'qualification':'local decoding, not a lease'})
  holder_pid=self.admin.execute('SELECT pg_backend_pid()').fetchone()[0];authority_thread=threading.Thread(target=controlled_role_change);authority_thread.start()
  try:
   deadline=time.monotonic()+5;blockers=[]
   while time.monotonic()<deadline:
    blockers=self.admin.execute('SELECT pg_blocking_pids(%s)',(authority_pid,)).fetchone()[0]
    if holder_pid in blockers:break
    time.sleep(.01)
   self.assertIn(holder_pid,blockers);observations.append({'id':'participating-native-role-changer-waits-on-authority-guard','blockerPid':holder_pid,'observed':blockers})
   with psycopg.connect(**params,autocommit=True) as admitted_fixture_reader:
    actual=[r[0] for r in admitted_fixture_reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,['RA','RAB']);self.assertTrue(authority_thread.is_alive());observations.append({'id':'guarded-buffered-result-before-authority-change','observed':actual})
  finally:self.admin.rollback();authority_thread.join(12)
  self.assertFalse(authority_thread.is_alive());self.assertEqual(authority_errors,[]);self.assertEqual(advanced,[('1',installation_bytes.hex(),profile_bytes.hex(),'2')]);observations.append({'id':'controlled-role-effect-and-generation-advance-commit','observed':[list(row) for row in advanced]})
  fresh_guard=self.admin.execute(acquire).fetchall();self.assertEqual(fresh_guard,[('1',installation_bytes.hex(),profile_bytes.hex(),'2')]);observations.append({'id':'next-authority-observation-sees-new-generation','observed':[list(row) for row in fresh_guard]})
  flags=self.admin.execute("SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname='alice'").fetchone();self.assertEqual(flags,(False,True));observations.append({'id':'new-generation-requires-original-caller-bypass-exclusion','observed':list(flags),'qualification':'new generation is not authorization'})
  authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone();authority_writer.execute('ALTER ROLE alice NOBYPASSRLS');restored_generation=authority_writer.execute(advance,(installation_bytes,profile_bytes,2)).fetchall();self.assertEqual(restored_generation,[('1',installation_bytes.hex(),profile_bytes.hex(),'3')]);authority_writer.execute('COMMIT');observations.append({'id':'controlled-restoration-preserves-generation-continuity','observed':[list(row) for row in restored_generation]})
  authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone();authority_writer.execute('ALTER ROLE alice BYPASSRLS')
  stale=authority_writer.execute(advance,(installation_bytes,profile_bytes,2)).fetchall();self.assertEqual(stale,[]);observations.append({'id':'stale-expected-generation-refuses-advance','observed':stale});authority_writer.rollback()
  flags=self.admin.execute("SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname='alice'").fetchone();generation=self.admin.execute('SELECT generation::text FROM truss.policy_generation_guard WHERE singleton=1').fetchone()[0];self.assertEqual(flags,(False,False));self.assertEqual(generation,'3');observations.append({'id':'failed-controlled-delta-rolls-back-role-and-generation','observed':{'flags':list(flags),'generation':generation}})
  for invalid_identity,invalid_profile,kind in [(b'foreign-installation',profile_bytes,'installation'),(installation_bytes,b'foreign-profile','profile')]:
   authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone()
   rows=authority_writer.execute(advance,(invalid_identity,invalid_profile,3)).fetchall();self.assertEqual(rows,[]);authority_writer.rollback();observations.append({'id':'foreign-authority-'+kind+'-refuses-generation-advance','observed':rows})
  with psycopg.connect(**params,autocommit=True) as ordinary:
   with self.assertRaises(psycopg.errors.InsufficientPrivilege) as failure:ordinary.execute('UPDATE truss.policy_generation_guard SET generation=1')
   self.assertEqual(failure.exception.sqlstate,'42501');observations.append({'id':'ordinary-authority-generation-reset-denied','observed':'42501'})
  authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone();authority_writer.execute('UPDATE truss.policy_generation_guard SET generation=9223372036854775807 WHERE singleton=1');authority_writer.execute('ALTER ROLE alice BYPASSRLS')
  exhausted=authority_writer.execute(advance,(installation_bytes,profile_bytes,9223372036854775807)).fetchall();self.assertEqual(exhausted,[]);observations.append({'id':'authority-generation-maximum-refuses-instead-of-wrap','observed':exhausted})
  maximum=authority_writer.execute('SELECT generation::text FROM truss.policy_generation_guard WHERE singleton=1').fetchone()[0];self.assertEqual(maximum,'9223372036854775807');observations.append({'id':'maximum-generation-remains-exact-before-rollback','observed':maximum});authority_writer.rollback()
  flags=self.admin.execute("SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname='alice'").fetchone();generation=self.admin.execute('SELECT generation::text FROM truss.policy_generation_guard WHERE singleton=1').fetchone()[0];self.assertEqual(flags,(False,False));self.assertEqual(generation,'3');observations.append({'id':'exhausted-authority-delta-rolls-back-role-and-generation','observed':{'flags':list(flags),'generation':generation}})
  # Losing the original coordinator cannot authorize its buffered result.
  coordinator=psycopg.connect(self.info.connection_uri,autocommit=True,options='-c statement_timeout=10000');self.addCleanup(coordinator.close)
  coordinator_pid=coordinator.execute('SELECT pg_backend_pid()').fetchone()[0];coordinator.execute('BEGIN');coordinator.execute('SELECT rev FROM truss.schema_head WHERE id=1 FOR SHARE').fetchone();held_generation=coordinator.execute(acquire).fetchall();self.assertEqual(held_generation,[('1',installation_bytes.hex(),profile_bytes.hex(),'3')])
  data_reader=psycopg.connect(**params,autocommit=True);self.addCleanup(data_reader.close);data_reader.execute('BEGIN');data_reader.execute("CREATE TEMP TABLE prior_data_work(value text);INSERT INTO prior_data_work VALUES('kept')")
  pending_buffer=[r[0] for r in data_reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))]
  self.assertEqual(pending_buffer,['RA','RAB']);lost_errors=[];lost_advance=[]
  def change_after_coordinator_loss():
   try:
    authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone();authority_writer.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':False}),int(aliases['AA'].id),int(assignment['typeId'])))
    rows=authority_writer.execute(advance,(installation_bytes,profile_bytes,3)).fetchall()
    if rows!=[('1',installation_bytes.hex(),profile_bytes.hex(),'4')]:raise ValueError('Original generation advance refused')
    lost_advance.extend(rows);authority_writer.execute('COMMIT')
   except Exception as exc:lost_errors.append(type(exc).__name__);authority_writer.rollback()
  loss_thread=threading.Thread(target=change_after_coordinator_loss);loss_thread.start()
  try:
   deadline=time.monotonic()+5;blockers=[]
   while time.monotonic()<deadline:
    blockers=self.admin.execute('SELECT pg_blocking_pids(%s)',(authority_pid,)).fetchone()[0]
    if coordinator_pid in blockers:break
    time.sleep(.01)
   self.assertIn(coordinator_pid,blockers);observations.append({'id':'authority-writer-waits-on-original-coordinator','observed':blockers,'coordinatorPid':coordinator_pid})
   terminated=self.admin.execute('SELECT pg_terminate_backend(%s)',(coordinator_pid,)).fetchone()[0];self.assertIs(terminated,True);observations.append({'id':'owned-original-coordinator-terminated','observed':True})
   with self.assertRaises(psycopg.OperationalError) as loss:coordinator.execute('SELECT 1')
   observations.append({'id':'original-coordinator-native-liveness-probe-fails','observed':{'kind':type(loss.exception).__name__,'sqlState':loss.exception.sqlstate}})
  finally:
   coordinator.close();loss_thread.join(12)
  self.assertFalse(loss_thread.is_alive());self.assertEqual(lost_errors,[]);self.assertEqual(lost_advance,[('1',installation_bytes.hex(),profile_bytes.hex(),'4')]);observations.append({'id':'authority-change-commits-after-native-coordinator-loss','observed':[list(row) for row in lost_advance]})
  self.assertEqual(data_reader.info.transaction_status,psycopg.pq.TransactionStatus.INTRANS);prior=data_reader.execute('TABLE prior_data_work').fetchall();self.assertEqual(prior,[('kept',)]);observations.append({'id':'coordinator-loss-preserves-original-data-transaction-work','observed':[list(row) for row in prior]});data_reader.rollback()
  pending_buffer=[];observations.append({'id':'lost-coordinator-buffer-withheld-by-fixture','observed':pending_buffer,'qualification':'explicit fixture release arbitration, not a production lease'})
  with psycopg.connect(**params,autocommit=True) as fresh:
   actual=[r[0] for r in fresh.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(actual,[]);observations.append({'id':'new-read-after-coordinator-loss-observes-revocation','observed':actual})
  # Same logical Record/Relationship condition over independent raw tables.
  authority_writer.execute('BEGIN');authority_writer.execute('SELECT generation FROM truss.policy_generation_guard WHERE singleton=1 FOR UPDATE').fetchone();authority_writer.execute('UPDATE truss.object SET props=jsonb_set(props,ARRAY[%s],%s::jsonb) WHERE id=%s AND type_id=%s',(active_id,json.dumps({'kind':'boolean','value':True}),int(aliases['AA'].id),int(assignment['typeId'])));rows=authority_writer.execute(advance,(installation_bytes,profile_bytes,4)).fetchall();self.assertEqual(rows,[('1',installation_bytes.hex(),profile_bytes.hex(),'5')]);authority_writer.execute('COMMIT')
  self.admin.execute('CREATE SCHEMA relational_fixture;CREATE TABLE relational_fixture.client(code text PRIMARY KEY);CREATE TABLE relational_fixture.project(code text PRIMARY KEY);CREATE TABLE relational_fixture.staff(code text PRIMARY KEY,login text NOT NULL);CREATE TABLE relational_fixture.resource(code text PRIMARY KEY);CREATE TABLE relational_fixture.assignment(code text PRIMARY KEY,active boolean NOT NULL)')
  for table,codes in [('client',['C']),('project',['A','B']),('resource',['RA','RB','RAB','RO'])]:
   for code in codes:self.admin.execute('INSERT INTO relational_fixture.'+table+' VALUES(%s)',(code,))
  for login in ['alice','bob','outsider']:self.admin.execute('INSERT INTO relational_fixture.staff VALUES(%s,%s)',('staff-'+login,login))
  for code,active in [('AA',True),('AB',False),('BB',True)]:self.admin.execute('INSERT INTO relational_fixture.assignment VALUES(%s,%s)',(code,active))
  for link,(source,target) in LINKS.items():
   self.admin.execute('CREATE TABLE relational_fixture.'+link+'(occurrence_id text PRIMARY KEY,source_code text NOT NULL REFERENCES relational_fixture.'+source.lower()+'(code),target_code text NOT NULL REFERENCES relational_fixture.'+target.lower()+'(code))')
   for index,(left,right) in enumerate(connections[link]):self.admin.execute('INSERT INTO relational_fixture.'+link+' VALUES(%s,%s,%s)',('raw-'+link+str(index),left,right))
  self.admin.execute('GRANT USAGE ON SCHEMA relational_fixture TO ontology_facts;GRANT SELECT ON ALL TABLES IN SCHEMA relational_fixture TO ontology_facts;GRANT CREATE ON SCHEMA relational_fixture TO ontology_facts')
  self.admin.execute('CREATE FUNCTION relational_fixture.decision_bound(text,text) RETURNS text LANGUAGE SQL SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$ '+sql['flatFold']['sql']+' $$;REVOKE ALL ON FUNCTION relational_fixture.decision_bound(text,text) FROM PUBLIC;ALTER FUNCTION relational_fixture.decision_bound(text,text) OWNER TO ontology_facts')
  self.admin.execute("CREATE FUNCTION relational_fixture.eligible(text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,pg_temp AS $$ DECLARE n bigint;subject_key text;decision text;BEGIN IF current_setting('transaction_isolation')<>'read committed' THEN RAISE EXCEPTION 'security authority profile unavailable' USING ERRCODE='0A000';END IF;SELECT count(*),min(code) INTO n,subject_key FROM relational_fixture.staff WHERE login=SESSION_USER::text;IF n<>1 THEN RAISE EXCEPTION 'security facts unavailable' USING ERRCODE='55000';END IF;decision:=relational_fixture.decision_bound($1,subject_key);IF decision IS NULL OR decision NOT IN ('permit','deny') THEN RAISE EXCEPTION 'security facts unavailable' USING ERRCODE='55000';END IF;RETURN decision='permit';END $$;REVOKE ALL ON FUNCTION relational_fixture.eligible(text) FROM PUBLIC;ALTER FUNCTION relational_fixture.eligible(text) OWNER TO ontology_facts;REVOKE CREATE ON SCHEMA relational_fixture FROM ontology_facts")
  self.admin.execute('ALTER TABLE relational_fixture.resource ENABLE ROW LEVEL SECURITY;ALTER TABLE relational_fixture.resource FORCE ROW LEVEL SECURITY;CREATE POLICY resource_membership ON relational_fixture.resource TO alice,bob,outsider USING(relational_fixture.eligible(code))')
  for login in ['alice','bob','outsider']:
   self.admin.execute('GRANT USAGE ON SCHEMA relational_fixture TO '+login+';GRANT SELECT ON relational_fixture.resource TO '+login+';GRANT EXECUTE ON FUNCTION relational_fixture.eligible(text) TO '+login)
   params=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);params['user']=login
   with psycopg.connect(**params,autocommit=True) as reader:
    flat=[r[0] for r in reader.execute('SELECT code FROM relational_fixture.resource ORDER BY code')];graph=[r[0] for r in reader.execute("SELECT props->%s->>'text' FROM truss.object ORDER BY props->%s->>'text'",(key,key))];self.assertEqual(flat,expected[login]);self.assertEqual(graph,expected[login]);observations.append({'id':'same-policy-raw-and-graph-oracle-'+login,'expected':expected[login],'raw':flat,'graph':graph})
    with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute('SELECT * FROM relational_fixture.assignment')
    observations.append({'id':'raw-private-assignment-table-denied-'+login,'observed':'42501'})
  if os.environ.get('TRUSS_SECURITY_COMPONENT_EVIDENCE'):Path(os.environ['TRUSS_SECURITY_COMPONENT_EVIDENCE']).write_text(json.dumps({'packet':packet,'sql':sql,'observations':observations,'publicCreatedIdentities':{alias:{'id':identity.id,'typeId':identity.type_id} for alias,identity in aliases.items()},'scope':'Actual public-created objects/edges, typed native joins to business keys and candidate typed Record/opaque Relationship membership lowering under ordinary native RLS. Private views are real graph projections, not seeded flat tables. Not complete source enrollment, held authority or released public API/security compiler admission.'},indent=2)+'\n')
if __name__=='__main__':
 import unittest;unittest.main()
