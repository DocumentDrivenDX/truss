export {inspectCoreRecordTypeReceipt} from './src/model/record-type-inspection';
export {declareCoreElementKind} from './src/model/field-kind';
export {declareCoreRecordType} from './src/model/record-type';
