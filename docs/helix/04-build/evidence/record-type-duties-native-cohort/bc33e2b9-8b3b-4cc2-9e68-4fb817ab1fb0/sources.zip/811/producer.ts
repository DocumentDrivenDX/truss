export {inspectCoreRecordTypeJournal} from './src/model/record-type-journal';
export {declareCoreElementKind} from './src/model/field-kind';
export {declareCoreRecordType} from './src/model/record-type';
