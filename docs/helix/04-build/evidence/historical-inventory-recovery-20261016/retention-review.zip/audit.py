from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,re
P=Path('/private/tmp/truss-historical-inventory-recovery-packet-20261016');O=Path('/private/tmp/truss-historical-inventory-recovery-review-20261016');H=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((P/n).read_bytes())
ret=load('retention.json');sm=load('source-manifest.json');receipt=load('historical-umf-inventory-composition.json');browser=load('historical-umf-inventory-composition-browser.json');dataset=load('historical-umf-dataset-browser.json')
for name,pin in ret['files'].items():
 b=(P/name).read_bytes();assert len(b)==pin['bytes'] and H(b)==pin['sha256'],name
assert set(ret['files'])=={p.name for p in P.iterdir() if p.is_file()}-{'retention.json'}
with tarfile.open(P/'historical-current-source.tar.gz','r:gz') as t:
 members=t.getmembers();assert len(members)==len(sm)==ret['sourceFiles']==1006
 assert len(set(m.name for m in members))==len(members) and set(m.name for m in members)==set(sm)
 for m in members:
  assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
  b=t.extractfile(m).read();pin=sm[m.name];assert len(b)==pin['bytes'] and H(b)==pin['sha256'],m.name
relative={k:v for k,v in receipt['sourceDigests'].items() if not k.startswith('/')};assert len(relative)==1002
assert set(relative)<=set(sm)
for k,v in relative.items():assert sm[k]['historicalExpectedSha256']==v
changed=[k for k,v in relative.items() if sm[k]['sha256']!=v];assert len(changed)==18
# Check the current primary endpoints only, not historical stability/ABA.
primary=Path('/Users/erik/Projects/truss');current=[]
for k,pin in sm.items():
 p=primary/k
 if not p.is_file() or H(p.read_bytes())!=pin['sha256']:current.append(k)
def check_relative(d):
 pins={k:v for k,v in d['sourceDigests'].items() if not k.startswith('/')}
 return {'pins':len(pins),'missingFromArchive':[k for k in pins if k not in sm],'drift':[k for k,v in pins.items() if k in sm and v!=sm[k]['sha256']]}
bs,ds=check_relative(browser),check_relative(dataset)
assert bs['drift']==['packages/umf-bun/src/index.ts'] and not bs['missingFromArchive']
assert ds=={'pins':4,'missingFromArchive':[],'drift':[]}
conflicts=re.findall(r'^error: (.+): patch does not apply$',(P/'apply-check.log').read_text(),re.M);assert len(conflicts)==len(set(conflicts))==8
selected=load('audit.json')['selectedSourceFiles']
for k,v in selected.items():assert sm[k]['sha256']==v
abs_pins={k:v for d in [receipt,browser,dataset] for k,v in d['sourceDigests'].items() if k.startswith('/')}
missing=[k for k in abs_pins if not Path(k).exists()]
assert load('record-rebuild-manifest.json')['bundleSha256']!=receipt['composition']['record']['sha256']
assert len(browser['inspectionManifest']['sourceFiles'])==769
result={'status':'passed','retainedFiles':len(ret['files']),'archiveMembers':len(sm),'totalArchivedBytes':sum(p['bytes'] for p in sm.values()),'historicalRelativePins':len(relative),'historicalMatching':len(relative)-len(changed),'historicalDrift':changed,'currentPrimaryEndpointMismatches':current,'browser':bs,'dataset':ds,'conflictingPatchPaths':conflicts,'selectedSourcePins':len(selected),'missingAbsoluteProducerAssets':missing,'inspectionSourcePins':769,'recordRebuildByteMismatchConfirmed':True,'scope':'Retention/correspondence audit only; no source implementation adoption or runtime/native qualification.'}
(O/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
