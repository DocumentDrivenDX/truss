/** Closed original0.7/0.8 facet components; unknown siblings never inherit coverage. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalCatalogObservationCollection,type collectCatalogAssertionObservations} from './catalog-assertion-observations';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Observations=ReturnType<typeof collectCatalogAssertionObservations>;
export function collectCatalogFacetComponents(prepared:Prepared,observations:Observations){
 requireOriginalCatalogPreparation(prepared);requireOriginalCatalogObservationCollection(prepared,observations);
 const bytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-facet-components/0.2.0',
  record:{mode:'record',profile:prepared.umfProfile},fields:{mode:'assertion-fields',profile:observations.fieldProfile},
  sourceVersions:['0.7.0','0.8.0'],operation:'inspect-core-facets',resultVersions:{'0.7.0':'3.0.0','0.8.0':'4.0.0'},
  components:{length:['min','max','unit'],integerWidth:['bits','signed'],precision:[],scale:[],collectionSize:['min','max'],range:['min','max','minInclusive','maxInclusive','numeric typed endpoint token']},
  selection:'only values in owner interpreted projection with exact original correspondence',
  unknown:'unavailable; no subtree inheritance',enforcement:'none/unqualified'}));
 const manifest=Object.freeze({identity:'truss.original-facet-components/0.2.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 const profile=Object.freeze({identity:'truss-original-facet-components',version:'0.2.0',sha256:manifest.sha256});
 const components=[];
 for(const observation of observations.observations){
  if(observation.operation!=='facets'||observation.basis!=='original')continue;
  const di=prepared.documents.findIndex(document=>document.documentId===observation.documentId),document=prepared.documents[di];
  if(!document||!['0.7.0','0.8.0'].includes(document.umfVersion))continue;
  const result=observation.result as any,ownerResult=result.observation;
  if(result.state!=='observed'||!['known','partial'].includes(ownerResult?.meaning?.state))continue;
  if(!observations.fieldProfile||ownerResult.operation!=='inspect-core-facets'||ownerResult.version!==(document.umfVersion==='0.8.0'?'4.0.0':'3.0.0')||JSON.stringify(ownerResult.source)!==JSON.stringify(document.interpretation.source))throw Error('Original facet component inspector required');
  const identity=observation.identity as any,mi=document.interpretation.source.modules.findIndex((module:any)=>module.id===identity?.module),module=document.interpretation.source.modules[mi];
  const ei=module?.elements.findIndex((element:any)=>element.id===identity?.element)??-1,element=module?.elements[ei],root=`/modules/${mi}/elements/${ei}/facets`;
  if(element?.kind!=='field'||ownerResult.path!==root||JSON.stringify(element.facets)!==JSON.stringify(ownerResult.meaning.facets))throw Error('Original facet component occurrence correspondence required');
  const interpreted=ownerResult.meaning.interpreted;
  if(!interpreted||typeof interpreted!=='object'||Array.isArray(interpreted))throw Error('Original interpreted facet projection required');
  const groups:Record<string,string[]>={length:document.umfVersion==='0.8.0'?['min','max','unit']:['max','unit'],integerWidth:['bits','signed'],precision:[],scale:[],...(document.umfVersion==='0.8.0'?{collectionSize:['min','max'],range:['min','max','minInclusive','maxInclusive']}:{})};
  for(const [group,members] of Object.entries(groups)){
   if(!Object.hasOwn(interpreted,group))continue;
   const paths=[group,...members.filter(member=>Object.hasOwn(interpreted[group],member)).map(member=>group+'/'+member)];
   if(group==='range')for(const endpoint of ['min','max']){
    if(!Object.hasOwn(interpreted.range,endpoint))continue;
    const literal=interpreted.range[endpoint];
    if(!literal||typeof literal!=='object'||Array.isArray(literal)||Object.keys(literal).length!==1||!['integerToken','decimalToken'].includes(Object.keys(literal)[0]!))throw Error('Original numeric range endpoint required');
    paths.push('range/'+endpoint+'/'+Object.keys(literal)[0]!);
   }
   for(const suffix of paths){
    const tokens=suffix.split('/');let original=element.facets,selected=interpreted;
    for(const token of tokens){original=original?.[token];selected=selected?.[token];}
    if(tokens.length===1&&members.length){
     if(!original||typeof original!=='object'||!selected||typeof selected!=='object')throw Error('Original facet group required');
    }else if(original===undefined||JSON.stringify(original)!==JSON.stringify(selected))throw Error('Original facet component value correspondence required');
    components.push(Object.freeze({documentId:document.documentId,moduleId:module.id as string,definitionPin:prepared.original.input.documents[di]!.artifact.sha256,sourcePointer:root+'/'+suffix,assertionPointer:root,ownerEvidence:observation.evidence}));
   }
  }
 }
 return Object.freeze({components:Object.freeze(components),profile,manifest,complete:false as const});
}
