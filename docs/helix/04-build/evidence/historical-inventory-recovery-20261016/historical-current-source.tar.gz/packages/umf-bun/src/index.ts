/** Trusted host-only original producer registration. No alternate UMF validation. */
import {resolve} from 'node:path';
import {requireUnchangedCatalogTransition} from './catalog-transition-correspondence';
const assertionCompositions=new WeakMap<object,{identity:string;version:string;record:{identity:string;version:string;sha256:string};inspection:{version:string;sha256:string};resultVersions:Record<string,Record<string,string>>}>();
const assertionOwners=new WeakMap<object,'declarations'|'assertion-fields'>();
function registerAssertionOwner<T extends object>(owner:T,mode:'declarations'|'assertion-fields'):T{assertionOwners.set(owner,mode);return owner;}
/** Private loaded-instance recognition; no external issuer or native qualification. */
export function requireLoadedUmfAssertionOwner(owner:object,mode:'declarations'|'assertion-fields'):void{
 if(assertionOwners.get(owner)!==mode)throw Error('Original loaded assertion owner required');
}
export const UMF_RUNTIME_SOURCE='c45c72a2a8a3c4fba61c40c5927dd9091acf8cc3';
export async function loadUmfProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_RUNTIME_SOURCE,'record',['readDocument','validateDocument','validateCoreRecordValues','upgradeSchemaPropertiesEnvelope','verifySchemaPropertiesUpgrade','rollbackSchemaPropertiesEnvelope']);
 return Object.freeze({sourceRevision:UMF_RUNTIME_SOURCE,bundleSha256:hash,
  inspect(originalText:string){
   if(typeof originalText!=='string'||Buffer.byteLength(originalText)>1048576)throw Error('Original document bound');
   const source=captured.readDocument(originalText,'json');const sourceValidation=captured.validateDocument(source);
   if(!sourceValidation.valid) return {originalText,source,sourceValidation,transition:null,targetValidation:null};
   let transition=null,target=source;
   if(source.umf==='0.7.0'){
    const originalSourceJson=JSON.stringify(source);
    transition=captured.upgradeSchemaPropertiesEnvelope(source);
    const verified=captured.verifySchemaPropertiesUpgrade(transition);
    const restored=captured.rollbackSchemaPropertiesEnvelope(transition,transition.target);
    requireUnchangedCatalogTransition(originalSourceJson,source,transition,verified,restored);
    target=transition.target;
   }else if(source.umf!=='0.8.0')throw Error('Unsupported original UMF version');
   return {originalText,source,sourceValidation,transition,targetValidation:captured.validateDocument(target),target};
  },
  checkRecord(target:unknown,identity:unknown,values:unknown){return captured.validateCoreRecordValues(target,identity,values)}
 });
}


/** Independently pinned current-core numeric conveniences; no Record-source substitution. */
export const UMF_NUMERIC_SOURCE='9e4bed3efe922c11e4b5a888ba6854de14f1b29f';
export async function loadUmfNumericProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_NUMERIC_SOURCE,'numeric',['exactDecimal','integerFromBigInt','integerToBigInt','admitJavascriptNumber','numericToNumberLossless']);
 return Object.freeze({sourceRevision:UMF_NUMERIC_SOURCE,bundleSha256:hash,
  exactDecimal:captured.exactDecimal,integerFromBigInt:captured.integerFromBigInt,
  integerToBigInt:captured.integerToBigInt,admitJavascriptNumber:captured.admitJavascriptNumber,
  numericToNumberLossless:captured.numericToNumberLossless,
 });
}


export const UMF_VALUE_SOURCE=UMF_NUMERIC_SOURCE;
/** Original current-core Field and tuple semantics, separate from native persistence. */
export async function loadUmfValueProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_VALUE_SOURCE,'values',['validateCoreFieldValue','encodeCoreKeyTuple','verifyCoreKeyTuple']);
 return Object.freeze({sourceRevision:UMF_VALUE_SOURCE,bundleSha256:hash,
  validateCoreFieldValue:captured.validateCoreFieldValue,
  encodeCoreKeyTuple:captured.encodeCoreKeyTuple,verifyCoreKeyTuple:captured.verifyCoreKeyTuple,
 });
}
/** Owner-defined metadata meaning; separate bundle from value checks and native claims. */
export async function loadUmfDeclarationProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_RUNTIME_SOURCE,'declarations',['inspectCoreSchemaProperties','inspectCoreKeys','inspectCoreRelationships']);
 return registerAssertionOwner(Object.freeze({sourceRevision:UMF_RUNTIME_SOURCE as string,bundleSha256:hash,
  inspectSchemaProperties:captured.inspectCoreSchemaProperties,
  inspectKeys:captured.inspectCoreKeys,inspectRelationships:captured.inspectCoreRelationships}),'declarations');
}
async function loadPinnedFunctions(directory:string,revision:string,mode:string,names:readonly string[],expectedHash?:string){
 const root=resolve(directory);const manifest=await Bun.file(root+'/producer-manifest.json').json();
 const bytes=await Bun.file(root+'/producer.js').arrayBuffer();
 const hash=new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
 if(expectedHash!==undefined&&hash!==expectedHash)throw Error('Unregistered original producer implementation');
 if(manifest.revision!==revision||(manifest.producerMode??'record')!==mode||manifest.bundleSha256!==hash)throw Error('Original UMF producer pin mismatch');
 const owner=await import('data:text/javascript;base64,'+Buffer.from(bytes).toString('base64'));
 const captured=Object.fromEntries(names.map(name=>{if(typeof owner[name]!=='function')throw Error('Missing original producer');return [name,owner[name].bind(owner)]}));
 return {hash,captured};
}

/** Original Field assertion meaning, not installation or enforcement evidence. */
export async function loadUmfFieldAssertionProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_RUNTIME_SOURCE,'assertion-fields',['inspectCoreElementKind','inspectCoreNullability','inspectCoreCardinality','inspectCoreFacets']);
 return registerAssertionOwner(Object.freeze({sourceRevision:UMF_RUNTIME_SOURCE as string,bundleSha256:hash,
  inspectKind:captured.inspectCoreElementKind,inspectNullability:captured.inspectCoreNullability,
  inspectCardinality:captured.inspectCoreCardinality,inspectFacets:captured.inspectCoreFacets}),'assertion-fields');
}

/** Closed composition of original Record admission and reviewed owner inspection bytes.
 * No external manifest, callback, resolver or hash can register another implementation.
 */
export const UMF_INVENTORY_SOURCE='snapshot-sha256:d27f40893073ee8e51e1fb3b0af4da8446ba9e76eff35b53330eb5421ac18b2c';
export const UMF_INVENTORY_BUNDLE='8e1cbe761190fc6d3f1af47cf1e88ff1a54e9ba4312c4c0c2fd192de52bb0c42';
const inventoryComposition=Object.freeze({identity:'truss-original-record-inventory-composition',version:'0.1.0',
 record:Object.freeze({identity:'umf-record-interpretation',version:UMF_RUNTIME_SOURCE,sha256:'81e99f9a812ad3f61647f0c1d69c8e5640853f876127b7ee25a85efecaf00b68'}),
 inspection:Object.freeze({version:UMF_INVENTORY_SOURCE,sha256:UMF_INVENTORY_BUNDLE}),
 resultVersions:Object.freeze({
  '0.7.0':Object.freeze({kind:'6.0.0',nullability:'5.0.0',cardinality:'4.0.0',facets:'3.0.0',keys:'2.0.0',relationships:'1.0.0'}),
  '0.8.0':Object.freeze({kind:'7.0.0',nullability:'6.0.0',cardinality:'5.0.0',facets:'4.0.0',keys:'3.0.0',relationships:'2.0.0',schema_properties:'1.0.0'})}),
});
export function requireCatalogInspectionComposition(record:{identity:string;version:string;sha256:string},owner:{sourceRevision:string;bundleSha256:string}){
 if(owner.sourceRevision===record.version)return null; // Historical same-source rule remains intact.
 const composition=assertionCompositions.get(owner);
 if(!composition||record.identity!==composition.record.identity||record.version!==composition.record.version||record.sha256!==composition.record.sha256||owner.sourceRevision!==composition.inspection.version||owner.bundleSha256!==composition.inspection.sha256)throw Error('Original owner observation source mismatch: registered exact composition required');
 return composition;
}
export async function loadUmfInventoryInspectionProducer(directory:string){
 const root=resolve(directory),bytes=await Bun.file(root+'/producer.js').arrayBuffer();
 const hash=new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
 if(hash!==UMF_INVENTORY_BUNDLE)throw Error('Unregistered inventory inspection implementation');
 const manifest=await Bun.file(root+'/producer-manifest.json').json();
 if(manifest.revision!==UMF_INVENTORY_SOURCE||manifest.bundleSha256!==hash||manifest.producerMode!=='inventory-inspections')throw Error('Inventory inspection profile mismatch');
 // Import exactly the verified bytes, avoiding a path replacement between check and load.
 const module=await import('data:text/javascript;base64,'+Buffer.from(bytes).toString('base64'));
 const capture=(name:string)=>{if(typeof module[name]!=='function')throw Error('Missing owner inventory operation');return module[name].bind(module)};
 const declarations=registerAssertionOwner(Object.freeze({sourceRevision:UMF_INVENTORY_SOURCE,bundleSha256:hash,inspectSchemaProperties:capture('inspectCoreSchemaProperties'),inspectKeys:capture('inspectCoreKeys'),inspectRelationships:capture('inspectCoreRelationships')}),'declarations');
 const fields=registerAssertionOwner(Object.freeze({sourceRevision:UMF_INVENTORY_SOURCE,bundleSha256:hash,inspectKind:capture('inspectCoreElementKind'),inspectNullability:capture('inspectCoreNullability'),inspectCardinality:capture('inspectCoreCardinality'),inspectFacets:capture('inspectCoreFacets')}),'assertion-fields');
 assertionCompositions.set(declarations,inventoryComposition);assertionCompositions.set(fields,inventoryComposition);
 return Object.freeze({declarations,fields,composition:inventoryComposition,scope:'original_source_read_only_inspection_composition_only' as const});
}

/** Original finite dataset semantics. Supplied scope is never native population coverage. */
export const UMF_DATASET_SOURCE='c7c95e1c4ea5b72541f47fa0350ca467ff02f395';
export const UMF_DATASET_BUNDLE='702ce5109480b097a7915d13b7c48aa8da5720cda3e6250b07014024b737f5c0';
const datasetOwners=new WeakSet<object>();
export function requireLoadedUmfDatasetOwner(owner:object):void{
 if(!datasetOwners.has(owner))throw Error('Original loaded dataset owner required');
}
export async function loadUmfDatasetProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_DATASET_SOURCE,'dataset',['validateCoreDatasetValues','verifyCoreDatasetValues'],UMF_DATASET_BUNDLE);
 const owner=Object.freeze({sourceRevision:UMF_DATASET_SOURCE,bundleSha256:hash,
  scope:'supplied-dataset-only' as const,
  validateCoreDatasetValues:(source:unknown,input:unknown)=>captured.validateCoreDatasetValues(source,input),
  verifyCoreDatasetValues:(receipt:unknown,source:unknown,input:unknown)=>captured.verifyCoreDatasetValues(receipt,source,input),
 });
 datasetOwners.add(owner);return owner;
}
/** Distinct compact owner operation; fragments retain their shared source reference. */
export const UMF_COMPACT_DATASET_SOURCE='a95c3ec18a8f904decde884a4fa252988d2a5b0f';
export const UMF_COMPACT_DATASET_BUNDLE='3a5cfb887a686601b8b8d5deb37c75ea8746db95e89679d69850b80d2b4ef967';
const compactDatasetOwners=new WeakSet<object>();
export function requireLoadedUmfCompactDatasetOwner(owner:object):void{
 if(!compactDatasetOwners.has(owner))throw Error('Original loaded compact dataset owner required');
}
export async function loadUmfCompactDatasetProducer(directory:string){
 const {hash,captured}=await loadPinnedFunctions(directory,UMF_COMPACT_DATASET_SOURCE,'dataset-compact',['validateCoreDatasetValuesCompact','verifyCoreDatasetValuesCompact'],UMF_COMPACT_DATASET_BUNDLE);
 const owner=Object.freeze({sourceRevision:UMF_COMPACT_DATASET_SOURCE,bundleSha256:hash,scope:'supplied-dataset-only' as const,
  validateCoreDatasetValuesCompact:(source:unknown,input:unknown)=>captured.validateCoreDatasetValuesCompact(source,input),
  verifyCoreDatasetValuesCompact:(receipt:unknown,source:unknown,input:unknown)=>captured.verifyCoreDatasetValuesCompact(receipt,source,input),
 });compactDatasetOwners.add(owner);return owner;
}
