/** Original0.7/0.8 validated generic references; no native admission or enforcement. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalAssertionSourceOccurrences,type collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Census=ReturnType<typeof collectOriginalAssertionSourceOccurrences>;
export function collectCatalogReferenceAssertionIdentities(prepared:Prepared,census:Census){
 requireOriginalCatalogPreparation(prepared);requireOriginalAssertionSourceOccurrences(census,prepared);
 const bytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-generic-reference/0.1.0',producer:{mode:'record',profile:prepared.umfProfile},sourceVersions:['0.7.0','0.8.0'],governingSurface:'src/validation/document.ts generic reference target resolution; spec/core/relationship-document.schema.json and schema-properties-document.schema.json#/$defs/reference',selector:'indexed original generic reference declarations',components:['direct role','direct module','direct element'],roleMeaning:'opaque; source validation does not establish record-type author provenance',unknown:'unavailable; no subtree inheritance',absence:'no assertion invented',enforcement:'none/opaque; no role-specific native meaning',maxEvidenceArtifactUtf8Bytes:4194304}));
 const manifest=Object.freeze({identity:'truss.original-generic-reference/0.1.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 const profile=Object.freeze({identity:'truss-original-generic-reference',version:'0.1.0',sha256:manifest.sha256});
 const entries=[];let evidenceBytes=0;
 const validationEvidence=new Map<number,Readonly<{identity:string;bytesBase64:string;sha256:string}>>();
 function artifact(identity:string,bytes:Buffer){
  const value=Object.freeze({identity,bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
  evidenceBytes+=Buffer.byteLength(JSON.stringify(value),'utf8');if(evidenceBytes>4194304)throw Error('Generic reference evidence capacity exceeded');return value;
 }
 for(const occurrence of census.occurrences){
  const match=/^\/modules\/(0|[1-9][0-9]*)\/elements\/(0|[1-9][0-9]*)\/references\/(0|[1-9][0-9]*)$/.exec(occurrence.sourcePointer);
  if(!match)continue;
  const document=prepared.documents[occurrence.documentIndex]!;
  if(!['0.7.0','0.8.0'].includes(document.umfVersion))continue;
  const module=document.interpretation.source.modules[Number(match[1])],element=module?.elements[Number(match[2])];
  const reference=element?.references?.[Number(match[3])];
  if(!document.interpretation.sourceValidation.valid||occurrence.owner.moduleId!==module.id||!reference||occurrence.value!==reference||typeof reference.role!=='string'||typeof reference.module!=='string'||typeof reference.element!=='string')throw Error('Original validated generic references required');
  let validation=validationEvidence.get(occurrence.documentIndex);
  if(!validation){validation=artifact('truss.original-reference-validation/'+occurrence.documentIndex,Buffer.from(JSON.stringify({producer:prepared.umfProfile,documentId:document.documentId,contentSha256:occurrence.definitionPin,basis:'original',sourceValidation:document.interpretation.sourceValidation})));validationEvidence.set(occurrence.documentIndex,validation);}
  const evidence=Buffer.from(JSON.stringify({profile,producer:prepared.umfProfile,documentId:document.documentId,contentSha256:occurrence.definitionPin,basis:'original',sourcePointer:occurrence.sourcePointer,validationEvidenceSha256:validation.sha256}));
  const ownerEvidence=artifact('truss.original-generic-reference/'+occurrence.documentIndex+'/'+match[1]+'/'+match[2]+'/'+match[3],evidence);
  entries.push(Object.freeze({assertion:Object.freeze({sourceKind:'umf_document' as const,owner:Object.freeze({documentId:document.documentId,moduleId:module.id as string}),definitionPin:occurrence.definitionPin,sourcePointer:occurrence.sourcePointer,kind:'source' as const,sourceIdentityProfile:profile}),source:prepared.original.input.documents[occurrence.documentIndex]!.artifact,ruleName:'core.reference',ruleNameOrigin:'profile_generated' as const,enforcement:'none' as const,reason:'opaque' as const,ownerEvidence}));
 }
 return Object.freeze({entries:Object.freeze(entries),profile,manifest,validationEvidence:Object.freeze([...validationEvidence.values()]),retainedEvidenceBytes:evidenceBytes,complete:false as const});
}
