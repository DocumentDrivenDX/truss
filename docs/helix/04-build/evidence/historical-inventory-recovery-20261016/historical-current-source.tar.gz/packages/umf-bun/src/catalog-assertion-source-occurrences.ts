/** Complete original JSON occurrence census for the assertion-inventory producer.
 * Membership/meaning and enforcement are separate required qualifications. */
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
export interface OriginalAssertionOccurrence {
 readonly documentIndex:number;readonly documentId:string;readonly definitionPin:string;
 readonly sourcePointer:string;readonly owner:Readonly<{documentId:string;moduleId?:string}>;
 readonly value:unknown;
}
const issued=new WeakMap<object,Prepared>();
export function requireOriginalAssertionSourceOccurrences(value:object,prepared:Prepared):void{
 requireOriginalCatalogPreparation(prepared);
 if(issued.get(value)!==prepared)throw Error('Original assertion occurrence census custody required');
}
export function collectOriginalAssertionSourceOccurrences(prepared:Prepared){
 requireOriginalCatalogPreparation(prepared);
 const occurrences:OriginalAssertionOccurrence[]=[];let text=0;
 const escape=(key:string)=>key.replaceAll('~','~0').replaceAll('/','~1');
 for(let documentIndex=0;documentIndex<prepared.documents.length;documentIndex++){
  const document=prepared.documents[documentIndex]!,source=prepared.original.input.documents[documentIndex]!.artifact;
  const active=new WeakSet<object>();
  function visit(value:unknown,sourcePointer:string,moduleId:string|undefined,depth:number):void{
   if(depth>64||occurrences.length>=16384||(text+=Buffer.byteLength(sourcePointer,'utf8'))>4194304)throw Error('Original occurrence inventory capacity exceeded');
   const owner=Object.freeze({documentId:document.documentId,...(moduleId===undefined?{}:{moduleId})});
   occurrences.push(Object.freeze({documentIndex,documentId:document.documentId,definitionPin:source.sha256,sourcePointer,owner,value}));
   if(value===null||typeof value!=='object')return;
   if(active.has(value))throw Error('Original source cycle');active.add(value);
   const descriptors=Object.getOwnPropertyDescriptors(value);
   for(const key of Object.keys(descriptors)){
    if(Array.isArray(value)&&key==='length')continue;
    const descriptor=descriptors[key]!;
    if(!Object.hasOwn(descriptor,'value')||!descriptor.enumerable)throw Error('Original source data occurrence required');
    let childModule=moduleId;
    if(sourcePointer==='/modules'&&Array.isArray(value)){
     const candidate=descriptor.value;if(!candidate||typeof candidate!=='object')throw Error('Original module occurrence required');
     const identity=Object.getOwnPropertyDescriptor(candidate,'id');
     if(!identity||!Object.hasOwn(identity,'value')||typeof identity.value!=='string')throw Error('Original module identity required');childModule=identity.value;
    }
    visit(descriptor.value,sourcePointer+'/'+escape(key),childModule,depth+1);
   }
   active.delete(value);
  }
  visit(document.interpretation.source,'',undefined,0);
 }
 const result=Object.freeze({occurrences:Object.freeze(occurrences),scope:'original_source_occurrence_census_only' as const});
 issued.set(result,prepared);return result;
}
