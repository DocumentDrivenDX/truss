/** Complete assertion-field correspondence; not complete report/profile admission. */
import {collectOriginalCompleteAssertionInventoryArtifact,requireOriginalCompleteAssertionInventory,type collectCompleteCatalogAssertionInventory} from './catalog-complete-assertion-inventory';
import {requireOriginalAcceptanceProfileResolver,type createAcceptanceProfileResolver} from './acceptance-profiles';
import type {createCatalogInputPreparation} from './catalog-input';
import type {ProfilePin} from '../../../docs/helix/02-design/contracts/bindings/truss-acceptance-input-v0.1';
import type {EnforcementReport} from '../../../docs/helix/02-design/contracts/bindings/truss-enforcement-report-v0.1';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Inventory=ReturnType<typeof collectCompleteCatalogAssertionInventory>;
const issued=new WeakMap<object,{prepared:Prepared;inventory:Inventory}>();
function same(left:unknown,right:unknown):boolean{
 if(left===right)return true;
 if(left===null||right===null||typeof left!=='object'||typeof right!=='object')return false;
 const arrays=Array.isArray(left)||Array.isArray(right);
 if(arrays&&(!Array.isArray(left)||!Array.isArray(right)))return false;
 for(const value of [left,right]){const prototype=Object.getPrototypeOf(value);if(arrays?prototype!==Array.prototype:prototype!==Object.prototype&&prototype!==null)return false;}
 const a=Object.getOwnPropertyDescriptors(left),b=Object.getOwnPropertyDescriptors(right),keys=Reflect.ownKeys(a),other=Reflect.ownKeys(b);
 if(keys.some(key=>typeof key!=='string')||other.some(key=>typeof key!=='string'))return false;
 const names=(keys as string[]).sort(),otherNames=(other as string[]).sort();
 if(names.length!==otherNames.length||names.some((key,index)=>key!==otherNames[index]||!('value' in a[key]!)||!('value' in b[key]!)||a[key]!.enumerable!==b[key]!.enumerable))return false;
 if(arrays){
  const length=a.length?.value;if(typeof length!=='number'||!Number.isSafeInteger(length)||length<0||length!==b.length?.value||names.length!==length+1)return false;
  for(let index=0;index<length;index++)if(!Object.hasOwn(a,String(index))||!Object.hasOwn(b,String(index)))return false;
 }
 return names.every(key=>same(a[key]!.value,b[key]!.value));
}
export function collectOriginalAssertionReportCandidate(prepared:Prepared,inventory:Inventory,revision:string,
 resolver:ReturnType<typeof createAcceptanceProfileResolver>,selected:ProfilePin){
 requireOriginalCompleteAssertionInventory(inventory,prepared);requireOriginalAcceptanceProfileResolver(resolver);
 if(typeof revision!=='string'||!/^[1-9][0-9]{0,9}$/.test(revision)||BigInt(revision)>2147483647n)throw Error('Original positive catalog revision required');
 const registration=resolver.resolveReport(selected),artifact=collectOriginalCompleteAssertionInventoryArtifact(inventory,prepared);
 const entries=Object.freeze(inventory.entries.map(entry=>Object.freeze({assertion:entry.assertion,source:entry.source,ruleName:entry.ruleName,ruleNameOrigin:entry.ruleNameOrigin,enforcement:entry.enforcement,reason:entry.reason})));
 const candidate:EnforcementReport&{readonly scope:{readonly kind:'complete'}}=Object.freeze({interfaceVersion:'truss-enforcement-report/0.1.0',catalogRevision:revision,
  reportProfile:registration.profile,layoutProfile:prepared.original.input.layoutProfile,scope:Object.freeze({kind:'complete'}),assertionInventorySha256:artifact.sha256,entries});
 const result=Object.freeze({candidate,inventoryArtifact:artifact,registeredReportArtifact:registration.artifact,
  scope:'complete_original_assertion_field_candidate_only' as const});
 issued.set(result,{prepared,inventory});return result;
}
export function requireOriginalAssertionReportCandidate(value:ReturnType<typeof collectOriginalAssertionReportCandidate>,prepared:Prepared,inventory:Inventory):void{
 const original=issued.get(value);if(!original||original.prepared!==prepared||original.inventory!==inventory)throw Error('Original assertion report candidate custody required');
 requireOriginalCompleteAssertionInventory(inventory,prepared);
}
export function verifyOriginalAssertionReportCandidate(value:ReturnType<typeof collectOriginalAssertionReportCandidate>,prepared:Prepared,inventory:Inventory,report:unknown):void{
 requireOriginalAssertionReportCandidate(value,prepared,inventory);
 if(!same(report,value.candidate))throw Error('Complete original assertion report correspondence required');
}
