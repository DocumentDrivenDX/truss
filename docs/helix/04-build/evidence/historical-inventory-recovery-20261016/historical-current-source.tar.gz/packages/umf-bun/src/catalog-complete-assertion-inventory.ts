/** Complete original source inventory only; enforcement/report admission is separate. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireCompleteOriginalSourceDisposition,type reconcileCatalogAssertionOccurrences} from './catalog-assertion-reconciliation';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Reconciliation=ReturnType<typeof reconcileCatalogAssertionOccurrences>;
type Artifact={readonly identity:string;readonly bytesBase64:string;readonly sha256:string};
const issued=new WeakMap<object,Prepared>();
const issuedArtifacts=new WeakMap<object,Artifact>();
const limit=4194304;
export function requireOriginalCompleteAssertionInventory(value:object,prepared:Prepared):void{
 requireOriginalCatalogPreparation(prepared);
 if(issued.get(value)!==prepared)throw Error('Original complete assertion inventory custody required');
}
export function collectCompleteCatalogAssertionInventory(prepared:Prepared,reconciliation:Reconciliation){
 requireCompleteOriginalSourceDisposition(reconciliation,prepared);
 if(prepared.original.input.binding.state!=='absent')throw Error('Complete original binding assertion inventory required');
 const artifacts=new Map<string,Artifact>();
 let retainedWireBytes=0;
 function charge(value:unknown):void{
  retainedWireBytes+=Buffer.byteLength(JSON.stringify(value),'utf8');
  if(retainedWireBytes>limit)throw Error('Complete original inventory capacity exceeded');
 }
 function retain(value:Artifact):string{
  if(value.bytesBase64.length>limit)throw Error('Complete original inventory capacity exceeded');
  const bytes=Buffer.from(value.bytesBase64,'base64');
  if(bytes.toString('base64')!==value.bytesBase64||createHash('sha256').update(bytes).digest('hex')!==value.sha256)throw Error('Exact original inventory evidence required');
  const prior=artifacts.get(value.sha256);
  if(prior&&prior.bytesBase64!==value.bytesBase64)throw Error('Conflicting original inventory evidence');
  if(!prior){charge(value);artifacts.set(value.sha256,value);}
  return value.sha256;
 }
 const families=[reconciliation.coreManifest,reconciliation.scalarManifest,reconciliation.itemManifest,reconciliation.literalManifest,reconciliation.referenceManifest,reconciliation.metadataManifest,reconciliation.facetManifest,reconciliation.keyManifest,reconciliation.relationshipManifest,reconciliation.schemaPropertyManifest,reconciliation.membershipManifest];
 for(const manifest of families)retain(manifest);
 for(const evidence of [...reconciliation.scalarValidationEvidence,...reconciliation.referenceValidationEvidence,...reconciliation.membershipValidationEvidence])retain(evidence);
 const entries=[];
 const identities=new Set<string>();
 for(const row of reconciliation.dispositions){
  if(row.state!=='assertion')continue;
  const entry=row.assertion;
  if(entry.enforcement!=='none')throw Error('Independent admitted enforcement join required');
  const identity=JSON.stringify([row.occurrence.definitionPin,row.owner,row.occurrence.sourcePointer]);
  if(identities.has(identity))throw Error('Duplicate complete original assertion');identities.add(identity);
  if('sourceIdentityProfile' in entry.assertion&&!families.some(value=>value.sha256===entry.assertion.sourceIdentityProfile?.sha256))throw Error('Original assertion identity profile artifact required');
  const corroborating='corroboratingOwnerEvidence' in entry?entry.corroboratingOwnerEvidence:null;
  const retained=Object.freeze({assertion:entry.assertion,source:entry.source,ruleName:entry.ruleName,ruleNameOrigin:entry.ruleNameOrigin,
   enforcement:'none' as const,reason:entry.reason,ownerEvidenceSha256:retain(entry.ownerEvidence),
   corroboratingOwnerEvidenceSha256:corroborating?retain(corroborating):null});
  charge(retained);entries.push(retained);
 }
 const manifestBytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-assertion-inventory/0.1.0',
  interpretationProfile:prepared.umfProfile,sourceVersions:['0.7.0','0.8.0'],families:families.map(value=>({identity:value.identity,sha256:value.sha256})),
  rules:['core.kind','core.nullability','core.cardinality','core.facets','core.keys','core.relationships','core.schema_properties.allowedValues','core.schema_properties.default','core.scalarType','core.itemType','core.members','core.reference'],
  membership:'Complete privately issued original-occurrence partition; unavailable membership refuses',
  unknown:'Retain owner-classified opaque assertion tokens as none/opaque; unclassified content refuses',
  absence:'Original owner absence observations; no invented assertion',enforcement:'none; independent native/engine qualification required',
  inventoryDigest:'SHA-256 of the complete privately issued inventory object encoded as compact UTF-8 JSON in producer member/array order; exact bytes, not semantic canonical equality',
  capacity:{serializedInventoryUtf8Bytes:limit}}));
 const manifest=Object.freeze({identity:'truss.original-assertion-inventory/0.1.0',bytesBase64:manifestBytes.toString('base64'),sha256:createHash('sha256').update(manifestBytes).digest('hex')});retain(manifest);
 const profile=Object.freeze({identity:'truss-original-assertion-inventory',version:'0.1.0',sha256:manifest.sha256});
 const dispositions=reconciliation.dispositions.map(row=>{const value=Object.freeze({definitionPin:row.occurrence.definitionPin,owner:row.owner,sourcePointer:row.occurrence.sourcePointer,state:row.state});charge(value);return value;});
 for(const absence of reconciliation.absent)charge(absence);
 // Bound the complete retained inventory, including repeated wire representations.
 // This is a component reservation, not the full report's pre-effect reservation.
 const payload=Object.freeze({profile,manifest,entries:Object.freeze(entries),dispositions:Object.freeze(dispositions),
  absent:reconciliation.absent,artifacts:Object.freeze([...artifacts.values()]),inventoryComplete:true as const,
  enforcementQualified:false as const,scope:'complete_original_assertion_inventory_only' as const});
 // Exact size from bounded constituent encodings; never allocate an oversized
 // whole-payload string merely to discover that it exceeds the wire budget.
 const skeletonBytes=Buffer.byteLength(JSON.stringify({...payload,entries:[],dispositions:[],absent:[],artifacts:[],serializedBytes:0}),'utf8');
 const commas=[entries.length,dispositions.length,reconciliation.absent.length,artifacts.size].reduce((total,length)=>total+Math.max(0,length-1),0);
 const fixedBytes=skeletonBytes+retainedWireBytes+commas-1;
 let serializedBytes=fixedBytes+1,previous=-1;
 while(previous!==serializedBytes){previous=serializedBytes;serializedBytes=fixedBytes+String(serializedBytes).length;}
 if(serializedBytes>limit)throw Error('Complete original inventory capacity exceeded');
 const result=Object.freeze({...payload,serializedBytes});issued.set(result,prepared);return result;
}

/** Exact emitted inventory bytes, not a digest of a caller's substituted tree. */
export function collectOriginalCompleteAssertionInventoryArtifact(value:ReturnType<typeof collectCompleteCatalogAssertionInventory>,prepared:Prepared):Artifact{
 requireOriginalCompleteAssertionInventory(value,prepared);
 const prior=issuedArtifacts.get(value);if(prior)return prior;
 const bytes=Buffer.from(JSON.stringify(value),'utf8');
 if(bytes.length!==value.serializedBytes||bytes.length>limit)throw Error('Original inventory wire size correspondence required');
 const artifact=Object.freeze({identity:'truss.original-assertion-inventory-output/0.1.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 issuedArtifacts.set(value,artifact);return artifact;
}
