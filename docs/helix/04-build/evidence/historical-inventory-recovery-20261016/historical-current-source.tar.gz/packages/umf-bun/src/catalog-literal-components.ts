/** Closed typed-literal traversal under original0.8 owner observations. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalAssertionSourceOccurrences,type collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
import {requireOriginalCatalogObservationCollection,type collectCatalogAssertionObservations} from './catalog-assertion-observations';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
export function collectCatalogLiteralComponents(prepared:Prepared,census:ReturnType<typeof collectOriginalAssertionSourceOccurrences>,observations:ReturnType<typeof collectCatalogAssertionObservations>){
 requireOriginalCatalogPreparation(prepared);requireOriginalAssertionSourceOccurrences(census,prepared);requireOriginalCatalogObservationCollection(prepared,observations);
 const bytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-literal-components/0.1.0',record:prepared.umfProfile,inspection:observations.profile,sourceVersion:'0.8.0',operation:'inspect-core-schema-properties',resultVersion:'1.0.0',grammar:'null or closed scalar carrier, array of literals or exact string-key map of literals',constraints:['allowedValues indexed literals','default.value'],annotations:['examples and indexed literals'],unknown:'no qualifier inheritance'}));
 const manifest=Object.freeze({identity:'truss.original-literal-components/0.1.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 const occurrences=new Map(census.occurrences.map(row=>[JSON.stringify([row.documentIndex,row.sourcePointer]),row]));
 const entries:{occurrence:ReturnType<typeof collectOriginalAssertionSourceOccurrences>['occurrences'][number];rootPointer:string;annotation:boolean;ownerEvidence:typeof observations.observations[number]['evidence']}[]=[];let pathBytes=0;
 for(const observed of observations.observations){
  if(!observations.composition||observed.operation!=='schema_properties'||observed.basis!=='original')continue;
  const di=prepared.documents.findIndex(d=>d.documentId===observed.documentId),document=prepared.documents[di];if(document?.umfVersion!=='0.8.0')continue;
  const identity=observed.identity as any;if(identity?.scope!=='element')continue;
  const mi=document.interpretation.source.modules.findIndex((m:any)=>m.id===identity.module),ei=mi>=0?document.interpretation.source.modules[mi].elements.findIndex((e:any)=>e.id===identity.element):-1;
  if(ei<0||document.interpretation.source.modules[mi].elements[ei].kind!=='field')continue;
  const result=observed.result as any;if(result.state!=='observed')continue;const owner=result.observation;
  if(owner.path!==`/modules/${mi}/elements/${ei}`||owner.operation!=='inspect-core-schema-properties'||owner.version!=='1.0.0'||JSON.stringify(owner.source)!==JSON.stringify(document.interpretation.source))throw Error('Original literal inspector required');
  const at=(path:string)=>occurrences.get(JSON.stringify([di,path]));
  function emit(path:string,root:string,annotation:boolean){const occurrence=at(path);if(!occurrence)throw Error('Original literal occurrence absent');if(entries.length>=16384||(pathBytes+=Buffer.byteLength(path,'utf8'))>4194304)throw Error('Literal component capacity exceeded');entries.push(Object.freeze({occurrence,rootPointer:root,annotation,ownerEvidence:observed.evidence}));}
  function visit(path:string,root:string,annotation:boolean,depth=0){if(depth>64)throw Error('Literal depth exceeded');const value=at(path)?.value;emit(path,root,annotation);if(value===null)return;
   if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1)throw Error('Closed original typed literal required');
   const tag=Object.keys(value)[0]!,payload=(value as any)[tag];emit(path+'/'+tag,root,annotation);
   if(tag==='array'){if(!Array.isArray(payload))throw Error('Literal array required');for(let i=0;i<payload.length;i++)visit(path+'/array/'+i,root,annotation,depth+1);}
   else if(tag==='map'){if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('Literal map required');for(const key of Object.keys(payload))visit(path+'/map/'+key.replaceAll('~','~0').replaceAll('/','~1'),root,annotation,depth+1);}
   else if(!['boolean','integerToken','decimalToken','string','binaryHex','floatToken','date','time','timestamp'].includes(tag))throw Error('Unknown literal carrier');
  }
  for(const name of ['allowedValues','default','examples']){
   if(!Object.hasOwn(owner.properties,name))continue;const root=owner.path+'/'+name,original=at(root)?.value;
   if(JSON.stringify(original)!==JSON.stringify(owner.properties[name]))throw Error('Original literal property correspondence required');
   if(name==='default')visit(root+'/value',root,false);
   else {if(!Array.isArray(original))throw Error('Original literal list required');if(name==='examples')emit(root,root,true);for(let i=0;i<original.length;i++)visit(root+'/'+i,root,name==='examples');}
  }
 }
 return Object.freeze({entries:Object.freeze(entries),manifest,complete:false as const});
}
