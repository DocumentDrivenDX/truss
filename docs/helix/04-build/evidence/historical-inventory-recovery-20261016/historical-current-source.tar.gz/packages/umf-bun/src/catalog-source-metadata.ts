/** Closed original-source metadata grammar; no unknown-child inheritance. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalAssertionSourceOccurrences,type collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
import {requireOriginalCatalogObservationCollection,type collectCatalogAssertionObservations} from './catalog-assertion-observations';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
export function collectCatalogSourceMetadata(prepared:Prepared,census:ReturnType<typeof collectOriginalAssertionSourceOccurrences>,observations:ReturnType<typeof collectCatalogAssertionObservations>){
 requireOriginalCatalogPreparation(prepared);requireOriginalAssertionSourceOccurrences(census,prepared);requireOriginalCatalogObservationCollection(prepared,observations);
 const rules={structure:['document object','umf/id','modules and indexed module objects','module id/namespace/elements and indexed element objects','extensions containers','keys/relationships/references containers'],annotations:['element name/description','original0.8 title/aliases and indexed alias strings'],registry:['vocabularies container','indexed vocabulary objects and direct version strings'],unknown:'unavailable; no parent-prefix coverage',examples:'not admitted by this grammar'};
 const bytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-source-metadata/0.1.0',record:prepared.umfProfile,composition:observations.composition,sourceVersions:['0.7.0','0.8.0'],rules}));
 const manifest=Object.freeze({identity:'truss.original-source-metadata/0.1.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 const index='(?:0|[1-9][0-9]*)',module='\\/modules\\/'+index,element=module+'\\/elements\\/'+index;
 const structurePattern=new RegExp('^(?:|/umf|/id|/modules|/extensions|'+module+'(?:/id|/namespace|/elements|/extensions|/relationships)?|'+element+'(?:/id|/extensions|/keys|/references)?)$');
 const annotationPattern=new RegExp('^'+element+'/(?:name|description)$');
 const currentAnnotationPattern=new RegExp('^(?:'+module+'|'+element+')/(?:title|aliases(?:/'+index+')?)$');
 const entries=[];
 if(observations.composition)for(const occurrence of census.occurrences){
  const document=prepared.documents[occurrence.documentIndex]!;
  if(!['0.7.0','0.8.0'].includes(document.umfVersion)||!document.interpretation.sourceValidation.valid)throw Error('Original metadata source profile required');
  const path=occurrence.sourcePointer;
  const structural=structurePattern.test(path);
  const registry=/^\/vocabularies(?:\/[^/]+(?:\/version)?)?$/.test(path);
  const annotation=annotationPattern.test(path);
  const currentAnnotation=document.umfVersion==='0.8.0'&&currentAnnotationPattern.test(path);
  // Root document annotations use /title and /aliases, rather than //title.
  const rootAnnotation=document.umfVersion==='0.8.0'&&/^\/(?:title|aliases(?:\/(?:0|[1-9][0-9]*))?)$/.test(path);
  if(structural||registry||annotation||currentAnnotation||rootAnnotation)entries.push(Object.freeze({occurrence,reason:structural?'core_structure' as const:registry?'vocabulary_registration' as const:'core_annotation' as const,metadataEvidence:manifest}));
 }
 return Object.freeze({entries:Object.freeze(entries),manifest,complete:false as const});
}
