/** Source-only report producers; call before effects, never an acceptance grant. */
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {collectCatalogAssertionObservations} from './catalog-assertion-observations';
import {assessCatalogObservationCoverage} from './catalog-observation-coverage';
import {collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
import {reconcileCatalogAssertionOccurrences} from './catalog-assertion-reconciliation';
import {collectCompleteCatalogAssertionInventory} from './catalog-complete-assertion-inventory';
import {collectCatalogCoreAssertionIdentities} from './catalog-core-assertion-identities';
import {collectCatalogExtensionInventory} from './catalog-extension-inventory';
import {collectCatalogValidationEvidence} from './catalog-validation-evidence';
import {collectCatalogIngressReportBasis} from './catalog-ingress-report-basis';
import type {loadUmfDeclarationProducer,loadUmfFieldAssertionProducer} from './index';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Owner=Awaited<ReturnType<typeof loadUmfDeclarationProducer>>;
type Fields=Awaited<ReturnType<typeof loadUmfFieldAssertionProducer>>;
const issued=new WeakMap<object,{prepared:Prepared;owner:Owner;fields:Fields}>();
export function requireOriginalCatalogSourceReportPreparation(value:object,prepared:Prepared,selection?:{readonly owner:Owner;readonly fields:Fields}):void{
 requireOriginalCatalogPreparation(prepared);
 const original=issued.get(value);
 if(!original||original.prepared!==prepared||selection!==undefined&&(original.owner!==selection.owner||original.fields!==selection.fields))throw Error('Original source report preparation custody required');
}
export function prepareCatalogSourceReport(prepared:Prepared,owner:Owner,fields:Fields){
 requireOriginalCatalogPreparation(prepared);
 if(prepared.original.input.transforms.length)throw Error('Complete transform execution and report producer required');
 const ingressBasis=collectCatalogIngressReportBasis(prepared);
 const ownerObservations=collectCatalogAssertionObservations(prepared,owner,fields);
 const observationCoverage=assessCatalogObservationCoverage(prepared,ownerObservations);
 const assertionSourceOccurrences=collectOriginalAssertionSourceOccurrences(prepared);
 const assertionReconciliation=reconcileCatalogAssertionOccurrences(prepared,assertionSourceOccurrences,ownerObservations);
 const assertionInventory=assertionReconciliation.dispositionComplete?collectCompleteCatalogAssertionInventory(prepared,assertionReconciliation):null;
 const coreAssertionIdentities=collectCatalogCoreAssertionIdentities(prepared,ownerObservations);
 const extensions=collectCatalogExtensionInventory(prepared);
 const validationEvidence=collectCatalogValidationEvidence(prepared);
 const result=Object.freeze({ingressBasis,ownerObservations,observationCoverage,assertionSourceOccurrences,assertionReconciliation,assertionInventory,coreAssertionIdentities,extensions,validationEvidence,
  scope:'original_source_only_report_preparation' as const});
 issued.set(result,{prepared,owner,fields});return result;
}
export function requireClosedCatalogSourceReport(value:ReturnType<typeof prepareCatalogSourceReport>,prepared:Prepared):void{
 requireOriginalCatalogSourceReportPreparation(value,prepared);
 if(!value.assertionInventory)throw Error('Complete original source assertion inventory required before staging');
}
