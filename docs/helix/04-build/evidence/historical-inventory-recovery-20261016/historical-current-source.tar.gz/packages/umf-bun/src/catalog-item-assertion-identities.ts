/** Original0.7/0.8 collection item reference, bound to original cardinality inspection. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalCatalogObservationCollection,type collectCatalogAssertionObservations} from './catalog-assertion-observations';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Observations=ReturnType<typeof collectCatalogAssertionObservations>;
export function collectCatalogItemAssertionIdentities(prepared:Prepared,observations:Observations){
 requireOriginalCatalogPreparation(prepared);requireOriginalCatalogObservationCollection(prepared,observations);
 const bytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-item-reference/0.2.0',
  record:{mode:'record',profile:prepared.umfProfile},fields:{mode:'assertion-fields',profile:observations.fieldProfile},
  sourceVersions:['0.7.0','0.8.0'],operation:'inspect-core-cardinality',resultVersions:{'0.7.0':'4.0.0','0.8.0':'5.0.0'},
  selector:'known array/map cardinality with original itemType',
  components:['module','element'],unknownChildren:'unavailable; no prefix inheritance',
  enforcement:'none/unqualified; no native shape or target validity inferred'}));
 const manifest=Object.freeze({identity:'truss.original-item-reference/0.2.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 const profile=Object.freeze({identity:'truss-original-item-reference',version:'0.2.0',sha256:manifest.sha256});
 const entries=[];
 for(const observation of observations.observations){
  if(observation.operation!=='cardinality'||observation.basis!=='original')continue;
  const di=prepared.documents.findIndex(document=>document.documentId===observation.documentId),document=prepared.documents[di];
  if(!document||!['0.7.0','0.8.0'].includes(document.umfVersion))continue;
  const result=observation.result as any,ownerResult=result.observation,identity=observation.identity as any;
  if(result.state!=='observed'||ownerResult?.meaning?.state!=='known'||!['array','map'].includes(ownerResult.meaning.cardinality)||!Object.hasOwn(ownerResult.meaning,'itemType'))continue;
  if(!observations.fieldProfile||ownerResult.operation!=='inspect-core-cardinality'||ownerResult.version!==(document.umfVersion==='0.8.0'?'5.0.0':'4.0.0')||JSON.stringify(ownerResult.source)!==JSON.stringify(document.interpretation.source)||typeof identity?.module!=='string'||typeof identity?.element!=='string')throw Error('Original item reference inspector correspondence required');
  const mi=document.interpretation.source.modules.findIndex((module:any)=>module.id===identity.module),module=document.interpretation.source.modules[mi];
  const ei=module?.elements.findIndex((element:any)=>element.id===identity.element)??-1,element=module?.elements[ei];
  const base=`/modules/${mi}/elements/${ei}`;
  if(element?.kind!=='field'||ownerResult.path!==base+'/cardinality'||JSON.stringify(element.itemType)!==JSON.stringify(ownerResult.meaning.itemType))throw Error('Original item reference occurrence correspondence required');
  const item=element.itemType;
  if(!item||typeof item!=='object'||Array.isArray(item)||typeof item.module!=='string'||typeof item.element!=='string')throw Error('Original item reference members required');
  const source=prepared.original.input.documents[di]!.artifact;
  entries.push(Object.freeze({assertion:Object.freeze({sourceKind:'umf_document' as const,owner:Object.freeze({documentId:document.documentId,moduleId:identity.module as string}),definitionPin:source.sha256,
   sourcePointer:base+'/itemType',kind:'source' as const,sourceIdentityProfile:profile}),source,
   ruleName:'core.itemType',ruleNameOrigin:'profile_generated' as const,enforcement:'none' as const,reason:'unqualified' as const,ownerEvidence:observation.evidence}));
 }
 return Object.freeze({entries:Object.freeze(entries),manifest,profile,complete:false as const});
}
