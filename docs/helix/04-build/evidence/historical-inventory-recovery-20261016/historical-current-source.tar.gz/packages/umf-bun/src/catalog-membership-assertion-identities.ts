/** Original0.7 validated Record membership; no native admission or enforcement. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalAssertionSourceOccurrences,type collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Census=ReturnType<typeof collectOriginalAssertionSourceOccurrences>;
export function collectCatalogMembershipAssertionIdentities(prepared:Prepared,census:Census){
 requireOriginalCatalogPreparation(prepared);requireOriginalAssertionSourceOccurrences(census,prepared);
 const bytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-record-membership/0.2.0',producer:{mode:'record',profile:prepared.umfProfile},sourceVersions:['0.7.0','0.8.0'],governingSurface:'src/validation/keys.ts validateKeyCandidate; spec/core/key-document.schema.json',selector:'original Record members array',components:['indexed reference objects','direct module','direct element'],unknown:'unavailable; no subtree inheritance',absence:'no assertion invented',enforcement:'none/unqualified',maxEvidenceArtifactUtf8Bytes:4194304}));
 const manifest=Object.freeze({identity:'truss.original-record-membership/0.2.0',bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
 const profile=Object.freeze({identity:'truss-original-record-membership',version:'0.2.0',sha256:manifest.sha256});
 const entries=[];let evidenceBytes=0;
 const validationEvidence=new Map<number,Readonly<{identity:string;bytesBase64:string;sha256:string}>>();
 function artifact(identity:string,bytes:Buffer){
  const value=Object.freeze({identity,bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
  evidenceBytes+=Buffer.byteLength(JSON.stringify(value),'utf8');if(evidenceBytes>4194304)throw Error('Record membership evidence capacity exceeded');return value;
 }
 for(const occurrence of census.occurrences){
  const match=/^\/modules\/(0|[1-9][0-9]*)\/elements\/(0|[1-9][0-9]*)\/members$/.exec(occurrence.sourcePointer);
  if(!match)continue;
  const document=prepared.documents[occurrence.documentIndex]!;
  if(!['0.7.0','0.8.0'].includes(document.umfVersion))continue;
  const module=document.interpretation.source.modules[Number(match[1])],element=module?.elements[Number(match[2])];
  if(element?.kind!=='record')continue;
  if(!document.interpretation.sourceValidation.valid||occurrence.owner.moduleId!==module.id||!Array.isArray(occurrence.value))throw Error('Original validated Record membership required');
  let validation=validationEvidence.get(occurrence.documentIndex);
  if(!validation){validation=artifact('truss.original-membership-validation/'+occurrence.documentIndex,Buffer.from(JSON.stringify({producer:prepared.umfProfile,documentId:document.documentId,contentSha256:occurrence.definitionPin,basis:'original',sourceValidation:document.interpretation.sourceValidation})));validationEvidence.set(occurrence.documentIndex,validation);}
  const evidence=Buffer.from(JSON.stringify({profile,producer:prepared.umfProfile,documentId:document.documentId,contentSha256:occurrence.definitionPin,basis:'original',sourcePointer:occurrence.sourcePointer,validationEvidenceSha256:validation.sha256}));
  const ownerEvidence=artifact('truss.original-record-membership/'+occurrence.documentIndex+'/'+match[1]+'/'+match[2],evidence);
  entries.push(Object.freeze({assertion:Object.freeze({sourceKind:'umf_document' as const,owner:Object.freeze({documentId:document.documentId,moduleId:module.id as string}),definitionPin:occurrence.definitionPin,sourcePointer:occurrence.sourcePointer,kind:'source' as const,sourceIdentityProfile:profile}),source:prepared.original.input.documents[occurrence.documentIndex]!.artifact,ruleName:'core.members',ruleNameOrigin:'profile_generated' as const,enforcement:'none' as const,reason:'unqualified' as const,ownerEvidence}));
 }
 return Object.freeze({entries:Object.freeze(entries),profile,manifest,validationEvidence:Object.freeze([...validationEvidence.values()]),retainedEvidenceBytes:evidenceBytes,complete:false as const});
}
