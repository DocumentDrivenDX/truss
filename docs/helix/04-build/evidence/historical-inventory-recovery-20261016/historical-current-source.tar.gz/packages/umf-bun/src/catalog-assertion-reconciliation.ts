import {collectCatalogLiteralComponents} from './catalog-literal-components';
import {collectCatalogReferenceAssertionIdentities} from './catalog-reference-assertion-identities';
import {collectCatalogSourceMetadata} from './catalog-source-metadata';
/** Exact original occurrence reconciliation. This is not semantic admission. */
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalAssertionSourceOccurrences,type collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
import {requireOriginalCatalogObservationCollection,type collectCatalogAssertionObservations} from './catalog-assertion-observations';
import {collectCatalogCoreAssertionIdentities} from './catalog-core-assertion-identities';
import {collectCatalogScalarAssertionIdentities} from './catalog-scalar-assertion-identities';
import {collectCatalogItemAssertionIdentities} from './catalog-item-assertion-identities';
import {collectCatalogFacetComponents} from './catalog-facet-components';
import {collectCatalogMembershipAssertionIdentities} from './catalog-membership-assertion-identities';
import {collectCatalogExtensionInventory} from './catalog-extension-inventory';
import {createHash} from 'node:crypto';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Census=ReturnType<typeof collectOriginalAssertionSourceOccurrences>;
type Observations=ReturnType<typeof collectCatalogAssertionObservations>;
const issued=new WeakMap<object,Prepared>();
export function requireOriginalAssertionReconciliation(value:object,prepared:Prepared):void{
 requireOriginalCatalogPreparation(prepared);
 if(issued.get(value)!==prepared)throw Error('Original assertion reconciliation custody required');
}
export function reconcileCatalogAssertionOccurrences(prepared:Prepared,census:Census,observations:Observations){
 requireOriginalCatalogPreparation(prepared);
 requireOriginalAssertionSourceOccurrences(census,prepared);
 requireOriginalCatalogObservationCollection(prepared,observations);
 const core=collectCatalogCoreAssertionIdentities(prepared,observations);
 const scalar=collectCatalogScalarAssertionIdentities(prepared,census);
 const item=collectCatalogItemAssertionIdentities(prepared,observations);
 const facets=collectCatalogFacetComponents(prepared,observations);
 const membership=collectCatalogMembershipAssertionIdentities(prepared,census);
 const references=collectCatalogReferenceAssertionIdentities(prepared,census);
 const extensionInventory=collectCatalogExtensionInventory(prepared);
 const metadata=collectCatalogSourceMetadata(prepared,census,observations);
 const literals=collectCatalogLiteralComponents(prepared,census,observations);
 const literalEntries=new Map(literals.entries.map(entry=>[entry.occurrence,entry]));
 const key=(pin:string,owner:unknown,pointer:string)=>JSON.stringify([pin,owner,pointer]);
 const extensionRoots=new Map(extensionInventory.entries.map(extension=>[key(extension.source.sha256,extension.owner,extension.sourcePointer),extension]));
 const remainingExtensions=new Set(extensionRoots.keys());
 const entries=[...core.entries,...scalar.entries,...item.entries,...membership.entries,...references.entries];
 const assertions=new Map(entries.map(entry=>[key(entry.assertion.definitionPin,entry.assertion.owner,entry.assertion.sourcePointer),entry]));
 if(assertions.size!==entries.length)throw Error('Duplicate original assertion source identity');
 const remaining=new Set(assertions.keys());
 const metadataEntries=new Map(metadata.entries.map(entry=>[key(entry.occurrence.definitionPin,entry.occurrence.owner.moduleId===undefined?{scope:'document',documentId:entry.occurrence.documentId}:entry.occurrence.owner,entry.occurrence.sourcePointer),entry]));
 const facetComponents=new Map(facets.components.map(component=>[key(component.definitionPin,{documentId:component.documentId,moduleId:component.moduleId},component.sourcePointer),component]));
 const keyManifestBytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-key-components/0.2.0',
  record:{mode:'record',profile:prepared.umfProfile},declarations:{mode:'declarations',profile:observations.profile},
  sourceVersions:['0.7.0','0.8.0'],operation:'inspect-core-keys',resultVersions:{'0.7.0':'2.0.0','0.8.0':'3.0.0'},
  components:['id','name','primary','fields','fields/{index}','fields/{index}/module','fields/{index}/element'],
  unknown:'unavailable; no prefix inheritance',enforcement:'none/unqualified'}));
 const keyManifest=Object.freeze({identity:'truss.original-key-components/0.2.0',bytesBase64:keyManifestBytes.toString('base64'),sha256:createHash('sha256').update(keyManifestBytes).digest('hex')});
 const checkedKeyEvidence=new WeakSet<object>();
 const checkedRelationshipEvidence=new WeakMap<object,readonly string[]>();
 const checkedSchemaPropertyEvidence=new WeakSet<object>();
 const scalarLiteral='(?:boolean|integerToken|decimalToken|string|binaryHex|floatToken|date|time|timestamp)';
 const propertyComponentPattern=new RegExp('^(.*\\/(?:allowedValues|default))\\/((?:0|[1-9][0-9]*)(?:\\/'+scalarLiteral+')?|on|value(?:\\/'+scalarLiteral+')?)$');
 const schemaPropertyManifestBytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-schema-property-components/0.1.0',sourceVersions:['0.8.0'],declarations:{mode:'declarations',profile:observations.profile},operation:'inspect-core-schema-properties',resultVersion:'1.0.0',components:['allowedValues indexed literal objects and direct scalar typed tokens','default on/value and direct scalar typed tokens'],collections:'nested literal array/map payload remains unresolved',unknown:'unavailable; no subtree inheritance',enforcement:'none/unqualified'}));
 const schemaPropertyManifest=Object.freeze({identity:'truss.original-schema-property-components/0.1.0',bytesBase64:schemaPropertyManifestBytes.toString('base64'),sha256:createHash('sha256').update(schemaPropertyManifestBytes).digest('hex')});
 const relationshipManifestBytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-relationship-components/0.2.0',record:{mode:'record',profile:prepared.umfProfile},declarations:{mode:'declarations',profile:observations.profile},sourceVersions:['0.7.0','0.8.0'],operation:'inspect-core-relationships',resultVersions:{'0.7.0':'1.0.0','0.8.0':'2.0.0'},components:{direct:['id','name','directed','inverse','targetLifecycle'],source:['module','element'],target:['module','element','key'],sourceMultiplicity:['min','max'],targetMultiplicity:['min','max'],associationRecord:['module','element']},containers:'explicit endpoint arrays and indexed reference objects only',unknown:'unavailable; no prefix inheritance',enforcement:'none/unqualified'}));
 const relationshipManifest=Object.freeze({identity:'truss.original-relationship-components/0.2.0',bytesBase64:relationshipManifestBytes.toString('base64'),sha256:createHash('sha256').update(relationshipManifestBytes).digest('hex')});
 const dispositions=census.occurrences.map(occurrence=>{
  const owner=Object.freeze(occurrence.owner.moduleId===undefined?
   {scope:'document' as const,documentId:occurrence.documentId}:
   {documentId:occurrence.documentId,moduleId:occurrence.owner.moduleId});
  const identity=key(occurrence.definitionPin,owner,occurrence.sourcePointer);
  let extensionPath=occurrence.sourcePointer;
  while(extensionPath){
   const extensionIdentity=key(occurrence.definitionPin,owner,extensionPath),extension=extensionRoots.get(extensionIdentity);
   if(extension){
    if(extensionPath===occurrence.sourcePointer){
     if(!remainingExtensions.delete(extensionIdentity)||occurrence.value!==extension.payload)throw Error('Original extension occurrence correspondence required');
    }
    return Object.freeze({occurrence,owner,state:'unavailable' as const,reason:'extension_assertion_membership_not_admitted' as const,extensionPointer:extensionPath,extensionId:extension.extensionId});
   }
   extensionPath=extensionPath.slice(0,extensionPath.lastIndexOf('/'));
  }
  const assertion=assertions.get(identity);
  if(assertion){
   if(!remaining.delete(identity))throw Error('Duplicate original assertion occurrence');
   return Object.freeze({occurrence,owner,state:'assertion' as const,assertion});
  }
  // Only the two explicitly interpreted reference members are components.
  // Unknown qualifiers, including their descendants, stay unresolved.
  const component=/^(.*\/itemType)\/(module|element)$/.exec(occurrence.sourcePointer);
  const parent=component?assertions.get(key(occurrence.definitionPin,owner,component[1]!)):undefined;
  if(parent?.ruleName==='core.itemType')return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:parent});
  const facetComponent=facetComponents.get(identity);
  if(facetComponent){
   const parent=assertions.get(key(occurrence.definitionPin,owner,facetComponent.assertionPointer));
   if(parent?.ruleName!=='core.facets')throw Error('Original facet assertion root required');
   return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:parent});
  }
  const keyComponent=/^(\/modules\/(?:0|[1-9][0-9]*)\/elements\/(?:0|[1-9][0-9]*)\/keys\/(?:0|[1-9][0-9]*))\/(id|name|primary|fields(?:\/(?:0|[1-9][0-9]*)(?:\/(?:module|element))?)?)$/.exec(occurrence.sourcePointer);
  const keyAssertion=keyComponent?assertions.get(key(occurrence.definitionPin,owner,keyComponent[1]!)):undefined;
  if(keyAssertion?.ruleName==='core.keys'&&['0.7.0','0.8.0'].includes(prepared.documents[occurrence.documentIndex]!.umfVersion)){
   if(!checkedKeyEvidence.has(keyAssertion.ownerEvidence)){
   const evidence=JSON.parse(Buffer.from(keyAssertion.ownerEvidence.bytesBase64,'base64').toString('utf8'));
   const result=evidence.result?.observation;
   if(evidence.operation!=='keys'||evidence.basis!=='original'||result?.operation!=='inspect-core-keys'||result.version!==(prepared.documents[occurrence.documentIndex]!.umfVersion==='0.8.0'?'3.0.0':'2.0.0')||JSON.stringify(evidence.profile)!==JSON.stringify(observations.profile))throw Error('Original key component inspector binding required');
   checkedKeyEvidence.add(keyAssertion.ownerEvidence);
   }
   return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:keyAssertion});
  }
  const relationshipComponent=/^(\/modules\/(?:0|[1-9][0-9]*)\/relationships\/(?:0|[1-9][0-9]*))\/(id|name|directed|inverse|targetLifecycle|sourceMultiplicity(?:\/(?:min|max))?|targetMultiplicity(?:\/(?:min|max))?|associationRecord(?:\/(?:module|element))?|source(?:\/(?:0|[1-9][0-9]*)(?:\/(?:module|element))?)?|target(?:\/(?:0|[1-9][0-9]*)(?:\/(?:module|element|key))?)?)$/.exec(occurrence.sourcePointer);
  const relationshipAssertion=relationshipComponent?assertions.get(key(occurrence.definitionPin,owner,relationshipComponent[1]!)):undefined;
  if(relationshipAssertion?.ruleName==='core.relationships'&&['0.7.0','0.8.0'].includes(prepared.documents[occurrence.documentIndex]!.umfVersion)){
   if(!checkedRelationshipEvidence.has(relationshipAssertion.ownerEvidence)){
    const evidence=JSON.parse(Buffer.from(relationshipAssertion.ownerEvidence.bytesBase64,'base64').toString('utf8')),result=evidence.result?.observation;
    if(evidence.operation!=='relationships'||evidence.basis!=='original'||result?.operation!=='inspect-core-relationships'||result.version!==(prepared.documents[occurrence.documentIndex]!.umfVersion==='0.8.0'?'2.0.0':'1.0.0')||JSON.stringify(evidence.profile)!==JSON.stringify(observations.profile))throw Error('Original relationship component inspector binding required');
    const unknown=result.meaning?.uninterpretedPaths;
    if(!Array.isArray(unknown)||unknown.some((path:unknown)=>typeof path!=='string'))throw Error('Original relationship uninterpreted paths required');
    checkedRelationshipEvidence.set(relationshipAssertion.ownerEvidence,unknown);
   }
   if(checkedRelationshipEvidence.get(relationshipAssertion.ownerEvidence)!.some(path=>occurrence.sourcePointer===path||occurrence.sourcePointer.startsWith(path+'/')))return Object.freeze({occurrence,owner,state:'unavailable' as const,reason:'semantic_disposition_not_admitted' as const});
   return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:relationshipAssertion});
  }
  const referenceComponent=/^(\/modules\/(?:0|[1-9][0-9]*)\/elements\/(?:0|[1-9][0-9]*)\/references\/(?:0|[1-9][0-9]*))\/(role|module|element)$/.exec(occurrence.sourcePointer);
  const referenceAssertion=referenceComponent?assertions.get(key(occurrence.definitionPin,owner,referenceComponent[1]!)):undefined;
  if(referenceAssertion?.ruleName==='core.reference')return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:referenceAssertion});
  const memberComponent=/^(\/modules\/(?:0|[1-9][0-9]*)\/elements\/(?:0|[1-9][0-9]*)\/members)\/(?:0|[1-9][0-9]*)(?:\/(?:module|element))?$/.exec(occurrence.sourcePointer);
  const memberAssertion=memberComponent?assertions.get(key(occurrence.definitionPin,owner,memberComponent[1]!)):undefined;
  if(memberAssertion?.ruleName==='core.members')return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:memberAssertion});
  const propertyComponent=propertyComponentPattern.exec(occurrence.sourcePointer);
  const propertyAssertion=propertyComponent?assertions.get(key(occurrence.definitionPin,owner,propertyComponent[1]!)):undefined;
  if(propertyAssertion&&['core.schema_properties.allowedValues','core.schema_properties.default'].includes(propertyAssertion.ruleName)&&prepared.documents[occurrence.documentIndex]!.umfVersion==='0.8.0'){
   const suffix=propertyComponent![2]!;
   const validMember=propertyAssertion.ruleName==='core.schema_properties.allowedValues'?/^(0|[1-9][0-9]*)(\/[^/]+)?$/.test(suffix):suffix==='on'||suffix==='value'||suffix.startsWith('value/');
   if(validMember){
    if(!checkedSchemaPropertyEvidence.has(propertyAssertion.ownerEvidence)){
     const evidence=JSON.parse(Buffer.from(propertyAssertion.ownerEvidence.bytesBase64,'base64').toString('utf8')),result=evidence.result?.observation;
     if(evidence.operation!=='schema_properties'||evidence.basis!=='original'||result?.operation!=='inspect-core-schema-properties'||result.version!=='1.0.0'||JSON.stringify(evidence.profile)!==JSON.stringify(observations.profile))throw Error('Original schema-property component inspector binding required');
     checkedSchemaPropertyEvidence.add(propertyAssertion.ownerEvidence);
    }
    return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:propertyAssertion});
   }
  }
  const literalEntry=literalEntries.get(occurrence);
  if(literalEntry){
   if(literalEntry.annotation)return Object.freeze({occurrence,owner,state:'non_assertive_metadata' as const,reason:'core_example' as const,metadataEvidence:literals.manifest});
   const parent=assertions.get(key(occurrence.definitionPin,owner,literalEntry.rootPointer));
   if(!parent||!['core.schema_properties.allowedValues','core.schema_properties.default'].includes(parent.ruleName))throw Error('Original literal assertion root required');
   return Object.freeze({occurrence,owner,state:'assertion_component' as const,assertion:parent});
  }
  const metadataEntry=metadataEntries.get(identity);
  if(metadataEntry)return Object.freeze({occurrence,owner,state:'non_assertive_metadata' as const,reason:metadataEntry.reason,metadataEvidence:metadataEntry.metadataEvidence});
  // No prefix inheritance: an inspected parent's unknown descendants retain
  // unresolved membership until an explicit semantic family covers them.
  return Object.freeze({occurrence,owner,state:'unavailable' as const,reason:'semantic_disposition_not_admitted' as const});
 });
 if(remaining.size)throw Error('Original assertion has no exact source occurrence');
 if(remainingExtensions.size)throw Error('Original extension has no exact source occurrence');
 const unresolvedCount=dispositions.filter(row=>row.state==='unavailable').length;
 const dispositionComplete=observations.composition!==null&&unresolvedCount===0;
 const result=Object.freeze({dispositionComplete,dispositions:Object.freeze(dispositions),absent:core.absent,coreManifest:core.manifest,scalarProfile:scalar.profile,scalarManifest:scalar.manifest,scalarValidationEvidence:scalar.validationEvidence,itemProfile:item.profile,itemManifest:item.manifest,
  unresolvedCount,
  literalManifest:literals.manifest,referenceManifest:references.manifest,referenceValidationEvidence:references.validationEvidence,metadataManifest:metadata.manifest,facetProfile:facets.profile,facetManifest:facets.manifest,keyManifest,relationshipManifest,schemaPropertyManifest,membershipManifest:membership.manifest,membershipValidationEvidence:membership.validationEvidence,unresolvedExtensionOccurrences:extensionInventory.entries.length,complete:false as const,scope:'original_exact_assertion_reconciliation_only' as const});
 issued.set(result,prepared);return result;
}

/** Source partition closure only; never complete report or enforcement admission. */
export function requireCompleteOriginalSourceDisposition(value:ReturnType<typeof reconcileCatalogAssertionOccurrences>,prepared:Prepared):void{
 requireOriginalAssertionReconciliation(value,prepared);
 if(!value.dispositionComplete||value.unresolvedCount!==0)throw Error('Complete original source disposition required');
}
