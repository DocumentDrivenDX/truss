/** Source-bound original compact checks; supplied input never attests native coverage. */
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireLoadedUmfCompactDatasetOwner,UMF_RUNTIME_SOURCE,type loadUmfCompactDatasetProducer} from './index';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Owner=Awaited<ReturnType<typeof loadUmfCompactDatasetProducer>>;
const issued=new WeakMap<object,{prepared:Prepared;owner:Owner;documentIndex:number}>();
function freeze(value:unknown):void{if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}}
export function collectOriginalCatalogDatasetEvidence(prepared:Prepared,owner:Owner,documentIndex:number,input:unknown){
 requireOriginalCatalogPreparation(prepared);requireLoadedUmfCompactDatasetOwner(owner);
 if(prepared.umfProfile.identity!=='umf-record-interpretation'||prepared.umfProfile.version!==UMF_RUNTIME_SOURCE||prepared.umfProfile.sha256!=='81e99f9a812ad3f61647f0c1d69c8e5640853f876127b7ee25a85efecaf00b68')throw Error('Registered original Record preparation required');
 if(typeof documentIndex!=='number'||!Number.isSafeInteger(documentIndex)||documentIndex<0||documentIndex>=prepared.documents.length)throw Error('Original document index required');
 const document=prepared.documents[documentIndex]!,declaration=prepared.original.input.documents[documentIndex]!;
 if(document.umfVersion!=='0.8.0'||document.interpretation.transition!==null)throw Error('Explicit preserved dataset transition composition required');
 // Original authored source, never a consumer-pruned or relabeled model.
 const source=document.interpretation.source;
 const receipt=owner.validateCoreDatasetValuesCompact(source,input);
 owner.verifyCoreDatasetValuesCompact(receipt,source,input);
 freeze(receipt);
 const value=Object.freeze({documentIndex,documentId:document.documentId,documentRevision:document.revision,sourceArtifact:declaration.artifact,
  producer:Object.freeze({sourceRevision:owner.sourceRevision,bundleSha256:owner.bundleSha256}),receipt,
  scope:'original_document_supplied_dataset_evidence_only' as const});
 issued.set(value,{prepared,owner,documentIndex});return value;
}
export function requireOriginalCatalogDatasetEvidence(value:ReturnType<typeof collectOriginalCatalogDatasetEvidence>,prepared:Prepared,owner:Owner,documentIndex:number):void{
 requireOriginalCatalogPreparation(prepared);requireLoadedUmfCompactDatasetOwner(owner);
 if(prepared.umfProfile.identity!=='umf-record-interpretation'||prepared.umfProfile.version!==UMF_RUNTIME_SOURCE||prepared.umfProfile.sha256!=='81e99f9a812ad3f61647f0c1d69c8e5640853f876127b7ee25a85efecaf00b68')throw Error('Registered original Record preparation required');
 const original=issued.get(value);
 if(!original||original.prepared!==prepared||original.owner!==owner||original.documentIndex!==documentIndex)throw Error('Original source-bound dataset evidence custody required');
}

/** Diagnose supplied occurrence incompatibility; never attests native population or admission. */
export function inspectOriginalDatasetEndpointUniqueness(
 evidence:ReturnType<typeof collectOriginalCatalogDatasetEvidence>,prepared:Prepared,owner:Owner,documentIndex:number,
){
 requireOriginalCatalogDatasetEvidence(evidence,prepared,owner,documentIndex);
 const receipt=evidence.receipt;
 if(!receipt.datasetValidation.valid||!receipt.datasetValidation.complete)throw Error('Complete valid original dataset receipt required');
 const first=new Map<string,string>();
 const conflicts:Array<Readonly<{identity:Readonly<{module:string;id:string}>;sourceInstanceId:string;targetInstanceId:string;firstInstanceId:string;parallelInstanceId:string}>>=[];
 for(const occurrence of receipt.relationships){
  const key=JSON.stringify([occurrence.identity.module,occurrence.identity.id,occurrence.sourceInstanceId,occurrence.targetInstanceId]);
  const prior=first.get(key);
  if(prior===undefined)first.set(key,occurrence.instanceId);
  else conflicts.push(Object.freeze({identity:Object.freeze({...occurrence.identity}),sourceInstanceId:occurrence.sourceInstanceId,
   targetInstanceId:occurrence.targetInstanceId,firstInstanceId:prior,parallelInstanceId:occurrence.instanceId}));
 }
 return Object.freeze({scope:'original_supplied_dataset_endpoint_uniqueness_only' as const,
  documentIndex,sourceArtifact:evidence.sourceArtifact,producer:evidence.producer,
  endpointUniqueWithinSuppliedDataset:conflicts.length===0,conflicts:Object.freeze(conflicts),
  nativePopulationQualified:false as const,physicalAdmissionQualified:false as const});
}
