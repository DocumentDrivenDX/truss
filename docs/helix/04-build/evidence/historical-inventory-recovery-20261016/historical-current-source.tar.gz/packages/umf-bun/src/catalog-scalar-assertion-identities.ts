/** Closed original0.7/0.8 scalar-family inventory rule; no native value-domain claim. */
import {createHash} from 'node:crypto';
import {requireOriginalCatalogPreparation,type createCatalogInputPreparation} from './catalog-input';
import {requireOriginalAssertionSourceOccurrences,type collectOriginalAssertionSourceOccurrences} from './catalog-assertion-source-occurrences';
type Prepared=ReturnType<Awaited<ReturnType<typeof createCatalogInputPreparation>>['prepare']>;
type Census=ReturnType<typeof collectOriginalAssertionSourceOccurrences>;
const knownFamilies=['boolean','integer','decimal','float','string','binary','date','time','timestamp'] as const;
export function collectCatalogScalarAssertionIdentities(prepared:Prepared,census:Census){
 requireOriginalCatalogPreparation(prepared);requireOriginalAssertionSourceOccurrences(census,prepared);
 const manifestBytes=Buffer.from(JSON.stringify({interfaceVersion:'truss-original-scalar-family/0.2.0',
  producer:{mode:'record',profile:prepared.umfProfile},sourceVersions:['0.7.0','0.8.0'],
  governingSurface:'spec/core/field-document.schema.json#/$defs/scalarType; src/model/types.ts SCALAR_TYPES',
  selector:'direct scalarType member of original module element with kind field',knownFamilies,
  unknown:'nonempty unknown scalar token is an opaque asserted family; none/opaque',
  absence:'no authored scalarType creates no assertion',descendants:'scalar token only; no parent-prefix coverage',
  evidence:'one source validation artifact per document; entries reference its digest',maxEvidenceArtifactUtf8Bytes:4194304,
  domain:'basic value family only; native ranges/precision/encoding/temporal semantics unqualified'}));
 const manifest=Object.freeze({identity:'truss.original-scalar-family/0.2.0',bytesBase64:manifestBytes.toString('base64'),sha256:createHash('sha256').update(manifestBytes).digest('hex')});
 const profile=Object.freeze({identity:'truss-original-scalar-family',version:'0.2.0',sha256:manifest.sha256});
 const entries=[];
 const validationEvidence=new Map<number,Readonly<{identity:string;bytesBase64:string;sha256:string}>>();let retainedEvidenceBytes=0;
 function artifact(identity:string,bytes:Buffer){
  const result=Object.freeze({identity,bytesBase64:bytes.toString('base64'),sha256:createHash('sha256').update(bytes).digest('hex')});
  retainedEvidenceBytes+=Buffer.byteLength(JSON.stringify(result),'utf8');
  if(retainedEvidenceBytes>4194304)throw Error('Scalar assertion evidence capacity exceeded');
  return result;
 }
 for(const occurrence of census.occurrences){
  if(!/^\/modules\/(0|[1-9][0-9]*)\/elements\/(0|[1-9][0-9]*)\/scalarType$/.test(occurrence.sourcePointer))continue;
  const document=prepared.documents[occurrence.documentIndex]!;
  if(!['0.7.0','0.8.0'].includes(document.umfVersion))continue;
  const parts=occurrence.sourcePointer.split('/'),module=document.interpretation.source.modules[Number(parts[2])],element=module?.elements[Number(parts[4])];
  if(element?.kind!=='field')continue;
  if(typeof occurrence.value!=='string'||!occurrence.value||occurrence.owner.moduleId!==module.id||!document.interpretation.sourceValidation.valid)throw Error('Original validated scalar family required');
  const known=(knownFamilies as readonly string[]).includes(occurrence.value);
  let validation=validationEvidence.get(occurrence.documentIndex);
  if(!validation){
   validation=artifact('truss.original-scalar-validation/'+occurrence.documentIndex,Buffer.from(JSON.stringify({producer:prepared.umfProfile,documentId:occurrence.documentId,contentSha256:occurrence.definitionPin,basis:'original',sourceValidation:document.interpretation.sourceValidation})));
   validationEvidence.set(occurrence.documentIndex,validation);
  }
  const evidenceBytes=Buffer.from(JSON.stringify({profile,producer:prepared.umfProfile,documentId:occurrence.documentId,
   contentSha256:occurrence.definitionPin,basis:'original',sourcePointer:occurrence.sourcePointer,
   scalarType:occurrence.value,validationEvidenceSha256:validation.sha256}));
  const ownerEvidence=artifact('truss.original-scalar-family/'+occurrence.documentIndex+'/'+parts[2]+'/'+parts[4],evidenceBytes);
  entries.push(Object.freeze({assertion:Object.freeze({sourceKind:'umf_document' as const,
   owner:Object.freeze({documentId:occurrence.documentId,moduleId:module.id}),definitionPin:occurrence.definitionPin,
   sourcePointer:occurrence.sourcePointer,kind:'source' as const,sourceIdentityProfile:profile}),
   source:prepared.original.input.documents[occurrence.documentIndex]!.artifact,
   ruleName:'core.scalarType',ruleNameOrigin:'profile_generated' as const,enforcement:'none' as const,
   reason:known?'unqualified' as const:'opaque' as const,ownerEvidence}));
 }
 return Object.freeze({profile,manifest,entries:Object.freeze(entries),validationEvidence:Object.freeze([...validationEvidence.values()]),retainedEvidenceBytes,complete:false as const,
  scope:'original0.7/0.8_scalar_family_source_identities_only' as const});
}
