-- Internal visible-row inventory prerequisite, never authenticated population coverage.
-- SECURITY INVOKER preserves caller visibility. Source/cut authority and full
-- property collection remain required. Capture each visibility predicate once.
CREATE FUNCTION truss.runtime_collect_visible_dataset_owners()
RETURNS TABLE(owner_kind text,owner_id text,discriminator_id text,source_id text,source_type text,target_id text,target_type text)
LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$
DECLARE objects jsonb; edges jsonb;
BEGIN
  -- Only fixed-width native IDs enter bounded local buffers. Never retain props.
  SELECT coalesce(jsonb_agg(jsonb_build_array(o.id::text,o.type_id::text)),'[]'::jsonb) INTO objects
    FROM (SELECT x.id,x.type_id FROM truss.object x LIMIT 1001) o;
  SELECT coalesce(jsonb_agg(jsonb_build_array(e.id::text,e.rel_type_id::text,e.source_id::text,e.source_type::text,e.target_id::text,e.target_type::text)),'[]'::jsonb) INTO edges
    FROM (SELECT x.id,x.rel_type_id,x.source_id,x.source_type,x.target_id,x.target_type FROM truss.edge x LIMIT 10001) e;
  IF jsonb_array_length(objects)>1000 OR jsonb_array_length(edges)>10000 THEN
    RAISE EXCEPTION 'visible dataset owner capacity exceeded' USING ERRCODE='54000';
  END IF;
  RETURN QUERY
    SELECT 'object'::text,v->>0,v->>1,NULL::text,NULL::text,NULL::text,NULL::text FROM jsonb_array_elements(objects) v
    UNION ALL
    SELECT 'edge'::text,v->>0,v->>1,v->>2,v->>3,v->>4,v->>5 FROM jsonb_array_elements(edges) v;
END;
$$;
REVOKE ALL ON FUNCTION truss.runtime_collect_visible_dataset_owners() FROM PUBLIC;
