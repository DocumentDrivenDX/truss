-- Candidate integrity prerequisite: refuse RLS filtering rather than bypass it.
-- Still requires authenticated cut, installation, source and property custody.
CREATE FUNCTION truss.runtime_collect_unfiltered_dataset_owners()
RETURNS TABLE(owner_kind text,owner_id text,discriminator_id text,source_id text,source_type text,target_id text,target_type text)
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path=pg_catalog,pg_temp SET row_security=off
AS $$ SELECT * FROM truss.runtime_collect_visible_dataset_owners() $$;
REVOKE ALL ON FUNCTION truss.runtime_collect_unfiltered_dataset_owners() FROM PUBLIC;
