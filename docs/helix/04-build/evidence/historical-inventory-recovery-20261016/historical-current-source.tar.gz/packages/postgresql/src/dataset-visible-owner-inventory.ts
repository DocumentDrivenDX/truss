/** Decode visible owner wire data only; no authority, cut or completeness grant. */
import {decodeVisibleOwnerInventoryJson} from './acceptance-json';
export interface VisibleDatasetOwner {owner_kind:'object'|'edge';owner_id:string;discriminator_id:string;source_id:string|null;source_type:string|null;target_id:string|null;target_type:string|null}
const fields=['owner_kind','owner_id','discriminator_id','source_id','source_type','target_id','target_type'].sort();
const fail=():never=>{throw Error('TRUSS_VISIBLE_DATASET_OWNER_WIRE');};
function integer(value:unknown,bits:32|64):string{
 if(typeof value!=='string'||value.length>20||!/^(0|-?[1-9][0-9]*)$/.test(value))return fail();
 const n=BigInt(value),bound=1n<<BigInt(bits-1);if(n< -bound||n>=bound)return fail();return value;
}
export function decodeVisibleDatasetOwners(originalText:string){
 if(typeof originalText!=='string'||originalText.length>2097152||new TextEncoder().encode(originalText).length>2097152)return fail();
 let parsed:unknown;try{parsed=decodeVisibleOwnerInventoryJson(new TextEncoder().encode(originalText));}catch{return fail();}
 if(!Array.isArray(parsed)||parsed.length>11000)return fail();
 let objects=0,edges=0;const identities=new Set<string>(),edgeIds=new Set<string>();
 const rows=parsed.map((row:unknown)=>{
  if(!row||typeof row!=='object'||Array.isArray(row)||JSON.stringify(Object.keys(row).sort())!==JSON.stringify(fields))return fail();
  const r=row as Record<string,unknown>;if(r.owner_kind!=='object'&&r.owner_kind!=='edge')return fail();
  const owner_id=integer(r.owner_id,64),discriminator_id=integer(r.discriminator_id,32);
  const identity=JSON.stringify([r.owner_kind,discriminator_id,owner_id]);if(identities.has(identity))return fail();identities.add(identity);
  let source_id:string|null=null,source_type:string|null=null,target_id:string|null=null,target_type:string|null=null;
  if(r.owner_kind==='object'){
   if(++objects>1000||[r.source_id,r.source_type,r.target_id,r.target_type].some(v=>v!==null))return fail();
  }else{
   if(++edges>10000||edgeIds.has(owner_id))return fail();edgeIds.add(owner_id);
   source_id=integer(r.source_id,64);source_type=integer(r.source_type,32);target_id=integer(r.target_id,64);target_type=integer(r.target_type,32);
  }
  return Object.freeze({owner_kind:r.owner_kind,owner_id,discriminator_id,source_id,source_type,target_id,target_type}) as Readonly<VisibleDatasetOwner>;
 });
 // Dangling or hidden endpoints stay visible; do not infer integrity from parsing.
 return Object.freeze({originalText,rows:Object.freeze(rows),scope:'decoded_invoker_visible_owner_wire_only' as const});
}
