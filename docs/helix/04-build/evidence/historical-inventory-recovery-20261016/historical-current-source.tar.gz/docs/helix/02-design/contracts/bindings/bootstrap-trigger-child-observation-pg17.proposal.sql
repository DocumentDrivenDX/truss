-- Unexecuted PG17 original admitted specific child batch; unique nonnull 1D oid[] <=256.
-- Resolve exact original child rows, then collect complete original parent fanout.
-- Actual parent/cut/full coverage/transport/resource interpretation remains required.
SELECT x.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       x.oid::pg_catalog.text AS object_oid,
       x.tgrelid::pg_catalog.text AS relation_oid,
       x.tgargs IS NULL AS arguments_are_null,
       pg_catalog.encode(x.tgargs,'hex') AS arguments_hex,
       pg_catalog.octet_length(x.tgargs)::pg_catalog.text AS argument_bytes,
       x.tgqual::pg_catalog.text AS when_native_tree,
       pg_catalog.pg_get_triggerdef(x.oid,false) AS definition_sql,
       x.tgattr::pg_catalog.text AS tgattr_native_vector_text,
       pg_catalog.array_dims(x.tgattr) AS tgattr_native_vector_dimensions,
       pg_catalog.to_jsonb(x)::pg_catalog.text AS original_catalog_row_json
FROM pg_catalog.pg_trigger AS x
WHERE x.oid = ANY($1::pg_catalog.oid[])
ORDER BY x.oid;
