-- CONTRACT-001/006 candidate PostgreSQL 17; unapplied and unqualified.
-- Fixed original administrative receipt home; protected head-serialized writer required.
CREATE SEQUENCE truss.migration_receipt_row_seq AS bigint
  MINVALUE 1 MAXVALUE 9223372036854775807 START WITH 1 NO CYCLE;
CREATE TABLE truss.key_migration_receipt (
  storage_row_id bigint PRIMARY KEY DEFAULT nextval('truss.migration_receipt_row_seq'),
  installation_id_utf8 bytea NOT NULL CHECK (octet_length(installation_id_utf8) > 0),
  source_epoch_utf8 bytea NOT NULL CHECK (octet_length(source_epoch_utf8) > 0),
  migration_attempt_id_utf8 bytea NOT NULL CHECK (octet_length(migration_attempt_id_utf8) > 0),
  original_request_bytes bytea NOT NULL CHECK (octet_length(original_request_bytes) > 0),
  original_attempt_bytes bytea NOT NULL CHECK (octet_length(original_attempt_bytes) > 0),
  receipt_bytes bytea NOT NULL CHECK (octet_length(receipt_bytes) > 0),
  prior_generation bigint NOT NULL CHECK (prior_generation >= 0),
  resulting_generation bigint NOT NULL CHECK (resulting_generation >= 0),
  installation_sha256 bytea GENERATED ALWAYS AS (pg_catalog.sha256(installation_id_utf8)) STORED,
  epoch_sha256 bytea GENERATED ALWAYS AS (pg_catalog.sha256(source_epoch_utf8)) STORED,
  attempt_sha256 bytea GENERATED ALWAYS AS (pg_catalog.sha256(migration_attempt_id_utf8)) STORED,
  receipt_sha256 bytea GENERATED ALWAYS AS (pg_catalog.sha256(receipt_bytes)) STORED,
  CONSTRAINT key_migration_receipt_storage_positive CHECK (storage_row_id > 0),
  CONSTRAINT key_migration_receipt_generation_step CHECK (resulting_generation - prior_generation = 1)
);
-- Fixed-size nonunique routing; complete original identity byte comparison is mandatory.
CREATE INDEX key_migration_receipt_route ON truss.key_migration_receipt
 (installation_sha256, epoch_sha256, attempt_sha256, storage_row_id);
-- No digest-only unique identity; no ordinary UPDATE/DELETE/TRUNCATE/sequence privilege.
-- Exact privileged insert/immutability/recovery/retention/finalizer/archive profiles remain open.
