-- Unexecuted PG17 original admitted pg_class batch; unique nonnull 1D oid[] <=256.
-- No namespace/name/state filters; full original cut/fanout/resources require admission.
SELECT i.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       i.inhrelid::pg_catalog.text AS child_relation_oid,
       i.inhparent::pg_catalog.text AS parent_relation_oid,
       i.inhseqno::pg_catalog.text AS parent_ordinal,
       pg_catalog.to_jsonb(i)::pg_catalog.text AS original_catalog_row_json
FROM pg_catalog.pg_inherits AS i
WHERE i.inhrelid = ANY($1::pg_catalog.oid[])
   OR i.inhparent = ANY($1::pg_catalog.oid[])
ORDER BY i.inhrelid, i.inhseqno, i.inhparent;
