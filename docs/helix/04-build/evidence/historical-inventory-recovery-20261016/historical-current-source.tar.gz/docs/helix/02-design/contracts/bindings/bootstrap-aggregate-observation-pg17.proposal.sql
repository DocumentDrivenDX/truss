-- Unexecuted aggregate adjunct lookup; admitted unique original pg_proc oid[] <=256.
SELECT a.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       a.aggfnoid::pg_catalog.oid::pg_catalog.text AS aggfnoid_oid,
       a.aggtransfn::pg_catalog.oid::pg_catalog.text AS aggtransfn_oid,
       a.aggfinalfn::pg_catalog.oid::pg_catalog.text AS aggfinalfn_oid,
       a.aggcombinefn::pg_catalog.oid::pg_catalog.text AS aggcombinefn_oid,
       a.aggserialfn::pg_catalog.oid::pg_catalog.text AS aggserialfn_oid,
       a.aggdeserialfn::pg_catalog.oid::pg_catalog.text AS aggdeserialfn_oid,
       a.aggmtransfn::pg_catalog.oid::pg_catalog.text AS aggmtransfn_oid,
       a.aggminvtransfn::pg_catalog.oid::pg_catalog.text AS aggminvtransfn_oid,
       a.aggmfinalfn::pg_catalog.oid::pg_catalog.text AS aggmfinalfn_oid,
       pg_catalog.to_jsonb(a)::pg_catalog.text AS original_catalog_row_json
FROM pg_catalog.pg_aggregate AS a
WHERE a.aggfnoid::pg_catalog.oid = ANY ($1::pg_catalog.oid[])
ORDER BY a.aggfnoid::pg_catalog.oid;
