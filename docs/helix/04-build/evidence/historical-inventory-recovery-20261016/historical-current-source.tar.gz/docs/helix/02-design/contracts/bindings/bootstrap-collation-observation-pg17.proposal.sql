-- Unexecuted PostgreSQL 17 raw collation observation; $1 is admitted namespace OID.
SELECT x.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       x.oid::pg_catalog.text AS object_oid,
       x.collnamespace::pg_catalog.text AS namespace_oid,
       pg_catalog.to_jsonb(x)::pg_catalog.text AS original_catalog_row_json
FROM pg_catalog.pg_collation AS x
WHERE x.collnamespace = $1::pg_catalog.oid
ORDER BY x.oid;
