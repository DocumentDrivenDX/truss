-- Review fragment only, not an installer or existing-row migration.
-- Requires the selected complete event/carrier profile and metadata op admission.
-- Coarse constraints do not prove closed wrapper shape, decoded canonical bytes,
-- original semantics, origin authority, full sibling closure or native resources.
ALTER TABLE truss.journal ADD CONSTRAINT journal_complete_payload
 CHECK (old_value IS NULL AND new_value IS NOT NULL AND
   (pg_catalog.jsonb_typeof(new_value) = 'object' AND
    new_value ->> 'interfaceVersion' = 'truss-journal-exact-bytes/0.2.0-proposal' AND
    new_value ->> 'component' = 'event') IS TRUE);
ALTER TABLE truss.journal ADD CONSTRAINT journal_complete_origin
 CHECK ((pg_catalog.jsonb_typeof(origin) = 'object' AND
    origin ->> 'interfaceVersion' = 'truss-journal-exact-bytes/0.2.0-proposal' AND
    origin ->> 'component' = 'origin') IS TRUE);
ALTER TABLE truss.journal ADD CONSTRAINT journal_complete_property_mapping
 CHECK (((op IN ('update', 'transform', 'rebind') AND prop_id IS NOT NULL) OR
         (op IN ('create', 'delete', 'retain', 'metadata') AND prop_id IS NULL)) IS TRUE);
ALTER TABLE truss.journal ADD CONSTRAINT journal_complete_positive_identity
 CHECK (entity_id > 0 AND ver > 0 AND seq > 0);
