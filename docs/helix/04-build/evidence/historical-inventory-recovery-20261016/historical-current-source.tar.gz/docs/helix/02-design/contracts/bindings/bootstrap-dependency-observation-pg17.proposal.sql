-- Raw pg_depend frontier proposal, not full native dependency qualification.
-- $1 oid[] catalog classes; $2 oid[] objects; $3 int4[] exact subobjects.
-- Admit nonnull equal-length one-dimensional arrays with no null elements first.
-- Every aligned tuple is an exact address; subobject zero is NOT a wildcard.
WITH frontier AS (
  SELECT f.classid, f.objid, f.objsubid
  FROM ROWS FROM (pg_catalog.unnest($1::pg_catalog.oid[]),
                  pg_catalog.unnest($2::pg_catalog.oid[]),
                  pg_catalog.unnest($3::pg_catalog.int4[]))
       AS f(classid, objid, objsubid)
)
SELECT d.classid::text AS dependent_class_oid,
       d.objid::text AS dependent_object_oid,
       d.objsubid::text AS dependent_subobject,
       d.refclassid::text AS referenced_class_oid,
       d.refobjid::text AS referenced_object_oid,
       d.refobjsubid::text AS referenced_subobject,
       d.deptype::text AS dependency_kind,
       pg_catalog.to_jsonb(d)::pg_catalog.text AS original_catalog_row_json
FROM pg_catalog.pg_depend AS d
WHERE EXISTS (
  SELECT 1 FROM frontier AS f
  WHERE (f.classid = d.classid AND f.objid = d.objid
         AND f.objsubid = d.objsubid)
     OR (f.classid = d.refclassid AND f.objid = d.refobjid
         AND f.objsubid = d.refobjsubid)
)
ORDER BY d.classid, d.objid, d.objsubid,
         d.refclassid, d.refobjid, d.refobjsubid, d.deptype;
-- Preserve each returned row; EXISTS avoids multiplication by duplicate roots.
-- No namespace restriction, LIMIT or dependency-type filtering hides closure.
