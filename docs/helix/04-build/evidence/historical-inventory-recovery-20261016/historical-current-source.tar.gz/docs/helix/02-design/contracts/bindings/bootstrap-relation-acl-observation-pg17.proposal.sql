-- Unexecuted PG17 relation/sequence ACL expansion; original pg_class oid[] <=256.
-- Unique nonnull one-dimensional original object/subobject-zero batch required.
-- Unsupported kinds retained explicitly, never interpreted as empty privileges.
SELECT c.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       c.oid::pg_catalog.text AS object_oid,
       c.relnamespace::pg_catalog.text AS namespace_oid,
       c.relowner::pg_catalog.text AS owner_oid,
       c.relkind::pg_catalog.text AS relation_kind,
       c.relkind IN ('r','p','v','m','f','S') AS supported_acl_kind,
       c.relacl IS NULL AS original_acl_is_null,
       c.relacl::pg_catalog.text AS original_acl_native_text,
       pg_catalog.array_dims(c.relacl) AS original_acl_native_dimensions,
       a.grantor IS NOT NULL AS has_expanded_grant,
       a.grantor::pg_catalog.text AS grantor_oid,
       a.grantee::pg_catalog.text AS grantee_oid,
       a.privilege_type, a.is_grantable
FROM pg_catalog.pg_class AS c
LEFT JOIN LATERAL pg_catalog.aclexplode(
 CASE WHEN c.relkind IN ('r','p','v','m','f') THEN
   COALESCE(c.relacl,pg_catalog.acldefault('r'::pg_catalog."char",c.relowner))
 WHEN c.relkind = 'S' THEN
   COALESCE(c.relacl,pg_catalog.acldefault('s'::pg_catalog."char",c.relowner))
 ELSE NULL::pg_catalog.aclitem[] END) AS a ON true
WHERE c.oid = ANY($1::pg_catalog.oid[])
ORDER BY c.oid,a.grantor,a.grantee,a.privilege_type,a.is_grantable;
