-- Unadopted CONTRACT-001 row-home presence/tree fragment, NOT an installer.
-- Baseline layout 0.2 unchanged. Missing typed payload stores/guards mean incomplete.
-- These two additional candidate unique constraints enable exact owner FKs.
ALTER TABLE truss.prop_def ADD CONSTRAINT prop_def_owner_property_row_home
  UNIQUE (type_id, prop_id);
ALTER TABLE truss.edge ADD CONSTRAINT edge_typed_identity_row_home
  UNIQUE (id, rel_type_id);

-- New allocator domain, not graph identity; native nonreset/nonreuse profile required.
CREATE SEQUENCE truss.row_home_id_seq AS bigint NO CYCLE;

CREATE TABLE truss.row_home_state (
  state_id bigint PRIMARY KEY DEFAULT nextval('truss.row_home_id_seq'),
  owner_kind text COLLATE pg_catalog."C" NOT NULL,
  object_id bigint,
  object_type_id int,
  edge_id bigint,
  relationship_type_id int,
  property_owner_type_id int NOT NULL,
  property_id int NOT NULL,
  root_node_id bigint NOT NULL,
  definition_bytes bytea NOT NULL,
  home_profile_bytes bytea NOT NULL,
  value_profile_bytes bytea NOT NULL,
  source_bytes bytea NOT NULL,
  CONSTRAINT row_home_state_positive_ids CHECK (state_id > 0 AND root_node_id > 0),
  CONSTRAINT row_home_state_kind CHECK (
    (owner_kind = 'object' AND object_id IS NOT NULL AND object_type_id IS NOT NULL
      AND edge_id IS NULL AND relationship_type_id IS NULL
      AND property_owner_type_id = object_type_id)
    OR (owner_kind = 'edge' AND edge_id IS NOT NULL AND relationship_type_id IS NOT NULL
      AND object_id IS NULL AND object_type_id IS NULL)),
  CONSTRAINT row_home_state_property_fk FOREIGN KEY (property_owner_type_id, property_id)
    REFERENCES truss.prop_def (type_id, prop_id),
  CONSTRAINT row_home_state_object_fk FOREIGN KEY (object_id, object_type_id)
    REFERENCES truss.object (id, type_id) ON DELETE CASCADE,
  CONSTRAINT row_home_state_edge_fk FOREIGN KEY (edge_id, relationship_type_id)
    REFERENCES truss.edge (id, rel_type_id) ON DELETE CASCADE,
  CONSTRAINT row_home_state_object_property UNIQUE (object_id, object_type_id, property_id),
  CONSTRAINT row_home_state_edge_property UNIQUE (edge_id, relationship_type_id, property_id),
  CONSTRAINT row_home_state_carriers_nonempty CHECK (
    octet_length(definition_bytes) > 0 AND octet_length(home_profile_bytes) > 0
    AND octet_length(value_profile_bytes) > 0 AND octet_length(source_bytes) > 0)
);

CREATE TABLE truss.row_home_node (
  state_id bigint NOT NULL REFERENCES truss.row_home_state (state_id) ON DELETE CASCADE,
  node_id bigint NOT NULL DEFAULT nextval('truss.row_home_id_seq'),
  parent_node_id bigint,
  slot_kind text COLLATE pg_catalog."C" NOT NULL,
  sequence_ordinal bigint,
  map_key text COLLATE pg_catalog."C",
  record_field_identity_bytes bytea,
  value_kind text COLLATE pg_catalog."C" NOT NULL,
  definition_bytes bytea NOT NULL,
  source_bytes bytea NOT NULL,
  CONSTRAINT row_home_node_pk PRIMARY KEY (state_id, node_id),
  CONSTRAINT row_home_node_id_unique UNIQUE (node_id),
  CONSTRAINT row_home_node_positive_ids CHECK (state_id > 0 AND node_id > 0
    AND (parent_node_id IS NULL OR parent_node_id > 0)),
  CONSTRAINT row_home_node_parent_fk FOREIGN KEY (state_id, parent_node_id)
    REFERENCES truss.row_home_node (state_id, node_id) ON DELETE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
  CONSTRAINT row_home_node_not_self_parent CHECK (parent_node_id IS DISTINCT FROM node_id),
  CONSTRAINT row_home_node_value_kind CHECK (
    value_kind IN ('scalar', 'null', 'sequence', 'map', 'record', 'structured')),
  CONSTRAINT row_home_node_slot CHECK (
    (slot_kind = 'root' AND parent_node_id IS NULL AND sequence_ordinal IS NULL
      AND map_key IS NULL AND record_field_identity_bytes IS NULL)
    OR (slot_kind = 'sequence' AND parent_node_id IS NOT NULL AND sequence_ordinal >= 0
      AND sequence_ordinal IS NOT NULL AND map_key IS NULL AND record_field_identity_bytes IS NULL)
    OR (slot_kind = 'map' AND parent_node_id IS NOT NULL AND map_key IS NOT NULL
      AND sequence_ordinal IS NULL AND record_field_identity_bytes IS NULL)
    OR (slot_kind = 'record' AND parent_node_id IS NOT NULL
      AND record_field_identity_bytes IS NOT NULL AND octet_length(record_field_identity_bytes) > 0
      AND sequence_ordinal IS NULL AND map_key IS NULL)),
  CONSTRAINT row_home_node_carriers_nonempty CHECK (
    octet_length(definition_bytes) > 0 AND octet_length(source_bytes) > 0)
);
ALTER TABLE truss.row_home_state ADD CONSTRAINT row_home_state_root_fk
  FOREIGN KEY (state_id, root_node_id) REFERENCES truss.row_home_node (state_id, node_id)
  DEFERRABLE INITIALLY DEFERRED;
CREATE UNIQUE INDEX row_home_one_root ON truss.row_home_node (state_id)
  WHERE parent_node_id IS NULL;
CREATE UNIQUE INDEX row_home_sequence_slot ON truss.row_home_node
  (state_id, parent_node_id, sequence_ordinal) WHERE slot_kind = 'sequence';
CREATE INDEX row_home_map_parent ON truss.row_home_node
  (state_id, parent_node_id) WHERE slot_kind = 'map';
-- Full map-key uniqueness requires bounded exact-byte guarded comparison too;
-- arbitrary authored map keys cannot be forced into a bounded B-tree entry.
-- Exact record identity byte uniqueness needs bounded full-byte guard/index design;
-- do not assume an unrestricted bytea B-tree can hold every qualified identity.
-- Edge property ownership is proven by the admitted association definition,
-- never by equality of relationship and property-owner IDs. The property FK
-- proves the property exists under its type, not that the edge owns that type.
-- Required finalizer: original association proves each edge/property owner;
-- root is actual parentless root; all nodes reachable/acyclic;
-- parent-kind matches slot, sequence contiguous, record fields exact/unique,
-- scalar/null/container payload cardinality and complete original carrier parity.
-- SQL alone does not enforce these cross-row guarantees or ordinary-writer custody.
