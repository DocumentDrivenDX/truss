-- Unexecuted PG17 relation rights; original role/relation arrays <=256.
-- Equal nonnull one-dimensional unique tuples; original native class/kind admitted.
WITH scope AS (
 SELECT f.role_oid,f.relation_oid
 FROM ROWS FROM (pg_catalog.unnest($1::pg_catalog.oid[]),
                 pg_catalog.unnest($2::pg_catalog.oid[])) AS f(role_oid,relation_oid)
)
SELECT r.oid::pg_catalog.text AS role_oid,
       c.oid::pg_catalog.text AS relation_oid,
       p.privilege,
       pg_catalog.has_table_privilege(r.oid,c.oid,p.privilege) AS has_privilege,
       pg_catalog.has_table_privilege(r.oid,c.oid,p.privilege || ' WITH GRANT OPTION') AS has_grant_option
FROM scope AS f
JOIN pg_catalog.pg_roles AS r ON r.oid = f.role_oid
JOIN pg_catalog.pg_class AS c ON c.oid = f.relation_oid
CROSS JOIN (VALUES ('SELECT'::pg_catalog.text),('INSERT'::pg_catalog.text),('UPDATE'::pg_catalog.text),('DELETE'::pg_catalog.text),('TRUNCATE'::pg_catalog.text),('REFERENCES'::pg_catalog.text),('TRIGGER'::pg_catalog.text),('MAINTAIN'::pg_catalog.text)) AS p(privilege)
WHERE c.relkind IN ('r','p','v','m','f')
ORDER BY r.oid,c.oid,p.privilege;
