-- Unexecuted truss-layout 0.2 private observation proposal; not a guard or repair.
-- All three statements use the SAME original admitted unique signed int4[]
-- relationship IDs (1D, lower bound 1, 1..256 members, no null members).
-- Original namespace/layout/catalog/cut/authority/held exclusion and native work
-- reservations precede dispatch. No source retirement or expected-edge filtering.
SELECT r.rel_type_id::pg_catalog.text AS relationship_id,
       r.module AS module_identity,
       r.rel_id AS authored_relationship_id,
       r.source_min::pg_catalog.text AS sources_per_target_min,
       r.source_max::pg_catalog.text AS sources_per_target_max,
       r.target_min::pg_catalog.text AS targets_per_source_min,
       r.target_max::pg_catalog.text AS targets_per_source_max,
       r.since_rev::pg_catalog.text AS definition_since_revision,
       r.doc_ord::pg_catalog.text AS definition_document_ordinal,
       r.retired_rev::pg_catalog.text AS retired_revision
FROM truss.rel_def AS r
WHERE r.rel_type_id = ANY($1::pg_catalog.int4[])
ORDER BY r.rel_type_id;

SELECT e.id::pg_catalog.text AS edge_id,
       e.rel_type_id::pg_catalog.text AS relationship_id,
       e.source_id::pg_catalog.text AS source_id,
       e.source_type::pg_catalog.text AS source_type,
       e.target_id::pg_catalog.text AS target_id,
       e.target_type::pg_catalog.text AS target_type,
       e.rev::pg_catalog.text AS edge_revision,
       e.ver::pg_catalog.text AS edge_version
FROM truss.edge AS e
WHERE e.rel_type_id = ANY($1::pg_catalog.int4[])
ORDER BY e.rel_type_id, e.id;

-- Include every marker naming selected relationships OR linked to a selected
-- canonical edge, even if its stored relationship/side/endpoint is wrong.
SELECT m.rel_type_id::pg_catalog.text AS marker_relationship_id,
       m.side::pg_catalog.text AS marker_side,
       m.endpoint_id::pg_catalog.text AS marker_endpoint_id,
       m.edge_id::pg_catalog.text AS marker_edge_id
FROM truss.edge_limit AS m
WHERE m.rel_type_id = ANY($1::pg_catalog.int4[])
   OR EXISTS (SELECT 1 FROM truss.edge AS e
              WHERE e.id = m.edge_id
                AND e.rel_type_id = ANY($1::pg_catalog.int4[]))
ORDER BY m.rel_type_id, m.side, m.endpoint_id, m.edge_id;
