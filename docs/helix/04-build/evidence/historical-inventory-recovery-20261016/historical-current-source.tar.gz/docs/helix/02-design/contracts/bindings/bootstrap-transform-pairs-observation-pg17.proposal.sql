-- Unexecuted original type/language pair lookup; equal-length nonnull 1D arrays.
-- <=256 unique ordered pairs; scalar repetition allowed, no Cartesian scope.
SELECT t.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       t.oid::pg_catalog.text AS object_oid,
       t.trftype::pg_catalog.text AS type_oid,
       t.trflang::pg_catalog.text AS language_oid,
       t.trffromsql::pg_catalog.oid::pg_catalog.text AS from_sql_routine_oid,
       t.trftosql::pg_catalog.oid::pg_catalog.text AS to_sql_routine_oid,
       pg_catalog.to_jsonb(t)::pg_catalog.text AS original_catalog_row_json
FROM pg_catalog.pg_transform AS t
WHERE EXISTS (
  SELECT 1 FROM pg_catalog.unnest($1::pg_catalog.oid[], $2::pg_catalog.oid[])
    AS q(type_oid, language_oid)
  WHERE q.type_oid = t.trftype AND q.language_oid = t.trflang
)
ORDER BY t.oid;
