-- Unadopted private original-current-transaction custody observations.
-- Execute separately under one qualified original transaction/exclusion/cut.
-- Registration-address order is collection order, never delivery order.
-- Timestamp text needs selected native settings/clock grammar; no freshness claim.

SELECT
  t.source_epoch,
  t.feed_profile,
  t.original_writer_xid::pg_catalog.text AS original_writer_xid,
  t.registration_counter::pg_catalog.text AS registration_counter,
  t.prerequisite_registration_counter::pg_catalog.text AS prerequisite_registration_counter,
  t.configuration_registration_counter::pg_catalog.text AS configuration_registration_counter,
  t.membership_generation::pg_catalog.text AS membership_generation,
  t.finalized_generation::pg_catalog.text AS finalized_generation,
  pg_catalog.encode(t.original_context_bytes, 'hex') AS original_context_bytes_hex,
  pg_catalog.encode(t.manifest_profile_bytes, 'hex') AS manifest_profile_bytes_hex,
  pg_catalog.encode(t.manifest_bytes, 'hex') AS manifest_bytes_hex,
  pg_catalog.encode(t.manifest_sha256, 'hex') AS manifest_sha256_hex
FROM truss.feed_tx AS t
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned();

SELECT
  t.source_epoch,
  t.feed_profile,
  t.original_writer_xid::pg_catalog.text AS original_writer_xid,
  t.registration_address::pg_catalog.text AS registration_address,
  t.delivery_ordinal::pg_catalog.text AS delivery_ordinal,
  t.fact_kind,
  t.original_write_at::pg_catalog.text AS original_write_at,
  pg_catalog.encode(t.original_fact_key_bytes, 'hex') AS original_fact_key_bytes_hex,
  pg_catalog.encode(t.original_fact_key_profile_bytes, 'hex') AS original_fact_key_profile_bytes_hex,
  pg_catalog.encode(t.original_payload_bytes, 'hex') AS original_payload_bytes_hex,
  pg_catalog.encode(t.original_payload_profile_bytes, 'hex') AS original_payload_profile_bytes_hex,
  pg_catalog.encode(t.original_payload_sha256, 'hex') AS original_payload_sha256_hex,
  pg_catalog.encode(t.original_owner_context_bytes, 'hex') AS original_owner_context_bytes_hex,
  pg_catalog.encode(t.original_fact_clock_bytes, 'hex') AS original_fact_clock_bytes_hex
FROM truss.feed_member AS t
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
ORDER BY t.registration_address;

SELECT
  t.source_epoch,
  t.feed_profile,
  t.original_writer_xid::pg_catalog.text AS original_writer_xid,
  t.prerequisite_address::pg_catalog.text AS prerequisite_address,
  t.original_revision::pg_catalog.text AS original_revision,
  pg_catalog.encode(t.original_artifact_identity_bytes, 'hex') AS original_artifact_identity_bytes_hex,
  pg_catalog.encode(t.original_definition_bytes, 'hex') AS original_definition_bytes_hex,
  pg_catalog.encode(t.original_definition_profile_bytes, 'hex') AS original_definition_profile_bytes_hex,
  pg_catalog.encode(t.original_definition_sha256, 'hex') AS original_definition_sha256_hex,
  pg_catalog.encode(t.original_owner_context_bytes, 'hex') AS original_owner_context_bytes_hex
FROM truss.feed_prerequisite AS t
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
ORDER BY t.prerequisite_address;

SELECT
  t.source_epoch,
  t.feed_profile,
  t.original_writer_xid::pg_catalog.text AS original_writer_xid,
  t.configuration_address::pg_catalog.text AS configuration_address,
  t.original_configuration_generation::pg_catalog.text AS original_configuration_generation,
  pg_catalog.encode(t.original_installation_identity_bytes, 'hex') AS original_installation_identity_bytes_hex,
  pg_catalog.encode(t.original_configuration_profile_bytes, 'hex') AS original_configuration_profile_bytes_hex,
  pg_catalog.encode(t.original_configuration_bytes, 'hex') AS original_configuration_bytes_hex,
  pg_catalog.encode(t.original_producer_inventory_bytes, 'hex') AS original_producer_inventory_bytes_hex,
  pg_catalog.encode(t.original_configuration_sha256, 'hex') AS original_configuration_sha256_hex,
  pg_catalog.encode(t.original_owner_context_bytes, 'hex') AS original_owner_context_bytes_hex
FROM truss.feed_configuration_prerequisite AS t
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
ORDER BY t.configuration_address;
