-- Unexecuted original pg_attrdef address lookup; unique nonnull 1D oid[] <=256.
-- Original relation/attribute and expression meaning must be independently admitted.
SELECT d.tableoid::pg_catalog.oid::pg_catalog.text AS catalog_class_oid,
       d.oid::pg_catalog.text AS object_oid,
       d.adrelid::pg_catalog.text AS relation_oid,
       d.adnum::pg_catalog.text AS ordinal,
       d.adbin::pg_catalog.text AS expression_native_tree,
       pg_catalog.pg_get_expr(d.adbin, d.adrelid, false) AS expression_sql,
       pg_catalog.to_jsonb(d)::pg_catalog.text AS original_default_row_json
FROM pg_catalog.pg_attrdef AS d
WHERE d.oid = ANY($1::pg_catalog.oid[])
ORDER BY d.oid;
