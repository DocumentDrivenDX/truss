-- Raw PG17 proposal. $1 admitted namespace. No expected-ID/status filtering.
SELECT c.oid::text AS index_oid, n.nspname AS index_schema,
       c.relname AS index_name, c.relkind::text AS relation_kind,
       i.indrelid::text AS table_oid, tn.nspname AS table_schema,
       t.relname AS table_name,
       i.indnatts::text AS total_attributes,
       i.indnkeyatts::text AS key_attributes,
       i.indisunique AS is_unique, i.indnullsnotdistinct AS nulls_not_distinct,
       i.indisprimary AS is_primary, i.indisexclusion AS is_exclusion,
       i.indimmediate AS is_immediate, i.indisvalid AS is_valid,
       i.indisready AS is_ready, i.indislive AS is_live,
       i.indcheckxmin AS check_xmin, i.indisclustered AS is_clustered,
       i.indisreplident AS is_replica_identity,
       i.indkey::text AS attribute_vector_display,
       pg_catalog.array_dims(i.indkey) AS indkey_native_dimensions,
       i.indcollation::text AS collation_vector_display,
       pg_catalog.array_dims(i.indcollation) AS indcollation_native_dimensions,
       i.indclass::text AS opclass_vector_display,
       pg_catalog.array_dims(i.indclass) AS indclass_native_dimensions,
       i.indoption::text AS option_vector_display,
       pg_catalog.array_dims(i.indoption) AS indoption_native_dimensions,
       i.indexprs::text AS expression_native_tree,
       i.indpred::text AS predicate_native_tree,
       pg_catalog.pg_get_indexdef(c.oid) AS definition_sql,
       pg_catalog.to_jsonb(i)::pg_catalog.text AS original_index_row_json,
       pg_catalog.to_jsonb(c)::pg_catalog.text AS original_relation_row_json
FROM pg_catalog.pg_index AS i
LEFT JOIN pg_catalog.pg_class AS c ON c.oid = i.indexrelid
LEFT JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
LEFT JOIN pg_catalog.pg_class AS t ON t.oid = i.indrelid
LEFT JOIN pg_catalog.pg_namespace AS tn ON tn.oid = t.relnamespace
WHERE n.nspname = $1::pg_catalog.text OR tn.nspname = $1::pg_catalog.text
ORDER BY i.indexrelid;
-- Compare against full relation enumeration; missing pg_index rows cannot vanish.
-- Arrays, trees and OIDs require selected decoders/resolvers; no native proof here.
