-- Unadopted internal finalization steps; no ordinary caller mutation permission.
-- Admit complete originals/resources and original native exclusion/savepoint first.
-- Parameter 3 is the independently captured native membership generation.
UPDATE truss.feed_tx AS t
SET finalized_generation = NULL,
    manifest_bytes = NULL,
    manifest_sha256 = NULL
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
  AND t.membership_generation = $3::pg_catalog.int8
RETURNING t.source_epoch, t.feed_profile,
  t.original_writer_xid::pg_catalog.text AS original_writer_xid,
  t.membership_generation::pg_catalog.text AS membership_generation,
  t.finalized_generation::pg_catalog.text AS finalized_generation,
  pg_catalog.encode(t.manifest_bytes, 'hex') AS manifest_bytes_hex,
  pg_catalog.encode(t.manifest_sha256, 'hex') AS manifest_sha256_hex;

-- Same original exclusion/savepoint; complete child membership, no supplied list.
UPDATE truss.feed_member AS m
SET delivery_ordinal = NULL
WHERE m.source_epoch = $1::pg_catalog.text
  AND m.feed_profile = $2::pg_catalog.text
  AND m.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
RETURNING m.source_epoch, m.feed_profile,
  m.original_writer_xid::pg_catalog.text AS original_writer_xid,
  m.registration_address::pg_catalog.text AS registration_address,
  m.delivery_ordinal::pg_catalog.text AS delivery_ordinal;
