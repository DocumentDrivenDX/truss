-- Unexecuted PG17 original pg_class OID batch; unique nonnull 1D array <=256.
-- Columns/indexes are complete parent-scoped fanout; retain system/dropped/status rows.
-- Exact parent/address/cut/grammar/resource admission is independent of source parsing.
SELECT c.tableoid::pg_catalog.oid::pg_catalog.text AS relation_catalog_class_oid,
       c.oid::text AS index_oid, n.nspname AS index_schema,
       c.relname AS index_name, c.relkind::text AS relation_kind,
       i.indrelid::text AS table_oid, tn.nspname AS table_schema,
       t.relname AS table_name,
       i.indnatts::text AS total_attributes,
       i.indnkeyatts::text AS key_attributes,
       i.indisunique AS is_unique, i.indnullsnotdistinct AS nulls_not_distinct,
       i.indisprimary AS is_primary, i.indisexclusion AS is_exclusion,
       i.indimmediate AS is_immediate, i.indisvalid AS is_valid,
       i.indisready AS is_ready, i.indislive AS is_live,
       i.indcheckxmin AS check_xmin, i.indisclustered AS is_clustered,
       i.indisreplident AS is_replica_identity,
       i.indkey::text AS attribute_vector_display,
       pg_catalog.array_dims(i.indkey) AS indkey_native_dimensions,
       i.indcollation::text AS collation_vector_display,
       pg_catalog.array_dims(i.indcollation) AS indcollation_native_dimensions,
       i.indclass::text AS opclass_vector_display,
       pg_catalog.array_dims(i.indclass) AS indclass_native_dimensions,
       i.indoption::text AS option_vector_display,
       pg_catalog.array_dims(i.indoption) AS indoption_native_dimensions,
       i.indexprs::text AS expression_native_tree,
       i.indpred::text AS predicate_native_tree,
       pg_catalog.pg_get_indexdef(c.oid) AS definition_sql,
       pg_catalog.to_jsonb(i)::pg_catalog.text AS original_index_row_json,
       pg_catalog.to_jsonb(c)::pg_catalog.text AS original_relation_row_json
FROM pg_catalog.pg_index AS i
LEFT JOIN pg_catalog.pg_class AS c ON c.oid = i.indexrelid
LEFT JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
LEFT JOIN pg_catalog.pg_class AS t ON t.oid = i.indrelid
LEFT JOIN pg_catalog.pg_namespace AS tn ON tn.oid = t.relnamespace
WHERE i.indexrelid = ANY($1::pg_catalog.oid[])
   OR i.indrelid = ANY($1::pg_catalog.oid[])
ORDER BY i.indexrelid;
