-- Unadopted protected operation custody; not public replay/feed storage.
CREATE TABLE truss.row_home_operation (
  original_writer_xid xid8 NOT NULL,
  operation_ordinal bigint NOT NULL,
  operation_kind text COLLATE pg_catalog."C" NOT NULL,
  phase text COLLATE pg_catalog."C" NOT NULL,
  effect_generation bigint NOT NULL,
  readiness_generation bigint,
  sealed_generation bigint,
  application_generation bigint,
  original_context_bytes bytea NOT NULL,
  original_definition_bytes bytea NOT NULL,
  original_input_bytes bytea NOT NULL,
  original_prestate_bytes bytea NOT NULL,
  admitted_candidate_bytes bytea NOT NULL,
  effect_obligation_bytes bytea NOT NULL,
  original_group_custody_bytes bytea NOT NULL,
  application_result_bytes bytea,
  CONSTRAINT row_home_operation_pk PRIMARY KEY (original_writer_xid, operation_ordinal),
  CONSTRAINT row_home_operation_identity CHECK (operation_ordinal >= 0),
  CONSTRAINT row_home_operation_kind CHECK
    (operation_kind IN ('mutation', 'import', 'catalog-transform', 'catalog-acceptance',
      'home-migration', 'administrative-repair')),
  CONSTRAINT row_home_operation_generation CHECK
    (effect_generation >= 0
      AND (readiness_generation IS NULL OR readiness_generation = effect_generation)
      AND (sealed_generation IS NULL OR sealed_generation = effect_generation)
      AND (application_generation IS NULL OR application_generation = effect_generation)),
  CONSTRAINT row_home_operation_phase CHECK (
    (phase = 'admitted' AND readiness_generation IS NULL AND sealed_generation IS NULL
      AND application_generation IS NULL AND application_result_bytes IS NULL)
    OR (phase = 'effects_ready' AND readiness_generation IS NOT NULL
      AND sealed_generation IS NULL AND application_generation IS NULL
      AND application_result_bytes IS NULL)
    OR (phase = 'row_sealed' AND readiness_generation IS NOT NULL
      AND sealed_generation IS NOT NULL AND application_generation IS NULL
      AND application_result_bytes IS NULL)
    OR (phase = 'application_finalized' AND readiness_generation IS NOT NULL
      AND sealed_generation IS NOT NULL AND application_generation IS NOT NULL
      AND application_result_bytes IS NOT NULL
      AND octet_length(application_result_bytes) > 0)),
  CONSTRAINT row_home_operation_originals CHECK
    (octet_length(original_context_bytes) > 0 AND octet_length(original_definition_bytes) > 0
      AND octet_length(original_input_bytes) > 0 AND octet_length(original_prestate_bytes) > 0
      AND octet_length(admitted_candidate_bytes) > 0 AND octet_length(effect_obligation_bytes) > 0
      AND octet_length(original_group_custody_bytes) > 0)
);
-- Actual xid/ordinal/context/generations captured by protected native procedures.
-- Phase labels/CHECKs cannot prove complete originals, effects, seals or results.
-- Empty/no-row-effect operation may finalize only with complete absence evidence.
-- No caller phase override, automatic request receipt, or artificial feed member.
-- Guard/grant/codec/retention/capacity/native inventory realization still missing.
