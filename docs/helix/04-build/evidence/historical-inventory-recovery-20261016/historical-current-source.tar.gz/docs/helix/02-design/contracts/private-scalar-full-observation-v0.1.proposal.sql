-- Design-only direct-reader scalar observation, not a Weft result ABI.
-- Requires selected complete owner/state/node visibility and original read cut.
-- $1 original positive state_id bigint; $2 original positive node_id bigint.
-- Missing row does not classify absent property, null or container.
-- LIMIT 2 detects duplicate identity; it does not prove complete tree coverage.
SELECT s.state_id::pg_catalog.text AS state_id,
       s.node_id::pg_catalog.text AS node_id,
       s.scalar_kind AS scalar_kind,
       s.text_value AS text_value,
       s.boolean_value::pg_catalog.text AS boolean_value,
       s.numeric_value::pg_catalog.text AS native_numeric_text,
       s.numeric_token AS original_numeric_token,
       pg_catalog.encode(s.binary_value, 'hex') AS binary_value_hex,
       s.temporal_text AS temporal_text,
       s.temporal_instant::pg_catalog.text AS temporal_instant_text,
       pg_catalog.encode(s.opaque_bytes, 'hex') AS opaque_bytes_hex,
       pg_catalog.encode(s.codec_definition_bytes, 'hex') AS codec_bytes_hex,
       pg_catalog.encode(s.original_source_bytes, 'hex') AS source_bytes_hex,
       pg_catalog.current_setting('DateStyle') AS metadata_date_style,
       pg_catalog.current_setting('TimeZone') AS metadata_time_zone
FROM truss.row_home_scalar AS s
WHERE s.state_id = $1::pg_catalog.int8
  AND s.node_id = $2::pg_catalog.int8
LIMIT 2;
