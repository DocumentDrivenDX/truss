-- Proposed PostgreSQL 17 raw role graph observation; source design only.
-- Run only through the admitted private administrative observer operation.
-- Not a writer-context capture, effective-privilege evaluator or certificate.
-- Both bounded prefixes and overflow flags belong to one statement snapshot.
-- Any overflow invalidates the entire graph; never normalize a prefix.
-- Native scan/work, transport allocation and administrative coherence remain
-- separately qualified. No password or arbitrary role configuration is read.
WITH roles AS MATERIALIZED (
  SELECT r.oid, r.rolname, r.rolsuper, r.rolinherit, r.rolcreaterole,
         r.rolcreatedb, r.rolcanlogin, r.rolreplication, r.rolbypassrls
  FROM pg_catalog.pg_roles AS r
  ORDER BY r.oid
  LIMIT 10001
), memberships AS MATERIALIZED (
  SELECT m.oid, m.roleid, m.member, m.grantor, m.admin_option,
         m.inherit_option, m.set_option
  FROM pg_catalog.pg_auth_members AS m
  ORDER BY m.oid
  LIMIT 100001
)
SELECT pg_catalog.jsonb_build_object(
  'observationProfile', 'truss-installed-role-graph/0.1.0',
  'serverVersionNumber', pg_catalog.current_setting('server_version_num'),
  'serverEncoding', pg_catalog.current_setting('server_encoding'),
  'databaseName', pg_catalog.current_database(),
  'observerSessionRole', session_user::text,
  'observerCurrentRole', current_user::text,
  'observerRoleSetting', pg_catalog.current_setting('role'),
  'rolesOverflow', (SELECT pg_catalog.count(*) > 10000 FROM roles),
  'membershipsOverflow', (SELECT pg_catalog.count(*) > 100000 FROM memberships),
  'roles', COALESCE((
    SELECT pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
      'nativeOid', r.oid::text,
      'name', r.rolname::text,
      'superuser', r.rolsuper,
      'inherit', r.rolinherit,
      'createRole', r.rolcreaterole,
      'createDatabase', r.rolcreatedb,
      'canLogin', r.rolcanlogin,
      'replication', r.rolreplication,
      'bypassRls', r.rolbypassrls
    ) ORDER BY r.oid) FROM roles AS r
  ), '[]'::pg_catalog.jsonb),
  'memberships', COALESCE((
    SELECT pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
      'nativeOid', m.oid::text,
      'roleOid', m.roleid::text,
      'memberOid', m.member::text,
      'grantorOid', m.grantor::text,
      'adminOption', m.admin_option,
      'inheritOption', m.inherit_option,
      'setOption', m.set_option
    ) ORDER BY m.oid) FROM memberships AS m
  ), '[]'::pg_catalog.jsonb)
)::text AS role_graph_text;
