-- Protected closure insertion candidates, not synthetic semantic members.
-- Complete originals/identity/resources and confirmed family counter reservation first.
-- Reservation and insertion share one original exclusion/operation savepoint.
-- feed_prerequisite: context/profile slots 11/12 are statement-local.
INSERT INTO truss.feed_prerequisite AS p (
  source_epoch, feed_profile, original_writer_xid, prerequisite_address, original_revision, original_artifact_identity_bytes, original_definition_bytes, original_definition_profile_bytes, original_definition_sha256, original_owner_context_bytes)
SELECT t.source_epoch, t.feed_profile, t.original_writer_xid, $3::pg_catalog.int8, $5::pg_catalog.int8, $6::pg_catalog.bytea, $7::pg_catalog.bytea, $8::pg_catalog.bytea, $9::pg_catalog.bytea, $10::pg_catalog.bytea
FROM truss.feed_tx AS t
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
  AND t.prerequisite_registration_counter = $3::pg_catalog.int8
  AND t.membership_generation = $4::pg_catalog.int8
  AND t.original_context_bytes = $11::pg_catalog.bytea
  AND t.manifest_profile_bytes = $12::pg_catalog.bytea
  AND $3::pg_catalog.int8 > 0
  AND $4::pg_catalog.int8 > 0
RETURNING p.source_epoch,
  p.feed_profile,
  p.original_writer_xid::pg_catalog.text AS original_writer_xid,
  p.prerequisite_address::pg_catalog.text AS prerequisite_address,
  p.original_revision::pg_catalog.text AS original_revision,
  pg_catalog.encode(p.original_artifact_identity_bytes, 'hex') AS original_artifact_identity_bytes_hex,
  pg_catalog.encode(p.original_definition_bytes, 'hex') AS original_definition_bytes_hex,
  pg_catalog.encode(p.original_definition_profile_bytes, 'hex') AS original_definition_profile_bytes_hex,
  pg_catalog.encode(p.original_definition_sha256, 'hex') AS original_definition_sha256_hex,
  pg_catalog.encode(p.original_owner_context_bytes, 'hex') AS original_owner_context_bytes_hex;

-- feed_configuration_prerequisite: context/profile slots 12/13 are statement-local.
INSERT INTO truss.feed_configuration_prerequisite AS p (
  source_epoch, feed_profile, original_writer_xid, configuration_address, original_installation_identity_bytes, original_configuration_generation, original_configuration_profile_bytes, original_configuration_bytes, original_producer_inventory_bytes, original_configuration_sha256, original_owner_context_bytes)
SELECT t.source_epoch, t.feed_profile, t.original_writer_xid, $3::pg_catalog.int8, $5::pg_catalog.bytea, $6::pg_catalog.int8, $7::pg_catalog.bytea, $8::pg_catalog.bytea, $9::pg_catalog.bytea, $10::pg_catalog.bytea, $11::pg_catalog.bytea
FROM truss.feed_tx AS t
WHERE t.source_epoch = $1::pg_catalog.text
  AND t.feed_profile = $2::pg_catalog.text
  AND t.original_writer_xid = pg_catalog.pg_current_xact_id_if_assigned()
  AND t.configuration_registration_counter = $3::pg_catalog.int8
  AND t.membership_generation = $4::pg_catalog.int8
  AND t.original_context_bytes = $12::pg_catalog.bytea
  AND t.manifest_profile_bytes = $13::pg_catalog.bytea
  AND $3::pg_catalog.int8 > 0
  AND $4::pg_catalog.int8 > 0
RETURNING p.source_epoch,
  p.feed_profile,
  p.original_writer_xid::pg_catalog.text AS original_writer_xid,
  p.configuration_address::pg_catalog.text AS configuration_address,
  pg_catalog.encode(p.original_installation_identity_bytes, 'hex') AS original_installation_identity_bytes_hex,
  p.original_configuration_generation::pg_catalog.text AS original_configuration_generation,
  pg_catalog.encode(p.original_configuration_profile_bytes, 'hex') AS original_configuration_profile_bytes_hex,
  pg_catalog.encode(p.original_configuration_bytes, 'hex') AS original_configuration_bytes_hex,
  pg_catalog.encode(p.original_producer_inventory_bytes, 'hex') AS original_producer_inventory_bytes_hex,
  pg_catalog.encode(p.original_configuration_sha256, 'hex') AS original_configuration_sha256_hex,
  pg_catalog.encode(p.original_owner_context_bytes, 'hex') AS original_owner_context_bytes_hex;
