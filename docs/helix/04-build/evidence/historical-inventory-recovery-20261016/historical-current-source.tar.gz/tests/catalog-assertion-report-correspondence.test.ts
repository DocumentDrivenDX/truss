import {test,expect} from 'bun:test';
import {createCatalogInputPreparation} from '../packages/umf-bun/src/catalog-input';
import {loadUmfInventoryInspectionProducer} from '../packages/umf-bun/src/index';
import {createAcceptanceProfileResolver} from '../packages/umf-bun/src/acceptance-profiles';
import {collectCatalogReportPreparation} from '../packages/umf-bun/src/catalog-report-preparation';
import {prepareCatalogSourceReport} from '../packages/umf-bun/src/catalog-source-report-preparation';
import {collectOriginalAssertionReportCandidate,verifyOriginalAssertionReportCandidate} from '../packages/umf-bun/src/catalog-assertion-report-correspondence';
import {collectOriginalCompleteAssertionInventoryArtifact} from '../packages/umf-bun/src/catalog-complete-assertion-inventory';
import {createCatalogReportCorrespondence,createProposedCatalogReportCorrespondence} from '../packages/umf-bun/src/catalog-report-correspondence';
const record=process.env.TRUSS_UMF_PRODUCER,inventory=process.env.TRUSS_UMF_INVENTORY_PRODUCER,dependencies=process.env.TRUSS_UMF_DEPENDENCIES_PACKAGE;
if(!record||!inventory||!dependencies)throw Error('Original producers and dependencies required');
const preparation=await createCatalogInputPreparation(record,dependencies),loaded=await loadUmfInventoryInspectionProducer(inventory);
const base=(await Bun.file('docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json').json()).input;
const fixture=(await Bun.file('docs/helix/03-test/report-wire-untrusted.fixture.json').json()).report;
const profileBytes=new TextEncoder().encode('Test report byte custody only; no semantic profile authority');
const pin={identity:'report-byte-custody',version:'test',sha256:new Bun.CryptoHasher('sha256').update(profileBytes).digest('hex')};
const resolver=createAcceptanceProfileResolver([{role:'report',profile:pin,artifactIdentity:'report-bytes',bytes:profileBytes}]);
const wire=(value:unknown)=>new TextEncoder().encode(JSON.stringify(value));
const codecs=[await createCatalogReportCorrespondence(dependencies),await createProposedCatalogReportCorrespondence(dependencies)];
async function setup(){
 const source={umf:'0.8.0',id:'original',vocabularies:{},modules:[{id:'m',namespace:'',elements:[{id:'v',kind:'field',scalarType:'future-scalar',extensions:{}},{id:'w',kind:'field',scalarType:'string',extensions:{}}]}]};
 const bytes=wire(source),sha256=new Bun.CryptoHasher('sha256').update(bytes).digest('hex'),input=structuredClone(base);input.binding={state:'absent'};input.transforms=[];
 input.documents=[{documentId:source.id,documentRevision:'r1',artifact:{identity:'original',bytesBase64:Buffer.from(bytes).toString('base64'),sha256},umfProfile:preparation.umfProfile,ingress:{kind:'native'}}];
 const prepared=preparation.prepare(wire(input)),queries:string[]=[];
 // These are synthetic read observations, not native installation evidence.
 const connection={queries,unsafe:async(query:string)=>{queries.push(query);if(query.includes('runtime_collect_report_documents'))return [{doc_id:'original',doc_revision:'r1',content_sha256:sha256,ord:'0',writer_xid:'42',operation_ordinal:'0',effect_generation:'11'}];if(query.includes('runtime_collect_new_catalog_counts'))return [{types_added:'0',properties_added:'0',keys_added:'0',relationships_added:'0',endpoints_added:'0',elements_retired:'0',provisional_count:'0',writer_xid:'42',operation_ordinal:'0',effect_generation:'11'}];return []}};
 const basis=await collectCatalogReportPreparation(connection,prepared,'1',loaded.declarations,loaded.fields);
 if(!basis.assertionInventory)throw Error('Expected genuine closed inventory');
 const assertions=collectOriginalAssertionReportCandidate(prepared,basis.assertionInventory,'1',resolver,pin);
 const report={...structuredClone(fixture),reportProfile:pin,rev:'1',acceptedInput:prepared.original.input,documents:basis.documentBasis.documents,counts:basis.counts,provisional:basis.provisional,
  diagnostics:basis.validationEvidence.diagnostics,documentInterpretations:basis.validationEvidence.documentInterpretations,losses:basis.ingressBasis.losses,transformRegistrations:basis.ingressBasis.transformRegistrations,extensions:[],assertions:assertions.candidate};
 return {prepared,basis,assertions,report,connection};
}
function version(report:Record<string,unknown>,index:number){return index===0?report:{...report,interfaceVersion:'truss-acceptance-report/0.3.0-proposal',lifecycleProfile:pin,reactivations:[]};}
test('exact issued inventory bytes bind the complete assertion field under both wire versions',async()=>{
 const {prepared,basis,assertions,report,connection}=await setup(),inventory=basis.assertionInventory!;
 const expected=['/modules/0/elements/0/kind','/modules/0/elements/0/scalarType','/modules/0/elements/1/kind','/modules/0/elements/1/scalarType'].sort();
 expect(assertions.candidate.entries.map(row=>row.assertion.sourcePointer).sort()).toEqual(expected);
 expect(assertions.candidate.entries.every(row=>row.enforcement==='none')).toBe(true);
 expect(assertions.candidate.entries.filter(row=>row.enforcement==='none'&&row.reason==='opaque').length).toBe(1);
 const artifact=collectOriginalCompleteAssertionInventoryArtifact(inventory,prepared);expect(artifact).toBe(assertions.inventoryArtifact);
 expect(Buffer.from(artifact.bytesBase64,'base64')).toEqual(Buffer.from(JSON.stringify(inventory)));
 expect(artifact.sha256).toBe(new Bun.CryptoHasher('sha256').update(Buffer.from(artifact.bytesBase64,'base64')).digest('hex'));expect(assertions.candidate.assertionInventorySha256).toBe(artifact.sha256);
 for(let index=0;index<codecs.length;index++){
  const bytes=wire(version(report,index)),saved=Buffer.from(bytes),unsafe=connection.unsafe;
  connection.unsafe=async(query:string)=>{bytes.fill(0);return unsafe(query)};
  const result=await codecs[index]!.verifyWithRegisteredProfileAndAssertions(connection,prepared,basis,bytes,resolver,pin,assertions);
  connection.unsafe=unsafe;
  expect(result.verifiedFields.length).toBe(12);expect(result.verifiedFields).toContain('assertions');expect(result.scope).toBe('twelve_original_fields_with_assertion_candidate_only');expect(Buffer.from(result.originalUtf8Hex,'hex')).toEqual(saved);
 }
});
test('whole expected assertion correspondence rejects omission, duplication, identity substitution and fabricated enforcement before native reads',async()=>{
 const {prepared,basis,assertions,report,connection}=await setup();
 const changes:((value:any)=>void)[]=[value=>value.entries.pop(),value=>value.entries.push(value.entries[0]),value=>value.entries.reverse(),value=>value.entries[0].assertion.owner.documentId='other',value=>value.entries[0].assertion.definitionPin='0'.repeat(64),value=>value.entries[0].assertion.sourcePointer='/modules/0/elements/1/kind',value=>value.entries[0].source.identity='substituted',value=>value.entries[0].ruleName='fabricated',value=>value.assertionInventorySha256='0'.repeat(64),value=>value.catalogRevision='2',value=>value.layoutProfile.identity='other',value=>value.reportProfile.identity='other',value=>value.entries[0].reason='unsupported',value=>{const row=value.entries[0];delete row.reason;Object.assign(row,{enforcement:'database',procedureProfile:pin,qualificationReceiptSha256:'1'.repeat(64),installedInventorySha256:'2'.repeat(64),currentObservationEvidenceSha256:'3'.repeat(64),qualifiedWritePaths:['ordinary']})},value=>{const row=value.entries[0];delete row.reason;Object.assign(row,{enforcement:'engine',validatorProfile:pin,qualificationReceiptSha256:'1'.repeat(64)})}];
 for(const change of changes)for(let index=0;index<codecs.length;index++){
  const changed=structuredClone(assertions.candidate);change(changed);connection.queries.length=0;
  await expect(codecs[index]!.verifyWithRegisteredProfileAndAssertions(connection,prepared,basis,wire(version({...report,assertions:changed},index)),resolver,pin,assertions)).rejects.toThrow('assertion report correspondence');expect(connection.queries).toEqual([]);
 }
});
test('unissued or cross-preparation assertion candidates cannot enter report correspondence',async()=>{
 const first=await setup(),second=await setup();
 first.connection.queries.length=0;
 for(const candidate of [{...first.assertions},second.assertions])await expect(codecs[0]!.verifyWithRegisteredProfileAndAssertions(first.connection,first.prepared,first.basis,new Uint8Array(),resolver,pin,candidate)).rejects.toThrow('candidate custody');
 expect(first.connection.queries).toEqual([]);
 expect(()=>verifyOriginalAssertionReportCandidate(first.assertions,second.prepared,second.basis.assertionInventory!,first.assertions.candidate)).toThrow('candidate custody');
 expect(()=>collectOriginalCompleteAssertionInventoryArtifact({...first.basis.assertionInventory!},first.prepared)).toThrow('inventory custody');
 let coercions=0;
 for(const revision of ['0','01','2147483648',1,['1'],{toString(){coercions++;return '1'}}])expect(()=>collectOriginalAssertionReportCandidate(first.prepared,first.basis.assertionInventory!,revision as any,resolver,pin)).toThrow('positive catalog revision');expect(coercions).toBe(0);
});

test('direct assertion comparison rejects sparse, extra and accessor trees without invoking getters',async()=>{
 const {prepared,basis,assertions}=await setup(),inventory=basis.assertionInventory!;
 verifyOriginalAssertionReportCandidate(assertions,prepared,inventory,structuredClone(assertions.candidate));
 let getters=0,methods=0;
 const sparse={...structuredClone(assertions.candidate),entries:new Array(assertions.candidate.entries.length)};
 const extra=structuredClone(assertions.candidate);Object.defineProperty(extra.entries,'extra',{value:'unknown'});
 const accessor=structuredClone(assertions.candidate);Object.defineProperty(accessor.entries,'0',{get(){getters++;return assertions.candidate.entries[0]}});
 const objectAccessor=structuredClone(assertions.candidate);Object.defineProperty(objectAccessor,'reportProfile',{get(){getters++;return pin}});
 const symbol=structuredClone(assertions.candidate);Object.defineProperty(symbol,Symbol('unknown'),{value:'unknown'});
 const method=structuredClone(assertions.candidate);Object.defineProperty(method.entries,'every',{value(){methods++;return true}});
 const nonEnumerable=structuredClone(assertions.candidate);Object.defineProperty(nonEnumerable,'reportProfile',{enumerable:false});
 for(const report of [sparse,extra,accessor,objectAccessor,symbol,method,nonEnumerable])expect(()=>verifyOriginalAssertionReportCandidate(assertions,prepared,inventory,report)).toThrow('assertion report correspondence');
 expect(getters).toBe(0);expect(methods).toBe(0);
});

test('combined thirteen-field path requires original execution custody before wire parsing or native I/O',async()=>{
 const {prepared,basis,assertions,connection}=await setup();connection.queries.length=0;
 for(const codec of codecs)await expect(codec.verifyWithExecutionRegisteredProfileAndAssertions(connection,prepared,basis,new Uint8Array(),{candidate:fixture.originalExecution} as any,resolver,pin,assertions)).rejects.toThrow('execution report candidate custody');
 expect(connection.queries).toEqual([]);
});

test('report reuses the issued pre-effect source basis and rejects substituted custody before native reads',async()=>{
 const {prepared,connection}=await setup(),source=prepareCatalogSourceReport(prepared,loaded.declarations,loaded.fields);connection.queries.length=0;
 const basis=await collectCatalogReportPreparation(connection,prepared,'1',loaded.declarations,loaded.fields,source);
 expect(basis.assertionInventory).toBe(source.assertionInventory);expect(basis.ownerObservations).toBe(source.ownerObservations);expect(basis.validationEvidence).toBe(source.validationEvidence);
 connection.queries.length=0;
 await expect(collectCatalogReportPreparation(connection,prepared,'1',loaded.declarations,loaded.fields,{...source})).rejects.toThrow('source report preparation custody');
 await expect(collectCatalogReportPreparation(connection,prepared,'1',{...loaded.declarations},loaded.fields,source)).rejects.toThrow('source report preparation custody');
 await expect(collectCatalogReportPreparation(connection,prepared,'1',undefined as any,loaded.fields,source)).rejects.toThrow('source report preparation custody');
 await expect(collectCatalogReportPreparation(connection,prepared,'1',loaded.declarations,undefined as any,source)).rejects.toThrow('source report preparation custody');
 const other=await setup();connection.queries.length=0;
 await expect(collectCatalogReportPreparation(connection,prepared,'1',loaded.declarations,loaded.fields,prepareCatalogSourceReport(other.prepared,loaded.declarations,loaded.fields))).rejects.toThrow('source report preparation custody');expect(connection.queries).toEqual([]);
});
