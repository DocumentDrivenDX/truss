import {test,expect} from 'bun:test';
import {source,input} from './catalog-dataset-fixture';
import {loadUmfCompactDatasetProducer,loadUmfDatasetProducer,requireLoadedUmfCompactDatasetOwner} from '../packages/umf-bun/src/index';
const compactDirectory=process.env.TRUSS_UMF_COMPACT_DATASET_PRODUCER,fullDirectory=process.env.TRUSS_UMF_DATASET_PRODUCER;
if(!compactDirectory||!fullDirectory)throw Error('Original full and compact dataset producers required');
const compact=await loadUmfCompactDatasetProducer(compactDirectory),full=await loadUmfDatasetProducer(fullDirectory);
function expand(fragment:any,shared:any){const {sourceRef,...rest}=fragment;expect(sourceRef).toBe('#/source');expect(Object.hasOwn(fragment,'source')).toBe(false);return {...rest,source:shared};}
test('distinct compact owner preserves nonempty full logical results and original warnings',()=>{
 requireLoadedUmfCompactDatasetOwner(compact);expect(()=>requireLoadedUmfCompactDatasetOwner({...compact})).toThrow();expect(()=>requireLoadedUmfCompactDatasetOwner(full)).toThrow();
 const c=compact.validateCoreDatasetValuesCompact(source,input),f=full.validateCoreDatasetValues(source,input);
 expect(c.operation).toBe('validate-core-dataset-values-compact');expect(c.datasetValidation).toEqual(f.datasetValidation);expect(c.obligations).toEqual(f.obligations);expect(c.residuals).toEqual(f.residuals);
 expect(c.records.map((r:any)=>({...r,result:expand(r.result,c.source)}))).toEqual(f.records);
 expect(c.keys.map((r:any)=>({...r,result:expand(r.result,c.source)}))).toEqual(f.keys);
 expect(c.relationships.map((r:any)=>({...r,targetKey:expand(r.targetKey,c.source)}))).toEqual(f.relationships);
 expect(compact.verifyCoreDatasetValuesCompact(c,source,input)).toEqual(c);
});
test('compact recomputation rejects fragment references, result ordering, diagnostics and key byte tampering',()=>{
 const receipt=compact.validateCoreDatasetValuesCompact(source,input);
 for(const mutate of [(r:any)=>r.records[0].result.sourceRef='#/input',(r:any)=>r.records[0].result.source=r.source,(r:any)=>r.records.reverse(),(r:any)=>r.keys[0].result.bytesHex+='00',(r:any)=>r.datasetValidation.complete=false]){
  const bad=structuredClone(receipt);mutate(bad);expect(()=>compact.verifyCoreDatasetValuesCompact(bad,source,input)).toThrow();
 }
});
test('compact preserves unresolved original association meaning, exact context and refuses accessor execution',()=>{
 const s=structuredClone(source);s.modules[0].relationships[0].associationRecord={module:'m',element:'Staff'};
 const request=structuredClone(input);request.context={opaque:['雪',null,'2E+1']};const c=compact.validateCoreDatasetValuesCompact(s,request);
 expect(c.datasetValidation.complete).toBe(false);expect(c.source).toEqual(s);expect(c.input).toEqual(request);
 let calls=0;Object.defineProperty(request,'context',{enumerable:true,get(){calls++;return {};}});expect(()=>compact.validateCoreDatasetValuesCompact(source,request)).toThrow();expect(calls).toBe(0);
});
test('compact admits a whole supplied population exceeding historical repeated-source receipt budget',()=>{
 const s=structuredClone(source);s.title='a'.repeat(100000);const request=structuredClone(input);request.records=[];request.relationships=[];
 for(let i=0;i<20;i++){
  for(const kind of ['Staff','Project'])request.records.push({instanceId:kind+i,identity:{module:'m',element:kind},values:[{field:{module:'m',element:kind+'.id'},state:'present',value:{string:kind+i}}]});
  request.relationships.push({instanceId:'edge'+i,identity:{module:'m',id:'WorksOn'},sourceInstanceId:'Staff'+i,target:{identity:{module:'m',element:'Project',key:'identity'},values:[{string:'Project'+i}]}});
 }
 let refusal:any;try{full.validateCoreDatasetValues(s,request);}catch(error){refusal=error;}
 expect(refusal?.code).toBe('LIMIT');expect(refusal?.message).toBe('Dataset work/retained receipt budget exceeded');
 const c=compact.validateCoreDatasetValuesCompact(s,request);expect(c.datasetValidation).toEqual({valid:true,complete:true,diagnostics:[]});expect(c.records.length).toBe(40);expect(c.relationships.length).toBe(20);
 expect(compact.verifyCoreDatasetValuesCompact(c,s,request)).toEqual(c);
});
