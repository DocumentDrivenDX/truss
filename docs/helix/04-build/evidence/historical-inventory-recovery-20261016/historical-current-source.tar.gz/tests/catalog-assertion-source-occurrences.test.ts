import {test,expect} from 'bun:test';
import {createCatalogInputPreparation} from '../packages/umf-bun/src/catalog-input';
import {collectOriginalAssertionSourceOccurrences,requireOriginalAssertionSourceOccurrences} from '../packages/umf-bun/src/catalog-assertion-source-occurrences';
import {reconcileCatalogAssertionOccurrences,requireOriginalAssertionReconciliation} from '../packages/umf-bun/src/catalog-assertion-reconciliation';
import {collectCatalogAssertionObservations} from '../packages/umf-bun/src/catalog-assertion-observations';
import {loadUmfDeclarationProducer,loadUmfFieldAssertionProducer} from '../packages/umf-bun/src/index';
import {collectCatalogScalarAssertionIdentities} from '../packages/umf-bun/src/catalog-scalar-assertion-identities';
import {collectCatalogMembershipAssertionIdentities} from '../packages/umf-bun/src/catalog-membership-assertion-identities';
const recordDirectory=process.env.TRUSS_UMF_PRODUCER;
const declarationDirectory=process.env.TRUSS_UMF_DECLARATION_PRODUCER;
const fieldDirectory=process.env.TRUSS_UMF_FIELD_ASSERTION_PRODUCER;
const dependenciesPackage=process.env.TRUSS_UMF_DEPENDENCIES_PACKAGE;
if(!recordDirectory||!declarationDirectory||!fieldDirectory||!dependenciesPackage)throw Error('Original Record/declaration/Field producers and dependency package required');
const preparation=await createCatalogInputPreparation(recordDirectory,dependenciesPackage);
const input=structuredClone((await Bun.file('docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json').json()).input);input.binding={state:'absent'};input.transforms=[];
const model={umf:'0.7.0',id:'doc',vocabularies:{},extensions:{},modules:[{id:'m',namespace:'m',elements:[{id:'v',kind:'field',scalarType:'string',nullability:'required',cardinality:'one',facets:{future:{'a/~':[null,[]]}},extensions:{}}]}]};
const bytes=Buffer.from(JSON.stringify(model));const sha=new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
input.documents=[{documentId:'doc',documentRevision:'1',umfProfile:preparation.umfProfile,ingress:{kind:'native'},artifact:{identity:'doc',bytesBase64:bytes.toString('base64'),sha256:sha}}];
const prepared=preparation.prepare(new TextEncoder().encode(JSON.stringify(input)));
test('exact inspected assertions reconcile without blanket classification of opaque descendants',async()=>{
 const owner=await loadUmfDeclarationProducer(declarationDirectory);
 const fields=await loadUmfFieldAssertionProducer(fieldDirectory);
 const observations=collectCatalogAssertionObservations(prepared,owner,fields),census=collectOriginalAssertionSourceOccurrences(prepared);
 const result=reconcileCatalogAssertionOccurrences(prepared,census,observations),field='/modules/0/elements/0';
 expect(result.dispositions.filter(row=>row.state==='assertion').map(row=>row.occurrence.sourcePointer)).toEqual([field+'/kind',field+'/scalarType',field+'/nullability',field+'/cardinality',field+'/facets']);
 expect(result.dispositions.filter(row=>row.state==='unavailable').length).toBe(17);
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===field+'/facets/future/a~1~0/0')!.state).toBe('unavailable');
 expect(result.dispositions[0]!.owner).toEqual({scope:'document',documentId:'doc'});
 expect(result.complete).toBe(false);
 requireOriginalAssertionReconciliation(result,prepared);
 expect(()=>requireOriginalAssertionReconciliation({...result},prepared)).toThrow('custody');
 expect(()=>reconcileCatalogAssertionOccurrences(prepared,{...census},observations)).toThrow('custody');
 expect(()=>reconcileCatalogAssertionOccurrences(prepared,census,{...observations})).toThrow('custody');
});
test('every original occurrence retains exact pointer, source and qualified owner including opaque children',()=>{
 const result=collectOriginalAssertionSourceOccurrences(prepared),field='/modules/0/elements/0';
 const expected=['','/umf','/id','/vocabularies','/extensions','/modules','/modules/0','/modules/0/id','/modules/0/namespace','/modules/0/elements',field,field+'/id',field+'/kind',field+'/scalarType',field+'/nullability',field+'/cardinality',field+'/facets',field+'/facets/future',field+'/facets/future/a~1~0',field+'/facets/future/a~1~0/0',field+'/facets/future/a~1~0/1',field+'/extensions'];
 expect(result.occurrences.map(row=>row.sourcePointer)).toEqual(expected);
 expect(result.occurrences.every(row=>row.definitionPin===sha&&row.documentId==='doc')).toBe(true);
 expect(result.occurrences.find(row=>row.sourcePointer===field+'/facets/future/a~1~0/0')!.value).toBeNull();
 expect(result.occurrences.find(row=>row.sourcePointer===field+'/facets/future/a~1~0/1')!.value).toEqual([]);
 expect(result.occurrences.find(row=>row.sourcePointer===field)!.owner).toEqual({documentId:'doc',moduleId:'m'});
 expect(result.occurrences.find(row=>row.sourcePointer==='/umf')!.value).toBe('0.7.0');
 expect(Object.hasOwn(result,'complete')).toBe(false);requireOriginalAssertionSourceOccurrences(result,prepared);
 expect(()=>requireOriginalAssertionSourceOccurrences({...result},prepared)).toThrow('custody');
 expect(()=>collectOriginalAssertionSourceOccurrences({...prepared})).toThrow();
});

test('UTF-8 path bytes bound multibyte original occurrences before retaining excess output',()=>{
 const oversized=structuredClone(model);oversized.modules[0]!.elements[0]!.facets.future={['漢'.repeat(4000)]:Array(1000).fill(null)} as any;
 const source=Buffer.from(JSON.stringify(oversized)),request=structuredClone(input);
 request.documents[0].artifact={identity:'multibyte',bytesBase64:source.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(source).digest('hex')};
 const actual=preparation.prepare(new TextEncoder().encode(JSON.stringify(request)));
 expect(()=>collectOriginalAssertionSourceOccurrences(actual)).toThrow('capacity exceeded');
});

function prepareSource(sourceModel:unknown){
 const source=Buffer.from(JSON.stringify(sourceModel)),request=structuredClone(input);
 request.documents[0].documentId=(sourceModel as any).id;
 request.documents[0].artifact={identity:'doc',bytesBase64:source.toString('base64'),sha256:new Bun.CryptoHasher('sha256').update(source).digest('hex')};
 return preparation.prepare(new TextEncoder().encode(JSON.stringify(request)));
}
test('original0.7 scalar-family declarations retain known, opaque and absent distinctions',()=>{
 for(const family of ['boolean','integer','decimal','float','string','binary','date','time','timestamp','future-family']){
  const sourceModel=structuredClone(model);sourceModel.modules[0]!.elements[0]!.scalarType=family;
  const original=prepareSource(sourceModel),census=collectOriginalAssertionSourceOccurrences(original);
  const result=collectCatalogScalarAssertionIdentities(original,census);
  expect(result.entries.length).toBe(1);
  expect(result.entries[0]!.reason).toBe(family==='future-family'?'opaque':'unqualified');
  expect(result.entries[0]!.enforcement).toBe('none');
  expect(result.entries[0]!.assertion.definitionPin).toBe(original.original.input.documents[0]!.artifact.sha256);
 }
 const absent=structuredClone(model);delete (absent.modules[0]!.elements[0] as any).scalarType;
 const original=prepareSource(absent);
 expect(collectCatalogScalarAssertionIdentities(original,collectOriginalAssertionSourceOccurrences(original)).entries).toEqual([]);
 const newer={...structuredClone(model),umf:'0.8.0'},newPrepared=prepareSource(newer);
 expect(collectCatalogScalarAssertionIdentities(newPrepared,collectOriginalAssertionSourceOccurrences(newPrepared)).entries.map(row=>row.ruleName)).toEqual(['core.scalarType']);
 expect(()=>collectCatalogScalarAssertionIdentities(original,{...collectOriginalAssertionSourceOccurrences(original)})).toThrow('custody');
});
test('scalar evidence succeeds at exact4MiB and refuses the next base64-sized increment',()=>{
 // Independently derived by Astra from artifact JSON/base64 shapes; these
 // authored sizes do not use producer output to choose or adjust the input.
 const sourceModel={umf:'0.7.0',id:'d'.repeat(233),vocabularies:{},extensions:{},modules:[{id:'m',namespace:'m',elements:Array.from({length:2800},(_,index)=>({id:'f'+index,kind:'field',scalarType:'future-family',extensions:{}}))}]};
 sourceModel.modules[0]!.elements[2799]!.scalarType+='x'.repeat(5203);
 let original=prepareSource(sourceModel),census=collectOriginalAssertionSourceOccurrences(original);
 expect(census.occurrences.length).toBe(14010);
 expect(collectCatalogScalarAssertionIdentities(original,census).retainedEvidenceBytes).toBe(4194304);
 sourceModel.modules[0]!.elements[2799]!.scalarType+='xxx';
 original=prepareSource(sourceModel);census=collectOriginalAssertionSourceOccurrences(original);
 expect(()=>collectCatalogScalarAssertionIdentities(original,census)).toThrow('Scalar assertion evidence capacity exceeded');
});
test('many opaque scalar declarations share one source-bound validation artifact',()=>{
 const sourceModel=structuredClone(model);
 sourceModel.modules[0]!.elements=Array.from({length:300},(_,index)=>({id:'f'+index,kind:'field',scalarType:'future-family',nullability:'required',cardinality:'one',facets:{future:{'a/~':[null,[]]}},extensions:{}}));
 const original=prepareSource(sourceModel),result=collectCatalogScalarAssertionIdentities(original,collectOriginalAssertionSourceOccurrences(original));
 expect(result.entries.length).toBe(300);expect(result.validationEvidence.length).toBe(1);
 expect(result.retainedEvidenceBytes).toBeLessThan(1000000);
 expect(result.entries.every(entry=>JSON.parse(Buffer.from(entry.ownerEvidence.bytesBase64,'base64').toString()).validationEvidenceSha256===result.validationEvidence[0]!.sha256)).toBe(true);
 expect(JSON.parse(Buffer.from(result.validationEvidence[0]!.bytesBase64,'base64').toString()).contentSha256).toBe(original.original.input.documents[0]!.artifact.sha256);
});
test('collection item reference covers only owner-interpreted module and element members',async()=>{
 const sourceModel=structuredClone(model);
 const field=sourceModel.modules[0]!.elements[0]!;field.cardinality='array';delete (field as any).scalarType;delete (field as any).facets;
 (field as any).itemType={module:'m',element:'item',future:{module:'uninterpreted'}};
 sourceModel.modules[0]!.elements.push({id:'item',kind:'field',scalarType:'string',nullability:'required',cardinality:'one',facets:{future:{'a/~':[null,[]]}},extensions:{}});
 const original=prepareSource(sourceModel),owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory);
 const result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),collectCatalogAssertionObservations(original,owner,fields)),root='/modules/0/elements/0/itemType';
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root)!.state).toBe('assertion');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/module')!.state).toBe('assertion_component');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/element')!.state).toBe('assertion_component');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/future/module')!.state).toBe('unavailable');
 expect(result.complete).toBe(false);
});
test('known facet components retain unknown qualifiers without subtree inheritance',async()=>{
 const owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory),root='/modules/0/elements/0/facets';
 for(const specimen of [
  {scalarType:'string',facets:{length:{max:12,unit:'unicode-scalar',future:{max:999}}},components:['length','length/max','length/unit'],unknown:'length/future/max'},
  {scalarType:'integer',facets:{integerWidth:{bits:16,signed:true,future:{bits:999}}},components:['integerWidth','integerWidth/bits','integerWidth/signed'],unknown:'integerWidth/future/bits'},
  {scalarType:'decimal',facets:{precision:10,scale:2,future:{precision:999}},components:['precision','scale'],unknown:'future/precision'},
  {scalarType:'string',facets:{length:{max:12,unit:'future-unit'}},components:[],unknown:'length/unit'},
 ]){
  const sourceModel=structuredClone(model);Object.assign(sourceModel.modules[0]!.elements[0]!,{scalarType:specimen.scalarType,facets:specimen.facets});
  const original=prepareSource(sourceModel),result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),collectCatalogAssertionObservations(original,owner,fields));
  expect(result.dispositions.filter(row=>row.state==='assertion_component').map(row=>row.occurrence.sourcePointer)).toEqual(specimen.components.map(suffix=>root+'/'+suffix));
  expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/'+specimen.unknown)!.state).toBe('unavailable');
  expect(result.complete).toBe(false);
 }
});
test('original Key and Record components preserve unknown qualifiers',async()=>{
 const sourceModel:any=structuredClone(model);
 sourceModel.modules[0].elements.push({id:'R',kind:'record',members:[{module:'m',element:'v',future:{element:'other'}}],keys:[{id:'k',name:'identity',fields:[{module:'m',element:'v',future:{element:'other'}}],primary:true,future:{primary:false}}],extensions:{}});
 const original=prepareSource(sourceModel),owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory),root='/modules/0/elements/1/keys/0';
 const result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),collectCatalogAssertionObservations(original,owner,fields));
 expect(result.dispositions.filter(row=>row.state==='assertion_component'&&row.occurrence.sourcePointer.startsWith(root+'/')).map(row=>row.occurrence.sourcePointer)).toEqual(['id','name','fields','fields/0','fields/0/module','fields/0/element','primary'].map(suffix=>root+'/'+suffix));
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/fields/0/future/element')!.state).toBe('unavailable');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/future/primary')!.state).toBe('unavailable');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer==='/modules/0/elements/1/members/0/element')!.state).toBe('assertion_component');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer==='/modules/0/elements/1/members/0/future/element')!.state).toBe('unavailable');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root)!.state).toBe('assertion');
 expect(result.complete).toBe(false);
});
test('relationship components retain unknown endpoint and multiplicity qualifiers',async()=>{
 const sourceModel:any=structuredClone(model);
 sourceModel.modules[0].elements.push({id:'R',kind:'record',members:[{module:'m',element:'v'}],keys:[{id:'k',name:'identity',fields:[{module:'m',element:'v'}],primary:true}],extensions:{}});
 sourceModel.modules[0].relationships=[{id:'rel',name:'self',source:[{module:'m',element:'R',future:{element:'other'}}],target:[{module:'m',element:'R',key:'k'}],sourceMultiplicity:{min:0,max:1,future:{max:999}},targetMultiplicity:{min:0,max:'*'},targetLifecycle:'independent',directed:true}];
 const original=prepareSource(sourceModel),owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory),root='/modules/0/relationships/0';
 const result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),collectCatalogAssertionObservations(original,owner,fields));
 const expected=['id','name','source','source/0','source/0/module','source/0/element','target','target/0','target/0/module','target/0/element','target/0/key','sourceMultiplicity','sourceMultiplicity/min','sourceMultiplicity/max','targetMultiplicity','targetMultiplicity/min','targetMultiplicity/max','targetLifecycle','directed'];
 expect(result.dispositions.filter(row=>row.state==='assertion_component'&&row.occurrence.sourcePointer.startsWith(root+'/')).map(row=>row.occurrence.sourcePointer)).toEqual(expected.map(suffix=>root+'/'+suffix));
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/source/0/future/element')!.state).toBe('unavailable');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/sourceMultiplicity/future/max')!.state).toBe('unavailable');
 expect(result.complete).toBe(false);
 sourceModel.modules[0].relationships[0].targetLifecycle='future-lifecycle';
 const unknownOriginal=prepareSource(sourceModel),unknownResult=reconcileCatalogAssertionOccurrences(unknownOriginal,collectOriginalAssertionSourceOccurrences(unknownOriginal),collectCatalogAssertionObservations(unknownOriginal,owner,fields));
 expect(unknownResult.dispositions.find(row=>row.occurrence.sourcePointer===root+'/targetLifecycle')!.state).toBe('unavailable');
});
test('Record membership evidence resolves one retained original validation artifact',()=>{
 const sourceModel:any=structuredClone(model);
 sourceModel.modules[0].elements.push({id:'R',kind:'record',members:[],extensions:{}},{id:'S',kind:'record',members:[{module:'m',element:'v'}],extensions:{}});
 const original=prepareSource(sourceModel),result=collectCatalogMembershipAssertionIdentities(original,collectOriginalAssertionSourceOccurrences(original));
 expect(result.entries.map(entry=>entry.assertion.sourcePointer)).toEqual(['/modules/0/elements/1/members','/modules/0/elements/2/members']);
 expect(result.validationEvidence.length).toBe(1);
 const validation=result.validationEvidence[0]!,decoded=JSON.parse(Buffer.from(validation.bytesBase64,'base64').toString('utf8'));
 expect(new Bun.CryptoHasher('sha256').update(Buffer.from(validation.bytesBase64,'base64')).digest('hex')).toBe(validation.sha256);
 expect(decoded.sourceValidation).toEqual(original.documents[0]!.interpretation.sourceValidation);
 expect(decoded.contentSha256).toBe(original.original.input.documents[0]!.artifact.sha256);
 expect(result.entries.every(entry=>JSON.parse(Buffer.from(entry.ownerEvidence.bytesBase64,'base64').toString('utf8')).validationEvidenceSha256===validation.sha256)).toBe(true);
 expect(result.complete).toBe(false);
});
test('unselected extension semantics preserve every scope without acquiring core assertion meaning',async()=>{
 const sourceModel:any=structuredClone(model),id='future/~',payload={kind:'field',scalarType:'string',members:[{module:'m',element:'v'}],rules:[{id:'rule',effect:'permit'}],future:{primary:true}};
 sourceModel.vocabularies={[id]:{version:'1.0.0'}};sourceModel.extensions={[id]:payload};sourceModel.modules[0].extensions={[id]:payload};sourceModel.modules[0].elements[0].extensions={[id]:payload};
 const original=prepareSource(sourceModel),owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory);
 const result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),collectCatalogAssertionObservations(original,owner,fields));
 const roots=['/extensions/future~1~0','/modules/0/extensions/future~1~0','/modules/0/elements/0/extensions/future~1~0'];
 expect(result.unresolvedExtensionOccurrences).toBe(3);
 for(const root of roots){
  const rows=result.dispositions.filter(row=>row.occurrence.sourcePointer===root||row.occurrence.sourcePointer.startsWith(root+'/'));
  expect(rows.every(row=>row.state==='unavailable'&&row.reason==='extension_assertion_membership_not_admitted'&&row.extensionPointer===root)).toBe(true);
  expect(rows.map(row=>row.occurrence.sourcePointer).includes(root+'/members/0/element')).toBe(true);
 }
 expect(result.complete).toBe(false);
});
test('ordered composite Keys sharing one inspector receipt retain each original component',async()=>{
 const sourceModel:any=structuredClone(model);
 sourceModel.modules[0].elements.push({id:'w',kind:'field',scalarType:'string',nullability:'required',cardinality:'one',extensions:{}},
  {id:'R',kind:'record',members:[{module:'m',element:'v'},{module:'m',element:'w'}],keys:[
   {id:'primary',name:'ordered',fields:[{module:'m',element:'w'},{module:'m',element:'v'}],primary:true},
   {id:'secondary',name:'alternate',fields:[{module:'m',element:'v'}],primary:false}],extensions:{}});
 const original=prepareSource(sourceModel),owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory);
 const observations=collectCatalogAssertionObservations(original,owner,fields),result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),observations),base='/modules/0/elements/2/keys';
 for(const [index,suffixes] of [
  [0,['id','name','fields','fields/0','fields/0/module','fields/0/element','fields/1','fields/1/module','fields/1/element','primary']],
  [1,['id','name','fields','fields/0','fields/0/module','fields/0/element','primary']],
 ] as const){
  const root=base+'/'+index;
  expect(result.dispositions.filter(row=>row.state==='assertion_component'&&row.occurrence.sourcePointer.startsWith(root+'/')).map(row=>row.occurrence.sourcePointer)).toEqual(suffixes.map(suffix=>root+'/'+suffix));
 }
 const assertions=result.dispositions.flatMap(row=>row.state==='assertion'&&row.assertion.ruleName==='core.keys'?[row.assertion]:[]);
 expect(assertions.length).toBe(2);
 expect(assertions[0]!.ownerEvidence).toBe(assertions[1]!.ownerEvidence);
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===base+'/0/fields/0/element')!.occurrence.value).toBe('w');
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===base+'/0/fields/1/element')!.occurrence.value).toBe('v');
 expect(result.complete).toBe(false);
});
test('original0.8 scalar allowed-values and default components preserve original typed tokens',async()=>{
 const sourceModel:any=structuredClone(model);sourceModel.umf='0.8.0';
 const field=sourceModel.modules[0].elements[0];field.allowedValues=[{string:'red'},{string:'blue'}];field.default={value:{string:'red'},on:'missing'};
 const original=prepareSource(sourceModel),owner=await loadUmfDeclarationProducer(declarationDirectory),fields=await loadUmfFieldAssertionProducer(fieldDirectory),root='/modules/0/elements/0';
 const result=reconcileCatalogAssertionOccurrences(original,collectOriginalAssertionSourceOccurrences(original),collectCatalogAssertionObservations(original,owner,fields));
 expect(result.dispositions.filter(row=>row.state==='assertion_component').map(row=>row.occurrence.sourcePointer)).toEqual(['allowedValues/0','allowedValues/0/string','allowedValues/1','allowedValues/1/string','default/value','default/value/string','default/on'].map(suffix=>root+'/'+suffix));
 expect(result.dispositions.find(row=>row.occurrence.sourcePointer===root+'/default/value/string')!.occurrence.value).toBe('red');
 expect(result.complete).toBe(false);
});
test('exact node limit succeeds and one further original occurrence refuses',()=>{
 const sourceModel=structuredClone(model);sourceModel.modules[0]!.elements[0]!.facets.future={n:Array.from({length:4},()=>Array(4090).fill(null))} as any;
 expect(collectOriginalAssertionSourceOccurrences(prepareSource(sourceModel)).occurrences.length).toBe(16384);
 sourceModel.modules[0]!.elements[0]!.facets.future={n:[Array(4091).fill(null),...Array.from({length:3},()=>Array(4090).fill(null))]} as any;
 expect(()=>collectOriginalAssertionSourceOccurrences(prepareSource(sourceModel))).toThrow('capacity exceeded');
});
test('original document and module namespaces retain separate indices and source digests',()=>{
 const second=structuredClone(model);second.id='second';second.modules[0]!.id='other';second.modules[0]!.namespace='other';
 const request=structuredClone(input),source=Buffer.from(JSON.stringify(second)),digest=new Bun.CryptoHasher('sha256').update(source).digest('hex');
 request.documents.push({...request.documents[0],documentId:'second',artifact:{identity:'second',bytesBase64:source.toString('base64'),sha256:digest}});
 const result=collectOriginalAssertionSourceOccurrences(preparation.prepare(new TextEncoder().encode(JSON.stringify(request))));
 expect(result.occurrences.filter(row=>row.documentIndex===0).every(row=>row.documentId==='doc'&&row.definitionPin===sha)).toBe(true);
 expect(result.occurrences.filter(row=>row.documentIndex===1).every(row=>row.documentId==='second'&&row.definitionPin===digest)).toBe(true);
 expect(result.occurrences.find(row=>row.documentIndex===1&&row.sourcePointer==='/modules/0')!.owner).toEqual({documentId:'second',moduleId:'other'});
});

test('depth64 retains its deepest occurrence and depth65 refuses',()=>{
 const sourceModel=structuredClone(model);let value:unknown=null;
 for(let i=0;i<58;i++)value={x:value};sourceModel.modules[0]!.elements[0]!.facets.future=value as any;
 const census=collectOriginalAssertionSourceOccurrences(prepareSource(sourceModel));
 expect(census.occurrences.find(row=>row.sourcePointer==='/modules/0/elements/0/facets/future'+'/x'.repeat(58))!.value).toBeNull();
 sourceModel.modules[0]!.elements[0]!.facets.future={x:value} as any;
 expect(()=>collectOriginalAssertionSourceOccurrences(prepareSource(sourceModel))).toThrow('capacity exceeded');
});

test('exact4MiB UTF-8 pointer budget succeeds and one further byte refuses',()=>{
 const sourceModel=structuredClone(model),field='/modules/0/elements/0',future=field+'/facets/future',key='漢'.repeat(1200);
 // Independently authored fixed source topology; expected byte accounting does
 // not consume the census output or implementation counters.
 const fixed=['','/umf','/id','/vocabularies','/extensions','/modules','/modules/0','/modules/0/id','/modules/0/namespace','/modules/0/elements',field,field+'/id',field+'/kind',field+'/scalarType',field+'/nullability',field+'/cardinality',field+'/facets',future,field+'/extensions'];
 const pointers=[...fixed,future+'/'+key,...Array.from({length:1100},(_,i)=>future+'/'+key+'/'+i)];
 const used=pointers.reduce((sum,path)=>sum+Buffer.byteLength(path,'utf8'),0);
 const padding=4194304-used-Buffer.byteLength(future+'/','utf8');
 sourceModel.modules[0]!.elements[0]!.facets.future={[key]:Array(1100).fill(null),['p'.repeat(padding)]:''} as any;
 expect(collectOriginalAssertionSourceOccurrences(prepareSource(sourceModel)).occurrences.length).toBe(1121);
 sourceModel.modules[0]!.elements[0]!.facets.future={[key]:Array(1100).fill(null),['p'.repeat(padding+1)]:''} as any;
 expect(()=>collectOriginalAssertionSourceOccurrences(prepareSource(sourceModel))).toThrow('capacity exceeded');
});
