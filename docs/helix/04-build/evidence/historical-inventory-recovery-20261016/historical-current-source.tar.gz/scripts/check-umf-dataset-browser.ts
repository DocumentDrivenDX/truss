/** Exact original dataset bundle parity in a real browser; no population coverage. */
import {loadUmfDatasetProducer,loadUmfCompactDatasetProducer} from '../packages/umf-bun/src/index';
import {source,input} from '../tests/catalog-dataset-fixture';
const compact=process.argv[2]==='compact';
if(process.argv[2]!==undefined&&!compact)throw Error('Unknown dataset operation selection');
const directory=compact?process.env.TRUSS_UMF_COMPACT_DATASET_PRODUCER:process.env.TRUSS_UMF_DATASET_PRODUCER,dependencies=process.env.TRUSS_UMF_DEPENDENCIES_PACKAGE;
if(!directory||!dependencies)throw Error('Producer and dependency package required');
const paths=['scripts/check-umf-dataset-browser.ts','scripts/build-umf-runtime.ts','packages/umf-bun/src/index.ts','tests/catalog-dataset-fixture.ts',directory+'/producer.js',directory+'/producer-manifest.json'];
const digest=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,new Bun.CryptoHasher('sha256').update(await Bun.file(p).arrayBuffer()).digest('hex')])));
const sourceDigests=await digest(),owner=compact?await loadUmfCompactDatasetProducer(directory):await loadUmfDatasetProducer(directory);
const validationOperation=compact?'validateCoreDatasetValuesCompact':'validateCoreDatasetValues',verificationOperation=compact?'verifyCoreDatasetValuesCompact':'verifyCoreDatasetValues';
const cases=[{source,input},{source,input:structuredClone(input)},{source:structuredClone(source),input}];
cases[1]!.input.relationships=[];cases[2]!.source.modules[0].relationships[0].associationRecord={module:'m',element:'Staff'};
const expected=cases.map(row=>(owner as any)[validationOperation](row.source,row.input));
const bundle=await Bun.file(directory+'/producer.js').arrayBuffer();
const servedBundleSha256=new Bun.CryptoHasher('sha256').update(bundle).digest('hex');
if(servedBundleSha256!==owner.bundleSha256||servedBundleSha256!==sourceDigests[directory+'/producer.js'])throw Error('Original served dataset bundle mismatch');
const {chromium}=await import(new URL('./node_modules/playwright/index.mjs',new URL('file://'+dependencies)).href);
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(request){const p=new URL(request.url).pathname;return p==='/producer.js'?new Response(bundle,{headers:{'content-type':'text/javascript'}}):p==='/cases'?Response.json({cases,expected,validationOperation,verificationOperation}):new Response('<!doctype html><title>Original dataset checks</title>');}});
let browser;
try{
 browser=await chromium.launch({headless:true,...(process.env.UMF_CHROMIUM_PATH?{executablePath:process.env.UMF_CHROMIUM_PATH}:{})});const page=await browser.newPage(),externalRequests:string[]=[];
 await page.route('**/*',(route:any)=>{if(!route.request().url().startsWith(`http://127.0.0.1:${server.port}/`)){externalRequests.push(route.request().url());return route.abort();}return route.continue();});await page.goto(`http://127.0.0.1:${server.port}/`);
 const checks=await page.evaluate(async()=>{const path='/producer.js',u=await import(path),data=await(await fetch('/cases')).json();let parity=0,recomputed=0;
  for(let i=0;i<data.cases.length;i++){const row=data.cases[i],receipt=u[data.validationOperation](row.source,row.input);if(JSON.stringify(receipt)!==JSON.stringify(data.expected[i]))throw Error('Dataset parity mismatch');parity++;if(JSON.stringify(u[data.verificationOperation](receipt,row.source,row.input))!==JSON.stringify(receipt))throw Error('Recomputation mismatch');recomputed++;}
  if('Bun'in globalThis||'process'in globalThis)throw Error('Host global present');return {parity,recomputed};});
 const sourcesUnchanged=JSON.stringify(sourceDigests)===JSON.stringify(await digest());if(!sourcesUnchanged||externalRequests.length||checks.parity!==3||checks.recomputed!==3)throw Error('Browser qualification failed');
 await Bun.write(compact?'docs/helix/04-build/evidence/umf-compact-dataset-browser.json':'docs/helix/04-build/evidence/umf-dataset-browser.json',JSON.stringify({status:'component-checks-passed',validationOperation,verificationOperation,scope:'Three original supplied-dataset browser parity and verifier recomputation cases; no native population/support/enforcement admission',browser:browser.version(),servedBundleSha256,checks,externalRequests,sourceDigests,sourcesUnchanged,producer:{sourceRevision:owner.sourceRevision,bundleSha256:owner.bundleSha256}},null,2)+'\n');console.log(JSON.stringify(checks));
}finally{await browser?.close();server.stop(true);}
