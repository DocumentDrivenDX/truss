/** Snapshot an owner working tree; output remains private until exact composition is reviewed. */
import {mkdtemp,readdir,readFile,mkdir,writeFile,symlink} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
const repository=resolve(process.argv[2]??'');if(!process.argv[2])throw Error('Owner repository required');
const output=await mkdtemp('/private/tmp/truss-umf-inventory-');
const hash=(bytes:Uint8Array|string)=>new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
const files:string[]=[];
async function walk(relative:string){for(const entry of await readdir(repository+'/'+relative,{withFileTypes:true})){const path=relative+'/'+entry.name;if(entry.isDirectory())await walk(path);else if(entry.isFile())files.push(path);else throw Error('Unexpected source symlink');}}
await walk('src');await walk('spec');files.sort();
const sourceFiles:Record<string,string>={};
for(const path of files){const bytes=await readFile(repository+'/'+path);sourceFiles[path]=hash(bytes);await mkdir(dirname(output+'/'+path),{recursive:true});await writeFile(output+'/'+path,bytes);}
const sourceBytes=JSON.stringify(sourceFiles),revision='snapshot-sha256:'+hash(sourceBytes);
await symlink(repository+'/node_modules',output+'/node_modules');
const exports={inspectCoreSchemaProperties:'schema-properties',inspectCoreKeys:'keys',inspectCoreRelationships:'relationships',inspectCoreElementKind:'field-kind',inspectCoreNullability:'nullability',inspectCoreCardinality:'cardinality',inspectCoreFacets:'facets'};
await writeFile(output+'/producer.ts',Object.entries(exports).map(([name,module])=>`export {${name}} from './src/model/${module}';`).join('\n')+'\n');
const built=await Bun.build({entrypoints:[output+'/producer.ts'],outdir:output,target:'browser',format:'esm',minify:true,naming:'producer.js'});if(!built.success)throw Error('Owner inventory build failed');
for(const path of files)if(hash(await readFile(repository+'/'+path))!==sourceFiles[path])throw Error('Owner source changed during snapshot build');
const bundleSha256=hash(await readFile(output+'/producer.js'));
await writeFile(output+'/producer-manifest.json',JSON.stringify({revision,producerMode:'inventory-inspections',bundleSha256,sourceFiles,operations:Object.keys(exports),scope:'Exact owner source snapshot; private inspection only, no backend admission'},null,2)+'\n');
console.log(JSON.stringify({directory:output,revision,bundleSha256}));
