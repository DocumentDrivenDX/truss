/** Exact registered owner bundle browser parity; no native or full-inventory claim. */
import assert from 'node:assert/strict';
import {loadUmfInventoryInspectionProducer,loadUmfProducer} from '../packages/umf-bun/src/index';
const directory=process.env.TRUSS_UMF_INVENTORY_PRODUCER,recordDirectory=process.env.TRUSS_UMF_PRODUCER,dependencies=process.env.TRUSS_UMF_DEPENDENCIES_PACKAGE;
if(!directory||!recordDirectory||!dependencies)throw Error('Original producer directories and dependency package required');
const loaded=await loadUmfInventoryInspectionProducer(directory),record=await loadUmfProducer(recordDirectory);
const {chromium}=await import(new URL('./node_modules/playwright/index.mjs',new URL('file://'+dependencies)).href);
const cases:{source:unknown;operation:string;identity:unknown;expected:unknown}[]=[];
for(const umf of ['0.7.0','0.8.0']){
 const document={umf,id:'original',vocabularies:{},modules:[{id:'m',namespace:'m',elements:[{id:'v',kind:'field',scalarType:'integer',nullability:'required',cardinality:'one',facets:{integerWidth:{bits:128,signed:true},future:{opaque:true},...(umf==='0.8.0'?{range:{min:{integerToken:'9007199254740993'}}}:{})},extensions:{}},{id:'R',kind:'record',members:[{module:'m',element:'v'}],keys:[{id:'K',name:'key',fields:[{module:'m',element:'v'}],primary:true}],extensions:{}}],relationships:[]}]};
 const admitted=record.inspect(JSON.stringify(document));if(!admitted.sourceValidation.valid||!admitted.targetValidation?.valid)throw Error('Original source refused');const source=admitted.source;
 const operations=[['inspectCoreElementKind',loaded.fields.inspectKind,{module:'m',element:'v'}],['inspectCoreNullability',loaded.fields.inspectNullability,{module:'m',element:'v'}],['inspectCoreCardinality',loaded.fields.inspectCardinality,{module:'m',element:'v'}],['inspectCoreFacets',loaded.fields.inspectFacets,{module:'m',element:'v'}],['inspectCoreKeys',loaded.declarations.inspectKeys,{module:'m',element:'R'}],['inspectCoreRelationships',loaded.declarations.inspectRelationships,{module:'m'}]] as const;
 for(const [operation,inspect,identity] of operations)cases.push({source,operation,identity,expected:inspect(source,identity)});
 if(umf==='0.8.0')cases.push({source,operation:'inspectCoreSchemaProperties',identity:{scope:'element',module:'m',element:'v'},expected:loaded.declarations.inspectSchemaProperties(source,{scope:'element',module:'m',element:'v'})});
}
const bundle=await Bun.file(directory+'/producer.js').arrayBuffer(),digest=(bytes:Uint8Array|ArrayBuffer)=>new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(request){const path=new URL(request.url).pathname;if(path==='/producer.js')return new Response(bundle,{headers:{'content-type':'text/javascript'}});if(path==='/cases')return Response.json(cases);return new Response('<!doctype html><title>Owner inventory composition</title>');}});let browser;
try{
 browser=await chromium.launch({headless:true,...(process.env.UMF_CHROMIUM_PATH?{executablePath:process.env.UMF_CHROMIUM_PATH}:{})});const page=await browser.newPage(),externalRequests:string[]=[];
 await page.route('**/*',(route:any)=>{if(!route.request().url().startsWith(`http://127.0.0.1:${server.port}/`)){externalRequests.push(route.request().url());return route.abort();}return route.continue();});await page.goto(`http://127.0.0.1:${server.port}/`);
 const checks=await page.evaluate(async()=>{const url='/producer.js',u=await import(url),rows=await(await fetch('/cases')).json();let parityChecks=0,getterCalls=0;
  for(const row of rows){if(JSON.stringify(u[row.operation](row.source,row.identity))!==JSON.stringify(row.expected))throw Error('Original output mismatch');parityChecks++;}
  let refused=false;try{u.inspectCoreFacets({get umf(){getterCalls++;return '0.8.0';}},{module:'m',element:'v'});}catch{refused=true;}if(!refused||getterCalls)throw Error('Accessor executed');if('Bun'in globalThis||'process'in globalThis)throw Error('Host global present');return {parityChecks,getterCalls};
 });assert.deepEqual(checks,{parityChecks:13,getterCalls:0});assert.deepEqual(externalRequests,[]);
 const sourcePaths=['scripts/check-umf-inventory-composition-browser.ts','scripts/build-umf-inventory-runtime.ts','packages/umf-bun/src/index.ts','packages/umf-bun/src/catalog-assertion-observations.ts','packages/umf-bun/src/catalog-core-assertion-identities.ts','tests/catalog-inventory-inspection-composition.test.ts'];
 const sourceDigests=Object.fromEntries(await Promise.all(sourcePaths.map(async path=>[path,digest(await Bun.file(path).arrayBuffer())])));
 await Bun.write('docs/helix/04-build/evidence/umf-inventory-composition-browser.json',JSON.stringify({scope:'Original0.7/0.8 registered Record/inspection composition, full browser output parity only; no complete inventory or native enforcement',browser:browser.version(),checks,externalRequests,composition:loaded.composition,sourceDigests,inspectionManifest:await Bun.file(directory+'/producer-manifest.json').json()},null,2)+'\n');console.log(JSON.stringify(checks));
}finally{await browser?.close();server.stop(true);}
