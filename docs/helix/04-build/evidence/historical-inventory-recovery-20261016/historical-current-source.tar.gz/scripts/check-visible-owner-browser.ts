/** Browser parity of visible-owner wire decoding; no native authority claim. */
import {mkdtemp} from 'node:fs/promises';
import {decodeVisibleDatasetOwners} from '../packages/postgresql/src/dataset-visible-owner-inventory';
const dependencies=process.env.TRUSS_UMF_DEPENDENCIES_PACKAGE;if(!dependencies)throw Error('Dependency package required');
const nativePath='/Users/erik/.codex/worktrees/1598/umf/docs/helix/04-build/evidence/security/truss-visible-owner-inventory.json';
const paths=['scripts/check-visible-owner-browser.ts','packages/postgresql/src/dataset-visible-owner-inventory.ts','packages/postgresql/src/acceptance-json.ts',nativePath];
const digest=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,new Bun.CryptoHasher('sha256').update(await Bun.file(p).arrayBuffer()).digest('hex')])));
const nativeBytes=await Bun.file(nativePath).arrayBuffer(),native=JSON.parse(new TextDecoder().decode(nativeBytes));
const nativeRoot='/Users/erik/.codex/worktrees/1598/umf';
for(const path of Object.keys(native.sourceDigests))paths.push(path.startsWith('/')?path:nativeRoot+'/'+path);
const sourceDigests=await digest();
if(sourceDigests[nativePath]!==new Bun.CryptoHasher('sha256').update(nativeBytes).digest('hex'))throw Error('Native receipt changed');
for(const [path,pin] of Object.entries(native.sourceDigests))if(new Bun.CryptoHasher('sha256').update(await Bun.file(path.startsWith('/')?path:nativeRoot+'/'+path).arrayBuffer()).digest('hex')!==pin)throw Error('Stale native source');
const canonical=(v:any):string=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
function bindNativeWire(value:any){
 if(value.status!=='passed-visible-owner-inventory-component'||typeof value.ownerWire?.bytesHex!=='string'||!/^(?:[0-9a-f]{2})+$/.test(value.ownerWire.bytesHex))throw Error('Native wire binding');
 const bytes=Buffer.from(value.ownerWire.bytesHex,'hex');if(bytes.toString('hex')!==value.ownerWire.bytesHex)throw Error('Native wire binding');
 const hash=new Bun.CryptoHasher('sha256').update(bytes).digest('hex'),text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes),decoded=decodeVisibleDatasetOwners(text);
 const observation=value.observations.find((o:any)=>o.id==='typed-owner-kind-discriminator-and-large-id');
 if(hash!==value.ownerWire.sha256||hash!==value.decodedOwnerWire?.wireSha256||text!==value.decodedOwnerWire?.originalText||!observation||canonical(decoded.rows)!==canonical(observation.expected)||canonical(decoded.rows)!==canonical(observation.observed)||canonical(decoded.rows)!==canonical(value.decodedOwnerWire.rows))throw Error('Native wire binding');
 return {text,rows:decoded.rows};
}
const bound=bindNativeWire(native),sample=bound.rows,originalNativeText=bound.text;
const substituted=structuredClone(native),empty=Buffer.from('[]\n');substituted.ownerWire={...substituted.ownerWire,bytesHex:empty.toString('hex'),sha256:new Bun.CryptoHasher('sha256').update(empty).digest('hex')};
substituted.decodedOwnerWire={...substituted.decodedOwnerWire,wireSha256:substituted.ownerWire.sha256,originalText:'[]\n',rows:[]};
let substitutionRefused=false;try{bindNativeWire(substituted);}catch{substitutionRefused=true;}if(!substitutionRefused)throw Error('Substituted native wire accepted');
const strings=[originalNativeText,JSON.stringify(sample.filter((r:any)=>r.owner_kind==='edge')),JSON.stringify([sample[0],sample[0]]),'[{"owner_kind":"object","owner_kind":"edge"}]',JSON.stringify([{...sample[0],owner_id:1}])];
const expected=strings.map(text=>{try{return {accepted:true,result:decodeVisibleDatasetOwners(text)}}catch{return {accepted:false}}});
const staged=await mkdtemp('/private/tmp/truss-visible-owner-browser-');
for(const name of ['dataset-visible-owner-inventory.ts','acceptance-json.ts']){const path='packages/postgresql/src/'+name,bytes=await Bun.file(path).arrayBuffer();if(new Bun.CryptoHasher('sha256').update(bytes).digest('hex')!==sourceDigests[path])throw Error('Build source changed');await Bun.write(staged+'/'+name,bytes);}
const build=await Bun.build({entrypoints:[staged+'/dataset-visible-owner-inventory.ts'],target:'browser',format:'esm',minify:true});if(!build.success)throw Error('Browser build failed');
const bundle=await build.outputs[0]!.arrayBuffer(),servedBundleSha256=new Bun.CryptoHasher('sha256').update(bundle).digest('hex');
await Bun.write(staged+'/decoder.js',bundle);
const {chromium}=await import(new URL('./node_modules/playwright/index.mjs',new URL('file://'+dependencies)).href);
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(request){const p=new URL(request.url).pathname;return p==='/decoder.js'?new Response(bundle,{headers:{'content-type':'text/javascript'}}):p==='/cases'?Response.json({strings,expected}):new Response('<!doctype html><title>Visible owner decoder</title>');}});let browser;
try{
 browser=await chromium.launch({headless:true,...(process.env.UMF_CHROMIUM_PATH?{executablePath:process.env.UMF_CHROMIUM_PATH}:{})});const page=await browser.newPage(),externalRequests:string[]=[];
 await page.route('**/*',(route:any)=>{if(!route.request().url().startsWith(`http://127.0.0.1:${server.port}/`)){externalRequests.push(route.request().url());return route.abort();}return route.continue();});await page.goto(`http://127.0.0.1:${server.port}/`);
 const checks=await page.evaluate(async()=>{const path='/decoder.js',u=await import(path),data=await(await fetch('/cases')).json();let accepted=0,refused=0;
 for(let i=0;i<data.strings.length;i++){let result;try{result={accepted:true,result:u.decodeVisibleDatasetOwners(data.strings[i])}}catch{result={accepted:false}}if(JSON.stringify(result)!==JSON.stringify(data.expected[i]))throw Error('Decoder parity mismatch');if(result.accepted)accepted++;else refused++;}if('Bun'in globalThis||'process'in globalThis)throw Error('Host global present');return {accepted,refused};});
 const sourcesUnchanged=JSON.stringify(sourceDigests)===JSON.stringify(await digest());if(!sourcesUnchanged||externalRequests.length||checks.accepted!==2||checks.refused!==3)throw Error('Browser evidence failed');
 await Bun.write('docs/helix/04-build/evidence/visible-owner-browser.json',JSON.stringify({status:'component-checks-passed',scope:'Browser/Bun decoding parity on retained native sample and refusals; no fresh native execution, source authority or complete population',sourceDigests,sourcesUnchanged,substitutionRefused,servedBundleSha256,bundleArtifactPath:staged+'/decoder.js',browser:browser.version(),externalRequests,checks},null,2)+'\n');console.log(JSON.stringify(checks));
}finally{await browser?.close();server.stop(true);}
