import sys,types,pathlib,importlib.util,unittest,io,json,hashlib,ast,copy
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;F=R/'frozen';OLD=pathlib.Path('/private/tmp/truss-native-source-descriptor-astra-20261016');checks=[]
def check(n,v):
 checks.append({'id':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
m=json.loads((F/'manifest.json').read_text())
for p,h in m['files'].items():
 b=(F/p).read_bytes();check('packet-pin:'+p,len(b)==h['bytes']and hashlib.sha256(b).hexdigest()==h['sha256'])
for name,old in [('packages/python/src/truss/_native_source_descriptor.py',OLD/'frozen'),('packages/python/src/truss/_owner_evidence_json.py',OLD/'baseline'),('docs/helix/02-design/technical-designs/native-source-binding.md',OLD/'frozen')]:check('unchanged:'+name,(F/name).read_bytes()==(old/name).read_bytes())
oldTree=ast.parse((OLD/'frozen/packages/python/tests/test_native_source_descriptor.py').read_bytes());newTree=ast.parse((F/'packages/python/tests/test_native_source_descriptor.py').read_bytes())
oldClass=next(x for x in oldTree.body if isinstance(x,ast.ClassDef));newClass=next(x for x in newTree.body if isinstance(x,ast.ClassDef));newMethods={x.name:x for x in newClass.body if isinstance(x,ast.FunctionDef)}
for method in oldClass.body:
 if isinstance(method,ast.FunctionDef):check('retained-method:'+method.name,ast.dump(method,include_attributes=False)==ast.dump(newMethods[method.name],include_attributes=False))
pkg=types.ModuleType('truss');pkg.__path__=[str(F/'packages/python/src/truss')];sys.modules['truss']=pkg
spec=importlib.util.spec_from_file_location('review_tests',F/'packages/python/tests/test_native_source_descriptor.py');tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
stream=io.StringIO();res=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests));(R/'tests.log').write_text(stream.getvalue());check('15-authored-tests',res.testsRun==15 and res.wasSuccessful())
case=tests.NativeSourceDescriptorTests();case.setUp();nodes=[]
for n,last in [(1_000_000,1338),(1_000_001,1339)]:
 value={'releaseId':'layout-r1','opaque':[['']*3900 for _ in range(256)]+[['']*last]}
 pending=[(value,0)];count=0;depth=0
 while pending:
  obj,d=pending.pop();count+=1;depth=max(depth,d)
  if type(obj)is dict:pending.extend((x,d+1)for x in obj.keys());pending.extend((x,d+1)for x in obj.values())
  elif type(obj)is list:pending.extend((x,d+1)for x in obj)
 check('independent-exact-node-count:'+str(n),count==n)
 raw=tests.wire(value);check('node-test-within-byte-budget:'+str(n),len(raw)<4_000_000)
 try:obj=case.with_runtime_source(raw);outcome='accepted';check('node-raw-preserved:'+str(n),obj.runtime_release==raw)
 except ValueError as e:outcome='refused';check('node-refusal-cause:'+str(n),'tree capacity'in str(e))
 check('node-boundary:'+str(n),outcome==('accepted'if n==1_000_000 else'refused'));nodes.append({'nodes':n,'rawBytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'maximumDepth':depth,'outcome':outcome})
# Full numeric token includes sign, fractional marker, and exponent syntax.
for token,expected in [('-'+'1'*511,True),('-'+'1'*512,False),('1.'+'0'*505+'e+123',True),('1.'+'0'*506+'e+123',False)]:
 raw=b'{"releaseId":"layout-r1","opaque":'+token.encode()+b'}'
 try:d=case.with_runtime_source(raw);outcome=True;check('numeric-raw:'+str(len(checks)),d.runtime_release==raw)
 except ValueError as e:outcome=False;check('numeric-cause:'+str(len(checks)),'token capacity'in str(e))
 check('numeric-token:'+str(len(token))+':'+token[:2],outcome==expected)
(R/'review-controls.json').write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks),'authoredTests':15,'exactNodeControls':nodes,'scope':'Additive pure capacity repair; unchanged production bytes and original tests; no native SQL/authority or package installation qualification. Supplied node test straddles the limit; independent controls additionally test exactly 1,000,000 and1,000,001 nodes.'},indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(checks),'tests':15,'nodes':nodes}))
