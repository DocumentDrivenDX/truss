from pathlib import Path
import json,hashlib
r=Path(__file__).parent;old=Path('/private/tmp/truss-native-source-descriptor-astra-20261016')
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
report={
 'review':'Native-source descriptor R2 capacity-profile correction',
 'status':'passed','remainingFindings':[],
 'packet':{'path':'review.zip',**pin(r/'review.zip')},
 'originalReview':{'path':str(old/'review.json'),**pin(old/'review.json'),'finding':'NSB-DOC-01','preservedUnchanged':True},
 'resolvedFindings':[{'id':'NSB-DOC-01','resolution':'CONTRACT-013 explicitly declares modules1..256 and strict JSON number-token512, object/array4096, root-depth0/max128 and node1,000,000 limits, applied to every original and each nested documentJson scan. Test plan adds paired capacity controls. Existing implementation limits are unchanged.'}],
 'sourceCorrespondence':{
  'descriptorSha256':pin(r/'frozen/packages/python/src/truss/_native_source_descriptor.py')['sha256'],
  'decoderSha256':pin(r/'frozen/packages/python/src/truss/_owner_evidence_json.py')['sha256'],
  'result':'Descriptor and design byte-identical to R1; decoder byte-identical to exact R1 baseline helper; all original test methods retained with no AST change.'
 },
 'validation':{
  'command':'/private/tmp/truss-practical-performance-env/bin/python -B review-controls.py',
  'result':'15 authored tests and39 independent checks passed',
  'logs':['tests.log','review-controls.log'],'receipt':'review-controls.json',
  'independentControls':'Exact packet pins, production/design byte correspondence, original test retention, full signed/fraction/exponent numeric-token boundaries, and independently counted exactly1,000,000/1,000,001-node originals with matching recomputed source hashes.',
  'nodeBoundary':{'accepted':1000000,'refused':1000001,'acceptedBytes':2999764,'refusedBytes':2999767,'depth':3},
  'qualification':'The added authored node test straddles the limit (998,661/1,002,562 nodes); the reviewer separately exercised exact boundary and first failure. No product source change required.'
 },
 'governanceReview':'docs-review/report.json',
 'scope':'Additive capacity-contract correction only. Pure supplied-data structural correspondence remains incomplete, authority:false, securityReady:false and nativeAdmission:required. No native capture/SQL, UMF semantic or Field/Key/edge/codec mapping, current source/caller authority, registration or guarded-release qualification. No original132/shared158 case promotion. R1 review and finding remain immutable; this separate addendum records closure.',
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256, bytes}; every retained file except top-level manifest'}
}
assert (r/'docs-review/report.json').is_file()
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={p.relative_to(r).as_posix():pin(p)for p in sorted(r.rglob('*'))if p.is_file()and p!=r/'manifest.json'and'__pycache__'not in p.parts};(r/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
for n,v in files.items():assert pin(r/n)==v,n
print(json.dumps({'review':pin(r/'review.json'),'manifest':pin(r/'manifest.json'),'artifacts':len(files),'totalBytes':sum(v['bytes']for v in files.values())},indent=2))
