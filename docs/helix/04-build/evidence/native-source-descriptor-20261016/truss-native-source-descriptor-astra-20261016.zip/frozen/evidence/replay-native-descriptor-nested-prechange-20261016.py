"""Reconstructed previous-source diagnostic, not native or authority proof."""
from pathlib import Path
from hashlib import sha256
import sys,types,json
root=Path('/private/tmp/truss-native-source-binding-owner-20261016')
sys.path[:0]=[str(root/'packages/python/src'),str(root/'packages/python/tests')]
source=(root/'packages/python/src/truss/_native_source_descriptor.py').read_bytes()
block=b"""        document=decode_owner_evidence_json(module['documentJson'].encode())
        if type(document) is not dict or document.get('id')!=identity or document.get('umf')!=pin['umfVersion']:
            raise ValueError('Strict original model object/identity correspondence required')
"""
assert source.count(block)==1
old=source.replace(block,b'');captured=Path('/private/tmp/native-source-descriptor-pre-nested-scan-20261016.py');captured.write_bytes(old)
module=types.ModuleType('truss._native_source_descriptor_prechange');module.__package__='truss';sys.modules[module.__name__]=module
exec(compile(old,str(captured),'exec'),module.__dict__)
from test_native_source_descriptor import NativeSourceDescriptorTests,wire
fixture=NativeSourceDescriptorTests();fixture.setUp();request=json.loads(fixture.request);assessment=json.loads(fixture.assessment)
raw='{"id":"d","id":"d","umf":"0.8.0"}'
request['modules'][0]['documentJson']=raw;digest=sha256(raw.encode()).hexdigest();request['modules'][0]['pin']['sha256']=digest;assessment['modelPins'][0]['sha256']=digest
arguments=dict(accepted_request=wire(request),accepted_assessment=wire(assessment),runtime_release=fixture.release,native_inventory=wire(fixture.inventory))
previous=module.prepare_native_source_descriptor(**arguments);assert json.loads(previous.json)['authority'] is False
from truss._native_source_descriptor import prepare_native_source_descriptor
try:prepare_native_source_descriptor(**arguments)
except ValueError:pass
else:raise AssertionError('Malformed nested original accepted after repair')
result={'status':'reproduced-and-repaired','scope':'Reconstructed previous source differs by exact added nested strict-scan block; data-only old envelope accepted malformed duplicate-key nested source, repaired rejects. No native SQL/authorization or case promotion.','prechangeSourceSha256':sha256(old).hexdigest(),'currentSourceSha256':sha256(source).hexdigest(),'nestedDocumentJson':raw,'acceptedRequestSha256':sha256(arguments['accepted_request']).hexdigest()}
Path('/private/tmp/native-source-descriptor-nested-repair-20261016.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'nativeSQL':False}))
