import sys,types,pathlib,importlib.util,unittest,io,json,hashlib,copy,time,dataclasses
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent
pkg=types.ModuleType('truss');pkg.__path__=[str(R/'frozen/packages/python/src/truss'),str(R/'baseline/packages/python/src/truss')];sys.modules['truss']=pkg
from truss._native_source_descriptor import prepare_native_source_descriptor
spec=importlib.util.spec_from_file_location('review_supplied_tests',R/'frozen/packages/python/tests/test_native_source_descriptor.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
out=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromModule(mod);result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite);(R/'supplied-tests.log').write_text(out.getvalue());assert result.wasSuccessful()and result.testsRun==10
case=mod.NativeSourceDescriptorTests();case.setUp();wire=mod.wire;checks=[]
def check(n,condition):
 checks.append({'id':n,'passed':bool(condition)})
 if not condition:raise AssertionError(n)
def go(name,mutate=None,accept=False,overrides=None):
 inv=copy.deepcopy(case.inventory)
 if mutate:mutate(inv)
 try:d=case.prepare(inv,**(overrides or {}))
 except ValueError:check(name,not accept);return None
 check(name,accept)
 report=json.loads(d.json);check(name+':false-authority',report['authority']is False and report['complete']is False and report['securityReady']is False and report['nativeAdmission']=='required')
 originals=[d.accepted_request,d.accepted_assessment,d.runtime_release,d.native_inventory]
 check(name+':exact-references',len(report['sources'])==4 and all(s['sha256']==hashlib.sha256(b).hexdigest()and s['utf8Bytes']==len(b)for s,b in zip(report['sources'],originals)))
 return d
for path in [(),('database',),('schema',),('release',),('relations',0),('relations',0,'columns',0)]:
 def target(i):
  for key in path:i=i[key]
  return i
 obj=target(case.inventory)
 for key in list(obj):go('missing:'+str(path)+':'+key,lambda i,k=key:target(i).pop(k))
 go('extra:'+str(path),lambda i:target(i).__setitem__('x',1))
# Every numeric locator is noncoercive and canonical; zero is allowed only for collation.
numbers=[(('database','systemIdentifier'),64,False),(('database','oid'),32,False),(('schema','oid'),32,False),(('relations',0,'oid'),32,False),(('relations',0,'ownerOid'),32,False),(('relations',0,'columns',0,'typeOid'),32,False),(('relations',0,'columns',0,'collationOid'),32,True)]
def put(i,path,value):
 for k in path[:-1]:i=i[k]
 i[path[-1]]=value
for path,bits,zero in numbers:
 for value in [True,1,None,[],{},'','-1','+1','01',' 1','1 ','1.0','1e0','１','\0','9'*21,str(2**bits)]:go('integer-invalid:'+str(path)+':'+repr(value),lambda i,p=path,v=value:put(i,p,v))
 for value in ['1',str(2**bits-1)]:go('integer-boundary:'+str(path)+':'+value,lambda i,p=path,v=value:put(i,p,v),True)
 go('integer-zero:'+str(path),lambda i,p=path:put(i,p,'0'),zero)
colpath=('relations',0,'columns',0)
for field,values in [('attnum',[False,1.0,'1',0,-1,32768]),('typmod',[False,1.0,'1',-(2**31)-1,2**31]),('notNull',[0,1,'false',None]),('dropped',[0,1,'false',None]),('generated',[0,False,None,'x']),('identity',[0,False,None,'x'])]:
 for v in values:go('column-invalid:'+field+':'+repr(v),lambda i,p=colpath+(field,),v=v:put(i,p,v))
for field,values in [('attnum',[1,32767]),('typmod',[-(2**31),0,2**31-1]),('notNull',[False,True]),('dropped',[False,True]),('generated',['','s','v']),('identity',['','a','d'])]:
 for v in values:go('column-boundary:'+field+':'+repr(v),lambda i,p=colpath+(field,),v=v:put(i,p,v),True)
for path in [('database','name'),('relations',0,'name'),colpath+('name',)]:
 for v in ['',None,12,'a'*64,'é'*32,'\0','a\0b','\ud800']:go('name-invalid:'+str(path)+':'+repr(v),lambda i,p=path,v=v:put(i,p,v))
 for v in ['a'*63,'é'*31+'x','𐀀'*15+'abc','quote";--','a\nb']:go('name-exact:'+str(path)+':'+repr(v),lambda i,p=path,v=v:put(i,p,v),True)
# Distinctness is scoped, exact, and order-preserving data.
go('same-oid-different-name',lambda i:i['relations'].append(dict(i['relations'][0],name='different')))
go('same-name-different-oid',lambda i:i['relations'].append(dict(i['relations'][0],oid='55')))
go('same-attnum-different-name',lambda i:i['relations'][0]['columns'].append(dict(i['relations'][0]['columns'][0],name='different')))
go('same-name-different-attnum',lambda i:i['relations'][0]['columns'].append(dict(i['relations'][0]['columns'][0],attnum=3)))
go('exact-case-distinct-names',lambda i:i['relations'].append(dict(i['relations'][0],oid='55',name='Object')),True)
for count in [0,256,257]:
 go('relations:'+str(count),lambda i,n=count:i.__setitem__('relations',[dict(i['relations'][0],oid=str(100+k),name='r'+str(k))for k in range(n)]),count==256)
for count in [0,4096,4097]:
 go('columns:'+str(count),lambda i,n=count:i['relations'][0].__setitem__('columns',[dict(i['relations'][0]['columns'][0],attnum=k+1,name='c'+str(k))for k in range(n)]),count==4096)
# Recompute all model hashes to isolate lexical/identity scanning, not stale-hash refusal.
def nested(raw,pin_update=None):
 req=json.loads(case.request);ass=json.loads(case.assessment);pin=req['modules'][0]['pin'];pin.update(pin_update or {});pin['sha256']=hashlib.sha256(raw.encode()).hexdigest();req['modules'][0]['documentJson']=raw;ass['modelPins']=[copy.deepcopy(pin)];return {'accepted_request':wire(req),'accepted_assessment':wire(ass)}
for raw in ['{"id":"d","\\u0069d":"d","umf":"0.8.0"}','{"id":"d","umf":"0.8.0","a":{"x":1,"x":2}}','{"id":"d","umf":"0.8.0","a":"\\udfff"}','{"id":"d","umf":"0.8.0","a":Infinity}','{"id":"d","umf":"0.8.0","a":'+('9'*513)+'}','{"id":"d","umf":"0.8.0"}false']:
 go('nested-refuse:'+hashlib.sha256(raw.encode()).hexdigest()[:10],overrides=nested(raw))
for value in ['1.2300e-999999','-'+'9'*512,'-0.000e+4']:
 raw='{"id":"d","umf":"0.8.0","opaque":'+value+'}';d=go('nested-exact-number:'+value[:12],accept=True,overrides=nested(raw));check('nested-raw-retrievable:'+value[:12],json.loads(d.accepted_request)['modules'][0]['documentJson']==raw)
for key in ['documentId','revision','umfVersion']:
 for value in ['',False,1,'x'*4097]:
  args=nested(case.document,{key:value});go('pin-invalid:'+key+':'+repr(value)[:20],overrides=args)
# Per-original exact byte bound with all dependent pins recomputed.
for size in [4_000_000,4_000_001]:
 prefix=b'{"releaseId":"layout-r1","pad":"';suffix=b'"}';raw=prefix+b'x'*(size-len(prefix)-len(suffix))+suffix
 ass=json.loads(case.assessment);ass['releaseSha256']=hashlib.sha256(raw).hexdigest()
 go('release-byte-boundary:'+str(size),lambda i,h=ass['releaseSha256']:i['release'].__setitem__('sha256',h),size==4_000_000,{'runtime_release':raw,'accepted_assessment':wire(ass)})
# UTF-8 and parser boundaries are inherited from the exact baseline decoder.
for raw in [b'\xff',b'\xef\xbb\xbf{}',b'{"x":-Infinity}',b'{"x":"\xed\xa0\x80"}']:
 go('raw-invalid:'+raw.hex(),overrides={'accepted_request':raw})
# Raw source mutation is not possible through the issued frozen byte object.
d=go('baseline',accept=True)
try:d.json=b'{}'
except dataclasses.FrozenInstanceError:check('frozen-instance',True)
else:check('frozen-instance',False)
# Retained exact loaded local source closure, not a package-installation claim.
pins={str(pathlib.Path(m.__file__).resolve()):{'sha256':hashlib.sha256(pathlib.Path(m.__file__).read_bytes()).hexdigest(),'bytes':len(pathlib.Path(m.__file__).read_bytes())}for name,m in sys.modules.items()if name.startswith('truss.')and getattr(m,'__file__',None)}
(R/'independent-controls.json').write_text(json.dumps({'status':'passed','suppliedTests':10,'checks':checks,'count':len(checks),'sourcePins':pins,'scope':'Actual frozen private descriptor plus exact baseline decoder loaded in isolated namespace; pure supplied data only, no package/public export/native/authority qualification.'},indent=2)+'\n');print(json.dumps({'status':'passed','suppliedTests':10,'checks':len(checks)}))
