import sys,types,pathlib,hashlib,json,importlib.util
sys.dont_write_bytecode=True
r=pathlib.Path(__file__).parent;f=r/'frozen'
pkg=types.ModuleType('truss');pkg.__path__=[str(f/'packages/python/src/truss'),str(r/'baseline/packages/python/src/truss')];sys.modules['truss']=pkg
from truss._native_source_descriptor import prepare_native_source_descriptor
spec=importlib.util.spec_from_file_location('review_tests',f/'packages/python/tests/test_native_source_descriptor.py');tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests);case=tests.NativeSourceDescriptorTests();case.setUp()
old=(f/'evidence/native-source-descriptor-pre-nested-scan-20261016.py').read_bytes();new=(f/'packages/python/src/truss/_native_source_descriptor.py').read_bytes();block=b"""        document=decode_owner_evidence_json(module['documentJson'].encode())
        if type(document) is not dict or document.get('id')!=identity or document.get('umf')!=pin['umfVersion']:
            raise ValueError('Strict original model object/identity correspondence required')
""";assert new.count(block)==1 and new.replace(block,b'')==old
m=types.ModuleType('truss.review_prechange');m.__package__='truss';sys.modules[m.__name__]=m;exec(compile(old,'<retained-exact-prechange>','exec'),m.__dict__)
controls=[]
for raw in ['{"id":"d","id":"d","umf":"0.8.0"}','{','[]','{"id":"other","umf":"0.8.0"}','{"id":"d","umf":"0.7.0"}','{"id":"d","umf":"0.8.0","x":NaN}']:
 req=json.loads(case.request);ass=json.loads(case.assessment);req['modules'][0]['documentJson']=raw;digest=hashlib.sha256(raw.encode()).hexdigest();req['modules'][0]['pin']['sha256']=digest;ass['modelPins'][0]['sha256']=digest
 args={'accepted_request':tests.wire(req),'accepted_assessment':tests.wire(ass),'runtime_release':case.release,'native_inventory':tests.wire(case.inventory)}
 prior=m.prepare_native_source_descriptor(**args);assert json.loads(prior.json)['authority']is False
 try:prepare_native_source_descriptor(**args)
 except ValueError as err:controls.append({'nested':raw,'matchingHash':digest,'oldAccepted':True,'currentRefused':True,'message':str(err)})
 else:raise AssertionError(raw)
(r/'nested-repair-controls.json').write_text(json.dumps({'status':'passed','cases':controls,'count':len(controls),'oldSourceSha256':hashlib.sha256(old).hexdigest(),'newSourceSha256':hashlib.sha256(new).hexdigest(),'scope':'Exact retained reconstructed prechange source and repaired source; demonstrates six matching-hash nested data refusals, not original historical execution or native authority.'},indent=2)+'\n');print('6 exact reconstructed old/new controls passed')
