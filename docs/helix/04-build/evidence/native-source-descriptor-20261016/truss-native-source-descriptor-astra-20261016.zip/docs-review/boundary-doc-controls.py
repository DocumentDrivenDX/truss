"""Focused contract-capacity examples using frozen descriptor and exact baseline decoder."""
import hashlib,importlib.util,json,pathlib,subprocess,sys,types
sys.dont_write_bytecode=True
root=pathlib.Path(__file__).parent;frozen=root.parent/'frozen';base='430b77b96373e05d20e513cbd048980d9e8031f1';rel='packages/python/src/truss/_owner_evidence_json.py';helper=subprocess.check_output(['git','show',base+':'+rel],cwd='/Users/erik/Projects/truss');(root/'baseline-owner-evidence-json.py').write_bytes(helper)
pkg=types.ModuleType('truss');pkg.__path__=[];sys.modules['truss']=pkg
for name,path in [('truss._owner_evidence_json',root/'baseline-owner-evidence-json.py'),('truss._native_source_descriptor',frozen/'packages/python/src/truss/_native_source_descriptor.py'),('fixture',frozen/'packages/python/tests/test_native_source_descriptor.py')]:
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
fixture=sys.modules['fixture'].NativeSourceDescriptorTests();fixture.setUp();wire=lambda value:json.dumps(value,separators=(',',':')).encode();sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check_release(label,raw,expected):
 inventory=json.loads(wire(fixture.inventory));inventory['release']['sha256']=sha(raw)
 assessment=json.loads(fixture.assessment);assessment['releaseSha256']=sha(raw)
 try:
  result=fixture.prepare(inventory,runtime_release=raw,accepted_assessment=wire(assessment));actual='accepted';error=None
  assert result.runtime_release==raw and json.loads(result.json)['authority']is False
 except ValueError as e:actual='refused';error=str(e)
 assert actual==expected
 checks.append(dict(id=label,bytes=len(raw),result=actual,error=error,passed=True))
for n in [4096,4097]:check_release('unknown-object-members-'+str(n),wire({'releaseId':'layout-r1','unknown':{str(i):None for i in range(n)}}),'accepted'if n==4096 else'refused')
for n in [512,513]:check_release('unknown-number-token-'+str(n),b'{"releaseId":"layout-r1","unknown":'+b'9'*n+b'}','accepted'if n==512 else'refused')
for n in [256,257]:
 request=json.loads(fixture.request);assessment=json.loads(fixture.assessment);request['modules']=[];assessment['modelPins']=[]
 for i in range(n):
  document=wire({'id':'d'+str(i),'umf':'0.8.0'}).decode();pin=dict(documentId='d'+str(i),revision='r',umfVersion='0.8.0',sha256=sha(document.encode()));request['modules'].append(dict(pin=pin,documentJson=document));assessment['modelPins'].append(pin)
 try:fixture.prepare(accepted_request=wire(request),accepted_assessment=wire(assessment));actual='accepted';error=None
 except ValueError as e:actual='refused';error=str(e)
 assert actual==('accepted'if n==256 else'refused')
 checks.append(dict(id='modules-'+str(n),requestBytes=len(wire(request)),assessmentBytes=len(wire(assessment)),result=actual,error=error,passed=True))
r=dict(scope='Six pure data-only structural capacity controls; no native or semantic acceptance.',base=base,decoderPath=rel,decoderSha256=sha(helper),descriptorSha256=sha((frozen/'packages/python/src/truss/_native_source_descriptor.py').read_bytes()),probeSha256=sha(pathlib.Path(__file__).read_bytes()),checks=checks);(root/'boundary-doc-controls.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
