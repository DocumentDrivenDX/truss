from pathlib import Path
import json,hashlib
r=Path(__file__).parent
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
doc=json.loads((r/'docs-review/report.json').read_text())
report={
 'review':'Truss native-source descriptor structural spike R1',
 'status':'one-narrow-documentation-finding','baseline':'430b77b96373e05d20e513cbd048980d9e8031f1',
 'packet':{'path':'review.zip',**pin(r/'review.zip')},
 'source':{'path':'frozen/packages/python/src/truss/_native_source_descriptor.py',**pin(r/'frozen/packages/python/src/truss/_native_source_descriptor.py')},
 'findings':doc['findings'],'remainingFindings':['NSB-DOC-01'],
 'conclusion':'No additional functional or false-authority defect found in this supplied-data structural envelope. Complete the normative capacity-profile declaration before treating CONTRACT-013 as the frozen structural contract. Keep current guards; no broader binding/native admission follows.',
 'validation':[
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B independent-controls.py','result':'10 authored tests and 402 independent checks passed','receipts':['supplied-tests.log','independent-controls.json','independent-controls.log']},
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B nested-repair-controls.py','result':'6 exact reconstructed prechange/current comparisons passed; old source accepts matching-hash malformed or mismatched nested documents, current source refuses','receipts':['nested-repair-controls.json','nested-repair-controls.log']},
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B docs-review/boundary-doc-controls.py','result':'6 paired pure boundary controls confirm the undeclared object, numeric-token and module capacities','receipts':['docs-review/boundary-doc-controls.json','docs-review/report.json']}
 ],
 'independentCoverage':[
  'All nine packet manifest entries verified; exact baseline shared decoder captured from Git and pinned. Tests load only these frozen private modules in an isolated namespace, not an installed-package/public API cohort.',
  'Closed inventory/nested shapes; every numeric native locator field with canonical uint32/uint64 endpoints, zero policy and invalid coercions; integer attnum/typmod ranges; exact Boolean/generated/identity flags; UTF-8 63-byte names, NUL/surrogates and case-distinct names.',
  'Relation/name and column/attnum uniqueness; 256/257 relations and 4096/4097 columns; matching-hash nested JSON duplicates, malformed text, nonfinite numbers and id/umf mismatch; raw source preservation and four exact hash/size references.',
  'Exact 4,000,000-byte original release accepted and 4,000,001 refused after dependent pins are recomputed. Large exact integers/decimals remain raw; parser numeric-token limits include signs.',
  'Every successful independent case retains complete/authority/securityReady false and nativeAdmission required. Issued object is frozen and retains original immutable source bytes.'
 ],
 'scope':[
  'Data-only structural correspondence of supplied originals. No native observation, semantic UMF validation, Field/Record/Key/edge/codec mapping, source continuity, registration, authenticated caller/current authority, SQL execution or guarded-release proof.',
  'Metadata OIDs, names, type/flag labels and equal copied identities do not establish actual native catalog states, identity continuity, comparator semantics or authority.',
  'The new design/test plan correctly retain future native binding/witness requirements. All original Truss132/shared158 allocations remain unchanged; no case promoted.',
  'External Python runtime and standard library are non-hermetic. This review pins exact selected source bytes; it does not claim continuously held files or ABA exclusion.'
 ],
 'retainedHistory':[
  'Original supplied reconstructed pre-nested-scan source, diagnostic script, failure/repair receipt and R1 ZIP remain unchanged. Reviewer old/new replay is separately labeled reconstruction, not historical execution.',
  'Reviewer first numerical-boundary expectation used 512 digits plus a minus sign, a 513-character token. That harness failure and source are retained as independent-controls-first.*; corrected total512-character input passes without product edits.'
 ],
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256, bytes}; all retained files except this top-level manifest'}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={p.relative_to(r).as_posix():pin(p) for p in sorted(r.rglob('*'))if p.is_file()and p!=r/'manifest.json'and'__pycache__'not in p.parts};(r/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
for n,v in files.items():assert pin(r/n)==v,n
print(json.dumps({'review':pin(r/'review.json'),'manifest':pin(r/'manifest.json'),'artifacts':len(files),'totalBytes':sum(v['bytes']for v in files.values())},indent=2))
