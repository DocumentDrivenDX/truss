from pathlib import Path
import ast,hashlib,json,subprocess,shutil,sys,unittest,importlib.util,io,tarfile
p=Path(__file__).resolve().parent;src=Path('/private/tmp/truss-raw-capture-profile-repair-review-r2-20261016');base='1972e596cc07263518c9a63cf0ccffee34b1d541';repo='/Users/erik/Projects/truss';H=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((src/'manifest.json').read_bytes())
for n,h in m.items():
 b=(src/n).read_bytes();assert H(b)==h,n;t=p/'packet'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
(p/'packet/manifest.json').write_bytes((src/'manifest.json').read_bytes())
name='packages/python/src/truss/_current_query_facts.py';old=subprocess.check_output(['git','-C',repo,'show',base+':'+name]);new=(src/name).read_bytes();a=ast.parse(old);b=ast.parse(new);c=next(n for n in b.body if isinstance(n,ast.ClassDef) and n.name=='CurrentQueryFactCapture');props=[n for n in c.body if isinstance(n,ast.FunctionDef) and n.name in ('graphs_bytes','graph_coverage_bytes')];assert len(props)==2
for n in props:
 assert len(n.decorator_list)==1 and isinstance(n.decorator_list[0],ast.Name) and n.decorator_list[0].id=='property'
 assert len(n.body)==1 and isinstance(n.body[0],ast.Return) and isinstance(n.body[0].value,ast.Constant) and n.body[0].value.value==b'[]'
 c.body.remove(n)
assert ast.dump(a)==ast.dump(b),'Unexpected change outside two read-only properties'
(p/'baseline-current-query-facts.py').write_bytes(old)
work=p/'working';shutil.copytree('/private/tmp/truss-graph-cohort-enrollment-review-result-20261016/working',work)
tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base,'packages/python/tests']))).extractall(work)
for n in [name,'packages/python/tests/test_current_disclosure_cohort.py']:(work/n).write_bytes((src/n).read_bytes())
sys.path[:0]=[str(work/'packages/python/src'),str(work/'packages/python/tests')]
spec=importlib.util.spec_from_file_location('repair_tests',work/'packages/python/tests/test_current_disclosure_cohort.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
with (p/'pure-tests.log').open('w') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(mod.RawCaptureProfileTests));assert result.wasSuccessful() and result.testsRun==1
from truss._current_query_facts import CurrentQueryFactCapture,_recipes
from test_current_disclosure_graphs import fixture
sources,_,_,_=fixture();init=json.loads(sources.initialize_bytes);init['sources']['ontology']['context']=[]
checks=[]
for kind in ['core-relationship','unknown',None]:
 q=json.loads(json.dumps(init));q['sources']['ontology']['associations']=[{} if kind is None else {'kind':kind}];sources.initialize_bytes=json.dumps(q).encode()
 try:_recipes(sources)
 except ValueError as e:assert 'Native graph fact capture remains required' in str(e);checks.append('association '+str(kind)+' refused')
 else:raise AssertionError(kind)
facts=b'[ {"number":1e+02} ]';coverage=b'[{"complete":false}]';c=CurrentQueryFactCapture(sources,facts,coverage,());assert c.facts_bytes is facts and c.coverage_bytes is coverage and c.graphs_bytes==c.graph_coverage_bytes==b'[]';checks.append('original fact/coverage bytes retained, including false completeness')
for name in ('graphs_bytes','graph_coverage_bytes'):
 try:setattr(c,name,b'[1]')
 except (AttributeError,TypeError):checks.append(name+' read-only')
 else:raise AssertionError('writable property')
first=(src/'native-cohort-replay-authorized.log').read_text();final=(src/'native-cohort-raw-profile-repair.log').read_text();assert 'FAILED' in first and 'graphs_bytes' in first and 'Ran 6 tests in 34.986s' in final and '\nOK\n' in final
cleanup=json.loads((src/'native-cleanup.json').read_text());assert cleanup['passed'] and not cleanup['newFixtureRoots'] and not cleanup['liveFixturePostgres']
report={'passed':True,'base':base,'frozenFilesVerified':len(m),'onlyTwoReadonlyEmptyProperties':True,'allOtherSourceASTExact':True,'pureRegressionTests':1,'additionalControls':checks,'suppliedNative':'initial 1 pass / 5 failures; repaired 6 pass, 34.986s; no reviewer native execution','cleanupScope':'supplied prefix process scan and root birth-time comparison; no new fixture roots/live fixture PostgreSQL; three older roots retained','SQLExecuted':False}
(p/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
