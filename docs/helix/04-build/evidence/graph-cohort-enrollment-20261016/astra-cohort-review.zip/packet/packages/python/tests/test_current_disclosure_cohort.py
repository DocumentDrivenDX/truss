"""Packaged computation custody only; no native authority or held-file proof."""
import pathlib,shutil,tempfile,unittest
from unittest.mock import patch
from truss._current_disclosure_computation import verify_current_disclosure_owner_assets

class DisclosureCohortTests(unittest.TestCase):
 def test_enrolled_assets_verify_and_each_source_stage_mutation_refuses(self):
  enrolled=verify_current_disclosure_owner_assets()
  with tempfile.TemporaryDirectory(prefix='truss-disclosure-assets-') as directory:
   package=pathlib.Path(directory);assets=package/'_current_disclosure_owner'
   shutil.copytree(str(enrolled),assets)
   with patch('truss._current_disclosure_computation.files',return_value=package):
    self.assertEqual(verify_current_disclosure_owner_assets(),assets)
    for name in ('consumer-manifest.json','manifest.json','current-native-disclosure-child.mjs','notices/ajv/LICENSE'):
     path=assets/name;original=path.read_bytes()
     try:
      path.write_bytes(original+b'\nchanged-source')
      with self.subTest(source=name),self.assertRaises(ValueError):
       verify_current_disclosure_owner_assets()
     finally:path.write_bytes(original)
     self.assertEqual(verify_current_disclosure_owner_assets(),assets)

if __name__=='__main__':unittest.main()
