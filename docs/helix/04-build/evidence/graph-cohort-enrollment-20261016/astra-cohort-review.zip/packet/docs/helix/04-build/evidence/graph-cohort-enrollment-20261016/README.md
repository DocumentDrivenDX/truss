# Explicit disclosure semantic cohort enrollment

This replaces the explicit local candidate's UMF 206951/d333 child with the
UMF11b412/548b child built by the original builder on Bun1.4.2. The source closure
has the same 257 paths: exactly `catalog-runtime-candidate.ts` changes. That
change stops pure AND/OR/EXISTS evaluation at absorbing truth values after
unchanged full dependency preflight. The prior UMF condition-short-circuit
packet retains independent review, browser/mutation checks and conditional F/U/T
algebra evidence. It does not prove TypeScript/native refinement or budget
adequacy. No operation limit, authority guard or Weft pin changes here.

The source snapshot and generated assets are retained in
`built-child-and-sources.zip`; original and replacement runtime files plus both
source manifests permit byte-level closure comparison. The consumer manifest,
asset manifest digest and exact cohort coordinates change together. The old
fixture provenance remains historical; it is not relabeled as new execution.

All15 supplied graph cases pass on the replacement child, including the three
parallel cases that refused in the prior packaged cohort. Their expected-failure
markers are removed without changing assertions or expected resources. The
focused source run passes27 tests, with no skips or expected failures. Four
independent asset-stage mutations (consumer manifest, build manifest, bundle,
license notice) refuse, followed by successful exact restoration checks.

The actual exact-a944 Weft/child/simulated-SQL composition passes all66 vectors
(46 rendered,20 refused, six fixture generations replaced by the simulated host
generation). A second replay strengthens refusal assertions to require the
semantic result boundary: unrelated startup/codec/asset errors cannot count as
expected refusal. Both passing logs are retained. This remains simulated SQL,
not a native graph or release proof.

The first candidate replay observed Homebrew Bun1.4.3 and failed the unchanged
Bun1.4.2 guard before child initialization. Its full failed log is preserved.
Passing replays explicitly select retained Cellar1.4.2; the test-only environment
selection does not broaden the product runtime pin. Runtime identity is retained
in `runtime.json`. No global toolchain was changed.

Native replay is a separate gate. The initial sandbox attempt could not acquire
pgserver's cache lock and executed zero tests; it is not evidence of a product
failure or success. The authorized isolated six-test replay and cleanup record
will be retained separately on completion. All backend acceptance cases remain
required; this enrollment alone promotes none. In particular native graph
source admission, typed graph compiler correspondence, whole codec/facet
semantics and authenticated current authority/closing release remain open.
