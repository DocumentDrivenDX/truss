from pathlib import Path
import hashlib,json,zipfile,io,subprocess,ast,tarfile,unittest,importlib.util,sys,difflib
r=Path(__file__).resolve().parent;o=Path('/private/tmp/truss-graph-cohort-enrollment-review-20261016');repo='/Users/erik/Projects/truss';m=json.loads((o/'manifest.json').read_bytes());base=m['base'];H=lambda b:hashlib.sha256(b).hexdigest();git=lambda path:subprocess.check_output(['git','-C',repo,'show',base+':'+path]);e=o/'docs/helix/04-build/evidence/graph-cohort-enrollment-20261016';assets=o/'packages/python/src/truss/_current_disclosure_owner'
for n,h in m['files'].items():b=(o/n).read_bytes();assert H(b)==h,n;t=r/'packet'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
(r/'packet/manifest.json').write_bytes((o/'manifest.json').read_bytes())
old=json.loads((e/'old-manifest.json').read_bytes());new=json.loads((assets/'manifest.json').read_bytes());assert (e/'old-manifest.json').read_bytes()==git('packages/python/src/truss/_current_disclosure_owner/manifest.json');assert len(old['sourcePins'])==len(new['sourcePins'])==257 and old['sourcePins'].keys()==new['sourcePins'].keys();changed=[n for n in old['sourcePins'] if old['sourcePins'][n]!=new['sourcePins'][n]];assert changed==['src/extensions/security/catalog-runtime-candidate.ts'];assert old['bun']==new['bun']=='1.4.2'
with zipfile.ZipFile(e/'built-child-and-sources.zip') as z:
 retention=json.loads(z.read('qualification-retention.json'))
 for n,h in retention['files'].items():assert H(z.read(n))==h,n
 with zipfile.ZipFile(io.BytesIO(z.read('qualification-source.zip'))) as q:
  assert set(q.namelist())==set(new['sourcePins']) and len(q.namelist())==257
  for n,h in new['sourcePins'].items():assert H(q.read(n))==h,n
  assert q.read(changed[0])==(e/'new-runtime.ts').read_bytes()
 for n in ['manifest.json','metafile.json','current-native-disclosure-child.mjs']:assert z.read(n)==(assets/n).read_bytes()
 qualification=json.loads(z.read('graph-transport-qualification.json'));assert len(qualification['cases'])==15 and all(c['passed'] for c in qualification['cases'])
consumer=json.loads((assets/'consumer-manifest.json').read_bytes());assert consumer['umfRevision']=='11b412e4a783fef8075aeb4109a286650a0bda28'
for n,h in consumer['files'].items():b=(assets/n).read_bytes() if (assets/n).exists() else git('packages/python/src/truss/_current_disclosure_owner/'+n);assert H(b)==h,n
assert new['bundleSha256']==consumer['files']['current-native-disclosure-child.mjs']
def assignment(raw,name):return next(n for n in ast.parse(raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
oldoriginal=git('packages/python/src/truss/_current_disclosure_originals.py');neworiginal=(o/'packages/python/src/truss/_current_disclosure_originals.py').read_bytes();oldc=ast.literal_eval(assignment(oldoriginal,'_CONSUMER_COHORTS').value);newc=ast.literal_eval(assignment(neworiginal,'_CONSUMER_COHORTS').value);assert len(oldc)==len(newc)==1;delta=[k for k in oldc[0] if oldc[0][k]!=newc[0][k]];assert set(delta)=={'umfRevision','umfBundleSha256','umfManifestSha256'}
assert newc[0]['umfRevision']==consumer['umfRevision'] and newc[0]['umfBundleSha256']==new['bundleSha256'] and newc[0]['umfManifestSha256']==H((assets/'manifest.json').read_bytes())
a=ast.parse(oldoriginal);b=ast.parse(neworiginal);assignment_node=lambda tree,name:next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets));assignment_node(b,'_CONSUMER_COHORTS').value=assignment_node(a,'_CONSUMER_COHORTS').value;assert ast.dump(a)==ast.dump(b)
a=ast.parse(git('packages/python/src/truss/_current_disclosure_computation.py'));b=ast.parse((o/'packages/python/src/truss/_current_disclosure_computation.py').read_bytes());assert ast.literal_eval(assignment_node(b,'_ASSET_MANIFEST_SHA256').value)==H((assets/'consumer-manifest.json').read_bytes());assignment_node(b,'_ASSET_MANIFEST_SHA256').value=assignment_node(a,'_ASSET_MANIFEST_SHA256').value;assert ast.dump(a)==ast.dump(b)
oldruntime=(e/'old-runtime.ts').read_bytes();newruntime=(e/'new-runtime.ts').read_bytes();assert H(oldruntime)==old['sourcePins'][changed[0]] and H(newruntime)==new['sourcePins'][changed[0]]
preold,postold=oldruntime.split(b' const evaluate=',1);prenew,postnew=newruntime.split(b' // Dependencies are preflighted above',1);assert preold==prenew;assert postold.split(b' const traces:',1)[1]==postnew.split(b' const traces:',1)[1]
prior=json.loads(Path('/private/tmp/umf-short-circuit-astra-20261016/review.json').read_bytes());assert prior['pins']['runtimeSha256']==H(newruntime) and prior['pins']['rebuiltBundleSha256']==new['bundleSha256'];(r/'prior-reviewed-optimization-pin.json').write_text(json.dumps({'reviewSha256':H(Path('/private/tmp/umf-short-circuit-astra-20261016/review.json').read_bytes()),'runtimeSha256':H(newruntime),'bundleSha256':new['bundleSha256']},indent=2)+'\n')
# Three former failure annotations removed; normalized bodies/assertions remain identical.
a=ast.parse(git('packages/python/tests/test_current_disclosure_graph_transport.py'));b=ast.parse((o/'packages/python/tests/test_current_disclosure_graph_transport.py').read_bytes());ca=next(n for n in a.body if isinstance(n,ast.ClassDef));cb=next(n for n in b.body if isinstance(n,ast.ClassDef));ma=[n for n in ca.body if isinstance(n,ast.FunctionDef)];mb=[n for n in cb.body if isinstance(n,ast.FunctionDef)];assert len(ma)==len(mb)
for x,y in zip(ma,mb):
 if x.name.startswith('test_parallel_'):assert len(x.decorator_list)==1 and not y.decorator_list;y.name=x.name;x.decorator_list=[]
class NormalizeBun(ast.NodeTransformer):
 def visit_Call(self,n):
  if isinstance(n.func,ast.Attribute) and n.func.attr=='get' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='TRUSS_DISCLOSURE_BUN':return ast.Constant('/opt/homebrew/bin/bun')
  return self.generic_visit(n)
b=NormalizeBun().visit(b);assert ast.dump(a)==ast.dump(b)
# Compiler regression strengthens refusal stage; original final vector counts are unchanged.
compiler=(o/'packages/python/tests/test_current_disclosure_compiler_integration.py').read_text();assert "assertRaisesRegex(ValueError,'Actual held rendered disclosure required')" in compiler and '(46,20,6)' in compiler
for log in ['compiler-replay-bun142.log','compiler-refusal-stage-replay.log']:assert '\nOK\n' in (e/log).read_text()
assert 'Ran 27 tests' in (e/'component-tests.log').read_text() and '\nOK\n' in (e/'component-tests.log').read_text();assert 'Original Bun1.4.2 runtime required' in (e/'failed-bun143-runtime-check.log').read_text()
# Small independent asset-stage mutation test; no compiler/child/native execution.
work=r/'working';work.mkdir(exist_ok=True);tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base,'packages/python/src']))).extractall(work)
for p in (o/'packages/python').rglob('*'):
 if p.is_file():t=work/'packages/python'/p.relative_to(o/'packages/python');t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
sys.path.insert(0,str(work/'packages/python/src'));spec=importlib.util.spec_from_file_location('cohort_tests',work/'packages/python/tests/test_current_disclosure_cohort.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
with (r/'asset-controls.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(t));assert result.wasSuccessful() and result.testsRun==1
runtime=json.loads((e/'runtime.json').read_bytes());assert H(Path(runtime['selectedPath']).read_bytes())==runtime['sha256'];assert subprocess.check_output([runtime['selectedPath'],'--version']).strip()==b'1.4.2'
report={'passed':True,'base':base,'frozenFilesVerified':len(m['files']),'sourcePins':257,'sameSourcePaths':True,'changedSources':changed,'allCapturedSourceBytesVerified':True,'unchangedRuntimeOutsidePureTruthEvaluator':True,'priorReviewedOptimizationExact':True,'cohortCoordinateChanges':delta,'WeftBunProtocolLimitsAndAuthorityCodeUnchanged':True,'threeExpectedFailureMarkersRemovedOnlyDesiredBodiesUnchanged':True,'refusalAssertionsStrengthened':True,'independentAssetMutationCases':4,'assetRestoreChecks':4,'selectedBun142BinaryHashAndVersionVerified':True,'SQLExecuted':False,'all66NotRerun':True};(r/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
