import sys,pathlib,unittest,os,json,hashlib,zipfile,importlib.metadata
if os.environ.get('TRUSS_NATIVE_SOURCE_OBSERVATION_QUALIFICATION')!='1':raise SystemExit('Explicit native qualification required')
root=pathlib.Path(__file__).parent;base=pathlib.Path('/private/tmp/truss-disclosure-main-integration-20261016');out=pathlib.Path(os.environ['TRUSS_NATIVE_SOURCE_OBSERVATION_EVIDENCE']);out.mkdir(parents=True,exist_ok=True)
inputs={}
for p in (base/'packages/python/src/truss').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:inputs['base/'+str(p.relative_to(base))]=p
for p in (base/'packages/python/tests').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:inputs['base/'+str(p.relative_to(base))]=p
for p in (base/'docs/helix/02-design/contracts/bindings').rglob('*'):
 if p.is_file():inputs['base/'+str(p.relative_to(base))]=p
for p in (root/'packages').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:inputs['owner/'+str(p.relative_to(root))]=p
inputs['owner/run-native-tests-r4.py']=pathlib.Path(__file__)
source={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in inputs.items()}
(out/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
with zipfile.ZipFile(out/'source-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,p in inputs.items():z.write(p,n)
sys.path.insert(0,str(base/'packages/python/src'));import truss
truss.__path__.insert(0,str(root/'packages/python/src/truss'));sys.path.insert(0,str(base/'packages/python/tests'));sys.path.insert(0,str(root/'packages/python/tests'))
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_native_source_observation_native.NativeSourceObservationNativeTests'))
from test_native_source_observation_native import NativeSourceObservationNativeTests as native
omitted=[]
for loaded in list(sys.modules.values()):
 path=getattr(loaded,'__file__',None)
 if path:
  p=pathlib.Path(path).resolve()
  if p.suffix=='.py' and (p.is_relative_to(base) or p.is_relative_to(root)) and p not in {v.resolve() for v in inputs.values()}:omitted.append(str(p))
assert not omitted,('Uncaptured imported project Python source',omitted)
closing={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in inputs.items()};assert source==closing,'Source changed during native campaign'
removed=not native.root.exists();assert removed,'Owned native fixture root remains'
try:os.kill(native.postmaster_pid,0)
except ProcessLookupError:stopped=True
else:stopped=False
assert stopped,'Owned native postmaster stop unconfirmed'
import psycopg
receipt={'status':'passed' if result.wasSuccessful() else 'failed','tests':result.testsRun,'sourcePins':len(source),'sourceEndpointsMatch':True,'importedProjectPythonClosureCaptured':True,'selectedTestFixturesCaptured':True,'python':sys.version,'psycopg':psycopg.__version__,'libpq':psycopg.pq.version(),'pgserver':importlib.metadata.version('pgserver-pg18'),'cleanup':{'root':str(native.root),'rootRemoved':removed,'postmasterPid':native.postmaster_pid,'postmasterStopped':stopped},'scope':'Actual original host/source/release and selected native metadata; source endpoint hashes are not held-file or ABA proof. No native binding/current authority/release or backend acceptance.'}
(out/'campaign.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())
