import sys,pathlib,unittest
root=pathlib.Path(__file__).parent
sys.path.insert(0,'/private/tmp/truss-disclosure-main-integration-20261016/packages/python/src')
import truss
truss.__path__.insert(0,str(root/'packages/python/src/truss'))
sys.path.insert(0,'/private/tmp/truss-disclosure-main-integration-20261016/packages/python/tests')
sys.path.insert(0,str(root/'packages/python/tests'))
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_native_source_observation_native.NativeSourceObservationNativeTests')).wasSuccessful())
