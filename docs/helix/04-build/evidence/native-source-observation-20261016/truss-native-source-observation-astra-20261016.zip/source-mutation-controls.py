import runpy,pathlib,types,sys,json,hashlib
from unittest.mock import patch
R=pathlib.Path(__file__).parent;n=runpy.run_path(str(R/'pure-controls.py'));obs=n['obs'];Cursor=n['Cursor'];request=n['raw_request'];legacy=n['legacy'];inv=n['inv'];source=(R/'frozen/owner/packages/python/src/truss/_native_source_observation.py').read_text();out=R/'mutants';out.mkdir(exist_ok=True);results=[]
def load(label,old,new):
 assert source.count(old)==1,(label,source.count(old));s=source.replace(old,new);p=out/(label+'.py');p.write_text(s);m=types.ModuleType('truss.review_'+label.replace('-','_'));m.__package__='truss';sys.modules[m.__name__]=m;exec(compile(s,str(p),'exec'),m.__dict__);return m
m=load('home-guard',"if len(rows)!=1 or rows[0][1:]!=(ns[0],installation[3],'r','p','false','false','false'):","if len(rows)!=1:")
def home(q,p,rs):
 if 'pg_class' in q and 'pg_locks'not in q:
  row=list(rs[0]);row[5]='true';return[tuple(row)]
 return rs

def attempt(module,mutate):
 try:
  with patch.object(module,'capture_accepted_catalog',return_value=legacy):module.capture_native_source_observation_with_cursor(Cursor(mutate),request)
 except ValueError:return 'refused'
 return 'returned'
def challenge(label,module,mutate):
 a=attempt(obs,mutate);b=attempt(module,mutate);assert(a,b)==('refused','returned');results.append({'id':label,'original':a,'mutant':b})
challenge('home-RLS',m,home)
for label,sqlkey,line in [('column-census','pg_attribute',"        if len(raw_columns)!=int(budget[0][0]):raise ValueError('Complete native source column census required')"),('constraint-census','pg_constraint',"        if len(raw_constraints)!=int(budget[0][0]):raise ValueError('Complete native constraint census required')")]:
 m=load(label,line,'        # Review mutation: omit complete census guard')
 def census(q,p,rs,key=sqlkey):return[(str(int(rs[0][0])+1),rs[0][1])]if key in q and q.startswith('SELECT count')else rs
 challenge(label,m,census)
m=load('final-byte-bound',"    if not 1<=len(raw)<=MAX_BYTES:raise ValueError('Native source observation capacity exceeded')","    # Review mutation: omit final byte cap")
def capacity(q,p,rs):
 if 'pg_attribute' in q:
  if q.startswith('SELECT count'):return[(rs[0][0],'1500000')]
  row=list(rs[0]);row[9]='true';row[10]='x'*1500000;return[tuple(row)]+rs[1:]
 return rs
challenge('aggregate-output-bytes',m,capacity)
# Rounding mutant is detected against an independently authored exact fractional row.
m=load('fractional-reserialize','            fragments.append(raw)','            fragments.append(json.dumps(json.loads(raw),separators=(\',\',\':\')).encode())')
row='{"facets":{"x":1.2345678901234567890000}}';T=n['testmod'];r=[]
for module in [obs,m]:
 with patch.object(module,'capture_accepted_catalog',return_value=legacy):raw,_=module._exact_assessment(T.Cursor([(row,)]),T.NativeSourceObservationTests().request(),('i','release','digest','42'),'1')
 r.append(row.encode()in raw)
assert r==[True,False];results.append({'id':'fractional-native-fragment','originalExact':r[0],'mutantExact':r[1]})
(R/'source-mutation-controls.json').write_text(json.dumps({'status':'passed','count':len(results),'controls':results,'scope':'Five separately compiled source mutants using actual frozen source and simulated stock TEXT rows; full legacy accepted-catalog verifier explicitly stubbed. No native execution.'},indent=2)+'\n');print('5 effective source mutations passed')
