import runpy,pathlib,json,hashlib
from unittest.mock import patch
R=pathlib.Path(__file__).parent
n=runpy.run_path(str(R/'pure-controls.py'))
obs=n['obs'];Cursor=n['Cursor'];raw_request=n['raw_request'];legacy=n['legacy'];inv=n['inv'];base=n['raw_release'];capture=n['capture']
import truss.catalog_runtime as runtime
original_files=runtime.files
package=original_files('truss')
class Proxy:
 def __init__(self,path,raw):self.path=path;self.raw=raw
 def joinpath(self,*parts):return Proxy(self.path.joinpath(*parts),self.raw)
 def read_bytes(self):return self.raw if str(self.path).endswith('/_catalog_runtime/manifest.json')else self.path.read_bytes()
probes=[]
for label,raw in [('duplicate-json',base.rstrip()[:-1]+b',"reviewUnknown":1,"reviewUnknown":2}'),('over-four-million',base.rstrip()[:-1]+b',"reviewUnknown":"'+b'x'*4_000_001+b'"}')]:
 digest=hashlib.sha256(raw).hexdigest();old_digest=inv['release']['sha256'];inv['release']['sha256']=digest
 try:
  with patch.object(runtime,'files',lambda name:Proxy(package,raw)),patch.object(obs,'files',lambda name:Proxy(package,raw)):
   # The actual unchanged release verifier still checks every original asset.
   manifest,actual,assets=runtime._release();assert actual==digest
   d,c=capture();assert d.runtime_release==raw
   refusal=None
   try:obs._bounded(d.runtime_release)
   except ValueError as e:refusal=str(e)
   assert refusal
   probes.append({'id':label,'actualReleaseVerifierAccepted':True,'actualObserverReturned':True,'returnedBytes':len(raw),'sha256':digest,'declaredScannerWouldRefuse':refusal,'authority':json.loads(d.report)['authority']})
 finally:inv['release']['sha256']=old_digest
(R/'release-capacity-probe.json').write_text(json.dumps({'status':'reproduced','probes':probes,'scope':'Exact actual release verifier and observer with retained packaged assets; supplied replacement manifest and simulated native cursor carrying matching installation hash. Full accepted-catalog verifier remains stubbed. Demonstrates omitted release scan/bound, not an actual native installation or authority exploit.'},indent=2)+'\n');print(json.dumps(probes,indent=2))
