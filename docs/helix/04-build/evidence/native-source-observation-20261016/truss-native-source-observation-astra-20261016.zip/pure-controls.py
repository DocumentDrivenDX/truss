import sys,pathlib,json,hashlib,types,importlib.util,unittest,io,copy
from unittest.mock import patch
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;F=R/'frozen';S=R/'source'
sys.path.insert(0,str(S/'base/packages/python/src'));import truss
truss.__path__.insert(0,str(S/'owner/packages/python/src/truss'))
import truss._native_source_observation as obs
from truss._owner_evidence_json import decode_owner_evidence_json
spec=importlib.util.spec_from_file_location('review_unit',S/'owner/packages/python/tests/test_native_source_observation.py');testmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(testmod)
stream=io.StringIO();res=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(testmod));(R/'unit-tests.log').write_text(stream.getvalue());assert res.testsRun==6 and res.wasSuccessful()
raw_request=(F/'native-r3/accepted-request.json').read_bytes();raw_assessment=(F/'native-r3/accepted-assessment.json').read_bytes();legacy=(F/'native-r3/legacy-assessment.json').read_bytes();raw_release=(F/'native-r3/runtime-release.json').read_bytes();inv=json.loads((F/'native-r3/native-inventory.json').read_bytes());assessment=json.loads(raw_assessment);checks=[]
def check(n,v):
 checks.append({'id':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
class Deadline:
 def __init__(self,fail=False):self.fail=fail;self.calls=0
 def check(self):
  self.calls+=1
  if self.fail:raise TimeoutError('review deadline')
class Cursor:
 def __init__(self,mutate=None):self.description=[];self.rows=[];self.queries=[];self._deadline=Deadline();self.path='"$user", public';self.mutate=mutate
 def execute(self,q,p=(),**kw):
  self.queries.append((q,p,kw));rows=[];cols=0
  if q.startswith('LOCK '):pass
  elif "set_config('search_path','pg_catalog, pg_temp',true)"in q:self.path='pg_catalog, pg_temp';rows=[(self.path,)]
  elif "set_config('search_path',%s,true)"in q:self.path=p[0];rows=[(self.path,)]
  elif "current_setting('server_version_num')"in q:rows=[('180006','read committed','off')]
  elif "current_setting('search_path')"in q:rows=[(self.path,)]
  elif 'pg_catalog.pg_locks' in q:rows=[(n,'r','p','false','false','false','true')for n in sorted(obs.SOURCE_TABLES)]
  elif 'runtime_current_installation' in q:rows=[(inv['installationId'],inv['release']['id'],inv['release']['sha256'],inv['relations'][0]['ownerOid'])]
  elif 'schema_head' in q:rows=[(assessment['revision'],)]
  elif 'pg_control_system' in q:d=inv['database'];rows=[(d['systemIdentifier'],d['oid'],d['name'])]
  elif "nspname='truss'"in q and 'pg_class'not in q:n=inv['schema'];rows=[(n['oid'],n['name'],n['ownerOid'])]
  elif 'SELECT to_jsonb(t)'in q:
   key=next(key for key,table,order in obs.CATALOGS if 'truss.'+table+' 'in q);rows=[(json.dumps(row,separators=(',',':')), )for row in assessment['inventory'][key]]
  elif 'pg_class' in q:
   x=next(x for x in inv['relations']if x['name']==p[0]);rows=[(x['oid'],x['namespaceOid'],x['ownerOid'],'r','p','false','false','false')]
  elif 'pg_attribute' in q:
   x=next(x for x in inv['relations']if x['oid']==p[0]);columns=x['columns']
   if q.startswith('SELECT count'):rows=[(str(len(columns)),str(sum(len((c['defaultExpression']or'').encode())for c in columns)))]
   else:rows=[(str(c['attnum']),c['name'],c['typeOid'],str(c['typmod']),c['collationOid'],str(c['notNull']).lower(),str(c['dropped']).lower(),c['generated'],c['identity'],str(c['defaultExpression']is not None).lower(),c['defaultExpression']or'')for c in columns]
  elif 'pg_constraint' in q:
   x=next(x for x in inv['relations']if x['oid']==p[0]);cs=x['constraints']
   if q.startswith('SELECT count'):rows=[(str(len(cs)),str(sum(len(c['definition'].encode())for c in cs)))]
   else:rows=[(c['oid'],c['name'],c['kind'],str(c['validated']).lower(),str(c['deferrable']).lower(),str(c['initiallyDeferred']).lower(),c['referencedRelationOid'],c['definition'])for c in cs]
  else:raise AssertionError(q)
  if self.mutate:rows=self.mutate(q,p,rows)
  self.rows=rows;self.description=[types.SimpleNamespace(type_code=25)for _ in range(len(rows[0])if rows else 1)]
 def fetchmany(self,n):return self.rows[:n]
def capture(cursor=None,**kw):
 cursor=cursor or Cursor()
 with patch.object(obs,'capture_accepted_catalog',return_value=legacy) as original:
  d=obs.capture_native_source_observation_with_cursor(cursor,raw_request,**kw)
 original.assert_called_once_with(cursor,raw_request,existing_source_cut=True)
 return d,cursor
captured,c= capture();check('actual-source-full-mocked-metadata',json.loads(captured.native_inventory)==inv);check('raw-request-retained',captured.accepted_request is raw_request);check('exact-original-release',captured.runtime_release==raw_release);check('search-path-restored',c.path=='"$user", public')
check('fixed-lock-closure',sorted(q for q,p,k in c.queries if q.startswith('LOCK'))==['LOCK TABLE ONLY truss.'+n+' IN SHARE MODE NOWAIT'for n in sorted(set(obs.SOURCE_TABLES)|set(obs.HOMES))])
report=json.loads(captured.report);check('false-authority',report['authority']is False and report['complete']is False and report['securityReady']is False and report['nativeAdmission']=='required')
check('actual-four-source-pins',all(e['sha256']==hashlib.sha256(b).hexdigest()and e['bytes']==len(b)for e,b in zip(report['sources'],[captured.accepted_request,captured.accepted_assessment,captured.runtime_release,captured.native_inventory])))
# Structured text-row refusal controls cover preflight and every selected-home flag.
def refusal(name,mutator):
 try:capture(Cursor(mutator))
 except (ValueError,TimeoutError):check(name,True)
 else:check(name,False)
for row in [('180005','read committed','off'),('180006','repeatable read','off'),('180006','read committed','on')]:refusal('profile:'+repr(row),lambda q,p,rs,row=row:[row]if"current_setting('server_version_num')"in q else rs)
for col,value in [(1,'999'),(2,'999'),(3,'v'),(4,'u'),(5,'true'),(6,'true'),(7,'true')]:
 def mutate(q,p,rs,col=col,value=value):
  if 'pg_class' in q and 'pg_locks'not in q:
   row=list(rs[0]);row[col]=value;return[tuple(row)]
  return rs
 refusal('home-column:'+str(col),mutate)
for category in ['columns','constraints']:
 def mismatch(q,p,rs,category=category):
  hit='pg_attribute' in q if category=='columns'else'pg_constraint' in q
  return[(str(int(rs[0][0])+1),rs[0][1])]if hit and q.startswith('SELECT count')else rs
 refusal('census:'+category,mismatch)
for col,value in [(0,'01'),(1,'x'),(2,'0'),(3,'-0'),(4,'-1'),(5,'TRUE'),(6,'true'),(7,'x'),(8,'x'),(9,'TRUE')]:
 if col==1:continue # Native name labels are data, not a fixed name map.
 def mutate(q,p,rs,col=col,value=value):
  if q.startswith('SELECT a.attnum'):
   row=list(rs[0]);row[col]=value;return[tuple(row)]+rs[1:]
  return rs
 refusal('column:'+str(col),mutate)
for col,value in [(0,'0'),(3,'TRUE'),(4,'TRUE'),(5,'TRUE'),(6,'-1')]:
 def mutate(q,p,rs,col=col,value=value):
  if q.startswith('SELECT oid::text,conname'):
   row=list(rs[0]);row[col]=value;return[tuple(row)]+rs[1:]
  return rs
 refusal('constraint:'+str(col),mutate)
for token in ['-2147483649','2147483648','+0','00','-0','１',True,None]:
 try:obs._signed(token)
 except ValueError:check('signed:'+repr(token),True)
 else:check('signed:'+repr(token),False)
# Preserve actual limitations: source flags/names are metadata, not semantic mapping/admission.
(R/'pure-controls.json').write_text(json.dumps({'status':'passed','unitTests':6,'checks':checks,'count':len(checks),'scope':'Actual frozen observer with real shared parser/text-row/source-cut helpers and captured metadata fed through simulated cursor. Existing full accepted-catalog verifier is explicitly stubbed, not claimed independently re-proved. No SQL.'},indent=2)+'\n');print(json.dumps({'status':'passed','unitTests':6,'checks':len(checks)}))
