import runpy,pathlib,json,hashlib,types,sys
from unittest.mock import patch
R=pathlib.Path(__file__).parent;n=runpy.run_path(str(R/'pure-controls.py'));obs=n['obs'];Cursor=n['Cursor'];base=n['raw_release'];inv=n['inv'];request=n['raw_request'];legacy=n['legacy'];capture=n['capture'];checks=[]
def check(k,v):
 checks.append({'id':k,'passed':bool(v)})
 if not v:raise AssertionError(k)
import truss.catalog_runtime as runtime
package=runtime.files('truss')
class Proxy:
 def __init__(self,path,raw):self.path=path;self.raw=raw
 def joinpath(self,*parts):return Proxy(self.path.joinpath(*parts),self.raw)
 def read_bytes(self):return self.raw if str(self.path).endswith('/_catalog_runtime/manifest.json')else self.path.read_bytes()
release_controls=[]
for label,raw in [('duplicate-json',base.rstrip()[:-1]+b',"reviewUnknown":1,"reviewUnknown":2}'),('over-four-million',base.rstrip()[:-1]+b',"reviewUnknown":"'+b'x'*4_000_001+b'"}')]:
 digest=hashlib.sha256(raw).hexdigest();old=inv['release']['sha256'];inv['release']['sha256']=digest
 try:
  with patch.object(runtime,'files',lambda name:Proxy(package,raw)),patch.object(obs,'files',lambda name:Proxy(package,raw)):
   _,actual,_=runtime._release();check(label+':legacy-release-verifier-accepts',actual==digest)
   with patch.object(obs,'_release',wraps=runtime._release)as release:
    try:capture()
    except ValueError as e:error=str(e)
    else:raise AssertionError(label+' returned')
    check(label+':refused-before-verifier',release.call_count==0)
   release_controls.append({'id':label,'returned':False,'bytes':len(raw),'sha256':digest,'reason':error,'releaseVerifierInvocations':0})
 finally:inv['release']['sha256']=old
# Table-driven expression states through full actual observer with explicit fake stock TEXT rows.
expressions=[]
for gen,present,text,expected in [('',False,'',{'kind':'none','source':None}),('',True,'42',{'kind':'default','source':'42'}),('s',True,'sha256(bytes)',{'kind':'generated','source':'sha256(bytes)'}),('v',True,'x + 1',{'kind':'generated','source':'x + 1'}),('s',False,'',None),('v',False,'',None),('',False,'unexpected',None),('s',False,'unexpected',None)]:
 def mutate(q,p,rs):
  if q.startswith('SELECT a.attnum'):
   row=list(rs[0]);row[7]=gen;row[9]=str(present).lower();row[10]=text;return[tuple(row)]+rs[1:]
  return rs
 label=repr((gen,present,text))
 try:d,c=capture(Cursor(mutate));actual=json.loads(d.native_inventory)['relations'][0]['columns'][0]['expression']
 except ValueError:check('expression-refusal:'+label,expected is None);expressions.append({'input':[gen,present,text],'outcome':'refused'})
 else:check('expression-value:'+label,actual==expected);expressions.append({'input':[gen,present,text],'outcome':actual})
# Both repaired production checks are effective against isolated source mutants.
source=(R/'frozen/owner/packages/python/src/truss/_native_source_observation.py').read_text();out=R/'mutants';out.mkdir(exist_ok=True);mutants=[]
def load(name,before,after):
 assert source.count(before)==1;content=source.replace(before,after);p=out/(name+'.py');p.write_text(content);m=types.ModuleType('truss.r2_'+name);m.__package__='truss';sys.modules[m.__name__]=m;exec(compile(content,str(p),'exec'),m.__dict__);return m
m=load('release_scan_removed',"release=_bounded(files('truss').joinpath('_catalog_runtime/manifest.json').read_bytes())","release=files('truss').joinpath('_catalog_runtime/manifest.json').read_bytes()")
raw=base.rstrip()[:-1]+b',"reviewUnknown":1,"reviewUnknown":2}';old=inv['release']['sha256'];inv['release']['sha256']=hashlib.sha256(raw).hexdigest()
try:
 with patch.object(runtime,'files',lambda name:Proxy(package,raw)),patch.object(m,'files',lambda name:Proxy(package,raw)),patch.object(m,'capture_accepted_catalog',return_value=legacy):
  d=m.capture_native_source_observation_with_cursor(Cursor(),request);check('release-scan-removal-exposes-original-defect',d.runtime_release==raw);mutants.append('release_scan_removed')
finally:inv['release']['sha256']=old
m=load('expression_guard_removed',"            if generated and not _boolean(has_default) or not _boolean(has_default) and expression:\n                raise ValueError('Consistent original native expression metadata required')","            # Review mutation: remove consistency guard")
def bad(q,p,rs):
 if q.startswith('SELECT a.attnum'):
  row=list(rs[0]);row[7]='s';row[9]='false';row[10]='';return[tuple(row)]+rs[1:]
 return rs
with patch.object(m,'capture_accepted_catalog',return_value=legacy):
 d=m.capture_native_source_observation_with_cursor(Cursor(bad),request);col=json.loads(d.native_inventory)['relations'][0]['columns'][0];check('expression-guard-removal-exposes-inconsistency',col['generated']=='s'and col['expression']['kind']=='none');mutants.append('expression_guard_removed')
(R/'repair-controls.json').write_text(json.dumps({'status':'passed','count':len(checks),'checks':checks,'release':release_controls,'expressions':expressions,'effectiveSourceMutants':mutants,'scope':'Actual frozen R2 helper and original release asset verifier; simulated native TEXT rows, legacy accepted-catalog verifier explicitly stubbed. No SQL, installed authority or source admission claim.'},indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(checks),'effectiveMutants':len(mutants)}))
