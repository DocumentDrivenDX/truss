"""R2 evidence closure: bytes, archived dependencies, isolated native-test assertions. No SQL."""
import ast,copy,hashlib,json,pathlib,types,unittest,zipfile
root=pathlib.Path(__file__).parent;review=root.parent;f=review/'frozen';source=review/'source';old=pathlib.Path('/private/tmp/truss-native-source-observation-astra-20261016');sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(label,ok):
 assert ok,label
 checks.append(dict(id=label,passed=True))
m=json.loads((f/'manifest.json').read_text());check('all24frozen-input-pins-match',len(m)==24 and all(sha((f/p).read_bytes())==h['sha256']and len((f/p).read_bytes())==h['bytes']for p,h in m.items()))
pins=json.loads((f/'native-r4/source-before.json').read_text());campaign=json.loads((f/'native-r4/campaign.json').read_text());check('1349selected-source-pins',len(pins)==campaign['sourcePins']==1349)
with zipfile.ZipFile(f/'native-r4/source-inputs.zip')as z:
 check('archive-exactly-1349unique-pinned-inputs',len(z.namelist())==len(set(z.namelist()))==1349 and set(z.namelist())==set(pins))
 check('all-archive-bytes-match-pins',all(sha(z.read(p))==pin['sha256']and len(z.read(p))==pin['bytes']for p,pin in pins.items()))
 check('all-extracted-bytes-match-archive',all((source/p).read_bytes()==z.read(p)for p in pins))
 for p in ['base/packages/python/tests/test_preparation.py','base/docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json']:
  check('previously-omitted-input-now-archived/'+p,p in pins)
 for p in [p for p in pins if p.startswith('owner/')]:check('captured-owner-equals-frozen/'+p,z.read(p)==(f/p).read_bytes())
report=json.loads((f/'native-r4/report.json').read_text());check('still-no-authority',report['complete']is False and report['authority']is False and report['securityReady']is False and report['nativeAdmission']=='required')
check('all4returned-source-pins-match',len(report['sources'])==4 and all(sha((f/'native-r4'/(s['role']+'.json')).read_bytes())==s['sha256']and len((f/'native-r4'/(s['role']+'.json')).read_bytes())==s['bytes']for s in report['sources']))
# Execute only the runner's captured project-module inclusion guard against synthetic module lists.
runner=f/'owner/run-native-tests-r4.py';runner_ast=ast.parse(runner.read_text());guard=[]
for node in runner_ast.body:
 if isinstance(node,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='omitted'for t in node.targets):guard.append(node)
 if isinstance(node,ast.For)and isinstance(node.target,ast.Name)and node.target.id=='loaded':guard.append(node)
 if isinstance(node,ast.Assert)and isinstance(node.test,ast.UnaryOp)and isinstance(node.test.operand,ast.Name)and node.test.operand.id=='omitted':guard.append(node)
check('actual-module-closure-guard-extracted',len(guard)==3);guard_code=compile(ast.fix_missing_locations(ast.Module(body=guard,type_ignores=[])),str(runner),'exec')
def module_guard(path):
 env={'sys':types.SimpleNamespace(modules={'fixture':types.SimpleNamespace(__file__=str(path))}),'pathlib':pathlib,'base':source/'base','root':source/'owner','inputs':{n:source/n for n in pins}}
 exec(guard_code,env)
module_guard(source/'base/packages/python/tests/test_preparation.py');check('guard-admits-captured-test-module',True)
for label,path in [('missing-base-module',source/'base/packages/python/tests/uncaptured_test.py'),('missing-owner-module',source/'owner/packages/python/src/truss/uncaptured.py')]:
 try:module_guard(path)
 except AssertionError:check(label+'-refused',True)
 else:raise AssertionError(label)
# Extract only independent expected constants and per-column assertions; none of the SQL/native code.
test=f/'owner/packages/python/tests/test_native_source_observation_native.py';tree=ast.parse(test.read_text());method=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='test_actual_original_source_and_complete_native_metadata');loop=next(n for n in ast.walk(method)if isinstance(n,ast.For)and isinstance(n.target,ast.Name)and n.target.id=='relation');selected=[]
for n in loop.body:
 if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in {'expected_default','expected_generated','nullable'}for t in n.targets):selected.append(n)
 if isinstance(n,ast.For)and isinstance(n.target,ast.Name)and n.target.id=='column':selected.append(n)
check('actual-independent-column-assertions-extracted',len(selected)==4);code=compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(test),'exec');tc=unittest.TestCase()
def validate(inventory):
 for relation in inventory['relations']:exec(code,{'self':tc,'relation':relation,'name':relation['name']})
inv=json.loads((f/'native-r4/native-inventory.json').read_text());validate(inv);check('all32captured-columns-pass-independent-assertions',sum(len(r['columns'])for r in inv['relations'])==32)
counts={kind:sum(c['expression']['kind']==kind for r in inv['relations']for c in r['columns'])for kind in ['none','default','generated']};check('exact-expression-kind-populations',counts=={'none':19,'default':11,'generated':2})
for ri,relation in enumerate(inv['relations']):
 for ci,column in enumerate(relation['columns']):
  for kind in ['notNull','identity','generated','expression']:
   mutant=copy.deepcopy(inv);target=mutant['relations'][ri]['columns'][ci]
   if kind=='notNull':target[kind]=not target[kind]
   elif kind=='identity':target[kind]='a'
   elif kind=='generated':target[kind]=''if target[kind]=='s'else's'
   else:target[kind]={'kind':'none','source':None}if target[kind]['kind']!='none'else{'kind':'default','source':'0'}
   try:validate(mutant)
   except AssertionError:check('column-mutant-refused/'+relation['name']+'/'+column['name']+'/'+kind,True)
   else:raise AssertionError('escaped independent assertions')
for label,predicate,change in [('erase-all-expressions',lambda c:True,lambda c:c.update(expression={'kind':'none','source':None})),('generated-mislabeled-default',lambda c:c['generated']=='s',lambda c:c['expression'].update(kind='default'))]:
 mutant=copy.deepcopy(inv)
 for relation in mutant['relations']:
  for c in relation['columns']:
   if predicate(c):change(c)
 try:validate(mutant)
 except AssertionError:check(label+'-refused',True)
 else:raise AssertionError(label)
base=json.loads((review/'baseline-correspondence.json').read_text());check('six-known-baseline-differences-retained',len(base['differentFrom593'])==6)
release=json.loads((f/'native-r4/runtime-release.json').read_text());check('captured-release-is-runtime071',release['releaseId']=='truss-catalog-runtime/0.71-candidate')
for entry in base['differentFrom593']:
 b=(source/'base'/entry['path']).read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();check('captured-differing-Git-blob-matches/'+entry['path'],blob==entry['capturedBlob'])
result={'scope':'No SQL/native campaign. Frozen byte/custody review plus isolated actual runner guard and native-test assertion execution against retained data.','controls':len(checks),'checks':checks,'expressionKinds':counts,'scriptSha256':sha(pathlib.Path(__file__).read_bytes())};(root/'controls.json').write_text(json.dumps(result,indent=2)+'\n')
final={'status':'R1-evidence-findings-closed-with-captured-baseline-qualification','findings':[],'remainingFindings':[],'resolvedFindings':['NSO-EVIDENCE-01','NSO-EVIDENCE-02'],'scope':'Narrow R2 evidence-custody and native column-assertion closure review. Parent independently handles runtime release bounds/source controls. No new native/SQL execution.',
'pins':{'reviewZipSha256':sha((review/'review.zip').read_bytes()),'manifestSha256':sha((f/'manifest.json').read_bytes()),'frozenFiles':m,'nativeArchiveSha256':sha((f/'native-r4/source-inputs.zip').read_bytes()),'sourcePinsSha256':sha((f/'native-r4/source-before.json').read_bytes()),'baselineCorrespondenceSha256':sha((review/'baseline-correspondence.json').read_bytes()),'R1ReportSha256':sha((old/'docs-review/report.json').read_bytes()),'controlsSha256':sha((root/'controls.json').read_bytes()),'reviewScriptSha256':sha(pathlib.Path(__file__).read_bytes())},
'closures':[
 {'id':'NSO-EVIDENCE-01','status':'closed','evidence':'R4 captures1349exact input entries, including test_preparation.py and its import-time capacity fixture; archives all base test files and contract-binding fixtures. The actual runner guard refuses currently loaded project .py paths omitted from the captured list before endpoint/cleanup checks and receipt issuance. All archived bytes and supplied extraction match pins.','limits':'This closes the specific omitted loaded module/fixture gap. It remains an endpoint inventory, not continuous/ABA custody, executable-bytecode equivalence, arbitrary unloaded/dynamic dependency closure or hermetic third-party runtime provenance.'},
 {'id':'NSO-EVIDENCE-02','status':'closed','evidence':'New independent authored expected declarations assert expression kind/source, generated, identity and nullability for all32native columns:11defaults,2stored generated expressions and19none.128individual per-column field mutants plus aggregate erasure/mislabel controls fail the extracted actual assertions; captured baseline passes.','limits':'These controls execute only frozen assertion blocks on retained native JSON. They do not perform independent native re-observation or execute SQL. Supplied R4 native log/campaign remains the execution evidence.'}
],
'baselineQualification':{'baseline':'59360445555a523cf78295a5ba97ef72a7128812','authoritativeCohort':'native-r4/source-inputs.zip and source-before.json','runtimeRelease':release['releaseId'],'differentBasePaths':base['differentFrom593'],'note':'The design59360445label is a starting baseline/historical checkpoint, not an exact identity claim for this R4captured cohort. Six captured base paths differ, including runtime operations.sql/owned.sql/manifest and three added source/test files. Use the captured archive and full pins for qualification; never replay this cohort by substituting clean59360445.'},
'docs':'Design accurately records explicit none/default/generated meaning, repaired imported-test fixture closure, source endpoint limits, and incomplete data-only/nativeAdmission-required scope. No Field/Key/edge/codec or current-authority/release acceptance is asserted. Historical R1/R2/R3 records remain retained separately.',
'controls':len(checks),'limits':['No SQL/native test replay or live cleanup check performed.','Public consumer/registration/full binding remains outside this narrow closure review.','The changed runtime0.71 source is captured evidence, not independently approved implementation by this documentation/custody subreview.']}
(root/'report.json').write_text(json.dumps(final,indent=2)+'\n');h={str(p.relative_to(root)):sha(p.read_bytes())for p in sorted(root.rglob('*'))if p.is_file()and p.name!='sha256.json'};(root/'sha256.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'status':final['status'],'controls':len(checks),'reportSha256':h['report.json'],'nativeTestSha256':sha(test.read_bytes()),'runnerSha256':sha(runner.read_bytes())}))
