from pathlib import Path
import json,hashlib,zipfile,subprocess,collections
R=Path(__file__).parent;F=R/'frozen';checks=[]
def check(n,v):
 checks.append({'id':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((F/'manifest.json').read_text());base='59360445555a523cf78295a5ba97ef72a7128812';pins=json.loads((F/'native-r4/source-before.json').read_text());z=zipfile.ZipFile(F/'native-r4/source-inputs.zip')
check('1349-exact-selected-members',set(pins)==set(z.namelist())and len(pins)==1349)
for n,h in m.items():b=(F/n).read_bytes();check('packet:'+n,len(b)==h['bytes']and sha(b)==h['sha256'])
ls=subprocess.check_output(['git','ls-tree','-r',base],cwd='/Users/erik/Projects/truss',text=True);blobs={line.split('\t',1)[1]:line.split()[2]for line in ls.splitlines()}
base_count=0
for n,h in pins.items():
 b=z.read(n);check('source-pin:'+n,len(b)==h['bytes']and sha(b)==h['sha256'])
 if n.startswith('base/'):
  rel=n[5:];gitsha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();expected_drift={x['path']for x in json.loads((R/'baseline-correspondence.json').read_text())['differentFrom593']};check('qualified-base-git:'+rel,(blobs.get(rel)==gitsha)==(rel not in expected_drift));base_count+=1
 elif (F/n).exists():check('owner-packet:'+n,(F/n).read_bytes()==b)
report=json.loads((F/'native-r4/report.json').read_bytes());roles=['accepted-request','accepted-assessment','runtime-release','native-inventory'];check('exact-source-role-order',[x['role']for x in report['sources']]==roles)
for name,pin in zip(roles,report['sources']):b=(F/'native-r3'/(name+'.json')).read_bytes();check('report-pin:'+name,pin['sha256']==sha(b)and pin['bytes']==len(b))
check('false-authority',all(report[k]is False for k in ['complete','authority','securityReady'])and report['nativeAdmission']=='required')
request=json.loads((F/'native-r4/accepted-request.json').read_bytes());ass=json.loads((F/'native-r4/accepted-assessment.json').read_bytes());legacy=json.loads((F/'native-r4/legacy-assessment.json').read_bytes());release=(F/'native-r4/runtime-release.json').read_bytes();inv=json.loads((F/'native-r4/native-inventory.json').read_bytes());runtime=json.loads(release)
check('assessment-versions',ass['version']=='truss.accepted-catalog-assessment/0.2-candidate'and legacy['version']=='truss.accepted-catalog-assessment/0.1')
check('exact-model-pin-order',ass['modelPins']==[x['pin']for x in request['modules']])
for module in request['modules']:
 doc=json.loads(module['documentJson']);check('model:'+doc['id'],sha(module['documentJson'].encode())==module['pin']['sha256']and doc['id']==module['pin']['documentId']and doc['umf']==module['pin']['umfVersion'])
check('release-correspondence',ass['releaseSha256']==sha(release)==inv['release']['sha256']and ass['releaseId']==runtime['releaseId']==inv['release']['id'])
check('installation-correspondence',ass['installationId']==legacy['installationId']==inv['installationId'])
check('new-old-actual-inventory',ass['inventory']==legacy['inventory'])
check('selected-home-coverage',inv['coverage']=={'relations':['edge','object','object_key_bucket'],'completeSelectedHomes':True}and[r['name']for r in inv['relations']]==['edge','object','object_key_bucket'])
check('32-columns',sum(len(r['columns'])for r in inv['relations'])==32);check('52-constraints',sum(len(r['constraints'])for r in inv['relations'])==52)
expressions=[]
for relation in inv['relations']:
 check('native-home-flags:'+relation['name'],relation['kind']=='r'and relation['persistence']=='p'and all(relation[k]is False for k in ['rowSecurity','forceRowSecurity','inherits']))
 check('column-unique:'+relation['name'],len({c['attnum']for c in relation['columns']})==len(relation['columns'])==len({c['name']for c in relation['columns']}))
 for col in relation['columns']:
  if col['expression']['source']is not None:expressions.append({'relation':relation['name'],'column':col['name'],'generated':col['generated'],'defaultExpression':col['expression']['source']})
check('13-labeled-expressions',len(expressions)==13)
result=json.loads((F/'native-r4/native-result.json').read_text());campaign=json.loads((F/'native-r4/campaign.json').read_text())
check('supplied-native-success',result['status']==campaign['status']=='passed'and campaign['tests']==4 and result['serverVersion']==180006)
check('six-external-lock-refusals',result['locks']==[n+':'+mode for n in ['edge','object','object_key_bucket']for mode in ['ROW EXCLUSIVE','ACCESS EXCLUSIVE']])
check('supplied-cleanup-witness',campaign['cleanup']['rootRemoved']is True and campaign['cleanup']['postmasterStopped']is True)
check('owned-root-currently-absent',not Path(campaign['cleanup']['root']).exists())
# Never probe recorded PID now: OS PID reuse would not assess historical cleanup.
(R/'native-evidence-audit.json').write_text(json.dumps({'status':'passed-with-captured-overlay-qualification','count':len(checks),'checks':checks,'baseFilesVerified':base_count,'selectedSourcePins':len(pins),'nativeExecutedByReviewer':False,'expressions':expressions,'scope':'Supplied actual native evidence audited without SQL replay.1349captured pins agree; six base-prefixed paths differ from original Git59360445 and are retained as explicit tested runtime0.71overlay. Previously omitted test_preparation and fixture now captured; imported project closure and selected fixture coverage are explicit runner claims. Root absence is only a current endpoint check; no historical PID probe.'},indent=2)+'\n');print(json.dumps({'checks':len(checks),'baseFiles':base_count,'expressions':len(expressions)}))
