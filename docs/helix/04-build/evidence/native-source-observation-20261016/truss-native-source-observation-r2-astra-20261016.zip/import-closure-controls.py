import sys,os,pathlib,unittest,io,json,hashlib,ast
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;S=R/'source';base=S/'base';owner=S/'owner'
os.environ.pop('TRUSS_NATIVE_SOURCE_OBSERVATION_QUALIFICATION',None)
sys.path.insert(0,str(base/'packages/python/src'));import truss
truss.__path__.insert(0,str(owner/'packages/python/src/truss'));sys.path.insert(0,str(base/'packages/python/tests'));sys.path.insert(0,str(owner/'packages/python/tests'))
import test_native_source_observation_native as native
stream=io.StringIO();res=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(native.NativeSourceObservationNativeTests));assert res.testsRun==4 and len(res.skipped)==4 and res.wasSuccessful();(R/'default-native-skips.log').write_text(stream.getvalue())
pins=json.loads((R/'frozen/native-r4/source-before.json').read_text());loaded={}
for name,module in list(sys.modules.items()):
 p=getattr(module,'__file__',None)
 if p:
  p=pathlib.Path(p).resolve()
  if p.suffix=='.py'and(p.is_relative_to(base)or p.is_relative_to(owner)):
   key=p.relative_to(S).as_posix();b=p.read_bytes();pin={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};assert pins[key]==pin;loaded[name]={'path':key,**pin}
for key in ['base/packages/python/tests/test_preparation.py','base/docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json']:
 assert key in pins and (S/key).exists()
assert any(x['path']=='base/packages/python/tests/test_preparation.py'for x in loaded.values())
# Actual parsed import-time fixture is the captured bytes, no native operation.
import test_preparation
config=json.loads((base/'docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json').read_bytes())['input'];config={k:v for k,v in config.items()if k not in ('interfaceVersion','documents')};config['binding']={'state':'absent'};config['transforms']=[];assert test_preparation.CONFIG==config
(R/'import-closure-controls.json').write_text(json.dumps({'status':'passed','nativeTestsSkipped':4,'loadedProjectPythonModules':len(loaded),'modules':loaded,'exactImportTimeFixture':True,'scope':'Fresh reconstructed source tree import/default test discovery with bytecode writing disabled; all native tests skip before setup. Imported project source paths and actual parsed capacity fixture match1349capturedpins. No SQL or hermetic external dependency claim.'},indent=2)+'\n');print(json.dumps({'status':'passed','modules':len(loaded),'nativeTestsSkipped':4}))
