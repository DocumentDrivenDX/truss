# Registered source and same-context population composition

The new private ContextDisclosureCapture issues its compiler parent/current once
from the committed registered source originals, joins native Graph/Model
requirements from that same context, captures the complete native populations,
and compares every native/logical object and graph occurrence to those original
definitions. The evaluator recognizes that exact private capture profile and
reuses the actual current/parent; it does not prepare a replacement parent.
Existing uncomposed captures retain their earlier issuance path.

Coverage includes every selected Record/member and graph role, even unused by
the SQL projection. Full typed native incidence and logical endpoint Keys,
ordered Key definitions, duplicate witness exclusion and original parallel
occurrences remain separate. Closing reuses the retained current, reobserves
native definitions and complete fact/Key/graph data, compares all original
reports and captures, and releases no data. Endpoint recapture cannot establish
ABA exclusion or changes after the check.

A second complete consumer cohort explicitly admits the separately pinned final
GraphRequirements dev wheel, sourceb34a823, wheel25947eaea9cd42db79a2671664e7829af10d79a802a82cf92f5ddc0b2675e5c8,
native7e6384ddada0f67a45839a222ffb059e04a5de00f6a9281ad811eefacdeffa42,
with the unchanged UMF548b/11b412 computation and Bun1.4.2. The original old
Weft cohort stays selected for its own exact binary. Default dependency pins,
public executor capture path, operation limits and activation are unchanged.
Weft PR16 main integration remains pending explicit merge approval; this is a
separately qualified optional source candidate, not a claim it is on Weft main.

The final actual PostgreSQL18.6/psycopg3.3.6 test passes1 case in31.259s. Existing
setup first creates14 public objects/12edges and executes its older diagnostic
source-wrapper controls. That phase is labeled separately. The new phase then
commits original source archives through the actual installer, captures them
without source-provider mocks, obtains actual native definition and population
correspondence, evaluates Alice through the original UMF semantic child, stages
SQL on PostgreSQL and passes whole-batch inspection. Alice's salary is exactly
100. The returned evaluation retains the exact same current and parent objects.
Closing succeeds, refuses an own-transaction edge-version mutation at its intended
comparison, then succeeds after rollback. Original archive bytes and rendered
batch are retained. No fixture server or new fixture root remains.

The first test requested90s at host construction and correctly failed against
the existing60s maximum before source registration. The correction uses60s;
no product limit changed. Product source endpoints match before/after both runs;
the final test hash documents the sole intentional timeout-input correction.
These are endpoint observations, not held-file/ABA or hermetic proofs. The test
time does not qualify performance. No successful result is credited to the
failed run.

Seven new pure/actual-context tests pass. They cover full and parallel occurrence
correspondence, missing/duplicate/incorrect coverage, wrong native incidence,
logical witness/role/Key drift and SQL substitution. The substitution refuses
before replacement parent preparation or semantic child construction. The new
optional compiler/evaluator/child composition passes all66 original vectors:
46rendered,20expectedrefusals, with unchanged strict refusal-stage assertions.

This establishes actual registered-source archival/capture and same-context
population composition for this finite profile. It does not establish native
binding admission, authenticated Subject/current authority, whole source/routine/
privilege closure, full codec/domain equivalence or final guarded public release.
The diagnostic Alice Subject and unadmitted fixture binding are explicit; no
backend case or acceptance criterion is promoted. All158 required cases remain.
Replay native with both context and original graph qualification flags, pinned
Bun and final Graph wheel, fresh evidence directory and serialized native window.
