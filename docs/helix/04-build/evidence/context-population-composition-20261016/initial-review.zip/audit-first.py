import json,hashlib,pathlib,zipfile,subprocess,ast,copy,sys
from types import SimpleNamespace
P=pathlib.Path('/private/tmp/truss-context-composition-review-20261016');O=pathlib.Path('/private/tmp/truss-context-composition-review-result-20261016');E=P/'docs/helix/04-build/evidence/context-population-composition-20261016'
h=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((P/'manifest.json').read_bytes())
for name,digest in manifest.items():assert h((P/name).read_bytes())==digest,name
ret=json.loads((E/'retention.json').read_bytes())
for name,digest in ret['sourceFiles'].items():assert h((P/name).read_bytes())==digest
for name,digest in ret['files'].items():assert h((E/name).read_bytes())==digest
members=json.loads((E/'native-artifacts.manifest.json').read_bytes())
with zipfile.ZipFile(E/'native-artifacts.zip') as z:
 assert set(z.namelist())==set(members)
 for name,pin in members.items():
  b=z.read(name);assert h(b)==pin['sha256'] and len(b)==pin['bytes'],name
 def obj(name):return json.loads(z.read(name))
 controls=obj('context-controls.json'); loc=obj('native-inputs-base/native-locators.json')
 from truss._current_disclosure_context_capture import _join_population
 defs=SimpleNamespace(report=z.read('context-definition-report.json'),model=SimpleNamespace(report=z.read('context-model-report.json')))
 c=SimpleNamespace(facts_bytes=z.read('context-facts.json'),coverage_bytes=z.read('context-coverage.json'),rows=tuple(tuple(r) for r in loc['objects']),graphs_bytes=z.read('context-graphs.json'),graph_coverage_bytes=z.read('context-graph-coverage.json'),graph_rows=tuple(tuple(r) for r in loc['edges']))
 _join_population(defs,c)
 mutants=[]
 for label,attr,edit in [('duplicate-object','rows',lambda a:a.__setitem__(1,a[0])),('duplicate-edge','graph_rows',lambda a:a.__setitem__(1,a[0]))]:
  m=copy.copy(c);a=list(getattr(m,attr));edit(a);setattr(m,attr,tuple(a))
  try:_join_population(defs,m)
  except ValueError:mutants.append(label)
  else:raise AssertionError(label)
 assert len(obj('context-facts.json'))==14 and len(obj('context-graphs.json'))==12
 assert obj('context-rendered-batch.json')['rows']==[[{'state':'original','value':{'integer':'100'}}]]
base='d47fb4c8faf26651f4b3f82266c5cc9040bba632'
name='packages/python/src/truss/_current_disclosure_originals.py'
before=subprocess.check_output(['git','-C','/Users/erik/Projects/truss','show',base+':'+name]);after=(P/name).read_bytes()
(O/'originals-before.py').write_bytes(before)
a=ast.parse(before);b=ast.parse(after)
def cohort(tree):
 for n in tree.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_CONSUMER_COHORTS' for t in n.targets):return n
x=cohort(a);y=cohort(b);assert len(x.value.elts)==1 and len(y.value.elts)==2
assert ast.dump(x.value.elts[0])==ast.dump(y.value.elts[0]);y.value.elts=y.value.elts[:1];assert ast.dump(a)==ast.dump(b)
summary={'status':'passed','packetFiles':len(manifest),'archiveMembers':len(members),'independentControls':['actual retained context population correspondence','duplicate object private identity refusal','duplicate edge occurrence refusal','old cohort and all remaining originals AST unchanged'],'observations':controls,'sourcePins':manifest,'nativeExecutionByReviewer':False}
(O/'audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
