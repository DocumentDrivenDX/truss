import pathlib,json,hashlib,shutil,datetime,subprocess
P=pathlib.Path('/private/tmp/truss-context-composition-review-20261016');O=pathlib.Path('/private/tmp/truss-context-composition-review-result-20261016');E=P/'docs/helix/04-build/evidence/context-population-composition-20261016'
h=lambda b:hashlib.sha256(b).hexdigest()
for rel in ['manifest.json',*json.loads((P/'manifest.json').read_bytes())]:
 d=O/'reviewed-inputs'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/rel,d)
shutil.copyfile('/private/tmp/truss-context-old-consumer-66-20261016.log',O/'supplemental-old-consumer-66.log')
pre=json.loads((E/'preflight.json').read_bytes());post=json.loads((E/'postflight.json').read_bytes())
# The native test correction is intentionally a distinct source epoch.
checks={}
for rel,pin in post['finalSources'].items():
 p=P/rel
 if p.exists():b=p.read_bytes()
 else:b=subprocess.check_output(['git','-C','/Users/erik/Projects/truss','show','d47fb4c8faf26651f4b3f82266c5cc9040bba632:'+rel])
 assert h(b)==pin,rel
 checks[rel]=pin
(O/'selected-source-correspondence.json').write_text(json.dumps(checks,indent=2)+'\n')
review={
 'status':'no-findings-within-bounded-scope','findings':[],
 'startedAt':'2026-10-16T20:24:37Z','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base':'d47fb4c8faf26651f4b3f82266c5cc9040bba632','packet':str(P),'packetManifestSha256':h((P/'manifest.json').read_bytes()),
 'scope':['same actual compiler parent/current through native definition/population capture, stage and inspector, and closing','complete selected coverage, typed object/edge incidence and distinct parallel occurrences','second exact opt-in cohort, preserved existing path, and scoped evidence claims'],
 'conclusions':[
 'Capture issues one actual parent/current. Native Graph/Model factories retain it; evaluator verifies exact current type, actual parent identity and original sourceRequestJson before reuse; closing uses that same current and compares reports plus complete original capture.',
 'Record/member and relationship/role coverage use exact census and type-sensitive comparison. Private object/edge census is compared with logical projections; endpoint Keys come from corresponding captured typed objects. Parallel edges remain distinct by native witness ID. This composes existing native Key/definition checks and UMF policy evaluation; it introduces no policy interpreter.',
 'Only a second complete explicit binary cohort is added. The old cohort and all other originals-module AST are identical. Evaluator checks after context issuance remain unchanged; the old uncomposed issuance path remains.',
 'Supplied native evidence distinguishes prior diagnostic source-wrapper setup from the new committed registered-source phase without substitution. Actual new composition covers 14 objects/12 edges; parallel occurrence coverage here is a pure control, not a new 13-edge native composition campaign.',
 'Registration/source archival and endpoint closing do not establish binding admission, authenticated Subject/current authority, ABA exclusion, full codec equivalence or guarded release. README explicitly preserves those exclusions and all 158 case allocations.'
 ],
 'independentValidation':{'focusedUnitTests':7,'unitSeconds':0.109,'actualExtensionUsed':True,'packetFileHashes':15,'nativeArchiveMemberHashesAndSizes':24,'selectedSourcePins':7,'additionalChecks':['retained actual native population replay through pure join','duplicate object identity refusal','duplicate edge occurrence refusal','old cohort/full remaining originals AST equality'],'unitCommand':'PYTHONPATH=<reconstructed base+overlay src>:<tests>:/private/tmp/truss-graph-requirements-final-weft-installed-20261016 TRUSS_GRAPH_JOIN_WEFT_QUALIFICATION=1 /private/tmp/truss-practical-performance-env/bin/python -B -m unittest test_current_disclosure_context_capture -v','auditCommand':'PYTHONPATH=<reconstructed src>:<final Weft install> /private/tmp/truss-practical-performance-env/bin/python -B audit.py'},
 'suppliedEvidence':{'nativeTests':1,'nativeSeconds':31.259,'nativeReplayedByReviewer':False,'newCompilerCohortVectors':66,'newCohortLogSeconds':31.850,'oldCohortSupplementalLogSeconds':33.719,'cohortVectorsReplayedByReviewer':False,'originalInvalid90SecondSetupRetained':True},
 'reviewerAttemptHistory':'audit-first.py/log retain an incorrect reviewer expected V2 cell spelling (state/integer). Corrected to the actual public disposition/integerToken shape; audit.py passes. This was a reviewer harness error, not a source finding.',
 'incompleteScope':['No independent SQL or native campaign, heavy build, or repeat of either 66-vector campaign. Supplied native cleanup/source endpoint receipts were checked as retained evidence, not independently observed process state.','No general theorem of complete physical mapping, all model/Key shapes, concurrency/ABA, authority, guarded release or backend acceptance. Latest live README/retention additions and later 17-test run were not part of the frozen review.'],
 'sourceEdits':False,'nativeExecution':False,'casePromotion':0,
 'artifactManifest':'manifest.json','workingTreeOutsideEvidence':'/private/tmp/truss-context-composition-review-work-20261016'
}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name!='manifest.json' or (p.is_file() and p!=O/'manifest.json'):
  b=p.read_bytes();files.append({'path':str(p.relative_to(O)),'sha256':h(b),'bytes':len(b)})
manifest={'version':1,'files':files,'artifactCount':len(files),'totalBytes':sum(x['bytes'] for x in files),'excludes':['manifest.json (self)']}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'review':h((O/'review.json').read_bytes()),'manifest':h((O/'manifest.json').read_bytes()),'artifacts':len(files),'bytes':manifest['totalBytes'],'completedAt':review['completedAt']},indent=2))
