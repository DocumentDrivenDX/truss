import pathlib,json,hashlib,ast,copy
from truss._current_disclosure_context_capture import _coverage_membership
P=pathlib.Path('/private/tmp/truss-context-coverage-fix-review-20261016');O=pathlib.Path('/private/tmp/truss-context-coverage-fix-review-result-20261016')
h=lambda b:hashlib.sha256(b).hexdigest()
for f,d in json.loads((P/'manifest.json').read_bytes()).items():assert h((P/f).read_bytes())==d
A=ast.parse((P/'context-before.py').read_bytes());B=ast.parse((P/'context-after.py').read_bytes())
def funcs(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=funcs(A),funcs(B)
for name,node in a.items():
 if name!='_join_population':assert ast.dump(node)==ast.dump(b[name]),name
# Only the coverage comparison expression changes in _join_population.
x=copy.deepcopy(a['_join_population']);y=copy.deepcopy(b['_join_population'])
for node in (x,y):
 first=next(n for n in node.body if isinstance(n,ast.If));first.test=ast.Constant(value='coverage comparison checked separately')
assert ast.dump(x)==ast.dump(y)
r={'documentId':'d','moduleId':'m','elementId':'r'};f={'documentId':'d','moduleId':'m','elementId':'a'};g={**f,'elementId':'b'}
base=[{'type':r,'complete':True,'fields':[f,g]}]
assert _coverage_membership(base)==_coverage_membership([{**base[0],'fields':[g,f]}])
edits=[('missing-field',lambda v:v[0]['fields'].pop()),('foreign-document',lambda v:v[0]['fields'][0].update(documentId='x')),('foreign-module',lambda v:v[0]['fields'][0].update(moduleId='x')),('foreign-element',lambda v:v[0]['fields'][0].update(elementId='x')),('foreign-record',lambda v:v[0]['type'].update(elementId='x'))]
for name,edit in edits:
 v=copy.deepcopy(base);edit(v);assert _coverage_membership(v)!=_coverage_membership(base),name
bad=[('duplicate-field',lambda v:v[0]['fields'].append(copy.deepcopy(v[0]['fields'][0]))),('duplicate-record',lambda v:v.append(copy.deepcopy(v[0]))),('integer-complete',lambda v:v[0].update(complete=1)),('false-complete',lambda v:v[0].update(complete=False)),('extra-row-key',lambda v:v[0].update(extra=1)),('extra-field-key',lambda v:v[0]['fields'][0].update(extra=1)),('empty-identity',lambda v:v[0]['fields'][0].update(moduleId='')),('integer-identity',lambda v:v[0]['fields'][0].update(moduleId=1)),('nonarray-fields',lambda v:v[0].update(fields={}))]
for name,edit in bad:
 v=copy.deepcopy(base);edit(v)
 try:_coverage_membership(v)
 except ValueError:pass
 else:raise AssertionError(name)
result={'status':'passed','packetFiles':4,'controls':15,'positive':'identical unique full identities accept reordered field coverage','negativeMembershipControls':[x[0] for x in edits],'malformedOrDuplicateRefusals':[x[0] for x in bad],'sourcePreservation':'Every existing function/class AST unchanged except the one coverage comparison expression; _inputs and all Key/graph/endpoint/capture/closing code preserved.'}
(O/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
