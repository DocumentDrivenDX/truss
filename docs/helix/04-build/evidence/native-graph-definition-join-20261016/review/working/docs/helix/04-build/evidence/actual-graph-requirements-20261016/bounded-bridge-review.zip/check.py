from pathlib import Path
import hashlib,json,zipfile,subprocess,gzip,tomllib
p=Path(__file__).resolve().parent;s=Path('/private/tmp/weft-graph-bridge-frozen-review-20261016');H=lambda b:hashlib.sha256(b).hexdigest();pins=json.loads((s/'review-pins.json').read_bytes());commit=pins['commit'];repo='/Users/erik/Projects/weft'
selected=set(pins['files'])|{'review-pins.json','review.diff','crates/weft-core/Cargo.toml','crates/weft-runtime/Cargo.toml','crates/weft-python/Cargo.toml','crates/weft-core/src/current_presence.rs','crates/weft-core/src/current_presence_model_requirements.rs','crates/weft-core/src/security_budget.rs','crates/weft-core/src/security_ontology.rs','crates/weft-core/src/security_association_ref.rs','docs/helix/02-design/contracts/CONTRACT-017-current-presence-graph-requirements.md','docs/helix/02-design/contracts/current-presence-graph-requirements-v0.1-candidate.schema.json','docs/helix/03-test/test-plans/current-presence-graph-requirements.md','tests/current-query-presence/fixtures/unadmitted-context.request.json','.github/workflows/conformance.yml'}
for n,h in pins['files'].items():assert H((s/n).read_bytes())==h
for n in selected-{'review-pins.json','review.diff'}:assert (s/n).read_bytes()==subprocess.check_output(['git','-C',repo,'show',commit+':'+n]),n
e=s/'docs/helix/04-build/evidence/graph-output-retention-20261016';ret=json.loads((e/'retention.json').read_bytes());selected.add(str((e/'retention.json').relative_to(s)))
for n,v in ret['files'].items():
 b=(s/n).read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'];selected.add(n)
# Retain relevant historical evidence separately; not credited as final source.
for folder in ['current-presence-graph-bridge-20261016','current-presence-graph-requirements-20261016']:
 for f in (s/'docs/helix/04-build/evidence'/folder).iterdir():
  if f.is_file() and f.suffix!='.whl':selected.add(str(f.relative_to(s)))
for n in selected:
 t=p/'inputs'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes((s/n).read_bytes())
for crate in ['weft-core','weft-runtime','weft-python']:
 f=tomllib.loads((s/f'crates/{crate}/Cargo.toml').read_text())['features'];assert 'current-presence-model-requirements-candidate' in f['current-presence-graph-requirements-candidate'];assert 'current-presence-graph-requirements-candidate' not in f.get('default',[])
wheel=e/'weft_sql-0.4.39-cp39-abi3-macosx_11_0_arm64.whl';assert H(wheel.read_bytes())=='25947eaea9cd42db79a2671664e7829af10d79a802a82cf92f5ddc0b2675e5c8'
with zipfile.ZipFile(wheel) as z:z.extractall(p/'installed')
run=subprocess.run(['/private/tmp/truss-practical-performance-env/bin/python','-B',str(s/'tests/current-query-presence/python-graph-requirements-bridge.py'),str(p/'installed'),'graph'],capture_output=True,text=True,timeout=25);(p/'python-38.log').write_text(run.stdout+run.stderr);assert run.returncode==0;assert json.loads(run.stdout)['passed']==38
report={'passed':True,'commit':commit,'reviewPins':len(pins['files']),'gitCorrespondenceFiles':len(selected-set(n for n in selected if n.startswith('docs/helix/04-build/evidence/'))-{'review-pins.json','review.diff'}),'finalRetentionMembers':len(ret['files']),'retainedSelectedInputs':len(selected),'independentActualNativeExtensionControls':38,'wheelSha256':H(wheel.read_bytes()),'featureGraphExplicitAndDefaultUnchanged':True,'scope':'Actual supplied Python extension replay plus static source/evidence checks; no Rust build, SQL, or native admission'};(p/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
