from pathlib import Path
import sys,json,copy,hashlib
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p/'installed'));import weft
s=Path('/private/tmp/weft-graph-bridge-frozen-review-20261016');base=json.loads((s/'tests/current-query-presence/fixtures/unadmitted-context.request.json').read_text());wire=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'));H=lambda x:hashlib.sha256(x.encode()).hexdigest();ref=lambda x:{'documentId':'domain','moduleId':'m','elementId':x};records=[]
def build(mut=None):
 q=copy.deepcopy(base);d=json.loads(q['modules'][0]['documentJson']);ont=json.loads(next(v['utf8'] for v in q['opaqueSources'] if v['role']=='ontology'))
 declaration={'id':'Assignment','name':'same nominal spelling','source':[{'module':'m','element':'Assignment'},{'module':'m','element':'Assignment'}],'target':[{'module':'m','element':'Project','key':'pk'},{'module':'m','element':'Project','key':'pk'}],'directed':True,'sourceMultiplicity':{'min':0,'max':'*'},'targetMultiplicity':{'min':0,'max':'*'},'targetLifecycle':'independent'};d['modules'][0]['relationships']=[declaration]
 selection={'kind':'core-relationship','relationship':{'documentId':'domain','moduleId':'m','relationshipId':'Assignment'},'witness':{'kind':'opaque-existential'},'endpoints':[{'role':'assignment','side':'source','target':ref('Assignment'),'keyId':'pk'},{'role':'project','side':'target','target':ref('Project'),'keyId':'pk'}]};ont['associations'].append(selection)
 if mut:mut(d,ont,declaration,selection)
 raw=wire(d);q['modules'][0]['documentJson']=raw;q['modules'][0]['pin']['sha256']=H(raw)
 for source in q['opaqueSources']:
  if source['role']=='ontology':source['utf8']=wire(ont);source['sha256']=H(source['utf8'])
 profile=next(x for x in q['opaqueSources'] if x['role']=='presence-designation');v=json.loads(profile['utf8']);v['modelPins']=[m['pin'] for m in q['modules']]
 for pin in v['sources']:
  pin['sha256']=next(x['sha256'] for x in q['opaqueSources'] if x['role']==pin['role'])
 profile['utf8']=wire(v);profile['sha256']=H(profile['utf8']);return q
def run(label,mut=None,refusal=False):
 q=build(mut);raw=wire(q)
 try:parent=weft.prepare_application_lineage(raw);child=parent.prepare_current_presence();out=child.graph_requirements_json()
 except (ValueError,TypeError) as e:
  assert refusal,(label,str(e));records.append({'case':label,'refused':True,'error':str(e),'requestSha256':H(raw)});return
 assert not refusal,label
 v=json.loads(out);assert v['authority'] is False and v['complete'] is False and v['securityReady'] is False and v['sourceRequestJson']==raw;records.append({'case':label,'refused':False,'reportSha256':H(out),'requestSha256':H(raw),'associations':v['associations']});return v
v=run('duplicate nominal declarations');g=v['associations'][2];assert g['reference'].get('relationshipId')=='Assignment' and 'elementId' not in g['reference'];assert g['endpoints'][0]['declarationOrdinals']==g['endpoints'][1]['declarationOrdinals']==[0,1]
v=run('repeat selected graph',lambda d,o,a,x:o['associations'].append(copy.deepcopy(x)));assert len(v['associations'])==4 and v['associations'][3]['ordinal']==3
v=run('source annotation is not a Key default',lambda d,o,a,x:a['source'][0].update(key='nonexistent-annotation'));assert v['associations'][2]['endpoints'][0]['key']['id']=='pk' and 'key' not in v['associations'][2]['sources'][0]
def composite(d,o,a,x):
 record=next(e for e in d['modules'][0]['elements'] if e['id']=='Assignment');record['keys'].append({'id':'alternate','name':'composite','fields':[{'module':'m','element':'assignmentProject'},{'module':'m','element':'assignmentStaff'}],'primary':False});a['target'].append({'module':'m','element':'Assignment','key':'alternate'})
v=run('unselected authored composite target order',composite);g=v['associations'][2];assert [f['element'] for f in g['targets'][2]['key']['fields']]==['assignmentProject','assignmentStaff'] and g['endpoints'][1]['declarationOrdinals']==[0,1]
for label,mut in [('missing target Key',lambda d,o,a,x:a['target'][0].pop('key')),('null target Key',lambda d,o,a,x:a['target'][0].update(key=None)),('unknown target Key',lambda d,o,a,x:a['target'][0].update(key='unknown')),('wrong nominal namespace',lambda d,o,a,x:x.update(relationship=ref('Assignment'))),('duplicate endpoint side',lambda d,o,a,x:x['endpoints'][1].update(side='source')),('selected Key mismatch',lambda d,o,a,x:x['endpoints'][1].update(keyId='other')),('unmatched target',lambda d,o,a,x:x['endpoints'][1].update(target=ref('Staff'))),('opaque witness for association Record',lambda d,o,a,x:a.update(associationRecord={'module':'m','element':'Ownership'}))]:run(label,mut,True)
(p/'adversarial.json').write_text(json.dumps({'passed':True,'controls':len(records),'results':records,'scope':'Actual retained native extension data-only calls; no SQL or native admission'},indent=2)+'\n');print(json.dumps({'passed':True,'controls':len(records)}))
