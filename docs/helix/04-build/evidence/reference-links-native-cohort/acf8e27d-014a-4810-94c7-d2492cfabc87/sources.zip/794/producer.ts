export {inspectCoreRecordMembers} from './src/model/record-members';
