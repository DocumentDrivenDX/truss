export {inspectCoreReferenceLinks} from './src/model/reference-links';
