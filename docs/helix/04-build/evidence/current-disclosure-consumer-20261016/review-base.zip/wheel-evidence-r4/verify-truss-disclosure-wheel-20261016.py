from pathlib import Path,PurePosixPath
from hashlib import sha256
from email.parser import BytesParser
import zipfile,json,sys
root=Path('/private/tmp/truss-presence-consumer-owner-20261016/packages/python/src')
wheel=Path('/private/tmp/truss-presence-consumer-wheel-r4-20261016/truss_toolkit-0.0.36.dev0-py3-none-any.whl')
installed=Path('/private/tmp/truss-presence-consumer-wheel-installed-r4-20261016');installed.mkdir(exist_ok=False)
verified={}
with zipfile.ZipFile(wheel) as z:
 names=z.namelist();assert len(names)==len(set(names))
 for name in names:
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
  if name.endswith('/'):continue
  raw=z.read(name);target=installed.joinpath(*p.parts);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  if name.startswith('truss/'):
   assert (root/name).read_bytes()==raw,name
   verified[name]=sha256(raw).hexdigest()
 metadata=BytesParser().parsebytes(z.read('truss_toolkit-0.0.36.dev0.dist-info/METADATA'))
 requirements=metadata.get_all('Requires-Dist');assert any('weft-sql==0.4.36' in r and 'query' in r for r in requirements)
 for path in (root/'truss/_current_disclosure_owner').rglob('*'):
  if path.is_file():assert str(path.relative_to(root)) in names
sys.path.insert(0,str(installed));sys.path.insert(1,'/private/tmp/weft-presence-python-combined-installed-20261016')
import truss
import truss._current_disclosure_originals as originals
import truss._current_query_originals as legacy
assert Path(truss.__file__).resolve()==installed/'truss/__init__.py'
consumer=originals._actual_disclosure_consumer()
fixture=json.loads(Path('/private/tmp/truss-presence-consumer-owner-20261016/packages/python/tests/fixtures/current-disclosure/source-correspondence.json').read_bytes())
wire=lambda x:json.dumps(x,separators=(',',':')).encode()
selected=truss.prepare_current_disclosure_originals(wire(fixture['opaqueSources']))
originals.check_disclosure_originals(selected,wire(fixture['initialize']),wire(fixture['acceptedRequest']))
try:legacy._actual_consumer()
except ValueError:pass
else:raise AssertionError('Old consumer unexpectedly enrolled presence wheel')
assert truss.CurrentDisclosureExecutor is not truss.CurrentQueryExecutor
receipt={'status':'passed','scope':'Local isolated wheel build/content/import and exact installed consumer/source-profile correspondence, no native SQL/authentication/release proof. Query extra unchanged at0.4.36; new candidate requires explicit matching local presence wheel. Source endpoint bytes compared, not hermetic or held-file proof.','wheelSha256':sha256(wheel.read_bytes()).hexdigest(),'wheelBytes':wheel.stat().st_size,'verifiedSourceMembers':verified,'requirements':requirements,'consumer':consumer,'installed':str(installed),'python':sys.version}
Path('/private/tmp/truss-disclosure-wheel-verification-20261016.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':True,'verifiedSourceMembers':len(verified),'wheelSha256':receipt['wheelSha256'],'nativeSQL':False}))
