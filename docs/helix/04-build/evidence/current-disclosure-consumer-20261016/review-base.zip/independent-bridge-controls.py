from pathlib import Path
import sys,os,json,time,types,re,copy,hashlib
from unittest.mock import patch
R=Path(__file__).parent;S=R/'source';sys.path[:0]=[str(S/'packages/python/src'),str(R/'wheel'),str(S/'packages/python/tests')]
import truss._current_disclosure_evaluation as evaluation
import truss._current_disclosure_stage as staging
from truss._current_disclosure_originals import prepare_current_disclosure_originals,check_disclosure_originals
from truss._current_query_sources import _DISCLOSURE_PROFILE,_initialize
from truss._current_query_evaluation import wire
from _current_disclosure_simulated_cursor import StageCursor
F=R/'frozen/packages/python/tests/fixtures/current-disclosure';vectors=json.loads((F/'native-disclosure-child-vectors.json').read_bytes());corpus=json.loads((F/'actual-atomic-transport.json').read_bytes());byid={p['id']:p for p in vectors['packets']};cases={p['id']:p for p in corpus['cases']};checks=[]
class Cursor(StageCursor):
 def execute(self,q,parameters=None,**kw):
  text=q.as_string() if hasattr(q,'as_string') else q
  if text=='SELECT pg_catalog.pg_current_xact_id()::pg_catalog.text':self.out=('fixture-generation',);return self
  if text.startswith('CREATE') and self.mode=='create-fails':raise ValueError('modeled creation failure')
  if text.startswith('DROP') and self.mode=='drop-fails':raise ValueError('modeled cleanup failure')
  out=super().execute(q,parameters,**kw)
  if text.startswith('SELECT private_key'):self.description=[types.SimpleNamespace(type_code=25)]*2
  self.capturing=text.startswith('SELECT private_key');return out
 def fetchmany(self,n):
  rows=super().fetchmany(n)
  if self.capturing:
   if self.mode=='capture-missing':rows=rows[1:]
   if self.mode=='capture-duplicate' and rows:rows[-1]=rows[0]
   if self.mode=='capture-changed' and rows:rows[0]=(rows[0][0],'{"kind":"absent"}')
  return rows
class Raw:
 def __init__(self,connection,**kw):self.c=connection
 def __enter__(self):return self
 def __exit__(self,*a):pass
 def execute(self,q,**kw):
  assert q.startswith('SELECT ') and kw=={'prepare':False,'binary':False};self.c.sql=q
  width=len(re.findall(r'AS "output_\d+"',q));assert width in (1,2),q
  self.description=[types.SimpleNamespace(type_code=25,name='output_'+str(i)) for i in range(width)]+[types.SimpleNamespace(type_code=25,name='__weft_source_rows')]
  self.rows=[tuple([r[1]]*width+[json.dumps({'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':r[0]}]})]) for r in reversed(self.c.rows)]
  if self.c.mode=='missing':self.rows=self.rows[1:]
  if self.c.mode=='duplicate' and self.rows:self.rows[-1]=self.rows[0]
  if self.c.mode=='changed-cell' and self.rows:self.rows[0]=('{"kind":"absent"}',)+self.rows[0][1:]
  if self.c.mode=='null' and self.rows:self.rows[0]=(None,)+self.rows[0][1:]
  if self.c.mode=='forged-key' and self.rows:self.rows[0]=self.rows[0][:-1]+(json.dumps({'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':'999'}]}),)
  if self.c.mode=='wrong-oid':self.description[0].type_code=23
  if self.c.mode=='wrong-name':self.description[0].name='salary'
  if self.c.mode=='extra' and self.rows:self.rows.append(self.rows[0])
 def fetchmany(self,n):return self.rows[:n]
def run(id,mode='good',repeat=False):
 p=byid[id];src=vectors['sources'][p['sourceIndex']];base=cases[{0:'allowed:string',1:'allowed:withheld',2:'allowed:transformed-null'}[p['sourceIndex']]]
 initial=wire({'kind':'initialize','requestId':'registered','sources':{**{k:src[k] for k in ('policy','catalog','closure','ontology')},'associationBindings':[],'extensionSelection':{}}})
 originals=prepare_current_disclosure_originals(wire(base['request']['opaqueSources']));accepted=wire({'modules':base['request']['modules']});check_disclosure_originals(originals,initial,accepted)
 sources=types.SimpleNamespace(source_profile=_DISCLOSURE_PROFILE,query_originals=originals,accepted_request_bytes=accepted,initialize_bytes=initial,source_receipt=_initialize(initial));captured=types.SimpleNamespace(sources=sources,facts_bytes=wire(p['cut']['facts']),coverage_bytes=wire(p['cut']['coverage']));cursor=Cursor(mode);cursor._deadline.end=time.monotonic()+60
 with patch.object(staging,'RawCursor',Raw),patch.object(staging,'_text_rows',return_value=[('pg_temp_7',)]):
  try:
   held=evaluation.evaluate_and_stage_current_disclosure(cursor,captured,types.SimpleNamespace(key=p['cut']['subject']['key'][0]['string']),sql='SELECT r.token AS second, r.token AS first FROM Resource r' if repeat else base['request']['sql'],parameters={},document_ids=tuple(m['pin']['documentId'] for m in base['request']['modules']),bun_executable='/opt/homebrew/bin/bun',maximum_rows=4096,maximum_scan_rows=4096,maximum_bytes=8_000_000)
   held.require_original_parent();assert mode=='good';assert json.loads(held.staged.reconstructed_batch)==p['result']['batch'];assert held.staged.field_indexes==((0,0) if repeat else (0,));assert cursor.dropped
   result={'outcome':'matched','rows':len(p['result']['resources']),'fieldIndexes':held.staged.field_indexes,'batchSha256':hashlib.sha256(held.staged.reconstructed_batch).hexdigest()}
  except ValueError as error:
   if mode=='good':raise
   assert cursor.dropped or mode in ('create-fails','drop-fails');result={'outcome':'refused','error':str(error)}
 checks.append({'id':id,'mode':mode,'repeatedProjection':repeat,'passed':True,'cleanupDropObserved':cursor.dropped,'sql':getattr(cursor,'sql',None),**result})
for id in [p['id'] for p in vectors['packets'] if p['id'].startswith('mixed:')]:
 run(id);run(id,repeat=True)
for mode in ['missing','duplicate','changed-cell','null','forged-key','wrong-oid','wrong-name','extra','capture-missing','capture-duplicate','capture-changed','create-fails','drop-fails']:run('mixed:mixed-string',mode)
(R/'independent-bridge-controls.json').write_text(json.dumps({'status':'passed','scope':'Actual packaged UMF child and reviewed Weft extension; modeled SQL cursor only, no database or native guard authority.','checks':checks},indent=2)+'\n');print(len(checks),'passed')
