from pathlib import Path
import json,hashlib,subprocess,tarfile,shutil,zipfile
r=Path(__file__).parent;f=r/'frozen';m=json.loads((f/'manifest.json').read_text());o=Path('/Users/erik/Projects/truss');s=r/'source';s.mkdir(exist_ok=True)
for p,v in m['files'].items():
 b=(f/p).read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v['bytes']
with (r/'base.tar').open('wb') as out:subprocess.run(['git','archive',m['baseline']],cwd=o,stdout=out,check=True)
with tarfile.open(r/'base.tar') as t:
 for x in t.getmembers():assert not x.name.startswith('/') and '..' not in Path(x.name).parts and not x.issym() and not x.islnk()
 t.extractall(s)
for p in m['files']:
 if p.startswith('packages/'):
  d=s/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f/p,d)
pins={str(p.relative_to(s)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in s.rglob('*') if p.is_file()};(r/'source-before.json').write_text(json.dumps(pins,indent=2)+'\n')
with zipfile.ZipFile(r/'reconstructed-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(pins):z.write(s/p,p)
changes={}
for p in m['files']:
 if p.startswith('packages/'):
  old=subprocess.run(['git','show',m['baseline']+':'+p],cwd=o,capture_output=True)
  if old.returncode==0:
   q=r/'base'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(old.stdout)
   changes[p]='unchanged' if old.stdout==(f/p).read_bytes() else 'modified'
  else:changes[p]='added'
(r/'changes.json').write_text(json.dumps(changes,indent=2)+'\n');print({'manifestFiles':len(m['files']),'reconstructedFiles':len(pins)})
