from pathlib import Path
import json,hashlib,zipfile,base64,csv,io,sys,os,subprocess
from email.parser import BytesParser
R=Path(__file__).parent;S=R/'source';sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(id,v):
 assert v,id
 checks.append({'id':id,'passed':True})
m3=json.loads((R/'frozen/manifest.json').read_text());m4=json.loads((R/'frozen-r4/manifest.json').read_text())
for epoch,m in [('frozen',m3),('frozen-r4',m4)]:
 for p,v in m['files'].items():
  b=(R/epoch/p).read_bytes();check(epoch+':'+p,sha(b)==v['sha256'] and len(b)==v['bytes'])
for p,v in m3['files'].items():check('r3-r4-identical:'+p,m4['files'][p]==v)
check('r4-only-three-additions',len(m4['files'])==len(m3['files'])+3)
source_pins=json.loads((R/'source-before.json').read_text());selected={p:v for p,v in source_pins.items() if p.startswith('packages/python/')}
for p,v in selected.items():
 b=(S/p).read_bytes();check('source-unchanged:'+p,sha(b)==v['sha256'] and len(b)==v['bytes'])
with zipfile.ZipFile(R/'python-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(selected):z.write(S/p,p)
(R/'python-source-pins.json').write_text(json.dumps(selected,indent=2)+'\n')
wroot=R/'wheel-evidence-r4';wm=json.loads((wroot/'manifest.json').read_text());receipt=json.loads((wroot/'truss-disclosure-wheel-verification-20261016.json').read_text())
for p,v in wm['files'].items():
 b=(wroot/p).read_bytes();check('wheel-evidence:'+p,sha(b)==v['sha256'] and len(b)==v['bytes'])
wheel=wroot/'truss_toolkit-0.0.36.dev0-py3-none-any.whl';installed=R/'truss-wheel';installed.mkdir()
with zipfile.ZipFile(wheel) as z:
 names=z.namelist();check('wheel-distinct-members',len(names)==len(set(names)))
 for n in names:
  check('safe-wheel-path:'+n,not n.startswith('/') and '..' not in Path(n).parts)
  if n.endswith('/'):continue
  b=z.read(n);p=installed/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  if n.startswith('truss/'):
   check('wheel-source:'+n,b==(S/'packages/python/src'/n).read_bytes());check('wheel-receipt:'+n,sha(b)==receipt['verifiedSourceMembers'][n])
 for n,h,size in csv.reader(io.StringIO(z.read('truss_toolkit-0.0.36.dev0.dist-info/RECORD').decode())):
  if h:
   b=z.read(n);check('wheel-record:'+n,h=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(b).digest()).decode().rstrip('=') and len(b)==int(size))
 metadata=BytesParser().parsebytes(z.read('truss_toolkit-0.0.36.dev0.dist-info/METADATA'));check('query-extra-unchanged',any('weft-sql==0.4.36' in v and 'query' in v for v in metadata.get_all('Requires-Dist')))
 check('all496-source-members',len([n for n in names if n.startswith('truss/') and not n.endswith('/')])==len(receipt['verifiedSourceMembers'])==496)
 for p in (S/'packages/python/src/truss/_current_disclosure_owner').rglob('*'):
  if p.is_file():check('packaged-owner:'+str(p.name),str(p.relative_to(S/'packages/python/src')) in names)
check('native-module',sha((R/'wheel/weft/weft.abi3.so').read_bytes())=='a94439b3949c6db574ded8d95d9b81b23e128b0cbb7570edff65228d3737c402')
py='/private/tmp/truss-practical-performance-env/bin/python';code="from pathlib import Path; import truss; from truss._current_disclosure_originals import _actual_disclosure_consumer; import truss._current_query_originals as old; assert Path(truss.__file__).resolve()==Path("+repr(str(installed/'truss/__init__.py'))+"); print(_actual_disclosure_consumer());\ntry: old._actual_consumer()\nexcept ValueError: print('Old profile correctly refuses candidate wheel')\nelse: raise AssertionError('old profile accepted candidate')\n"
(R/'installed-import-control.py').write_text(code)
with (R/'installed-import-control.log').open('wb') as log:p=subprocess.run([py,str(R/'installed-import-control.py')],env={**os.environ,'PYTHONPATH':str(installed)+':'+str(R/'wheel'),'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT,timeout=10)
check('installed-wheel-actual-profile',p.returncode==0)
report={'status':'passed','checks':checks,'sourceFilesUnchanged':len(selected),'wheelSourceMembers':496,'scope':'Exact source/packet/wheel bytes and installed import; supplied installed-wheel test log is not an independently replayed wheel test campaign. Source compiler/child tests were independently replayed on byte-identical source; no SQL.'}
(R/'custody-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(len(checks),'passed')
