import json,hashlib,pathlib,sys,time
from dataclasses import dataclass
from truss._current_disclosure_session import evaluate_stage_inspect
from truss._current_disclosure_pipe import CurrentDisclosurePipe,VERSION
from truss._current_disclosure_wire import frame_digest
from truss._current_query_evaluation import wire
root=pathlib.Path('/private/tmp/umf-held-native-disclosure-astra-20261016/reconstructed')
bundle_root=pathlib.Path('/private/tmp/umf-native-disclosure-child-bundle-r1-20261016')
manifest_raw=(bundle_root/'manifest.json').read_bytes();manifest=json.loads(manifest_raw)
bundle=bundle_root/'current-native-disclosure-child.mjs';sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(bundle.read_bytes())==manifest['bundleSha256']=='d333226d9186136704d3f84a9c9dbfc44796efebab563dbc732d60337d2e03eb'
vector_path=root/'tests/security/protection/native-disclosure-child-vectors.json';vector_raw=vector_path.read_bytes();vectors=json.loads(vector_raw)
source_root=pathlib.Path('/private/tmp/truss-presence-consumer-owner-20261016/packages/python/src/truss')
inputs={str(p):sha(p.read_bytes()) for p in [pathlib.Path(__file__),vector_path,bundle,bundle_root/'manifest.json',*(source_root/n for n in ['_current_disclosure_session.py','_current_disclosure_pipe.py','_current_disclosure_wire.py','_current_query_pipe.py','_owner_evidence_json.py'])]}
@dataclass
class Staged:reconstructed_batch:bytes
class Deadline:
 def __init__(self):self.end=time.monotonic()+20
 def check(self):
  if time.monotonic()>self.end:raise TimeoutError('Held disclosure replay deadline')
records=[]
for packet in vectors['packets']:
 source=vectors['sources'][packet['sourceIndex']]
 initial=wire(dict(version=VERSION,kind='initialize',requestId='init',sources={**{k:source[k] for k in ['policy','catalog','closure','ontology']},'associationBindings':[]},owner=source['owner'],selection=packet['selection']))
 evaluation=wire(dict(version=VERSION,kind='evaluate-disclosure',requestId='eval',sourceReceipt=frame_digest(initial),cut=packet['cut']))
 stages=[]
 def stage(raw):
  produced=json.loads(raw);assert produced==packet['result'];stages.append(True)
  return Staged(wire(produced['batch']))
 with CurrentDisclosurePipe(('/opt/homebrew/bin/bun',str(bundle)),timeout_seconds=20) as child:
  try:result=evaluate_stage_inspect(child,Deadline(),initial,evaluation,stage)
  except ValueError:
   assert packet['result']['status']=='refused' and not stages
   outcome='producer-refusal'
  else:
   assert packet['result']['status']=='rendered' and len(stages)==1 and json.loads(result.reconstructed_batch)==packet['result']['batch']
   outcome='held-inspected-data-only'
 assert child._cleanup_complete and child._child.poll() is not None
 records.append({'id':packet['id'],'outcome':outcome,'cleanupConfirmed':True})
assert len(records)==72 and sum(r['outcome']=='held-inspected-data-only' for r in records)==47
assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in inputs.items())
receipt={'status':'passed','scope':'Actual UMF0.2 child and Truss private session sequencing over supplied logical vectors; callback returns producer batch without native SQL/staging, caller/source/current-authority or guarded release. Candidate bundle, no enrollment or acceptance promotion. Input endpoint hashes only, not held-file/hermetic proof.','records':records,'inputs':inputs,'python':sys.version}
pathlib.Path('/private/tmp/truss-held-disclosure-session-20261016.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':True,'actualChildSessions':72,'renderedAndInspected':47,'producerRefusals':25,'nativeSQL':False}))
