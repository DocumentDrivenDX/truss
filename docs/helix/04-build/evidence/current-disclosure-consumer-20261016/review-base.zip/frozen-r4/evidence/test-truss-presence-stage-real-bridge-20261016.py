"""Actual native compiler/checker, simulated DB protocol; no SQL executed."""
import json,pathlib,sys,types,unittest
from unittest.mock import patch
sys.path.insert(0,'/private/tmp/weft-presence-python-combined-installed-20261016')
import weft.weft as native
import truss._current_disclosure_stage as stage
from truss._current_query_evaluation import wire
corpus=json.loads(pathlib.Path('/private/tmp/weft-presence-bridge-owner-20261016/tests/current-query-presence/fixtures/actual-atomic-transport.json').read_bytes())
class Deadline:
 def check(self):pass
class Cursor:
 def __init__(self,mode):self._deadline=Deadline();self.connection=self;self.rows=[];self.description=None;self.mode=mode;self.dropped=False
 def execute(self,query,parameters=None,**kw):
  text=query.as_string() if hasattr(query,'as_string') else query
  if text.startswith('INSERT'):self.rows.append(tuple(parameters[1:]));self.description=None
  elif text.startswith('SELECT count'):self.out=(str(len(self.rows)),)
  elif text.startswith('SELECT private_key'):
   self.description=[types.SimpleNamespace(type_code=25)]*len(self.rows[0]) if self.rows else [types.SimpleNamespace(type_code=25)]*2
  elif text.startswith('DROP'):self.dropped=True
  return self
 def fetchone(self):return self.out
 def fetchmany(self,n):return sorted(self.rows)[:n]
class Raw:
 def __init__(self,connection,**kw):self.c=connection
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def execute(self,query,**kw):
  assert query.startswith('SELECT ') and kw=={'prepare':False,'binary':False}
  self.description=[types.SimpleNamespace(type_code=25,name='output_0'),types.SimpleNamespace(type_code=25,name='__weft_source_rows')]
  self.rows=[(row[1],json.dumps({'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':row[0]}]})) for row in reversed(self.c.rows)]
  if self.c.mode=='missing':self.rows=self.rows[1:]
  if self.c.mode=='null' and self.rows:self.rows[0]=(None,self.rows[0][-1])
 def fetchmany(self,n):return self.rows[:n]
class Tests(unittest.TestCase):
 def test_actual_bridge_over_supplied_rendered_batches(self):
  count=0
  for case in corpus['cases']:
   if case['result']['status']!='rendered':continue
   parent=native.prepare_application_lineage(json.dumps(case['request'],ensure_ascii=False,sort_keys=True,separators=(',',':')));current=parent.prepare_current_presence()
   prep=current.json().encode();p=json.loads(prep);selection={'type':p['readRequirements']['scans'][0]['target'],'fields':[r['field'] for r in p['readRequirements']['fields']]}
   result=case['result'];facts=[dict(d['resource']) for d in result['decisions']]
   for mode in (['good','missing','null'] if result['resources'] else ['good']):
    cursor=Cursor(mode)
    with self.subTest(case=case['id'],mode=mode),patch.object(stage,'RawCursor',Raw),patch.object(stage,'_text_rows',return_value=[('pg_temp_7',)]):
     def invoke():return stage.stage_current_disclosure(cursor,native=native,current=current,preparation_json=prep,producer_result_bytes=wire(result),facts=facts,selection=selection,maximum_rows=4096,maximum_scan_rows=4096,maximum_bytes=8_000_000)
     if mode=='good':
      actual=invoke();self.assertEqual(json.loads(actual.reconstructed_batch),result['batch']);self.assertEqual(actual.field_indexes,(0,));count+=1
     else:
      with self.assertRaises(ValueError):invoke()
     self.assertTrue(cursor.dropped)
  self.assertEqual(count,41)
if __name__=='__main__':unittest.main()
