"""Actual UMF+native compiler/checker, simulated DB/source admission. No SQL."""
import sys,json,pathlib,types,time,importlib.util,unittest
from unittest.mock import patch
from contextlib import contextmanager
sys.path.insert(0,'/private/tmp/weft-presence-python-combined-installed-20261016')
import truss._current_disclosure_evaluation as evaluation
import truss._current_disclosure_stage as staging
from truss._current_disclosure_originals import prepare_current_disclosure_originals,check_disclosure_originals
from truss._current_query_sources import _DISCLOSURE_PROFILE,_initialize
from truss._current_disclosure_pipe import CurrentDisclosurePipe
from truss._current_query_evaluation import wire
spec=importlib.util.spec_from_file_location('stage_fixture','/private/tmp/test-truss-presence-stage-real-bridge-20261016.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
class Cursor(f.Cursor):
 def execute(self,query,parameters=None,**kw):
  if query=='SELECT pg_catalog.pg_current_xact_id()::pg_catalog.text':self.out=('fixture-generation',);return self
  return super().execute(query,parameters,**kw)
@contextmanager
def child(**kw):
 with CurrentDisclosurePipe(('/opt/homebrew/bin/bun','/private/tmp/umf-native-disclosure-child-bundle-r1-20261016/current-native-disclosure-child.mjs'),timeout_seconds=kw['timeout_seconds']) as pipe:yield pipe
 assert pipe._cleanup_complete and pipe._child.poll() is not None
vectors=json.loads(pathlib.Path('/private/tmp/umf-held-native-disclosure-astra-20261016/reconstructed/tests/security/protection/native-disclosure-child-vectors.json').read_bytes());packets={p['id']:p for p in vectors['packets']}
class Tests(unittest.TestCase):
 def test_actual_held_evaluation_compiler_and_checker(self):
  passed=refused=fresh_generation=0
  for case in f.corpus['cases']:
   packet=packets[case['id']];source=vectors['sources'][packet['sourceIndex']]
   expected=case['result']
   if case['id'].startswith('stale-generation:'):
    # The host does not accept either fixture generation token. It supplies
    # one current native generation to both fields. Compare the unchanged
    # facts/subject/sources to an independent matching non-stale vector.
    normalized=lambda cut:{k:v for k,v in cut.items() if k not in ('generation','expectedGeneration')}
    matches=[p for p in vectors['packets'] if not p['id'].startswith('stale-generation:') and p['sourceIndex']==packet['sourceIndex'] and p['selection']==packet['selection'] and normalized(p['cut'])==normalized(packet['cut'])]
    assert matches and all(p['result']==matches[0]['result'] for p in matches)
    expected=matches[0]['result'];fresh_generation+=1
   initial=wire({'kind':'initialize','requestId':'registered','sources':{**{k:source[k] for k in ('policy','catalog','closure','ontology')},'associationBindings':[],'extensionSelection':{}}})
   sources=types.SimpleNamespace(source_profile=_DISCLOSURE_PROFILE,query_originals=prepare_current_disclosure_originals(wire(case['request']['opaqueSources'])),accepted_request_bytes=wire({'modules':case['request']['modules']}),initialize_bytes=initial,source_receipt=_initialize(initial))
   check_disclosure_originals(sources.query_originals,initial,sources.accepted_request_bytes)
   captured=types.SimpleNamespace(sources=sources,facts_bytes=wire(packet['cut']['facts']),coverage_bytes=wire(packet['cut']['coverage']))
   subject=types.SimpleNamespace(key=packet['cut']['subject']['key'][0]['string'])
   cursor=Cursor('good');cursor._deadline.end=time.monotonic()+60
   with self.subTest(case=case['id']),patch.object(staging,'RawCursor',f.Raw),patch.object(staging,'_text_rows',return_value=[('pg_temp_7',)]):
    def invoke():return evaluation.evaluate_and_stage_current_disclosure(cursor,captured,subject,sql=case['request']['sql'],parameters={},document_ids=tuple(m['pin']['documentId'] for m in case['request']['modules']),bun_executable='/opt/homebrew/bin/bun',maximum_rows=4096,maximum_scan_rows=4096,maximum_bytes=8_000_000)
    if expected['status']=='rendered':
     result=invoke();self.assertEqual(json.loads(result.reconstructed_batch),expected['batch']);self.assertTrue(cursor.dropped);passed+=1
    else:
     with self.assertRaises(ValueError):invoke()
     self.assertFalse(cursor.dropped);refused+=1
  self.assertEqual((passed,refused,fresh_generation),(46,20,6))
if __name__=='__main__':unittest.main()
