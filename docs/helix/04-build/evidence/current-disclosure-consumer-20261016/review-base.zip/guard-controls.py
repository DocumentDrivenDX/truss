from pathlib import Path
import sys,json,types,time
from unittest.mock import patch
R=Path(__file__).parent;sys.path[:0]=[str(R/'source/packages/python/src'),str(R/'wheel')]
import truss._current_query_runtime as rt
import truss._current_disclosure_evaluation as evaluation
from truss.execution import Ok,Error,ExecutionFailure
from truss.current_disclosure import CurrentDisclosureRows
from truss.query import QueryRefused
from truss._current_disclosure_originals import CurrentDisclosureOriginals
from truss._current_query_originals import CurrentQueryOriginals
from truss._current_query_evaluation import wire
checks=[]
def run(mode,disclosure=True):
 events=[];state={'caller':0,'source':0,'protection':0,'parent':0}
 class Deadline:
  end=time.monotonic()+60
  def check(self):
   if mode=='late-deadline' and state['parent']==2:raise TimeoutError('modeled closing deadline')
 deadline=Deadline()
 target={'documentId':'d','moduleId':'m','elementId':'Staff'}
 request={'modules':[{'pin':{'revision':'r','sha256':'s'},'documentJson':json.dumps({'id':'d','modules':[{'id':'m'}]})}]}
 source=types.SimpleNamespace(source_profile=rt._DISCLOSURE_PROFILE if disclosure else rt._QUERY_PROFILE,query_originals=CurrentDisclosureOriginals(b'[]',b'{}') if disclosure else object.__new__(CurrentQueryOriginals),accepted_request_bytes=wire(request),accepted_revision='1',source_receipt='source',installation_id='installed',initialize_bytes=wire({'sources':{'ontology':{'subject':target}}}))
 if mode=='wrong-profile':source.source_profile=rt._QUERY_PROFILE if disclosure else rt._DISCLOSURE_PROFILE
 if mode=='wrong-original-class':source.query_originals=object.__new__(CurrentQueryOriginals) if disclosure else CurrentDisclosureOriginals(b'[]',b'{}')
 facts=[{'type':target,'key':[{'string':'alice'}]}]
 captured=types.SimpleNamespace(sources=source,facts_bytes=wire(facts),rows=[('obj','type','version',wire({'bytesHex':'61'}))])
 subject=types.SimpleNamespace(key='alice',source_receipt='source',installation_id='installed',database_oid='db',role_oid='role',object_id='obj',type_id='type',object_version='version',tuple_bytes=b'a')
 class Cursor:
  _deadline=deadline
  def execute(self,q,params=None,**kw):
   events.append('sql:'+str(q).split(' ')[0]);self.q=q
   return self
  def fetchone(self):
   if 'pg_current_xact_id_if_assigned' in self.q:return (mode!='assigned-xid',)
   if 'reader_catalog' in self.q:return (wire({'modules':[{'documentId':'d','moduleId':'m','documentRevision':'r','documentSha256':'s'}],'catalogRevision':1}),)
   raise AssertionError(self.q)
  def fetchmany(self,n):return [('original',)]
 class Host:
  def __init__(self,name):self.name=name;self._closed=False;self.connection=types.SimpleNamespace(closed=False,broken=False);self._custody=types.SimpleNamespace(quarantined=False,pending=None,last_attempt=None)
  def _run_operation(self,transaction,callback):
   events.append(self.name+'-operation')
   try:
    value=callback(Cursor(),[('10','vtx')])
    if self.name=='private' and mode=='private-completion-fails':raise ValueError('modeled completion failure')
    if self.name=='caller' and state['caller']==3:
     if mode=='caller-completion-fails':raise ValueError('modeled final caller failure')
     if mode=='host-closed':self._closed=True
     if mode=='host-pending':self._custody.pending=object()
     if mode=='host-quarantined':self._custody.quarantined=True
     if mode=='connection-broken':self.connection.broken=True
    return Ok(value)
   except Exception as e:
    self._custody.last_attempt=types.SimpleNamespace(error=e);return Error(ExecutionFailure('invalid_transaction','modeled host failure'))
 h=Host('caller');private=Host('private')
 class Pair:
  def __init__(self,*hosts):self.hosts=hosts;self.deadline=None
  def __enter__(self):events.append('pair-enter');return self
  def __exit__(self,*args):events.append('pair-exit')
 class Held:
  staged=types.SimpleNamespace(names=('token',),field_indexes=(0,),reconstructed_batch=b'{"rows":[]}',transport_report=b'PRIVATE')
  def require_original_parent(self):
   state['parent']+=1;events.append('parent-'+str(state['parent']))
   if mode=='parent-'+str(state['parent'])+'-fails':raise ValueError('modeled parent custody loss')
 def helper(*a):state['caller']+=1;events.append('caller-check-'+str(state['caller']))
 def rows(cursor,q,params=None,limit=None):
  if 'current_setting' in q:return [('UTF8','UTF8')] if 'server_encoding' in q else [('original',)]
  if 'current_query_subject_current' in q:
   n=state['caller'];return [('changed' if mode=='caller-'+str(n)+'-drift' else 'subject',)]
  if 'pg_stat_activity' in q:
   n=state['caller'];return [('db','changed' if mode=='peer-drift' and n>=2 else 'role','vtx')]
  raise AssertionError(q)
 def capture(*a):
  state['source']+=1;events.append('source-'+str(state['source']))
  if mode=='source-drift' and state['source']==2:return object()
  return source
 def protect(*a):
  state['protection']+=1;events.append('protection-'+str(state['protection']))
  if mode=='closing-protection-fails' and state['protection']==2:raise ValueError('modeled protection drift')
 def evaluate(*a,**kw):
  events.append('disclosure-evaluate')
  if mode=='evaluation-refuses':raise ValueError('modeled semantic refusal')
  if mode=='evaluation-limit':raise rt.CurrentQueryLimit('modeled limit')
  return Held()
 def legacy_eval(*a,**kw):events.append('legacy-evaluate');return object()
 def legacy_stage(*a,**kw):events.append('legacy-stage');return 'legacy-candidate'
 executor=types.SimpleNamespace(host=private,transaction=object(),subject_registration=object(),bun_executable='bun')
 patches={'_HostPairReservation':Pair,'_pin_cursor':lambda *a:None,'_text_rows':rows,'installation_administrator_with_cursor':lambda *a:None,'capture_current_query_sources_with_cursor':capture,'verify_current_query_protection':protect,'_verify_helper':helper,'_release':lambda:({'releaseId':'release'},'digest',None),'observe_current_query_subject_in_transaction':lambda *a,**kw:Ok(subject),'capture_current_query_facts_with_cursor':lambda *a,**kw:captured,'evaluate_current_query':legacy_eval,'stage_and_execute':legacy_stage}
 with patch.multiple(rt,**patches),patch.object(evaluation,'evaluate_and_stage_current_disclosure',side_effect=evaluate):
  fn=rt.run_current_disclosure if disclosure else rt.run_current_query
  outcome=fn(h,object(),executor,sql='SELECT r.token FROM Resource r',document_ids=('d',),parameters={},maximum_rows=100,maximum_scan_rows=100,maximum_bytes=10 if mode=='public-size-limit' else 10000)
 successful=isinstance(outcome,Ok) and (isinstance(outcome.value,CurrentDisclosureRows) if disclosure else outcome.value=='legacy-candidate')
 assert successful==(mode=='good'),(mode,outcome,events)
 if successful and disclosure:
  assert events.index('disclosure-evaluate')<events.index('caller-check-2')<events.index('source-2')<events.index('protection-2')<events.index('parent-1')<events.index('caller-check-3')<events.index('parent-2')<events.index('pair-exit')
  assert not hasattr(outcome.value,'transport_report') and not hasattr(outcome.value,'parent')
 assert 'legacy-evaluate' not in events if disclosure else 'disclosure-evaluate' not in events
 if mode.startswith('wrong-'):assert 'disclosure-evaluate' not in events and 'legacy-evaluate' not in events
 checks.append({'id':mode,'disclosure':disclosure,'passed':True,'publicResultReleased':successful,'outcomeType':type(outcome).__name__,'valueType':type(outcome.value).__name__ if isinstance(outcome,Ok) else None,'events':events})
for mode in ['good','wrong-profile','wrong-original-class','assigned-xid','evaluation-refuses','evaluation-limit','caller-2-drift','caller-3-drift','peer-drift','source-drift','closing-protection-fails','parent-1-fails','parent-2-fails','private-completion-fails','caller-completion-fails','host-closed','host-pending','host-quarantined','connection-broken','public-size-limit','late-deadline']:run(mode)
for mode in ['good','wrong-profile','wrong-original-class','caller-2-drift','caller-3-drift','source-drift']:run(mode,False)
(R/'guard-controls.json').write_text(json.dumps({'status':'passed','scope':'Actual runtime branch/closing release code with modeled host/cursor/capture callbacks. Not native authentication, locks, timing, races, DDL or transaction authority evidence.','checks':checks},indent=2)+'\n');print(len(checks),'passed')
