from pathlib import Path
import os,subprocess,json,hashlib,zipfile,time
R=Path(__file__).parent;S=R/'source';W=R/'wheel';W.mkdir(exist_ok=True)
wheel=Path('/private/tmp/umf-held-native-disclosure-astra-20261016/frozen/evidence/14-weft_sql-0.4.37.dev0-cp39-abi3-macosx_11_0_arm64.whl');b=wheel.read_bytes();assert hashlib.sha256(b).hexdigest()=='2b5806d53cb50b95b56f0dda0dee8ea79e6f1d72b839f5ec74304943fe3022ad';(R/wheel.name).write_bytes(b)
with zipfile.ZipFile(wheel) as z:
 for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
 z.extractall(W)
env={**os.environ,'PYTHONPATH':str(S/'packages/python/src')+':'+str(W),'PYTHONDONTWRITEBYTECODE':'1'}
python='/private/tmp/truss-practical-performance-env/bin/python';results=[]
for name,args,qualification in [('unit',['-m','unittest','discover','-s','packages/python/tests','-p','test_current_disclosure_*.py','-v'],False),('legacy',['-m','unittest','discover','-s','packages/python/tests','-p','test_current_query_pipe.py','-v'],False),('compiler',['-m','unittest','discover','-s','packages/python/tests','-p','test_current_disclosure_compiler_integration.py','-v'],True)]:
 e={**env};
 if qualification:e['TRUSS_DISCLOSURE_COMPONENT_QUALIFICATION']='1'
 with (R/(name+'.log')).open('wb') as log:
  start=time.monotonic();p=subprocess.run([python,*args],cwd=S,env=e,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 results.append({'name':name,'command':[python,*args],'cwd':str(S),'environment':{k:e[k] for k in ['PYTHONPATH','PYTHONDONTWRITEBYTECODE']+(['TRUSS_DISCLOSURE_COMPONENT_QUALIFICATION'] if qualification else [])},'exitCode':p.returncode,'seconds':time.monotonic()-start,'log':name+'.log'})
 (R/'portable-execution.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,p.returncode,flush=True)
