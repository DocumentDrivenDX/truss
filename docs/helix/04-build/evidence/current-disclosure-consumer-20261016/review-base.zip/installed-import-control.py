from pathlib import Path; import truss; from truss._current_disclosure_originals import _actual_disclosure_consumer; import truss._current_query_originals as old; assert Path(truss.__file__).resolve()==Path('/private/tmp/truss-presence-consumer-astra-20261016/truss-wheel/truss/__init__.py'); print(_actual_disclosure_consumer());
try: old._actual_consumer()
except ValueError: print('Old profile correctly refuses candidate wheel')
else: raise AssertionError('old profile accepted candidate')
