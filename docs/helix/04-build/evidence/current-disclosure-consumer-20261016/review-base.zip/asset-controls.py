from pathlib import Path
import sys,json,shutil,types
from unittest.mock import patch
R=Path(__file__).parent;sys.path[:0]=[str(R/'source/packages/python/src'),str(R/'wheel')]
import truss._current_disclosure_computation as c
from truss._current_disclosure_originals import _actual_disclosure_consumer
root=R/'source/packages/python/src/truss';scratch=R/'asset-controls';scratch.mkdir();checks=[]
for mode in ['good','manifest-drift','bundle-drift','notice-drift','missing-bundle','closing-bundle-drift','wrong-runtime','zero-deadline']:
 d=scratch/mode;shutil.copytree(root/'_current_disclosure_owner',d/'_current_disclosure_owner');assets=d/'_current_disclosure_owner'
 if mode=='manifest-drift':(assets/'consumer-manifest.json').write_bytes((assets/'consumer-manifest.json').read_bytes()+b' ')
 if mode=='bundle-drift':(assets/'current-native-disclosure-child.mjs').write_bytes((assets/'current-native-disclosure-child.mjs').read_bytes()+b'\n')
 if mode=='notice-drift':(assets/'notices/ajv/LICENSE').write_bytes(b'drift')
 if mode=='missing-bundle':(assets/'current-native-disclosure-child.mjs').unlink()
 child=None;refused=False
 with patch.object(c,'files',return_value=d):
  try:
   with c.open_current_disclosure_computation(bun_executable='/usr/bin/true' if mode=='wrong-runtime' else '/opt/homebrew/bin/bun',timeout_seconds=0 if mode=='zero-deadline' else 3) as child:
    assert child._child.poll() is None
    if mode=='closing-bundle-drift':(assets/'current-native-disclosure-child.mjs').write_bytes((assets/'current-native-disclosure-child.mjs').read_bytes()+b'\n')
  except (ValueError,OSError,TimeoutError):refused=True
 assert refused==(mode!='good')
 if child is not None:assert child._cleanup_complete and child._child.poll() is not None
 checks.append({'id':mode,'passed':True,'refused':refused,'childCreated':child is not None,'childCleanupConfirmed':None if child is None else child._cleanup_complete})
consumer=_actual_disclosure_consumer();assert consumer['weftModuleSha256']=='a94439b3949c6db574ded8d95d9b81b23e128b0cbb7570edff65228d3737c402'
(R/'asset-controls.json').write_text(json.dumps({'status':'passed','scope':'Actual asset verifier and process launch/kill/join, isolated copied assets; no SQL. Closing source check is endpoint custody, not anti-ABA or loaded-native-module authentication.','actualConsumer':consumer,'checks':checks},indent=2)+'\n');print(len(checks),'passed')
