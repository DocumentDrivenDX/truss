from pathlib import Path
import ast,hashlib,json,zipfile
R=Path(__file__).parent;ROOT=Path('/private/tmp/truss-disclosure-main-integration-20261016');P=ROOT/'scripts/check-module-boundaries.py';SOURCE=ROOT/'packages/python/src/truss';before=P.read_text();assert before==(R/'checker-before.py').read_text()
new={
 '_current_disclosure_computation': {'contextlib','hashlib','importlib.resources','json','shutil','subprocess','time','truss._current_disclosure_pipe'},
 '_current_disclosure_evaluation': {'dataclasses','hashlib','time','truss._current_disclosure_computation','truss._current_disclosure_originals','truss._current_disclosure_session','truss._current_disclosure_stage','truss._current_disclosure_wire','truss._current_query_evaluation','truss._current_query_sources','truss._owner_evidence_json','weft.weft'},
 '_current_disclosure_originals': {'dataclasses','hashlib','json','pathlib','truss._current_disclosure_computation','truss._current_query_originals','truss._owner_evidence_json','weft.weft'},
 '_current_disclosure_pipe': {'truss._current_query_pipe'},
 '_current_disclosure_session': {'truss._current_disclosure_pipe','truss._current_disclosure_wire','truss._current_query_evaluation','truss._owner_evidence_json'},
 '_current_disclosure_stage': {'dataclasses','hashlib','json','psycopg','psycopg.rows','truss._current_disclosure_wire','truss._current_query_evaluation','truss._owner_evidence_json','truss._security_catalog_subject_installation','uuid'},
 '_current_disclosure_wire': {'decimal','hashlib','json','struct','truss._current_disclosure_pipe','truss._current_query_sources','truss._owner_evidence_json'},
 'current_disclosure': {'dataclasses','typing','truss._current_disclosure_originals','truss._current_query_sources','truss.current_query','truss.execution','truss.psycopg_host'},
}
add={
 '__init__': {'truss.current_disclosure'},
 '_current_query_runtime': {'truss._current_disclosure_evaluation','truss._current_disclosure_originals','truss._current_query_originals','truss.current_disclosure'},
 '_current_query_sources': {'truss._current_disclosure_originals'},
 'catalog_runtime': {'truss.current_disclosure'},
}
# Independently require each new permission set to equal actual lexical imports.
actual={}
for name,expected in new.items():
 values=set()
 for n in ast.walk(ast.parse((SOURCE/(name+'.py')).read_text())):
  if isinstance(n,ast.Import):values.update(a.name for a in n.names)
  elif isinstance(n,ast.ImportFrom):
   assert n.level in (0,1);values.add('truss.'+n.module if n.level else n.module)
 assert values==expected,(name,values^expected);actual[name]=sorted(values)
lines=before.splitlines(True)
for name,targets in add.items():
 positions=[i for i,s in enumerate(lines) if s.startswith('    '+repr(name)+': ')]
 assert len(positions)==1;idx=positions[0];assert lines[idx].rstrip().endswith('},')
 for target in targets:assert repr(target) not in lines[idx]
 lines[idx]=lines[idx].rstrip()[:-2]+','+','.join(repr(t)for t in sorted(targets))+'},\n'
after=''.join(lines);anchor='ALLOWED = {\n';entries='    # Reviewed disclosure consumer: explicit held computation and transport edges.\n'+''.join('    '+repr(name)+': {'+','.join(repr(t)for t in sorted(values))+'},\n' for name,values in new.items())+'\n';after=after.replace(anchor,anchor+entries,1)
# Mutation is restricted to the literal permission map. Checker logic is identical.
oldtree=ast.parse(before);newtree=ast.parse(after)
strip=lambda tree:ast.dump(ast.Module(body=[n for n in tree.body if not(isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='ALLOWED'for t in n.targets))],type_ignores=[]),include_attributes=False)
assert strip(oldtree)==strip(newtree)
pins={str(p.relative_to(ROOT)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in sorted(SOURCE.rglob('*.py'))}
with zipfile.ZipFile(R/'python-source-inputs.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n in pins:z.write(ROOT/n,n)
(R/'source-before.json').write_text(json.dumps(pins,indent=2)+'\n');(R/'map-delta.json').write_text(json.dumps({'newModules':actual,'existingModuleAddedEdges':{k:sorted(v)for k,v in add.items()},'newModuleCount':len(new),'newModuleAllowedEdges':sum(map(len,new.values())),'existingModuleAddedEdgeCount':sum(map(len,add.values())),'checkerLogicUnchanged':True},indent=2)+'\n')
P.write_text(after);(R/'checker-after.py').write_text(after)
