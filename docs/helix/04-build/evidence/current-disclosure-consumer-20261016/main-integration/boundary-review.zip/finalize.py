from pathlib import Path
import hashlib,json,subprocess,shutil,ast
R=Path(__file__).parent;ROOT=Path('/private/tmp/truss-disclosure-main-integration-20261016');sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((R/n).read_text());write=lambda n,d:(R/n).write_text(json.dumps(d,indent=2)+'\n')
focused=read('focused-controls.json');existing=read('existing-controls.json');baseline=read('baseline-python312.json');result=read('checker-result.json');pins=read('source-before.json');delta=read('map-delta.json')
assert focused['status']=='passed'and focused['permissionRemovalControls']==64 and focused['sourceMutationControls']==12
assert existing['controlCount']==18 and result['passed']and not result['errors']and result['edgeCount']==1463
for n,pin in pins.items():assert sha((ROOT/n).read_bytes())==pin['sha256'],n
checker=ROOT/'scripts/check-module-boundaries.py';assert checker.read_bytes()==(R/'checker-after.py').read_bytes();shutil.copyfile(ROOT/'scripts/check-module-boundaries-controls.py',R/'existing-controls-source.py')
# Compare literal allow maps and all executable logic, without executing repository source.
def tree(source):return ast.parse(source)
def mapping(t):
 n=next(n for n in t.body if isinstance(n,ast.Assign)and any(isinstance(v,ast.Name)and v.id=='ALLOWED'for v in n.targets));out={}
 for k,v in zip(n.value.keys,n.value.values):
  assert ast.literal_eval(k)not in out
  out[ast.literal_eval(k)]=set()if isinstance(v,ast.Call)and isinstance(v.func,ast.Name)and v.func.id=='set'and not v.args else set(ast.literal_eval(v))
 return n,out
before=tree((R/'checker-before.py').read_text());after=tree(checker.read_text());bn,bm=mapping(before);an,am=mapping(after);assert set(am)-set(bm)==set(delta['newModules'])
for n,old in bm.items():assert am[n]==old|set(delta['existingModuleAddedEdges'].get(n,[])),n
for n,expected in delta['newModules'].items():assert am[n]==set(expected)
before.body.remove(bn);after.body.remove(an);assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)
patch=subprocess.check_output(['git','diff','--','scripts/check-module-boundaries.py'],cwd=ROOT);(R/'boundary-map.patch').write_bytes(patch);check=subprocess.run(['git','diff','--check','--','scripts/check-module-boundaries.py'],cwd=ROOT,capture_output=True);assert check.returncode==0;(R/'diff-check.log').write_bytes(check.stdout+check.stderr)
write('source-custody.json',{'status':'passed','pythonSourceFiles':len(pins),'sourceBeforeAfterIdentical':True,'checkerSha256':sha(checker.read_bytes()),'checkerExecutableLogicUnchanged':True,'onlyAllowMapChanges':True,'newModules':8,'newModuleImportPermissions':57,'addedPermissionsOnExistingModules':7,'noPermissionsRemoved':True,'noBroadExceptionAdded':True,'rootHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()})
report={'status':'implemented-and-verified','reviewer':'Astra Ultra retained independent reviewer','scope':'Explicit Python lexical import map for the previously reviewed disclosure consumer; no runtime semantic or native admission change.','file':str(checker),'checkerSha256':sha(checker.read_bytes()),'change':'Eight explicit new module entries match57 actual imports. Seven concrete edges are added across __init__, catalog_runtime, _current_query_runtime and _current_query_sources. All other permissions and checker logic are unchanged.','findings':[], 'checks':{'python':'3.12.14','actualImports':1463,'existingMutationControls':18,'focusedDisclosureSourceMutationControls':12,'eachAddedPermissionRemovalRefuses':64,'pythonSourceFilesUnchanged':len(pins),'diffCheck':'passed'},'commands':[['/private/tmp/weft-toolchain/venv/bin/python','scripts/check-module-boundaries.py','--json'],['/private/tmp/weft-toolchain/venv/bin/python','scripts/check-module-boundaries-controls.py'],['/private/tmp/weft-toolchain/venv/bin/python',str(R/'focused-controls.py')]],'retainedFailures':['Original Python3.9 run includes unsupported Python syntax errors and map failures. Python3.12 baseline reproduces only the16 map diagnostics.','First reviewer focused-control script had an else-token typo before execution; exact source/log retained. Corrected controls all pass.'],'limits':['Static Python-only check; TypeScript/native SQL, indirect reflection, runtime object custody, authenticated caller/source/current cut and guarded release are not established.','No package source or production runtime changed. Only scripts/check-module-boundaries.py was edited in the integration checkout.'],'evidence':['map-delta.json','baseline-python312.json','checker-result.json','existing-controls.json','focused-controls.json','source-custody.json','boundary-map.patch'],'artifactManifest':'manifest.json'}
write('review.json',report);files={}
for p in sorted(R.iterdir()):
 if p.is_file()and p.name!='manifest.json':b=p.read_bytes();files[p.name]={'sha256':sha(b),'bytes':len(b)}
write('manifest.json',files)
for n,pin in files.items():assert sha((R/n).read_bytes())==pin['sha256']and(R/n).stat().st_size==pin['bytes']
print(json.dumps({'reviewSha256':sha((R/'review.json').read_bytes()),'manifestSha256':sha((R/'manifest.json').read_bytes()),'checkerSha256':sha(checker.read_bytes()),'artifacts':len(files),'bytes':sum(p['bytes']for p in files.values())}))
