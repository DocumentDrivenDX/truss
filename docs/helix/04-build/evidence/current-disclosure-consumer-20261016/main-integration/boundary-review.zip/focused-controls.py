from pathlib import Path
import json,subprocess,tempfile,zipfile,hashlib
R=Path(__file__).parent;ROOT=Path('/private/tmp/truss-disclosure-main-integration-20261016');CHECKER=ROOT/'scripts/check-module-boundaries.py';SOURCE=ROOT/'packages/python/src/truss';PY='/private/tmp/weft-toolchain/venv/bin/python';delta=json.loads((R/'map-delta.json').read_text());namespace={'__name__':'reviewed_boundary_checker','__file__':str(CHECKER)};exec(compile(CHECKER.read_bytes(),str(CHECKER),'exec'),namespace)
# Every added permission must be exercised by at least one actual source import.
necessary=[]
for module,targets in {**delta['newModules'],**delta['existingModuleAddedEdges']}.items():
 for target in targets:
  namespace['ALLOWED'][module].remove(target)
  try:
   errors,edges=namespace['inspect_sources'](SOURCE);expected='forbidden import '+target
   assert any(e.startswith(module+'.py:')and expected in e for e in errors),(module,target,errors)
   necessary.append({'source':module,'target':target,'removalRefused':True})
  finally:namespace['ALLOWED'][module].add(target)
cases=[
 ('allowed-deferred-source-registration','current_disclosure.py','\ndef fixture():\n    from ._current_query_sources import register_current_disclosure_sources_in_transaction\n',None),
 ('eager-source-registration-cycle','current_disclosure.py','\nfrom ._current_query_sources import register_current_disclosure_sources_in_transaction\n','Python import cycle'),
 ('wire-cannot-own-driver','_current_disclosure_wire.py','\nimport psycopg\n','forbidden import psycopg'),
 ('session-cannot-own-process','_current_disclosure_session.py','\nimport subprocess\n','forbidden import subprocess'),
 ('public-facade-cannot-import-native-compiler','current_disclosure.py','\nimport weft.weft\n','forbidden import weft.weft'),
 ('root-cannot-export-private-wire','__init__.py','\nfrom ._current_disclosure_wire import frame_digest\n','forbidden import truss._current_disclosure_wire'),
 ('root-cannot-export-held-session','__init__.py','\nfrom ._current_disclosure_session import evaluate_stage_inspect\n','forbidden import truss._current_disclosure_session'),
 ('stage-cannot-use-private-admission','_current_disclosure_stage.py','\nfrom ._operation_admission import AdmissionCustody\n','forbidden import truss._operation_admission'),
 ('evaluation-dynamic-execution-refused','_current_disclosure_evaluation.py','\nexec("pass")\n','dynamic source/import execution'),
 ('new-disclosure-module-unmapped','_current_disclosure_future.py','\nimport json\n','unmapped module'),
 ('wire-wildcard-refused','_current_disclosure_wire.py','\nfrom json import *\n','wildcard import'),
 ('pipe-escape-refused','_current_disclosure_pipe.py','\nfrom ..host import Driver\n','import escapes package'),
]
results=[]
for label,name,addition,expected in cases:
 with tempfile.TemporaryDirectory(prefix='truss-disclosure-boundary-')as temporary:
  source=Path(temporary)/'truss';source.mkdir()
  for p in SOURCE.rglob('*.py'):
   dest=source/p.relative_to(SOURCE);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
  p=source/name;p.write_text((p.read_text()if p.exists()else'')+addition)
  cmd=[PY,str(CHECKER),'--source',str(source),'--json'];run=subprocess.run(cmd,capture_output=True,text=True,timeout=30);d=json.loads(run.stdout)
  assert run.returncode==(0 if d['passed']else 1)
  if expected is None:assert d['passed'],(label,d['errors'])
  else:assert not d['passed']and any(expected in e for e in d['errors']),(label,d)
  results.append({'id':label,'source':name,'addition':addition,'expected':expected,'exitCode':run.returncode,'result':d,'stderr':run.stderr})
(R/'focused-controls.json').write_text(json.dumps({'status':'passed','scope':'Python static boundary map only; no source execution or native qualification.','checkerSha256':hashlib.sha256(CHECKER.read_bytes()).hexdigest(),'necessaryAddedPermissions':necessary,'permissionRemovalControls':len(necessary),'sourceMutationControls':len(results),'results':results},indent=2)+'\n');print(len(necessary),'permission removals and',len(results),'source mutations passed')
