"""Basic new date/generic decimal values, keys, import and rollback workflow."""
import os
from truss import Ok,ObjectFound
from truss.contracts import TextValue,MapValue
from truss.groups import AuthoredValue,CreateObject,RootlessOwnership,GroupSuccess,GroupFailed,UpdateObject,StoredObjectReference,RequestNone
from truss.imports import ImportReported,ImportCreated
from test_numeric_facets_native import NumericFacetTests

class DateDecimalTests(NumericFacetTests):
    for name in tuple(n for n in dir(NumericFacetTests) if n.startswith('test_')):locals()[name]=None

    def fields(self,source):
        super().fields(source);source['umf']='0.8.0'
        module=source['modules'][0];record=next(e for e in module['elements'] if e['id']=='A')
        next(e for e in module['elements'] if e['id']=='amount')['facets']={'precision':14.0,'scale':2.0}
        module['elements'].append({'id':'day','name':'day','kind':'field','scalarType':'date','nullability':'required','cardinality':'one','extensions':{}})
        record['members'].append({'module':'m','element':'day'})
        record['keys'].append({'id':'amount-key','name':'Amount','fields':[{'module':'m','element':'amount'}]})

    def date_values(self,label='one',amount='999999999999.99',day='2000-02-29'):
        return self.values(label=label,amount=amount)+(AuthoredValue(name='day',value=TextValue(kind='date',text=day)),)

    def test_public_values_keys_import_commit_reopen(self):
        c,h,a,t=self.ready(self.fields)
        op=CreateObject(type_definition_pin=self.types[('adoc','A')].definition_pin,values=self.date_values(),ownership=RootlessOwnership())
        semantic,request=self.input(a,t,(op,));created=self.apply(a,t,semantic,request)
        self.assertIsInstance(created,GroupSuccess,repr(created));identity=created.response.semantic.results[0].identity
        h.detach();c.commit();c,h,a,t=self.consumer()
        update=UpdateObject(target=StoredObjectReference(identity=identity),set=(AuthoredValue(name='amount',value=TextValue(kind='decimal',text='1.2300')),AuthoredValue(name='day',value=TextValue(kind='date',text='2024-02-29'))),unset=())
        context=a.group_context_in_transaction(t).value
        changed=a.apply_in_transaction(t,context.input((update,),MapValue(entries=())),RequestNone(),documents=self.documents)
        self.assertIsInstance(changed,Ok,repr(changed));self.assertIsInstance(changed.value,GroupSuccess,repr(changed.value))
        for name,kind,text in (('day','date','2024-02-30'),('amount','decimal','1.234')):
            bad=UpdateObject(target=StoredObjectReference(identity=identity),set=(AuthoredValue(name=name,value=TextValue(kind=kind,text=text)),),unset=())
            refused=a.apply_in_transaction(t,context.input((bad,),MapValue(entries=())),RequestNone(),documents=self.documents)
            self.assertIsInstance(refused,Ok,repr(refused));self.assertIsInstance(refused.value,GroupFailed,repr(refused.value))
        built=a.object_import_record_in_transaction(t,document_id='adoc',module_id='m',record_id='A',values=self.date_values(label='imported',amount='2.34',day='2025-01-01'))
        self.assertIsInstance(built,Ok,repr(built));imports=a.import_context_in_transaction(t).value
        imported=a.import_in_transaction(t,imports.input((built.value,),load_id='date-import',asserted_origin=MapValue(entries=())),documents=self.documents,bun_executable=os.environ.get('TRUSS_BUN_EXECUTABLE','bun'))
        self.assertIsInstance(imported,ImportReported,repr(imported));self.assertIsInstance(imported.report.outcomes[0],ImportCreated)
        h.detach();c.commit();c,h,a,t=self.consumer()
        found=a.get_object_in_transaction(t,document_id='adoc',module_id='m',record_id='A',object_id=int(identity.id))
        self.assertIsInstance(found.value,ObjectFound,repr(found));values=dict(found.value.object.values)
        self.assertEqual(values['day'],TextValue(kind='date',text='2024-02-29'))
        self.assertEqual(values['amount'],TextValue(kind='decimal',text='1.2300'))
        key=a.lookup_key_in_transaction(t,document_id='adoc',module_id='m',record_id='A',key_id='amount-key',values=(TextValue(kind='decimal',text='1.23'),))
        self.assertIsInstance(key,Ok,repr(key));self.assertIsInstance(key.value,ObjectFound,repr(key.value))
        self.assertEqual(key.value.object.identity.id,identity.id)
        h.detach();c.rollback()

class LargeScaleDecimalTests(DateDecimalTests):
    test_public_values_keys_import_commit_reopen=None

    def fields(self,source):
        super().fields(source)
        next(e for e in source['modules'][0]['elements'] if e['id']=='amount')['facets']={'precision':10000001,'scale':10000000}

    def test_short_exact_value_at_large_declared_scale(self):
        c,h,a,t=self.ready(self.fields)
        op=CreateObject(type_definition_pin=self.types[('adoc','A')].definition_pin,values=self.date_values(amount='1e-10000000'),ownership=RootlessOwnership())
        semantic,request=self.input(a,t,(op,));created=self.apply(a,t,semantic,request)
        self.assertIsInstance(created,GroupSuccess,repr(created));identity=created.response.semantic.results[0].identity
        h.detach();c.commit();c,h,a,t=self.consumer()
        found=a.get_object_in_transaction(t,document_id='adoc',module_id='m',record_id='A',object_id=int(identity.id))
        self.assertIsInstance(found.value,ObjectFound,repr(found))
        self.assertEqual(dict(found.value.object.values)['amount'],TextValue(kind='decimal',text='1e-10000000'))
        key=a.lookup_key_in_transaction(t,document_id='adoc',module_id='m',record_id='A',key_id='amount-key',values=(TextValue(kind='decimal',text='1e-10000000'),))
        self.assertIsInstance(key,Ok,repr(key));self.assertIsInstance(key.value,ObjectFound,repr(key.value))
        self.assertEqual(key.value.object.identity.id,identity.id)
        h.detach();c.rollback()
