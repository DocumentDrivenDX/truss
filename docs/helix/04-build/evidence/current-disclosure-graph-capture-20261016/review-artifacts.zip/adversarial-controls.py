import sys,pathlib,json,copy,types,hashlib
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'source/packages/python/src'));sys.path.insert(0,str(R/'source/packages/python/tests'))
import truss._current_disclosure_facts as actual
from test_current_disclosure_graphs import fixture,Cursor
checks=[]
def check(name,test):
 checks.append({'id':name,'passed':bool(test)})
 if not test:raise AssertionError(name)
def refuses(fn):
 try:fn()
 except (ValueError,TimeoutError,KeyError):return True
 return False
row=('90','31','1','1','11','2','12')
for pos in range(7):
 for token in ['', '0','00','-1','1.0','1e1','\u0661','9223372036854775808','99999999999999999999']:
  changed=list(row);changed[pos]=token;check('bad-native-token:'+str(pos)+':'+repr(token),refuses(lambda:actual._capture_graphs(Cursor([tuple(changed)]),*fixture())))
for pos in [0,2]:
 changed=list(row);changed[pos]='9223372036854775807';result=actual._capture_graphs(Cursor([tuple(changed)]),*fixture());check('int64-max:'+str(pos),result[2]==(tuple(changed),))
for label,home in [('view',('v','p','false','false','true','false')),('temporary',('r','t','false','false','true','false')),('unlogged',('r','u','false','false','true','false')),('force-rls',('r','p','false','true','true','false')),('foreign-owner',('r','p','false','false','false','false')),('missing',None)]:
 c=Cursor([row]);c.home=[]if home is None else[home];check(label,refuses(lambda:actual._capture_graphs(c,*fixture())))
for label,mutate in [
 ('unknown-association',lambda a:a.update(kind='future')),('undeclared-relationship',lambda a:a['relationship'].update(relationshipId='other')),('empty-role',lambda a:a['endpoints'][0].update(role='')),('extra-endpoint',lambda a:a['endpoints'].append(copy.deepcopy(a['endpoints'][0]))),('unknown-witness',lambda a:a.update(witness={'kind':'opaque-existential','extra':1})),('endpoint-key-mismatch',lambda a:a['endpoints'][1].update(keyId='other'))]:
 sources,records,facts,private=fixture();initial=json.loads(sources.initialize_bytes);mutate(initial['sources']['ontology']['associations'][0]);sources.initialize_bytes=json.dumps(initial).encode();check(label,refuses(lambda:actual._capture_graphs(Cursor(),sources,records,facts,private)))
for label,mutate in [('request-digest',lambda r:r['modules'][0]['pin'].update(sha256='0'*64)),('request-document',lambda r:r['modules'][0].update(documentJson='{}')),('source-revision',lambda r:r['modules'][0]['pin'].update(revision='other'))]:
 sources,records,facts,private=fixture();request=json.loads(sources.accepted_request_bytes);mutate(request);sources.accepted_request_bytes=json.dumps(request).encode();check(label,refuses(lambda:actual._capture_graphs(Cursor(),sources,records,facts,private)))
# Combined10,000 fact+edge bound; complete parallel occurrences are retained as a bag.
sources,records,facts,private=fixture();rows=[(str(100+i),'31','1','1','11','2','12')for i in range(9997)];result=actual._capture_graphs(Cursor(rows),sources,records,facts,private);check('exact10000-combined-count',len(result[2])+len(facts)==10000 and len(json.loads(result[0]))==9997)
rows.append(('20000','31','1','1','11','2','12'));check('10001-combined-count-refuses',refuses(lambda:actual._capture_graphs(Cursor(rows),sources,records,facts,private)))
# Real source mutations, separate modules, against focused guard controls.
source=(R/'source/packages/python/src/truss/_current_disclosure_facts.py').read_text();mutations={
 'home-check':("if homes!=[('r','p','false','false','true','false')]:","if False:"),
 'complete-census':('if len(rows)!=int(census[0][0]):','if False:'),
 'duplicate-witness':("if edge_id in seen or relationship_id not in selected:","if relationship_id not in selected:"),
 'graph-output-bound':("if retained>8388608:","if False:"),
 'per-row-deadline':("        cursor._deadline.check()\n        for token in (edge_id", "        for token in (edge_id")}
mutant_results=[];M=R/'mutants';M.mkdir(exist_ok=True)
for name,(old,new)in mutations.items():
 assert source.count(old)==1,(name,source.count(old));text=source.replace(old,new);path=M/(name+'.py');path.write_text(text);module=types.ModuleType('truss._graph_reviewer_'+name.replace('-','_'));module.__package__='truss';sys.modules[module.__name__]=module;exec(compile(text,str(path),'exec'),module.__dict__)
 def invoke(api):
  sources,records,facts,private=fixture();c=Cursor([row])
  if name=='home-check':c.home=[('r','p','true','false','true','false')]
  if name=='complete-census':c.count=2
  if name=='duplicate-witness':c=Cursor([row,row])
  if name=='graph-output-bound':
   facts[0]['key']=[{'string':'s'*65536}];facts[1]['key']=[{'string':'p'*65536}];c=Cursor([(str(90+i),'31','1','1','11','2','12')for i in range(128)])
  if name=='per-row-deadline':
   def expired():raise TimeoutError('reviewer expiry')
   c._deadline.check=expired
  return api._capture_graphs(c,sources,records,facts,private)
 original_refuses=refuses(lambda:invoke(actual));mutant_refuses=refuses(lambda:invoke(module));check('effective-mutation:'+name,original_refuses and not mutant_refuses);mutant_results.append({'id':name,'originalRefuses':original_refuses,'mutantRefuses':mutant_refuses,'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(R/'adversarial-controls.json').write_text(json.dumps({'status':'passed','count':len(checks),'checks':checks,'mutations':mutant_results,'scope':'Actual frozen graph helper and five separately compiled mutations with simulated cursors. No database or caller/source authority. Exact10000 combined population and all7 native integer columns challenged.'},indent=2)+'\n');print(len(checks),'controls passed')
