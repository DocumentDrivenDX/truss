"""Actual public population and native projection; source wrapper is diagnostic only.

No registration/native binding/authenticated protected release admission. The
source-provider substitution is explicit and does not stand in for those gates.
"""
import copy,json,hashlib,struct,time,os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import psycopg
from truss import Ok
from truss.contracts import MapValue,TextValue,BooleanValue
from truss.groups import CreateObject,CreateEdge,RootlessOwnership,AuthoredValue,AliasObjectReference,NullOrderKey,GroupSuccess
from truss._current_disclosure_facts import capture_current_disclosure_facts_with_cursor
from truss._current_query_pipe import CurrentQueryPipe
from truss._security_catalog_assessment import capture_accepted_catalog
import test_group_create_native as base

ROOT=Path('/private/tmp/truss-current-graph-capture-owner-20261016')
PACKETS=json.loads((ROOT/'composition-test-packets.json').read_text().replace('graph-capture','adoc'))
wire=lambda x:json.dumps(x,separators=(',',':'),ensure_ascii=True).encode()

class Deadline:
    def __init__(self):self.end=time.monotonic()+90
    def check(self):
        if time.monotonic()>self.end:raise TimeoutError('Native graph experiment deadline')
class NativeCursor:
    def __init__(self,connection):self.cursor=connection.cursor();self._deadline=Deadline()
    def execute(self,*args,**kwargs):self._deadline.check();return self.cursor.execute(*args,**kwargs)
    def fetchmany(self,n):self._deadline.check();return self.cursor.fetchmany(n)
    @property
    def description(self):return self.cursor.description

class NativeGraphCaptureTests(base.PublicCreateGroupTests):
    for name in tuple(n for n in dir(base.PublicCreateGroupTests) if n.startswith('test_')):locals()[name]=None
    def test_actual_public_graph_capture_and_original_held_semantics(self):
        initial=copy.deepcopy(PACKETS['initialize']);document=initial['sources']['closure']['documents'][0]['document']
        def source(old):old.clear();old.update(copy.deepcopy(document))
        c,h,a,t=self.ready(source,document_ids=('adoc',))
        facts=PACKETS['packets'][0]['cut']['facts'];graphs=PACKETS['packets'][0]['cut']['graphs']
        aliases={};operations=[];field_names={x['id']:x['name'] for x in document['modules'][0]['elements'] if x['kind']=='field'}
        for i,fact in enumerate(facts):
            name=fact['type']['elementId'];alias='n'+str(i);aliases[(name,json.dumps(fact['key'],sort_keys=True))]=alias
            values=[]
            for cell in fact['fields']:
                value=cell['value'];literal=BooleanValue(value=value['boolean']) if 'boolean' in value else TextValue(kind='integer' if 'integerToken' in value else 'string',text=value.get('integerToken',value.get('string')))
                values.append(AuthoredValue(name=field_names[cell['field']['elementId']],value=literal))
            operations.append(CreateObject(type_definition_pin=self.types[('adoc',name)].definition_pin,values=tuple(values),ownership=RootlessOwnership(),alias=alias))
        declarations={r['id']:r for r in document['modules'][0]['relationships']};refs={name:a.get_relationship_reference_in_transaction(t,document_id='adoc',module_id='m',relationship_id=name).value for name in declarations}
        expected_incidence=[]
        for graph in graphs:
            name=graph['relationship']['relationshipId'];decl=declarations[name];ends={e['role']:e['key'] for e in graph['endpoints']}
            src=aliases[(decl['source'][0]['element'],json.dumps(ends['source'],sort_keys=True))];dst=aliases[(decl['target'][0]['element'],json.dumps(ends['target'],sort_keys=True))]
            operations.append(CreateEdge(relationship_definition_pin=refs[name].definition_pin,source=AliasObjectReference(alias=src),target=AliasObjectReference(alias=dst),values=(),order_key=NullOrderKey()))
            expected_incidence.append((name,src,dst))
        context=a.group_context_in_transaction(t).value;result=self.apply(a,t,context.input(tuple(operations),MapValue(entries=())),context.request('graph-capture-native'))
        self.assertIsInstance(result,GroupSuccess);identities={x.alias:x.identity for x in result.response.semantic.aliases};h.detach();c.commit()
        original_document=self.documents[0];raw=original_document.content
        request=wire({'modules':[{'pin':{'documentId':'adoc','revision':original_document.document_revision,'umfVersion':'0.8.0','sha256':hashlib.sha256(raw).hexdigest()},'documentJson':raw.decode()}]})
        # The semantic closure must retain exact accepted revision and document.
        initial['sources']['closure']={'pins':[{'documentId':'adoc','revision':original_document.document_revision}],'documents':[{'revision':original_document.document_revision,'document':json.loads(raw)}]}
        initial['sources']['ontology']['documents']=[{'documentId':'adoc','revision':original_document.document_revision}]
        self.admin.execute('BEGIN')
        from truss._security_catalog_assessment import SOURCE_TABLES
        self.admin.execute('LOCK TABLE '+','.join('ONLY truss.'+name for name in SOURCE_TABLES)+' IN SHARE MODE NOWAIT')
        cursor=NativeCursor(self.admin)
        assessment=capture_accepted_catalog(cursor,request)
        supplied=SimpleNamespace(source_profile='truss-current-disclosure-sources/0.1-candidate',initialize_bytes=wire(initial),accepted_request_bytes=request,accepted_assessment_bytes=assessment)
        with patch('truss._current_disclosure_facts.capture_current_query_sources_with_cursor',return_value=supplied):captured=capture_current_disclosure_facts_with_cursor(cursor,bun_executable=os.environ['TRUSS_BUN_EXECUTABLE'])
        self.assertEqual(len(json.loads(captured.facts_bytes)),14);self.assertEqual(len(captured.graph_rows),12);self.assertEqual(len(json.loads(captured.graph_coverage_bytes)),5)
        self.assertEqual(len(captured.rows),14)
        actual=self.admin.execute('SELECT rel_type_id::text,source_id::text,target_id::text FROM truss.edge ORDER BY id').fetchall()
        self.assertEqual(actual,[(refs[n].relationship_id,identities[s].id,identities[d].id) for n,s,d in expected_incidence])
        lock_observations=[]
        def require_external_exclusion(stage):
            with psycopg.connect(self.info.connection_uri,autocommit=True) as writer:
                for name in ('object','object_key_bucket','edge'):
                    with self.assertRaises(psycopg.errors.LockNotAvailable):
                        with writer.transaction():writer.execute('LOCK TABLE ONLY truss.'+name+' IN ROW EXCLUSIVE MODE NOWAIT')
            lock_observations.append(stage)
        require_external_exclusion('captured')
        # Native home refusal and complete empty graph coverage are separate
        # diagnostic savepoint controls; no altered bytes leave this experiment.
        self.admin.execute('SAVEPOINT graph_home_control')
        self.admin.execute('ALTER TABLE truss.edge ENABLE ROW LEVEL SECURITY')
        with patch('truss._current_disclosure_facts.capture_current_query_sources_with_cursor',return_value=supplied):
            with self.assertRaisesRegex(ValueError,'unfiltered native graph home'):capture_current_disclosure_facts_with_cursor(cursor,bun_executable=os.environ['TRUSS_BUN_EXECUTABLE'])
        self.admin.execute('ROLLBACK TO SAVEPOINT graph_home_control')
        self.admin.execute('RELEASE SAVEPOINT graph_home_control')
        self.admin.execute('SAVEPOINT graph_empty_control')
        self.admin.execute('DELETE FROM truss.edge')
        with patch('truss._current_disclosure_facts.capture_current_query_sources_with_cursor',return_value=supplied):empty=capture_current_disclosure_facts_with_cursor(cursor,bun_executable=os.environ['TRUSS_BUN_EXECUTABLE'])
        self.assertEqual(empty.graphs_bytes,b'[]');self.assertEqual(len(json.loads(empty.graph_coverage_bytes)),5);self.assertNotEqual(empty.graphs_bytes,captured.graphs_bytes)
        self.admin.execute('ROLLBACK TO SAVEPOINT graph_empty_control');self.admin.execute('RELEASE SAVEPOINT graph_empty_control')
        observations=[]
        for staff,expected in [('Alice',['RA']),('Bob',['RB']),('Outsider',[])]:
            cut=copy.deepcopy(PACKETS['packets'][0]['cut']);cut.update(facts=json.loads(captured.facts_bytes),coverage=json.loads(captured.coverage_bytes),graphs=json.loads(captured.graphs_bytes),graphCoverage=json.loads(captured.graph_coverage_bytes),domains=initial['sources']['closure']['pins']);cut['subject']['key']=[{'string':staff}]
            initial_raw=wire(initial);receipt=hashlib.sha256(struct.pack('>I',len(initial_raw))+initial_raw).hexdigest()
            with CurrentQueryPipe((os.environ['TRUSS_BUN_EXECUTABLE'],'/private/tmp/umf-short-circuit-native-child-r1-20261016/current-native-disclosure-child.mjs'),timeout_seconds=20) as child:
                require_external_exclusion(staff+':initialize')
                init=json.loads(child.exchange(initial_raw,source_receipt=receipt));self.assertEqual(init['kind'],'initialized')
                result=json.loads(child.exchange(wire({'version':initial['version'],'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':receipt,'cut':cut}),source_receipt=receipt))
                self.assertEqual(result['kind'],'disclosure-evaluated');decision=result['result'];self.assertEqual(decision['status'],'rendered')
                self.assertEqual([r['key'][0]['string'] for r in decision['resources']],expected)
                require_external_exclusion(staff+':inspection')
                inspected=json.loads(child.exchange(wire({'version':initial['version'],'kind':'inspect-native-disclosure','requestId':'inspect','sourceReceipt':receipt,'batch':decision['batch']}),source_receipt=receipt));self.assertEqual(inspected['kind'],'native-disclosure-inspected')
                self.assertTrue(child._cleanup_complete)
                observations.append({'subject':staff,'expected':expected,'decision':decision,'inspection':inspected})
        (ROOT/'native-graph-capture-result.json').write_bytes(wire({'scope':'Actual public population, native fact/key/graph projection and original held UMF semantics; substituted source wrapper is diagnostic, no source admission/current authority/guarded release or case promotion.','serverVersion':self.admin.info.server_version,'facts':len(captured.rows),'graphs':len(captured.graph_rows),'heldFactLockChecks':lock_observations,'nativeControls':['edge-RLS-refusal','complete-empty-coverage','own-mutation-changes-recapture','savepoint-restoration'],'sourceAssessmentSha256':hashlib.sha256(assessment).hexdigest(),'observations':observations}))
        self.admin.rollback()
