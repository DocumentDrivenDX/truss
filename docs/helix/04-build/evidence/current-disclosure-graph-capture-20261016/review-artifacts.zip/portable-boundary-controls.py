import sys,pathlib,os,unittest,importlib.util,json,hashlib,subprocess,ast,contextlib,io
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;S=R/'source';ROOT=pathlib.Path('/private/tmp/truss-disclosure-main-integration-20261016');sys.path.insert(0,str(S/'packages/python/src'));sys.path.insert(0,str(S/'packages/python/tests'));script=R/'portable-r6/packages/python/tests/test_current_disclosure_graphs_native.py';checks=[]
def check(n,v):
 checks.append({'id':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
keys=['TRUSS_GRAPH_CAPTURE_NATIVE_QUALIFICATION','TRUSS_GRAPH_CAPTURE_UMF_CHILD','TRUSS_GRAPH_CAPTURE_EVIDENCE'];prior={k:os.environ.get(k)for k in keys}
def load(values,i):
 for k in keys:os.environ.pop(k,None)
 os.environ.update(values);spec=importlib.util.spec_from_file_location('review_graph_native_'+str(i),script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
try:
 for i,values in enumerate([{}, {'TRUSS_GRAPH_CAPTURE_NATIVE_QUALIFICATION':'1'}, {'TRUSS_GRAPH_CAPTURE_UMF_CHILD':'/unused'}, {'TRUSS_GRAPH_CAPTURE_NATIVE_QUALIFICATION':'yes','TRUSS_GRAPH_CAPTURE_UMF_CHILD':'/unused'}]):
  m=load(values,i);suite=unittest.defaultTestLoader.loadTestsFromTestCase(m.NativeGraphCaptureTests);out=io.StringIO();res=unittest.TextTestRunner(stream=out).run(suite);check('disabled-no-native:'+str(i),res.testsRun==2 and len(res.skipped)==2 and res.wasSuccessful())
 old=pathlib.Path('/private/tmp/umf-held-native-disclosure-astra-20261016/frozen/bundle/current-native-disclosure-child.mjs');new=R/'frozen/umf-owner-bundle/current-native-disclosure-child.mjs'
 for i,bundle in enumerate([old,R/'missing-bundle.mjs',new],10):
  m=load({'TRUSS_GRAPH_CAPTURE_NATIVE_QUALIFICATION':'1','TRUSS_GRAPH_CAPTURE_UMF_CHILD':str(bundle),'TRUSS_GRAPH_CAPTURE_EVIDENCE':str(R/'non-native-guard-output')},i);check('enabled:'+str(i),not getattr(m.NativeGraphCaptureTests,'__unittest_skip__',False));test=m.NativeGraphCaptureTests('test_actual_public_graph_capture_and_original_held_semantics');test.root=R;called=[]
  class Marker(Exception):pass
  def ready(*a,**k):called.append(True);raise Marker('Stopped before native setup')
  test.ready=ready
  try:test._run_population(False)
  except Marker:check('good-bundle-reaches-stub:'+str(i),bundle==new and called==[True])
  except (AssertionError,FileNotFoundError):check('bad-bundle-stops-before-native:'+str(i),bundle!=new and not called)
  else:raise AssertionError('Unexpected native test continuation')
finally:
 for k,v in prior.items():
  os.environ.pop(k,None)
  if v is not None:os.environ[k]=v
# Current integration adds only one exact permission-map entry; do not edit it.
checker=ROOT/'scripts/check-module-boundaries.py';before=(S/'scripts/check-module-boundaries.py').read_bytes();after=checker.read_bytes();(R/'boundary-before.py').write_bytes(before);(R/'boundary-after.py').write_bytes(after)
def get(src):
 t=ast.parse(src);n=next(n for n in t.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='ALLOWED'for x in n.targets));ns={'__name__':'review_checker'};exec(compile(src,'<checker>','exec'),ns);return t,n,ns
bt,bn,bns=get(before);at,an,ans=get(after);bm=bns['ALLOWED'];am=ans['ALLOWED'];check('one-module-only',set(am)-set(bm)=={'_current_disclosure_facts'} and all(am[k]==v for k,v in bm.items()));bt.body.remove(bn);at.body.remove(an);check('checker-logic-unchanged',ast.dump(bt,include_attributes=False)==ast.dump(at,include_attributes=False));check('same-explicit-old-fact-imports',am['_current_disclosure_facts']==bm['_current_query_facts'])
cmd=['/private/tmp/weft-toolchain/venv/bin/python',str(checker),'--source',str(S/'packages/python/src/truss'),'--json'];p=subprocess.run(cmd,capture_output=True,text=True,timeout=30);d=json.loads(p.stdout);check('boundary-pass',p.returncode==0 and d['passed']);(R/'boundary-result.json').write_text(json.dumps(d,indent=2)+'\n')
# Package runtime and entrypoints remain exact base; only the new helper is added.
production={}
import zipfile
z=zipfile.ZipFile(R/'frozen/base-inputs.zip')
for n in z.namelist():
 if n.startswith('packages/python/src/truss/')and n.endswith('.py'):
  b=z.read(n);check('unchanged-integration:'+n,(ROOT/n).read_bytes()==b);production[n]=hashlib.sha256(b).hexdigest()
for n in ['packages/python/src/truss/_current_disclosure_facts.py','packages/python/tests/test_current_disclosure_graphs.py']:
 check('integration-frozen:'+n,(ROOT/n).read_bytes()==(R/'frozen'/n).read_bytes())
for n in ['packages/python/tests/test_current_disclosure_graphs_native.py','packages/python/tests/fixtures/current-disclosure/native-graph-capture.json']:
 check('integration-r6:'+n,(ROOT/n).read_bytes()==(R/'portable-r6'/n).read_bytes())
(R/'portable-boundary-controls.json').write_text(json.dumps({'status':'passed','count':len(checks),'checks':checks,'boundaryCommand':cmd,'boundaryCheckerSha256':hashlib.sha256(after).hexdigest(),'productionInputs':production,'scope':'R6 environment/bundle guards and default native-test skips, with native setup explicitly stubbed for the good-bundle control. Actual Python3.12 static boundary checker; no SQL or native process started.'},indent=2)+'\n');print(len(checks),'checks passed')
