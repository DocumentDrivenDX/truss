import sys,pathlib,unittest,json,hashlib
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'source/packages/python/src'));sys.path.insert(0,str(R/'source/packages/python/tests'))
suite=unittest.defaultTestLoader.loadTestsFromName('test_current_disclosure_graphs');result=unittest.TextTestRunner(verbosity=2).run(suite)
pins={}
for name,module in tuple(sys.modules.items()):
 p=getattr(module,'__file__',None)
 if p and(name.startswith('truss.')or name=='test_current_disclosure_graphs'):
  path=pathlib.Path(p)
  if path.is_file():pins[str(path.relative_to(R))]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
(R/'pure-tests.json').write_text(json.dumps({'status':'passed'if result.wasSuccessful()else'failed','python':sys.version,'tests':result.testsRun,'sourcePins':pins,'scope':'Eight supplied pure simulated-cursor tests, exact reconstructed base and frozen overlay. No database/native execution.'},indent=2)+'\n');raise SystemExit(not result.wasSuccessful())
