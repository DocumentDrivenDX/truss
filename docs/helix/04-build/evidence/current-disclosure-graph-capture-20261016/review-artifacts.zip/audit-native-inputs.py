from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,struct,collections
sys.dont_write_bytecode=True
R=Path(__file__).parent;F=R/'frozen';S=R/'source';sys.path.insert(0,str(S/'packages/python/src'));from truss._current_query_pipe import CurrentQueryPipe
sha=lambda b:hashlib.sha256(b).hexdigest();wire=lambda v:json.dumps(v,separators=(',',':'),ensure_ascii=True).encode();frame=lambda b:struct.pack('>I',len(b))+b;checks=[]
def check(n,v):
 checks.append({'id':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
for root in [F,R/'parallel-r5',R/'portable-r6']:
 manifest=json.loads((root/'manifest.json').read_text());files=manifest.get('files',manifest)
 for n,pin in files.items():
  if not isinstance(pin,dict)or'sha256'not in pin:continue
  b=(root/n).read_bytes();check('manifest:'+str(root.name)+':'+n,sha(b)==pin['sha256']and len(b)==pin['bytes'])
# Exact Git base bytes, with blob IDs calculated independently from retained ZIP.
base='9e328d9105905204731e761fa974d909c81cf19c';git=Path('/Users/erik/Projects/truss');tree=subprocess.check_output(['git','ls-tree','-r','-z',base],cwd=git).split(b'\0');objects={}
for row in tree:
 if row:
  meta,n=row.split(b'\t',1);objects[n.decode()]=meta.split()[2].decode()
z=zipfile.ZipFile(F/'base-inputs.zip')
for n in z.namelist():
 b=z.read(n);oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();check('git-base:'+n,objects.get(n)==oid)
new=F/'umf-owner-bundle/current-native-disclosure-child.mjs';old=Path('/private/tmp/umf-held-native-disclosure-astra-20261016/frozen/bundle/current-native-disclosure-child.mjs');check('bundle548',sha(new.read_bytes())=='548b7ff64dabf3bc796afe99ecca265f5bcf242202e367ba7125e62c64f0a735')
check('old-bundle-d333',sha(old.read_bytes())=='d333226d9186136704d3f84a9c9dbfc44796efebab563dbc732d60337d2e03eb')
epochs=[('r3-base',F/'native-inputs',F/'native-graph-capture-result.json'),('r5-base',R/'parallel-r5/native-inputs-base',R/'parallel-r5/native-graph-capture-base-r5-result.json'),('r5-parallel',R/'parallel-r5/native-inputs-parallel',R/'parallel-r5/native-graph-capture-parallel-r5-result.json'),('r6-base',R/'portable-r6/native-evidence/native-inputs-base',R/'portable-r6/native-evidence/native-graph-capture-base-result.json'),('r6-parallel',R/'portable-r6/native-evidence/native-inputs-parallel',R/'portable-r6/native-evidence/native-graph-capture-parallel-result.json')]
outputs=[];old_outputs=[]
for epoch,inputs,receipt in epochs:
 load=lambda n:json.loads((inputs/n).read_bytes());d=json.loads(receipt.read_bytes());facts=load('facts.json');graphs=load('graphs.json');coverage=load('graph-coverage.json');loc=load('native-locators.json');assessment=load('assessment.json');initial=load('initialize.json');request=load('accepted-request.json');doc=json.loads(request['modules'][0]['documentJson']);expected_graphs=13 if'parallel'in epoch else 12
 check(epoch+':counts',len(facts)==len(loc['objects'])==d['facts']==14 and len(graphs)==len(loc['edges'])==d['graphs']==expected_graphs and len(coverage)==5)
 check(epoch+':assessment-sha',sha((inputs/'assessment.json').read_bytes())==d['sourceAssessmentSha256']);check(epoch+':request-document-sha',sha(request['modules'][0]['documentJson'].encode())==request['modules'][0]['pin']['sha256']);check(epoch+':closed-domain',initial['sources']['closure']['documents'][0]['document']==doc)
 objects={};types={str(v['type_id']):v for v in assessment['inventory']['types']};relationships={str(v['rel_type_id']):v for v in assessment['inventory']['relationships']}
 for fact,private in zip(facts,loc['objects'],strict=True):
  oid,tid,version,kr,ns,transport=private;key=json.loads(bytes.fromhex(kr));namespace=json.loads(bytes.fromhex(ns));check(epoch+':typed-object:'+oid,fact['type']=={'documentId':types[tid]['document_id'],'moduleId':types[tid]['module'],'elementId':types[tid]['element']});check(epoch+':key-custody:'+oid,key['source']==doc and key['values']==fact['key']and key['identity']['element']==fact['type']['elementId']and bytes.fromhex(transport)==('umf-key-tuple-v1:hex:'+key['bytesHex']).encode()and namespace['typeId']==tid and namespace['installationId']==assessment['installationId']);objects[oid,tid]=fact
 incidence=collections.defaultdict(list)
 for graph,row in zip(graphs,loc['edges'],strict=True):
  eid,rid,ver,sid,st,tid,tt=row;rel=relationships[rid];name=rel['rel_id'];check(epoch+':edge-id:'+eid,graph['relationship']=={'documentId':rel['document_id'],'moduleId':rel['module'],'relationshipId':name}and graph['witness']=={'kind':'opaque-existential','id':eid});ends={v['role']:v['key']for v in graph['endpoints']};check(epoch+':endpoint-keys:'+eid,ends=={'source':objects[sid,st]['key'],'target':objects[tid,tt]['key']});incidence[name].append((sid,tid))
 check(epoch+':distinct-edge-witnesses',len({g['witness']['id']for g in graphs})==expected_graphs)
 if expected_graphs==13:check(epoch+':actual-parallel-occurrence',len(incidence['StaffAssignment'])==4 and len(set(incidence['StaffAssignment']))==3)
 check(epoch+':lock-stages',d['heldFactLockChecks']==['captured','Alice:initialize','Alice:inspection','Bob:initialize','Bob:inspection','Outsider:initialize','Outsider:inspection'])
 check(epoch+':native-negative-labels',d['nativeControls']==['edge-RLS-refusal','complete-empty-coverage','own-mutation-changes-recapture','savepoint-restoration'])
 for observation in d['observations']:
  staff=observation['subject'];cut=load(staff+'-cut.json');check(epoch+':cut-'+staff,cut['facts']==facts and cut['graphs']==graphs and cut['graphCoverage']==coverage)
  raw=(inputs/'initialize.json').read_bytes();source=sha(frame(raw));evalraw=wire({'version':initial['version'],'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':source,'cut':cut});inspectraw=wire({'version':initial['version'],'kind':'inspect-native-disclosure','requestId':'inspect','sourceReceipt':source,'batch':observation['decision']['batch']});ins=observation['inspection']
  check(epoch+':frame-'+staff,ins['sourceReceipt']==source and ins['evaluationFrameSha256']==sha(frame(evalraw))and ins['inspectionFrameSha256']==sha(frame(inspectraw))and ins['status']=='validated-disclosure'and ins['complete']is False and ins['authority']is False)
  with CurrentQueryPipe(('/opt/homebrew/bin/bun',str(new)),timeout_seconds=30)as child:
   initialized=json.loads(child.exchange(raw,source_receipt=source));evaluated=json.loads(child.exchange(evalraw,source_receipt=source));checked=json.loads(child.exchange(inspectraw,source_receipt=source));check(epoch+':actual-process-'+staff,initialized['kind']=='initialized'and evaluated['result']==observation['decision']and checked==ins)
  check(epoch+':cleanup-'+staff,child._cleanup_complete);outputs.append({'epoch':epoch,'subject':staff,'result':evaluated,'inspection':checked,'cleanupComplete':child._cleanup_complete})
  if epoch.startswith('r6')and staff in ('Alice','Outsider'):
   with CurrentQueryPipe(('/opt/homebrew/bin/bun',str(old)),timeout_seconds=30)as child:
    initialized=json.loads(child.exchange(raw,source_receipt=source));prior=json.loads(child.exchange(evalraw,source_receipt=source))
   old_outputs.append({'epoch':epoch,'subject':staff,'facts':len(facts),'graphs':len(graphs),'result':prior,'cleanupComplete':child._cleanup_complete})
(R/'native-input-audit.json').write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks),'baseFiles':len(z.namelist()),'newActualProcessReplays':outputs,'oldActualProcessObservations':old_outputs,'scope':'Independent retained native evidence/byte correspondence and non-database actual UMF child replay. Supplied SQL, lock and savepoint campaign audited, not independently re-executed; source-provider substitution remains diagnostic. Endpoint source custody is not continuous holding/ABA or hermetic closure.'},indent=2)+'\n');print(len(checks),'checks;15 new processes; old',[(x['epoch'],x['subject'],x['result']['result']['status'])for x in old_outputs])
