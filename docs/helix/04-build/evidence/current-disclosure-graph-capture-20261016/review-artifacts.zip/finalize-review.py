from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).parent
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
old=Path('/private/tmp/umf-held-native-disclosure-astra-20261016/frozen/bundle/current-native-disclosure-child.mjs');shutil.copyfile(old,r/'old-current-native-disclosure-child.mjs')
readme=Path('/private/tmp/truss-disclosure-main-integration-20261016/docs/helix/04-build/evidence/current-disclosure-graph-capture-20261016/README.md');shutil.copyfile(readme,r/'integration-README.md')
pins={n:pin(r/n) for n in ['review.zip','parallel-addendum-r5.zip','portable-addendum-r6.zip','frozen/packages/python/src/truss/_current_disclosure_facts.py','frozen/packages/python/tests/test_current_disclosure_graphs.py','portable-r6/packages/python/tests/test_current_disclosure_graphs_native.py','portable-r6/packages/python/tests/fixtures/current-disclosure/native-graph-capture.json','boundary-before.py','boundary-after.py','integration-README.md','old-current-native-disclosure-child.mjs','frozen/umf-owner-bundle/current-native-disclosure-child.mjs']}
report={
 'review':'Truss unexported current-disclosure graph capture R3, parallel R5 and portable harness R6',
 'reviewer':'Independent retained Astra Ultra reviewer',
 'status':'passed-with-explicit-component-scope','remainingFindings':[],
 'baseline':'9e328d9105905204731e761fa974d909c81cf19c','pins':pins,
 'conclusion':'No actionable defect found in the reviewed graph collector, R6 opt-in test harness, or minimal import-map addition. Exact existing production Python sources and public consumer entrypoints remain unchanged. This is not activation or backend acceptance.',
 'independentlyExecuted':[
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B run-pure-tests.py','result':'8 tests passed','receipt':'pure-tests.json','log':'pure-tests.log'},
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B adversarial-controls.py','result':'87 checks passed; five separately compiled source mutations each change original refusal into acceptance','receipt':'adversarial-controls.json','log':'adversarial-controls.log'},
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B audit-native-inputs.py','result':'1316 checks passed; all 853 baseline archive files match Git blobs; 15 actual new held-child replays reproduce complete retained decisions/inspection results; four old-bundle observations retained','receipt':'native-input-audit.json','log':'native-input-audit-r2.log'},
  {'command':'/private/tmp/truss-practical-performance-env/bin/python -B portable-boundary-controls.py','result':'213 checks passed; four disabled environment combinations skip both native cases; incorrect/missing bundle refuses before native setup; correct bundle reaches a stub before DB setup; Python3.12 checker passes 1472 import edges','receipt':'portable-boundary-controls.json','log':'portable-boundary-controls.log'}
 ],
 'sourceAssessment':[
  'Original object/key capture and complete typed private-key correspondence are preserved. New graph recipes require exact admitted document correspondence, directed binary core relationships, opaque-existential witnesses, exact native metadata and one typed endpoint alternative per role.',
  'Graph capture requires ordinary permanent owner-matched no-RLS/no-inheritance storage, SHARE NOWAIT lock, complete count/census correspondence, empty edge properties, distinct positive canonical native witness IDs, exact held endpoint membership, count/byte/deadline bounds and complete empty coverage.',
  'Parallel occurrences retain distinct witness IDs even with equal typed endpoints. Tested exact combined 10000 population boundary and rejection above it; every native integer column challenged with malformed values.',
  'Only the new _current_disclosure_facts import-map entry is added, equal to the existing fact collector nine explicit dependencies; checker logic and all existing permissions are unchanged.',
  'R6 removes prototype hardcoded fixture/owner paths, requires explicit opt-in and exact supplied UMF child hash, and skips by default.'
 ],
 'suppliedNativeEvidence':{
  'independentlyExecutedDatabase':False,
  'epochs':'R3 base, R5 base/parallel, R6 base/parallel retained distinctly; R6 supplied two tests pass in 18.045s.',
  'audited':'Native locator/key/full-source correspondence, 14 objects with 12 or 13 edges, exact typed graph incidence, complete facts/coverage/cuts, all held frame hashes and resulting Alice RA/Bob RB/Outsider empty decisions. Supplied tests exercise public creation, external writer exclusion at seven stages per population, edge RLS refusal, empty coverage, same-transaction recapture and savepoint rollback.',
  'oldBundle':'Actual retained 14/12 base Alice and Outsider cuts render; both 14/13 parallel cuts refuse. These explicit observations do not relabel old evidence.',
  'qualification':'The accepted-source assessor is actual, but its provider is deliberately substituted; generation is supplied. SQL/locking/savepoint outcomes were audited from supplied evidence and test source, not independently rerun.'
 },
 'scopeLimits':[
  'No registered source/caller authority, current generation continuity, admitted native binding, final closing release guards, production activation or new acceptance claim.',
  'The collector is an unused private helper. Existing public consumer and original 206951/d333 assets remain unchanged. This graph prototype uses directed opaque binary edges and supported JSON scalar facts; non-JSON homes, Record-backed witnesses/attributes, rooted groups, context and full operator/domain scope remain open.',
  'SHARE cuts are transaction-scoped; same-transaction mutations, trigger/routine/role closure and release remain host composition obligations.',
  'External Python/Bun/dependencies are not hermetic. Hashes establish supplied bytes and endpoint correspondence, not continuously held files or ABA exclusion.',
  'Fresh 497-member wheel/installed-unit claims in the copied integration README are owner-supplied and were not independently rerun in this review.',
  'Shared 158 cases and 34 criteria remain 45 implemented and 113 missing; no case promotion.'
 ],
 'retainedAttempts':[
  'Original R1/R2/R3 native harness sources/failures and later R5/R6 epochs are preserved in the original archives.',
  'Reviewer initial ZIP-member-count assumption corrected: 44 manifest-covered files plus manifest.json.',
  'Reviewer first audit script syntax error occurred before execution; retained audit-native-inputs-first.py and native-input-audit.log.',
  'Reviewer first R6 guard import lacked a transitive test fixture absent from selected base snapshot. Exact baseline Git fixture was recovered under supplemental-base/ and pinned in supplemental-base.json; first log retained. No product code change.'
 ],
 'artifactManifest':{'path':'manifest.json','format':'Relative file path -> {sha256, bytes}; excludes itself and reconstruction source/ (recoverable from base-inputs.zip + frozen overlay + supplemental fixture).'}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={p.relative_to(r).as_posix():pin(p) for p in sorted(r.rglob('*')) if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts and p.relative_to(r).parts[0]!='source'}
# Include nested source manifests; only exclude this top-level manifest.
for p in sorted(r.rglob('manifest.json')):
 if p!=r/'manifest.json' and '__pycache__' not in p.parts and p.relative_to(r).parts[0]!='source':files[p.relative_to(r).as_posix()]=pin(p)
files=dict(sorted(files.items()));(r/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
for n,v in files.items():assert pin(r/n)==v,n
print(json.dumps({'review':pin(r/'review.json'),'manifest':pin(r/'manifest.json'),'artifacts':len(files),'totalBytes':sum(v['bytes']for v in files.values())},indent=2))
