# SPDX-License-Identifier: MIT OR Apache-2.0
"""Basic source preparation for declaration-only scalar Fields; no native claim."""
import json
import os
from pathlib import Path
import unittest
from truss import CatalogDocument
from truss.preparation import prepare_core10_acceptance
from truss.catalog_preparation import _configuration
from truss._catalog_report_semantics import canonical_numeric_free
from truss._catalog_source_reference import DATE10_PROFILE
from truss._catalog_support import evaluate_catalog_support


class DeclarativeCatalogTests(unittest.TestCase):
    def test_exact_owner_model_keeps_standalone_scalar_without_storage_declaration(self):
        content=(Path(__file__).parent/'fixtures/named-current-native-refusal-core-umf10.json').read_bytes()
        config=_configuration();config['supportProfile']=dict(DATE10_PROFILE)
        prepared=prepare_core10_acceptance((CatalogDocument('domain','named-query-core-r1',content),),canonical_numeric_free(config),bun_executable=os.environ.get('TRUSS_BUN_EXECUTABLE','bun'))
        inventory=evaluate_catalog_support(prepared)['closedSourceInventory']
        self.assertEqual(prepared.documents[0].document.content,content)
        self.assertNotIn('clear',[field['fieldId'] for doc in json.loads(prepared.declarations_bytes) for record in doc['records'] for field in record['fields']])
        self.assertNotIn('entries',inventory)
