# SPDX-License-Identifier: MIT OR Apache-2.0
"""Registered Alice/Bob/outsider native callers through one guarded source profile."""
from dataclasses import replace
import json,uuid
from unittest.mock import patch
import psycopg
from psycopg import sql
from truss import Ok,Error,adopt_psycopg_host
import test_security_catalog_source_cut_native as source

class RegisteredCallersNativeTests(source.CatalogSourceCutTests):
 for name in tuple(n for n in dir(source.CatalogSourceCutTests) if n.startswith('test_')):locals()[name]=None
 def setup_subject(self):
  suffix=uuid.uuid4().hex[:12];self.bob='registered_bob_'+suffix;self.outsider='registered_outsider_'+suffix
  for name in (self.bob,self.outsider):self.admin.execute(sql.SQL('CREATE ROLE {} LOGIN').format(sql.Identifier(name)))
  self.subject_bindings=(('consumer','s1'),(self.bob,'s2'),(self.outsider,'s3'))
  return super().setup_subject()
 def populated(self):
  return super().populated(extra_rows=(('Staff',{'staffId':'s2'}),('Staff',{'staffId':'s3'}),('Assignment',{'assignmentId':'bob-a1','assignmentStaff':'s2','assignmentProject':'p2','active':True})))
 def publish(self,caller,transaction,mapping,selection,inspector,relations,cut,subjects,delivered):
  return source.subject.publish_registered_ddl_epoch_guarded_native_catalog_resource_read(caller,transaction,self.host,self.tx,mapping,selection,inspector,relations,cut,subjects,delivered.append)
 def test_three_actual_callers_obey_own_project_membership(self):
  """@covers US-056-AC2; B01 population prerequisite, not complete backend admission."""
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();subjects=self.registered_subjects
  rows=[]
  for role,expected in (('consumer',['r1']),(self.bob,['r2']),(self.outsider,[])):
   parameters=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);parameters['user']=role
   with psycopg.connect(**parameters,autocommit=True,options='-c statement_timeout=10000') as native:
    native.execute('BEGIN');caller=adopt_psycopg_host(native,statement_timeout_ms=10000,operation_timeout_ms=30000)
    try:
     adopted=caller.adopt_transaction();self.assertIsInstance(adopted,Ok,str(caller._custody.last_attempt.error))
     transaction=adopted.value;delivered=[]
     self.assertEqual(native.execute('SELECT SESSION_USER::pg_catalog.text').fetchone(),(role,))
     result=self.publish(caller,transaction,mapping,replace(selection,principal=role),inspector,relations,cut,subjects,delivered)
     self.assertIsInstance(result,Ok,str(caller._custody.last_attempt.error));self.assertEqual(delivered,[result.value])
     receipt=json.loads(result.value);actual=[r['key'][0]['string'] for r in receipt['rows']]
     self.assertEqual(actual,expected)
     for row in receipt['rows']:self.assertEqual(row['output'][0]['disposition'],'withheld')
     for table in ('truss.object','truss.catalog_subject_map'):
      self.assertEqual(native.execute('SELECT has_table_privilege(%s,\'SELECT\')',(table,)).fetchone(),(False,))
     rows.append({'role':role,'resources':actual,'salaryWithheld':True})
    finally:caller.detach();native.rollback()
  self.assertEqual([r['resources'] for r in rows],[['r1'],['r2'],[]])
 def test_unregistered_extra_helper_grant_refuses_before_subject(self):
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[]
  self.admin.execute('GRANT EXECUTE ON FUNCTION truss.catalog_subject_current(text) TO PUBLIC')
  with patch.object(source.subject,'encode_literal_key_tuple') as encoder,patch.object(source.subject,'run_owned_catalog_resource_read') as evaluator:
   result=self.publish(h,t,mapping,selection,inspector,relations,cut,self.registered_subjects,delivered)
   encoder.assert_not_called();evaluator.assert_not_called()
  self.assertIsInstance(result,Error);self.assertEqual(delivered,[])
  self.assertEqual(str(self.host._custody.last_attempt.error),'Exact installed catalog subject helper ACL required')
 def test_changed_registered_staff_binding_refuses_before_subject(self):
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[]
  self.admin.execute("UPDATE truss.catalog_subject_map SET staff_key='s2' WHERE role_oid=(SELECT oid FROM pg_roles WHERE rolname='consumer')")
  with patch.object(source.subject,'encode_literal_key_tuple') as encoder:
   result=self.publish(h,t,mapping,selection,inspector,relations,cut,self.registered_subjects,delivered);encoder.assert_not_called()
  self.assertIsInstance(result,Error);self.assertEqual(delivered,[])
  self.assertEqual(str(self.host._custody.last_attempt.error),'Original registered Subject map changed')

 def test_hostile_text_domain_cannot_run_in_registered_checker(self):
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[]
  self.admin.execute("CREATE SCHEMA registered_hostile;CREATE FUNCTION registered_hostile.reject_text(pg_catalog.text) RETURNS pg_catalog.bool LANGUAGE plpgsql AS $$BEGIN RAISE EXCEPTION 'registered hostile text executed';END$$;CREATE DOMAIN registered_hostile.text AS pg_catalog.text CHECK(registered_hostile.reject_text(VALUE))")
  self.admin.execute('SET LOCAL search_path=registered_hostile,pg_catalog')
  result=self.publish(h,t,mapping,selection,inspector,relations,cut,self.registered_subjects,delivered)
  self.assertIsInstance(result,Ok,str(h._custody.last_attempt.error));self.assertEqual(delivered,[result.value])

 def test_registered_role_privilege_drift_refuses_before_subject(self):
  """@covers US-056-AC9; selected role drift, not complete concurrent authority."""
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[]
  self.admin.execute(sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)))
  with patch.object(source.subject,'encode_literal_key_tuple') as encoder,patch.object(source.subject,'run_owned_catalog_resource_read') as evaluator:
   result=self.publish(h,t,mapping,selection,inspector,relations,cut,self.registered_subjects,delivered)
   encoder.assert_not_called();evaluator.assert_not_called()
  self.assertIsInstance(result,Error);self.assertEqual(delivered,[])
  self.assertEqual(str(self.host._custody.last_attempt.error),'Original ordinary registered Subject principals required')

 def test_committed_role_drift_during_evaluation_refuses_publication(self):
  """@covers US-056-AC9; independent committed drift before final comparison."""
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[];changed=[]
  original=source.subject.run_owned_catalog_resource_read
  def drift(*args,**kwargs):
   result=original(*args,**kwargs)
   self.assertIsInstance(result,Ok)
   with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=1000') as writer:
    writer.execute(sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)))
    self.assertEqual(writer.execute('SELECT rolbypassrls FROM pg_catalog.pg_roles WHERE rolname=%s',(self.bob,)).fetchone(),(True,))
   changed.append(True)
   return result
  try:
   with patch.object(source.subject,'run_owned_catalog_resource_read',drift):
    result=self.publish(h,t,mapping,selection,inspector,relations,cut,self.registered_subjects,delivered)
   self.assertEqual(changed,[True]);self.assertIsInstance(result,Error);self.assertEqual(delivered,[])
   self.assertEqual(str(self.host._custody.last_attempt.error),'Original ordinary registered Subject principals required')
  finally:
   with psycopg.connect(self.info.connection_uri,autocommit=True) as writer:
    writer.execute(sql.SQL('ALTER ROLE {} NOBYPASSRLS').format(sql.Identifier(self.bob)))

 def test_role_catalog_cut_survives_receiver_until_executor_settlement(self):
  """@covers US-056-AC9; selected dual catalog lock publication lifetime."""
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[];attempts=[]
  def probe():
   for statement in (sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)),sql.SQL('GRANT {} TO {}').format(sql.Identifier(self.installation.owner_role),sql.Identifier(self.bob))):
    with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=100ms') as writer:
     with self.assertRaises(psycopg.errors.LockNotAvailable):writer.execute(statement)
     attempts.append(True)
  def receive(packet):probe();delivered.append(packet)
  result=source.subject.publish_role_fenced_registered_catalog_resource_read(h,t,self.host,self.tx,mapping,selection,inspector,relations,cut,self.registered_subjects,receive)
  self.assertIsInstance(result,Ok,str(h._custody.last_attempt.error));self.assertEqual(delivered,[result.value]);probe();self.assertEqual(attempts,[True]*4)
  self.host.detach();self.admin.rollback()
  with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=100ms') as writer:
   writer.execute(sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)))
   self.assertEqual(writer.execute('SELECT rolbypassrls FROM pg_catalog.pg_roles WHERE rolname=%s',(self.bob,)).fetchone(),(True,))
   writer.execute(sql.SQL('ALTER ROLE {} NOBYPASSRLS').format(sql.Identifier(self.bob)))

 def test_role_catalog_writer_contention_refuses_before_subject(self):
  """@covers US-056-AC9; opposing writer prevents initial role cut."""
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup();delivered=[]
  with psycopg.connect(self.info.connection_uri,autocommit=True) as writer:
   writer.execute('BEGIN');writer.execute(sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)))
   try:
    with patch.object(source.subject,'encode_literal_key_tuple') as encoder,patch.object(source.subject,'run_owned_catalog_resource_read') as evaluator:
     result=source.subject.publish_role_fenced_registered_catalog_resource_read(h,t,self.host,self.tx,mapping,selection,inspector,relations,cut,self.registered_subjects,delivered.append)
     encoder.assert_not_called();evaluator.assert_not_called()
    self.assertIsInstance(result,Error);self.assertEqual(delivered,[])
    self.assertIsInstance(self.host._custody.last_attempt.error,psycopg.errors.LockNotAvailable)
   finally:writer.execute('ROLLBACK')

 def test_ordinary_caller_uses_fixed_role_lock_issuer_without_catalog_write(self):
  """@covers US-056-AC9; original fixed definer lock issuer, not complete admission."""
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup()
  from truss._security_catalog_subject_installation import bootstrap_role_catalog_cut_issuer_in_transaction
  self.admin.execute("CREATE SCHEMA issuer_hostile;CREATE FUNCTION issuer_hostile.reject_text(pg_catalog.text) RETURNS pg_catalog.bool LANGUAGE plpgsql AS $$BEGIN RAISE EXCEPTION 'hostile issuer text executed';END$$;CREATE DOMAIN issuer_hostile.text AS pg_catalog.text CHECK(issuer_hostile.reject_text(VALUE))")
  self.admin.execute('SET LOCAL search_path=issuer_hostile,pg_catalog')
  installed=bootstrap_role_catalog_cut_issuer_in_transaction(self.host,self.tx,executor_role='consumer')
  self.assertEqual(self.admin.execute("SELECT pg_catalog.current_setting('search_path')").fetchone(),('issuer_hostile, pg_catalog',))
  self.assertIsInstance(installed,Ok,str(self.host._custody.last_attempt.error));self.assertFalse(installed.value.security_ready)
  self.assertEqual(installed.value.status,'pending_commit');self.assertEqual(installed.value.installation_id,self.installation.installation_id)
  repeated=bootstrap_role_catalog_cut_issuer_in_transaction(self.host,self.tx,executor_role='consumer')
  self.assertIsInstance(repeated,Error);self.assertEqual(str(self.host._custody.last_attempt.error),'Existing role cut issuer requires explicit migration')
  self.host.detach();self.admin.commit()
  self.assertEqual(c.execute("SELECT pg_catalog.has_table_privilege('pg_catalog.pg_authid','UPDATE'),pg_catalog.has_table_privilege('pg_catalog.pg_auth_members','UPDATE')").fetchone(),(False,False))
  from truss._security_catalog_subject_installation import acquire_issued_registered_role_catalog_cut_with_cursor
  owner,caller=self.admin.execute("SELECT (SELECT oid FROM pg_catalog.pg_roles WHERE rolname=CURRENT_USER),(SELECT oid FROM pg_catalog.pg_roles WHERE rolname='consumer')").fetchone()
  with c.cursor() as cursor:acquire_issued_registered_role_catalog_cut_with_cursor(cursor,owner_oid=owner,caller_oid=caller)
  self.assertEqual(c.execute("SELECT count(*) FROM pg_catalog.pg_locks WHERE pid=pg_catalog.pg_backend_pid() AND database=0 AND granted AND mode='ShareLock' AND relation IN ('pg_catalog.pg_authid'::pg_catalog.regclass,'pg_catalog.pg_auth_members'::pg_catalog.regclass)").fetchone(),(2,))
  with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=100ms') as writer:
   with self.assertRaises(psycopg.errors.LockNotAvailable):writer.execute(sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)))
   with self.assertRaises(psycopg.errors.LockNotAvailable):writer.execute(sql.SQL('GRANT {} TO {}').format(sql.Identifier(self.installation.owner_role),sql.Identifier(self.bob)))
  outsider=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);outsider['user']=self.outsider
  with psycopg.connect(**outsider,autocommit=True) as denied:
   with self.assertRaises(psycopg.errors.InsufficientPrivilege):denied.execute('SELECT truss.acquire_registered_role_catalog_cut()')
  h.detach();c.rollback()
  with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=100ms') as writer:
   writer.execute(sql.SQL('ALTER ROLE {} BYPASSRLS').format(sql.Identifier(self.bob)))
   writer.execute(sql.SQL('ALTER ROLE {} NOBYPASSRLS').format(sql.Identifier(self.bob)))

 def test_role_cut_issuer_definition_and_acl_drift_refuse_before_call(self):
  """@covers US-056-AC9; installed original issuer comparison."""
  from truss._security_catalog_subject_installation import verify_role_catalog_cut_issuer_with_cursor
  self.source_setup()
  self.admin.execute((source.ROOT/'packages/postgresql/native/registered-role-catalog-cut.sql').read_text())
  self.admin.execute('GRANT EXECUTE ON FUNCTION truss.acquire_registered_role_catalog_cut() TO consumer')
  owner,caller=self.admin.execute("SELECT (SELECT oid FROM pg_catalog.pg_roles WHERE rolname=CURRENT_USER),(SELECT oid FROM pg_catalog.pg_roles WHERE rolname='consumer')").fetchone()
  with self.admin.cursor() as cursor:
   verify_role_catalog_cut_issuer_with_cursor(cursor,owner_oid=owner,caller_oid=caller)
   for mutation in ('GRANT EXECUTE ON FUNCTION truss.acquire_registered_role_catalog_cut() TO PUBLIC','ALTER FUNCTION truss.acquire_registered_role_catalog_cut() SECURITY INVOKER','ALTER FUNCTION truss.acquire_registered_role_catalog_cut() SET search_path=public','ALTER FUNCTION truss.acquire_registered_role_catalog_cut() IMMUTABLE'):
    self.admin.execute('SAVEPOINT issuer_drift')
    try:
     self.admin.execute(mutation)
     with self.assertRaises(ValueError):verify_role_catalog_cut_issuer_with_cursor(cursor,owner_oid=owner,caller_oid=caller)
    finally:self.admin.execute('ROLLBACK TO SAVEPOINT issuer_drift');self.admin.execute('RELEASE SAVEPOINT issuer_drift')
   verify_role_catalog_cut_issuer_with_cursor(cursor,owner_oid=owner,caller_oid=caller)

 def test_ordinary_issued_cut_refuses_public_grant_before_acquisition(self):
  """@covers US-056-AC9; ordinary verified acquisition rejects broad issuer ACL."""
  from truss._security_catalog_subject_installation import acquire_issued_registered_role_catalog_cut_with_cursor
  mapping,c,h,t,selection,inspector,relations,cut=self.source_setup()
  self.admin.execute((source.ROOT/'packages/postgresql/native/registered-role-catalog-cut.sql').read_text())
  self.admin.execute('GRANT EXECUTE ON FUNCTION truss.acquire_registered_role_catalog_cut() TO consumer,PUBLIC')
  owner,caller=self.admin.execute("SELECT (SELECT oid FROM pg_catalog.pg_roles WHERE rolname=CURRENT_USER),(SELECT oid FROM pg_catalog.pg_roles WHERE rolname='consumer')").fetchone()
  self.host.detach();self.admin.commit()
  with c.cursor() as cursor:
   with self.assertRaises(ValueError):acquire_issued_registered_role_catalog_cut_with_cursor(cursor,owner_oid=owner,caller_oid=caller)
  self.assertEqual(c.execute("SELECT count(*) FROM pg_catalog.pg_locks WHERE pid=pg_catalog.pg_backend_pid() AND database=0 AND granted AND mode='ShareLock' AND relation IN ('pg_catalog.pg_authid'::pg_catalog.regclass,'pg_catalog.pg_auth_members'::pg_catalog.regclass)").fetchone(),(0,))

 def test_role_cut_installer_rejects_inherited_default_acl_and_preserves_work(self):
  """@covers US-056-AC9; fresh installer rollback on extra default grant."""
  from truss._security_catalog_subject_installation import bootstrap_role_catalog_cut_issuer_in_transaction
  self.source_setup()
  self.admin.execute("CREATE TEMP TABLE prior_role_issuer_work(value pg_catalog.text);INSERT INTO prior_role_issuer_work VALUES('kept')")
  self.admin.execute(sql.SQL('ALTER DEFAULT PRIVILEGES GRANT EXECUTE ON FUNCTIONS TO {}').format(sql.Identifier(self.outsider)))
  try:
   result=bootstrap_role_catalog_cut_issuer_in_transaction(self.host,self.tx,executor_role='consumer')
   self.assertIsInstance(result,Error)
   self.assertIsInstance(self.host._custody.last_attempt.error,ValueError)
   self.assertEqual(str(self.host._custody.last_attempt.error),'Bounded exact Subject installation rows required')
   self.assertEqual(self.admin.execute("SELECT pg_catalog.to_regprocedure('truss.acquire_registered_role_catalog_cut()')").fetchone(),(None,))
   self.assertEqual(self.admin.execute('SELECT value FROM prior_role_issuer_work').fetchall(),[('kept',)])
  finally:self.admin.execute(sql.SQL('ALTER DEFAULT PRIVILEGES REVOKE EXECUTE ON FUNCTIONS FROM {}').format(sql.Identifier(self.outsider)))

 def test_read_only_executor_uses_fixed_table_cut_without_update_grants(self):
  """@covers US-056-AC9; selected real native graph/source table lock primitive."""
  self.source_setup();executor='private_cut_'+uuid.uuid4().hex[:12]
  self.admin.execute(sql.SQL('CREATE ROLE {} LOGIN').format(sql.Identifier(executor)))
  self.addCleanup(self.admin.execute,sql.SQL('DROP OWNED BY {};DROP ROLE {}').format(sql.Identifier(executor),sql.Identifier(executor)))
  from truss._security_catalog_read_cut_installation import bootstrap_catalog_read_table_cut_issuer_in_transaction,acquire_issued_catalog_read_table_cut_with_cursor
  installed=bootstrap_catalog_read_table_cut_issuer_in_transaction(self.host,self.tx,executor_role=executor)
  self.assertIsInstance(installed,Ok,str(self.host._custody.last_attempt.error));self.assertFalse(installed.value.security_ready)
  self.admin.execute(sql.SQL('GRANT USAGE ON SCHEMA truss TO {};GRANT SELECT ON truss.object TO {};GRANT EXECUTE ON FUNCTION truss.acquire_catalog_read_table_cut() TO {}').format(*[sql.Identifier(executor)]*3))
  self.host.detach();self.admin.commit()
  parameters=psycopg.conninfo.conninfo_to_dict(self.info.connection_uri);parameters['user']=executor
  with psycopg.connect(**parameters,autocommit=True) as reader:
   reader.execute('BEGIN')
   self.assertEqual(reader.execute("SELECT pg_catalog.has_table_privilege('truss.object','SELECT'),pg_catalog.has_table_privilege('truss.object','UPDATE')").fetchone(),(True,False))
   reader.execute('SAVEPOINT direct_lock')
   with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute('LOCK TABLE ONLY truss.object IN SHARE MODE NOWAIT')
   reader.execute('ROLLBACK TO SAVEPOINT direct_lock');reader.execute('RELEASE SAVEPOINT direct_lock')
   with reader.cursor() as cursor:acquire_issued_catalog_read_table_cut_with_cursor(cursor,owner_oid=installed.value.owner_oid,caller_oid=installed.value.caller_oid)
   tables=('object','catalog_subject_map','installation_archive','source_epoch_current','source_epoch_registry','policy_generation_guard')
   for table in tables:
    self.assertEqual(reader.execute("SELECT count(*) FROM pg_catalog.pg_locks WHERE pid=pg_catalog.pg_backend_pid() AND granted AND mode='ShareLock' AND relation=pg_catalog.to_regclass(%s)",('truss.'+table,)).fetchone(),(1,))
    with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=100ms') as writer:
     with self.assertRaises(psycopg.errors.LockNotAvailable):writer.execute(sql.SQL('DELETE FROM {} WHERE false').format(sql.Identifier('truss',table)))
   self.assertGreater(reader.execute('SELECT count(*) FROM truss.object').fetchone()[0],0)
   reader.execute('SAVEPOINT direct_write')
   with self.assertRaises(psycopg.errors.InsufficientPrivilege):reader.execute('UPDATE truss.object SET props=props WHERE false')
   reader.execute('ROLLBACK TO SAVEPOINT direct_write');reader.execute('RELEASE SAVEPOINT direct_write')
   reader.rollback()
  with psycopg.connect(self.info.connection_uri,autocommit=True,options='-c lock_timeout=100ms') as writer:
   for table in tables:writer.execute(sql.SQL('DELETE FROM {} WHERE false').format(sql.Identifier('truss',table)))
  self.admin.execute('GRANT EXECUTE ON FUNCTION truss.acquire_catalog_read_table_cut() TO PUBLIC')
  try:
   with psycopg.connect(**parameters,autocommit=True) as reader:
    reader.execute('BEGIN')
    with reader.cursor() as cursor:
     with self.assertRaisesRegex(ValueError,'Bounded exact Subject installation rows required'):
      acquire_issued_catalog_read_table_cut_with_cursor(cursor,owner_oid=installed.value.owner_oid,caller_oid=installed.value.caller_oid)
    self.assertEqual(reader.execute("SELECT count(*) FROM pg_catalog.pg_locks WHERE pid=pg_catalog.pg_backend_pid() AND granted AND mode='ShareLock'").fetchone(),(0,))
    reader.rollback()
  finally:self.admin.execute('REVOKE EXECUTE ON FUNCTION truss.acquire_catalog_read_table_cut() FROM PUBLIC')
