from pathlib import Path
import hashlib,json,subprocess,tarfile,io,shutil,ast,sys,unittest,importlib.util
r=Path(__file__).resolve().parent;o=Path('/private/tmp/truss-explicit-graph-target-key-review-20261016');repo='/Users/erik/Projects/truss';base='4cecba63e1eb81744950fcdeec33de2530d7c0e4';H=lambda b:hashlib.sha256(b).hexdigest();manifest=json.loads((o/'manifest.json').read_bytes())
for name,pin in manifest.items():b=(o/name).read_bytes();assert H(b)==pin['sha256'] and len(b)==pin['bytes'];p=r/'packet'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(r/'packet/manifest.json').write_bytes((o/'manifest.json').read_bytes());assert H((o/'change.diff').read_bytes())=='e7886afb89db85072ec7d83225001582058dbf3ba382d4abd78af9527759e04e'
for name in ['packages/python/src/truss/_current_disclosure_facts.py','packages/python/tests/test_current_disclosure_graphs.py']:assert subprocess.check_output(['git','-C',repo,'show',base+':'+name])==(o/'before'/name).read_bytes()
src=r/'working';src.mkdir(exist_ok=True);tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base,'packages/python/src']))).extractall(src)
helper=src/'packages/python/src/truss/_current_disclosure_facts.py';helper.write_bytes((o/'after/packages/python/src/truss/_current_disclosure_facts.py').read_bytes());sys.path.insert(0,str(src/'packages/python/src'))
# Exactly one added test; all original tests, fixtures and other module AST stay unchanged.
a=ast.parse((o/'before/packages/python/tests/test_current_disclosure_graphs.py').read_bytes());b=ast.parse((o/'after/packages/python/tests/test_current_disclosure_graphs.py').read_bytes());newclass=next(n for n in b.body if isinstance(n,ast.ClassDef) and n.name=='GraphCaptureTests');added=[n for n in newclass.body if isinstance(n,ast.FunctionDef) and n.name=='test_explicit_authored_target_key_required_before_empty_coverage'];assert len(added)==1;newclass.body.remove(added[0]);assert ast.dump(a)==ast.dump(b)
spec=importlib.util.spec_from_file_location('graph_review_tests',o/'after/packages/python/tests/test_current_disclosure_graphs.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
with (r/'after-tests.log').open('w') as log:res=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(t));assert res.wasSuccessful() and res.testsRun==9
import truss._current_disclosure_facts as fixed
# Load original helper as a distinct package-qualified module; do not mutate fixed runtime or owner.
spec=importlib.util.spec_from_file_location('truss._review_before_graph_facts',o/'before/packages/python/src/truss/_current_disclosure_facts.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
schema=json.loads((o/'canonical-core-schema.json').read_bytes());assert 'key' in schema['$defs']['relationshipTarget']['required'];assert schema['$defs']['relationshipTarget']['properties']['key']=={'$ref':'#/$defs/id'};assert schema['$defs']['id']['type']=='string' and schema['$defs']['id']['minLength']==1
from jsonschema import Draft202012Validator
validator=Draft202012Validator({'$ref':'#/$defs/relationshipTarget','$defs':schema['$defs']})
controls=[]
def prepare(value):
 sources,records,facts,private=t.fixture();initial=json.loads(sources.initialize_bytes);core=initial['sources']['closure']['documents'][0]['document'];target=core['modules'][0]['relationships'][0]['target'][0]
 if value=='__missing__':target.pop('key')
 else:target['key']=value
 encoded=json.dumps(core,separators=(',',':'));accepted=json.loads(sources.accepted_request_bytes);accepted['modules'][0]['documentJson']=encoded;accepted['modules'][0]['pin']['sha256']=H(encoded.encode());sources.accepted_request_bytes=json.dumps(accepted).encode();sources.initialize_bytes=json.dumps(initial).encode();assessment=json.loads(sources.accepted_assessment_bytes);assessment['inventory']['relationships'][0]['target_key']=None if value=='__missing__' else value;sources.accepted_assessment_bytes=json.dumps(assessment).encode()
 assert accepted['modules'][0]['pin']['sha256']==H(encoded.encode()) and json.loads(encoded)==initial['sources']['closure']['documents'][0]['document'];fixed.require_current_model_correspondence(sources.initialize_bytes,sources.accepted_request_bytes)
 return sources,records,facts,private,target
for value in ['__missing__',None,'',False,0,[],{},'pk']:
 sources,records,facts,private,target=prepare(value);valid=value=='pk';assert validator.is_valid(target)==valid
 c=t.Cursor()
 try:fixed._capture_graphs(c,sources,records,facts,private);passed=True
 except ValueError:passed=False
 assert passed==valid and (valid or not c.queries);controls.append({'id':'key-'+repr(value),'schemaValid':valid,'fixedAccepted':passed,'queries':len(c.queries)})
sources,records,facts,private,_=prepare('__missing__');c=t.Cursor();old_result=old._capture_graphs(c,sources,records,facts,private);assert old_result[0]==b'[]' and len(c.queries)==4;controls.append({'id':'old-missing-null-counterexample','accepted':True,'queries':len(c.queries),'returnedCompleteCoverage':json.loads(old_result[1])[0]['complete']})
# Added test must fail with old implementation; retain exact result separately.
saved=t._capture_graphs;t._capture_graphs=old._capture_graphs
with (r/'before-regression.log').open('w') as log:failure=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('GraphCaptureTests.test_explicit_authored_target_key_required_before_empty_coverage',t));assert not failure.wasSuccessful() and failure.testsRun==1
t._capture_graphs=saved
# Target shape guard is fail-closed before queries, while original positive remains unchanged.
for value in [None,{},[],[{}],[None],[{'module':'m','element':'Project','key':'pk'},{'module':'m','element':'Project','key':'pk'}]]:
 sources,records,facts,private=t.fixture();initial=json.loads(sources.initialize_bytes);core=initial['sources']['closure']['documents'][0]['document'];core['modules'][0]['relationships'][0]['target']=value;encoded=json.dumps(core,separators=(',',':'));accepted=json.loads(sources.accepted_request_bytes);accepted['modules'][0]['documentJson']=encoded;accepted['modules'][0]['pin']['sha256']=H(encoded.encode());sources.accepted_request_bytes=json.dumps(accepted).encode();sources.initialize_bytes=json.dumps(initial).encode();c=t.Cursor()
 try:fixed._capture_graphs(c,sources,records,facts,private)
 except ValueError:pass
 else:raise AssertionError('malformed target accepted')
 assert not c.queries;controls.append({'id':'target-shape-'+repr(value),'refusedBeforeQuery':True})
report={'passed':True,'base':base,'packetMembersVerified':len(manifest),'originalFilesExactGit':2,'existingTestModuleASTUnchangedExceptOneRegression':True,'testsPassed':9,'oldRegressionTestsFailedAsExpected':1,'oldRegressionFailures':len(failure.failures),'controls':controls,'canonicalTargetKeyRequiredNonemptyString':True,'actualClosureAndHashCorrespondenceChecked':True,'SQLExecuted':False};(r/'controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='controls'}))
