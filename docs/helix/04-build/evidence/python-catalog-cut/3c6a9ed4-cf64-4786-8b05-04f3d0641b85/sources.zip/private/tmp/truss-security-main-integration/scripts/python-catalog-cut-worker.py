"""Administrative native catalog-cut feasibility; no protected provider or authority."""
import hashlib,json,re,sys
from pathlib import Path
input=json.loads(sys.stdin.read());sys.path.insert(0,input['capturedModules'])
from pg8000.native import Connection
observations=[];folder=Path(input['evidence']);source=Path(input['source']).read_text()
def connect():return Connection(user='postgres',unix_sock=input['unixSocket'],database='postgres',ssl_context=False,timeout=5)
def check(name,expected,observed):
 observations.append({'id':name,'expected':expected,'observed':observed})
 if type(expected) is not type(observed) or expected!=observed:raise AssertionError(name)
def image(con,label):
 rows=con.run(source);check(label+':one-original-result',True,len(rows)==1 and type(rows[0][0]) is str)
 b=rows[0][0].encode();(folder/(label+'.image.json')).write_bytes(b);return b
sha=lambda b:hashlib.sha256(b).hexdigest()
sections=re.findall("SELECT '([^']+)'::pg_catalog.text AS section",source)
# Explicit versioned view/aggregation expansion; no automatic interpretation.
names=sorted(set(sections)-{'pg_roles','foreign_routes'}|{'pg_authid','pg_foreign_data_wrapper','pg_foreign_server','pg_foreign_table','pg_user_mapping'})
lock='LOCK TABLE '+', '.join('pg_catalog.'+n for n in names)+' IN SHARE MODE'
(folder/'lock.sql').write_text(lock+';\n')
admin=connect();holder=connect();writer=connect()
try:
 check('exact-engine',[['160015']],admin.run("SELECT current_setting('server_version_num')::text"))
 admin.run("CREATE SCHEMA census_probe; CREATE TABLE census_probe.facts(value text); INSERT INTO census_probe.facts VALUES('original'); CREATE FUNCTION census_probe.value() RETURNS bigint LANGUAGE sql IMMUTABLE AS 'SELECT 1::bigint'; CREATE ROLE census_actor; CREATE ROLE census_group;")
 holder.run('BEGIN ISOLATION LEVEL READ COMMITTED');holder.run(lock)
 locks=holder.run("SELECT c.relname,l.mode,l.granted FROM pg_catalog.pg_locks l JOIN pg_catalog.pg_class c ON c.oid=l.relation WHERE l.pid=pg_catalog.pg_backend_pid() AND l.mode='ShareLock' ORDER BY c.relname")
 check('all-covered-catalog-locks',names,[r[0] for r in locks]);check('all-share-locks-granted',True,all(r[2] is True for r in locks))
 (folder/'locks.json').write_text(json.dumps(locks,indent=2)+'\n')
 baseline=image(holder,'held-baseline')
 actions=[('routine-body',"CREATE OR REPLACE FUNCTION census_probe.value() RETURNS bigint LANGUAGE sql IMMUTABLE AS 'SELECT 333::bigint'"),('role-membership','GRANT census_group TO census_actor'),('role-default',"ALTER ROLE census_actor SET search_path='census_probe'"),('owner','ALTER FUNCTION census_probe.value() OWNER TO census_actor'),('column','ALTER TABLE census_probe.facts ADD COLUMN hidden text'),('policy','CREATE POLICY census_policy ON census_probe.facts USING (true)'),('foreign-route','CREATE FOREIGN DATA WRAPPER census_foreign NO HANDLER')]
 writer.run("SET lock_timeout='150ms'")
 for name,sql in actions:
  try:writer.run(sql);code='unexpected-success'
  except Exception as error:
   detail=error.args[0] if error.args and type(error.args[0]) is dict else {};code=detail.get('C','unqualified-error')
  check(name+':native-lock-conflict','55P03',code)
 writer.run("UPDATE census_probe.facts SET value='changed'")
 check('ordinary-data-not-source-write',[['changed']],writer.run('SELECT value FROM census_probe.facts'))
 check('held-source-stable',sha(baseline),sha(image(holder,'held-after-blocked-writes')))
 check('held-native-execution',[[1]],holder.run('SELECT census_probe.value()'))
 holder.run('COMMIT');writer.run(actions[0][1]);check('write-after-release',[[333]],writer.run('SELECT census_probe.value()'))
 # Decisive counterexample: a held lock cannot refresh an old MVCC snapshot.
 writer.run("CREATE OR REPLACE FUNCTION census_probe.value() RETURNS bigint LANGUAGE sql IMMUTABLE AS 'SELECT 1::bigint'")
 holder.run('BEGIN ISOLATION LEVEL REPEATABLE READ');old=image(holder,'old-snapshot')
 writer.run(actions[0][1]);holder.run(lock)
 stale=image(holder,'old-snapshot-after-lock')
 check('stale-snapshot-survives-lock',sha(old),sha(stale))
 check('native-execution-sees-new-routine',[[333]],holder.run('SELECT census_probe.value()'))
 holder.run('COMMIT')
 holder.run('BEGIN ISOLATION LEVEL REPEATABLE READ');holder.run(lock)
 fresh=image(holder,'lock-before-first-snapshot');check('fresh-cut-detects-body-change',True,sha(fresh)!=sha(old))
 check('fresh-cut-native-execution',[[333]],holder.run('SELECT census_probe.value()'));holder.run('COMMIT')
 (folder/'native.json').write_text(json.dumps({'status':'component-passed','observations':observations,'catalogs':names,'scope':'Excluded administrative PostgreSQL16.15 catalog ShareLock feasibility and native stale-snapshot counterexample. Materialized pg8000 rows are not protected bounded original ingress. Same database, tested finite DDL set only; no all-writer/catalog/extension/runtime configuration completeness, provider authentication, final authority/data cut, cooperative handback or backend acceptance.'},indent=2)+'\n')
 print(json.dumps({'status':'component-passed','observations':len(observations)}))
except BaseException as error:
 (folder/'native-failure.json').write_text(json.dumps({'status':'failed','observations':observations,'error':str(error)},indent=2)+'\n');raise
finally:
 for con in (holder,writer,admin):con.close()
