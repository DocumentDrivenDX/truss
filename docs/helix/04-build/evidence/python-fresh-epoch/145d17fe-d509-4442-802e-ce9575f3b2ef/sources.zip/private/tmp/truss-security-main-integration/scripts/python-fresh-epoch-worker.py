"""Native original epoch projection component; no protected admission."""
import json,sys,threading,time,hashlib,struct
from pathlib import Path
config=json.loads(sys.stdin.read());sys.path.insert(0,config['capturedModules'])
from pg8000.native import Connection
from truss._native_pg8000 import NativeBoundary,NativeBoundaryRefusal
from truss._native_transactions import NativeTransactions
from truss._host_execution import HostExecutor
from truss._native_arbitration import NativeArbitration
from truss._operation_arbitration import Prepared
from truss.execution import Ok
from truss._native_fresh_epoch_capture import NativeFreshEpochCapture
folder=Path(config['evidence']);observations=[];threads=[];connections=[]
def connect(user='postgres'):
 c=Connection(user=user,database='postgres',unix_sock=config['unixSocket'],ssl_context=False,timeout=8);connections.append(c);return c
def check(name,expected,observed):
 observations.append({'id':name,'expected':expected,'observed':observed})
 if type(expected) is not type(observed) or expected!=observed:raise AssertionError(name)
def error_code(call):
 try:call();return 'unexpected-success'
 except Exception as error:return error.args[0].get('C','unknown') if error.args and type(error.args[0]) is dict else 'unknown'
query="SELECT * FROM truss.runtime_lock_fresh_source_epoch('component-test-installation',:epoch,:incarnation)"
admin=connect();reader=connect();writer=connect()
try:
 check('exact-engine',[['160015']],admin.run("SELECT current_setting('server_version_num')::text"))
 for name in ('layout','immutable','lock','issue','fresh'):
  admin.run(Path(config[name]).read_text())
 admin.run("INSERT INTO truss.installation_marker VALUES (1,'truss-bootstrap-marker/0.1.0','component-test-installation','component-only',decode(repeat('00',32),'hex'),'component',decode(repeat('00',32),'hex'),'owned-fixture','truss',now(),'component-clock-unqualified')")
 initial=admin.run("SELECT truss.runtime_issue_source_epoch('component-test-installation',NULL,'component-test-incarnation',decode('01','hex'),decode('0203','hex'))")[0][0]
 admin.run('CREATE ROLE fresh_epoch_ordinary LOGIN NOSUPERUSER NOBYPASSRLS; GRANT USAGE ON SCHEMA truss TO fresh_epoch_ordinary')
 ordinary=connect('fresh_epoch_ordinary')
 check('ungranted-ordinary-producer-refuses','42501',error_code(lambda:ordinary.run(query,epoch=initial,incarnation='component-test-incarnation')))
 reader.run('BEGIN ISOLATION LEVEL READ COMMITTED')
 native=reader.run("SELECT pg_current_xact_id()::text,(SELECT oid::text FROM pg_database WHERE datname=current_database()),pg_backend_pid()::text,session_user::text,current_user::text")[0]
 captured=reader.run(query,epoch=initial,incarnation='component-test-incarnation')
 expected=['component-test-installation',initial,'component-test-incarnation','01','0203',hashlib.sha256(bytes.fromhex('0203')).hexdigest(),*native,'transaction_source_epoch_lock_only']
 check('original-native-epoch-and-transaction-projection',[expected],captured)
 check('exact-ordered-text-columns',['installation_id','source_epoch','target_incarnation','profile_hex','evidence_hex','evidence_sha256','actual_writer_xid','actual_database_oid','actual_backend_pid','original_actor','effective_actor','cut_scope'],[c['name'] for c in reader.columns])
 writer.run("SET lock_timeout='150ms'")
 issue="SELECT truss.runtime_issue_source_epoch('component-test-installation',:prior,'component-test-incarnation',decode('01','hex'),decode('0405','hex'))"
 check('held-projection-blocks-participating-epoch-writer','55P03',error_code(lambda:writer.run(issue,prior=initial)))
 check('held-pointer-unchanged',[[initial]],admin.run('SELECT source_epoch FROM truss.source_epoch_current'))
 reader.run('COMMIT')
 successor=writer.run(issue,prior=initial)[0][0]
 check('release-permits-original-issuer',True,successor!=initial)
 # All bad calls run under a caller-owned savepoint; no epoch mutation follows.
 reader.run('BEGIN ISOLATION LEVEL READ COMMITTED')
 for label,epoch,incarnation in [('stale',initial,'component-test-incarnation'),('wrong-target',successor,'wrong'),('missing',None,'component-test-incarnation')]:
  reader.run('SAVEPOINT refusal')
  check(label+'-comparison-refuses','55000',error_code(lambda:reader.run(query,epoch=epoch,incarnation=incarnation)))
  reader.run('ROLLBACK TO SAVEPOINT refusal');reader.run('RELEASE SAVEPOINT refusal')
 check('refusals-leave-current-pointer',[[successor]],reader.run('SELECT source_epoch FROM truss.source_epoch_current'));reader.run('COMMIT')
 for level in ('REPEATABLE READ','SERIALIZABLE'):
  reader.run('BEGIN ISOLATION LEVEL '+level);reader.run('SELECT source_epoch FROM truss.source_epoch_current')
  check(level+'-inherited-snapshot-refuses','55000',error_code(lambda:reader.run(query,epoch=successor,incarnation='component-test-incarnation')));reader.run('ROLLBACK')
 reader.run('BEGIN READ ONLY')
 check('read-only-lock-profile-refuses','55000',error_code(lambda:reader.run(query,epoch=successor,incarnation='component-test-incarnation')));reader.run('ROLLBACK')
 # Pending original issuer update precedes reader acquisition. Native tuple/xid
 # wait must drain before the VOLATILE helper observes its committed registry.
 writer.run('BEGIN');pending=writer.run(issue,prior=successor)[0][0]
 reader.run('BEGIN ISOLATION LEVEL READ COMMITTED');pid=reader.run('SELECT pg_backend_pid()')[0][0]
 result=[];errors=[]
 def acquire():
  try:result.extend(reader.run(query,epoch=pending,incarnation='component-test-incarnation'))
  except Exception as e:errors.append(str(e))
 thread=threading.Thread(target=acquire);threads.append(thread);thread.start();deadline=time.monotonic()+4
 while not admin.run('SELECT :writer=ANY(pg_blocking_pids(:reader))',writer=writer.run('SELECT pg_backend_pid()')[0][0],reader=pid)[0][0]:
  if time.monotonic()>deadline:raise TimeoutError('Exact epoch writer blocker not observed')
  time.sleep(.01)
 check('pending-issuer-blocks-reader',True,thread.is_alive());writer.run('COMMIT');thread.join(8)
 check('drain-settles-reader',False,thread.is_alive());check('drain-no-driver-error',[],errors)
 check('post-drain-original-committed-epoch',pending,result[0][1]);check('post-drain-evidence','0405',result[0][4])
 check('post-drain-native-binding',True,result[0][8]==str(pid) and result[0][-1]=='transaction_source_epoch_lock_only')
 reader.run('COMMIT')
 # Response identity is not a durable capability: autocommit already released.
 auto=reader.run(query,epoch=pending,incarnation='component-test-incarnation')
 check('autocommit-response-is-idle','49',reader._transaction_status.hex())
 after_auto=writer.run(issue,prior=pending)[0][0]
 check('autocommit-return-does-not-hold-epoch',True,after_auto!=pending)
 reader.run('BEGIN ISOLATION LEVEL READ COMMITTED');reader.run('SAVEPOINT before_lock')
 saved=reader.run(query,epoch=after_auto,incarnation='component-test-incarnation')[0]
 reader.run('ROLLBACK TO SAVEPOINT before_lock')
 check('savepoint-rollback-keeps-parent-xid',[[saved[6]]],reader.run('SELECT pg_current_xact_id()::text'))
 after_savepoint=writer.run(issue,prior=after_auto)[0][0]
 check('savepoint-rollback-releases-epoch-lock',True,after_savepoint!=after_auto)
 reader.run('RELEASE SAVEPOINT before_lock');reader.run('COMMIT')
 reader.run('BEGIN ISOLATION LEVEL READ COMMITTED')
 owned=reader.run(query,epoch=after_savepoint,incarnation='component-test-incarnation')[0]
 after_same=reader.run(issue,prior=after_savepoint)[0][0]
 check('same-parent-writer-can-change-epoch',True,after_same!=after_savepoint)
 check('same-parent-writer-xid-unchanged',[[owned[6]]],reader.run('SELECT pg_current_xact_id()::text'))
 reader.run('ROLLBACK');pending=after_savepoint
 # A definer wrapper cannot manufacture original invoker correspondence.
 admin.run("CREATE ROLE fresh_epoch_definer; GRANT USAGE ON SCHEMA truss TO fresh_epoch_definer; GRANT EXECUTE ON FUNCTION truss.runtime_lock_fresh_source_epoch(text,text,text) TO fresh_epoch_definer; CREATE FUNCTION truss.fresh_epoch_definer_probe() RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog AS $$ SELECT cut_scope FROM truss.runtime_lock_fresh_source_epoch('component-test-installation', '"+pending+"', 'component-test-incarnation') $$; ALTER FUNCTION truss.fresh_epoch_definer_probe() OWNER TO fresh_epoch_definer")
 check('definer-invoker-elevation-refuses','55000',error_code(lambda:admin.run('SELECT truss.fresh_epoch_definer_probe()')))
 # Same installed helper through original operation/ingress/outbound custody.
 for label,lost in [('original-capture',False),('lost-local-reply',True)]:
  con=connect();gate=None
  try:
   boundary=NativeBoundary(con);tracker=NativeTransactions(boundary)
   tracker.begin(isolation='read_committed',access_mode='read_write');token=boundary.acquire_operation()
   port=tracker.port(token);executor=HostExecutor();adopted=executor.adopt_transaction(port,isolation='read_committed',access_mode='read_write')
   check(label+':original-adoption',True,type(adopted) is Ok)
   service=NativeArbitration(executor);assembly=object();check(label+':registered','registered',service.registry.register(assembly))
   prepared=service.registry.prepare(assembly,adopted.value);check(label+':original-attempt',True,type(prepared) is Prepared)
   session=service.bind(prepared.attempt);gate=NativeFreshEpochCapture(session,'component-test-installation',pending,'component-test-incarnation')
   if lost:
    publish=gate._publish
    def lose(observation):publish(observation);raise MemoryError('Lost local epoch reply')
    gate._publish=lose
   try:returned=gate.capture()
   except MemoryError:returned=None
   retained=gate.original_observation
   check(label+':closed-admission',True,session.admission_closed)
   check(label+':retained-native-result',True,retained is not None and retained.original_call is boundary.last_call and session.calls[-1].native_call is retained.original_call)
   check(label+':published-or-retained',True,(returned is retained) if not lost else returned is None)
   check(label+':response-only-scope','original_epoch_response_only',retained.scope)
   check(label+':original-epoch',pending,retained.original_row[1])
   check(label+':original-outbound-q',b'Q'+struct.pack('!I',len(gate.sql.encode())+5)+gate.sql.encode()+b'\0',retained.original_request)
   raw=b''.join(e.code+struct.pack('!I',len(e.payload)+4)+e.payload for e in retained.original_call.events)
   (folder/(label+'.response.bin')).write_bytes(raw);(folder/(label+'.request.bin')).write_bytes(retained.original_request)
   (folder/(label+'.row.json')).write_text(json.dumps(retained.original_row)+'\n')
   prior=boundary.last_call
   check(label+':replay-refuses','unknown',error_code(lambda:gate.capture()))
   check(label+':replay-no-native-call',True,boundary.last_call is prior)
   check(label+':actual-epoch-lock-blocks-writer','55P03',error_code(lambda:writer.run(issue,prior=pending)))
   gate.detach();check(label+':retained-after-detach',True,gate.original_observation is retained and con._sock is boundary._original_stream)
  finally:
   if gate is not None and not gate.detached:con._sock=gate.original_sock
   con.close()
 (folder/'native.json').write_text(json.dumps({'status':'component-passed','observations':observations,'scope':'Original source-epoch SQL projection in owned PostgreSQL16.15, original issuer lineage, native RC/read-write gate, pending issuer drain and transaction-bound row lock. Installer-authored synthetic marker/profile/evidence are not admitted artifacts. Materialized administrative pg8000 results are not bounded original NativeCall ingress. No authenticated provider, full source/authority/data writer closure, complete protected business execution/final host disclosure, final handback or backend acceptance.'},indent=2)+'\n')
 print(json.dumps({'status':'component-passed','observations':len(observations)}))
except BaseException as e:
 (folder/'native-failure.json').write_text(json.dumps({'status':'failed','observations':observations,'error':str(e)},indent=2)+'\n');raise
finally:
 writer.close()
 for thread in threads:thread.join(8)
 for connection in reversed(connections):
  if connection is not writer:connection.close()
